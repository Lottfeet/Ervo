import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Product, 
  Customer, 
  InvoiceItem, 
  StoreSettings, 
  Invoice, 
  ViewTab,
  MainViewTab,
  KasirUser,
  CheckpointPayload
} from './types';
import { 
  fetchProducts, 
  fetchCustomers, 
  fetchKasirList, 
  fetchKasirUsers,
  fetchSheetSettings, 
  fetchStockInHistory,
  getNextInvoiceNumber, 
  saveTransaction,
  addRecentInvoiceToLocal,
  deleteCustomer,
  deleteProduct,
  fetchAllDataBatch,
  getLocalProducts,
  getLocalCustomers,
  getLocalKasirUsers,
  getLocalSettings,
  getLocalStockInHistory,
  getSheetUrl,
  setSheetUrl
} from './services/gasService';
import {
  subscribeProducts,
  subscribeCustomers,
  subscribeKasirUsers,
  subscribeSettings,
  saveSettingsFirebase,
  subscribeInvoices,
  subscribeDeletedInvoices,
  saveInvoiceFirebase,
  getNextInvoiceNumberFirebase,
  deleteCustomerFirebase,
  deleteProductFirebase,
  subscribeDeletedProducts,
  isFirestoreQuotaExceeded,
  resetFirestoreQuotaSession,
  subscribeVendors,
  subscribeStockIn,
  subscribeExpenses,
  subscribeDeletedExpenses,
  fetchAllDataFromFirebase,
  startAutoSyncEngine
} from './services/firebaseService';
import { fRp, fDate, fTime, fDateInput, formatDateFromInput, computeItemTotal, INITIAL_PRODUCTS, INITIAL_CUSTOMERS, compareInvoicesDesc } from './utils/formatters';
import { generateThermalHTML, generateA5HTML, openPrintWindow } from './utils/printUtils';

import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SidebarNav } from './components/SidebarNav';
import { ProductCatalog } from './components/ProductCatalog';
import { SpecModal } from './components/SpecModal';
import { OrderCart } from './components/OrderCart';
import { ReceiptPreview } from './components/ReceiptPreview';
import { PelunasanModal } from './components/PelunasanModal';
import { ReprintModal } from './components/ReprintModal';
import { SettingsModal } from './components/SettingsModal';
import { ImportModal } from './components/ImportModal';
import { AddCustomerModal } from './components/AddCustomerModal';
import { GasSetupGuideModal } from './components/GasSetupGuideModal';
import { LoginScreen } from './components/LoginScreen';
import { BarangMasukView } from './components/BarangMasukView';
import { VendorView } from './components/VendorView';
import { LaporanView } from './components/LaporanView';
import { PelangganView } from './components/PelangganView';
import { DashboardView } from './components/DashboardView';
import { BackupCheckpointModal } from './components/BackupCheckpointModal';
import { create3LayerCheckpoint, scheduleDebouncedAutoCheckpoint, getAutoCheckpointConfig } from './services/backupService';
import { getStoredExpenses, saveExpenses } from './services/expenseService';
import { getStoredVendors, saveVendorsLocally } from './services/vendorService';
import { getStoredStockOpnames } from './services/firebaseService';
import { syncCashierTransactionToPayroll } from './services/payrollSyncService';
import { AlertTriangle, ExternalLink, RefreshCw, X } from 'lucide-react';

export default function App() {
  // Navigation State
  const [mainViewTab, setMainViewTab] = useState<MainViewTab>('dashboard');
  const [activeTab, setActiveTab] = useState<ViewTab>('catalog');

  // Master Data & User Authentication State
  const [products, setProducts] = useState<Product[]>(() => getLocalProducts());
  const [customers, setCustomers] = useState<Customer[]>(() => getLocalCustomers());
  const [kasirUsers, setKasirUsers] = useState<KasirUser[]>(() => getLocalKasirUsers());
  const [kasirList, setKasirList] = useState<string[]>(() => getLocalKasirUsers().map((u) => u.nama));
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem('strukku_logged_kasir') || null;
  });

  const [settings, setSettings] = useState<StoreSettings>(() => {
    let base: StoreSettings = {
      name: 'ERVO PRINT',
      address: 'Jl. HOS Cokroaminoto No.17, Ciamis',
      phone: '0812-2247-2007',
      footer: 'Terima Kasih Atas Kunjungan Anda',
      rekening: '',
      autoLogoutMinutes: 15,
      cashier: localStorage.getItem('strukku_logged_kasir') || 'Admin',
      prefixInvoice: 'ERV',
    };

    try {
      const sheetCfg = localStorage.getItem('strukku_sheet_settings');
      if (sheetCfg) {
        const p = JSON.parse(sheetCfg);
        if (p.name) base.name = p.name;
        if (p.address) base.address = p.address;
        if (p.phone) base.phone = p.phone;
        if (p.footer) base.footer = p.footer;
        if (p.rekening) base.rekening = p.rekening;
        if (p.prefixInvoice) base.prefixInvoice = p.prefixInvoice;
      }
      const localCfg = localStorage.getItem('strukku_settings');
      if (localCfg) {
        const p = JSON.parse(localCfg);
        if (p.name) base.name = p.name;
        if (p.address) base.address = p.address;
        if (p.phone) base.phone = p.phone;
        if (p.footer) base.footer = p.footer;
        if (p.rekening) base.rekening = p.rekening;
        if (p.autoLogoutMinutes) base.autoLogoutMinutes = p.autoLogoutMinutes;
      }
    } catch {}

    return base;
  });

  // Sync State
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  // Active Transaction State
  const [invoiceNo, setInvoiceNo] = useState<string>('Memuat...');
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [orderDate, setOrderDate] = useState<string>(fDateInput(new Date()));
  const [deadlineDate, setDeadlineDate] = useState<string>('');
  const [discountPct, setDiscountPct] = useState<number>(0);
  const [taxPct, setTaxPct] = useState<number>(0);
  const [negoAmt, setNegoAmt] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<string>('Tunai');
  const [dpAmount, setDpAmount] = useState<number | string>('');
  const [isTransactionSaved, setIsTransactionSaved] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Modal Dialog Controls
  const [specProduct, setSpecProduct] = useState<Product | null>(null);
  const [isSpecModalOpen, setIsSpecModalOpen] = useState<boolean>(false);
  const [selectedRestockProduct, setSelectedRestockProduct] = useState<Product | null>(null);
  const [selectedVendorForPo, setSelectedVendorForPo] = useState<string | null>(null);
  const [isPelunasanOpen, setIsPelunasanOpen] = useState<boolean>(false);
  const [isReprintOpen, setIsReprintOpen] = useState<boolean>(false);
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isGasGuideOpen, setIsGasGuideOpen] = useState<boolean>(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState<boolean>(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState<boolean>(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const transactionsSinceCheckpointRef = React.useRef<number>(0);

  // Handle when new customer is added or updated
  const handleCustomerAdded = (newCust: Customer) => {
    setCustomers((prev) => {
      let filtered = prev;
      if (customerToEdit && customerToEdit.nama.trim().toLowerCase() !== newCust.nama.trim().toLowerCase()) {
        filtered = filtered.filter((c) => c.nama.trim().toLowerCase() !== customerToEdit.nama.trim().toLowerCase());
      }
      const idx = filtered.findIndex((c) => c.nama.trim().toLowerCase() === newCust.nama.trim().toLowerCase());
      if (idx >= 0) {
        const updated = [...filtered];
        updated[idx] = newCust;
        return updated;
      }
      return [...filtered, newCust];
    });
    setCustomerToEdit(null);
    setSelectedCustomer(newCust.nama);
    if (newCust.diskon) {
      setDiscountPct(newCust.diskon);
    }
  };

  // Toast Banner State
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [quotaAlert, setQuotaAlert] = useState<boolean>(() => isFirestoreQuotaExceeded());

  useEffect(() => {
    const handleQuota = () => setQuotaAlert(true);
    const handleMetric = (e: any) => {
      if (e?.detail && e.detail.quotaExceeded === false) {
        setQuotaAlert(false);
      }
    };
    window.addEventListener('firestore-quota-exceeded', handleQuota);
    window.addEventListener('firestore-quota-metric-updated', handleMetric);
    return () => {
      window.removeEventListener('firestore-quota-exceeded', handleQuota);
      window.removeEventListener('firestore-quota-metric-updated', handleMetric);
    };
  }, []);

  const showToast = useCallback((msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ msg, type });
    setTimeout(() => {
      setToast((prev) => (prev?.msg === msg ? null : prev));
    }, 3500);
  }, []);

  // Fetch Central Invoice Number
  const loadNewInvoiceNumber = useCallback(async () => {
    setInvoiceNo('Memuat...');
    try {
      const num = await getNextInvoiceNumberFirebase(settings.prefixInvoice || 'INV');
      setInvoiceNo(num);
    } catch {
      const num = await getNextInvoiceNumber();
      setInvoiceNo(num);
    }
    setIsTransactionSaved(false);
  }, [settings.prefixInvoice]);

  // Real-Time Data Synchronization with Google Sheets & Firebase
  const handleSyncData = useCallback(async () => {
    setIsSyncing(true);
    let ok = false;

    try {
      const batch = await fetchAllDataBatch();

      if (batch.products && batch.products.length > 0) setProducts(batch.products);
      if (batch.customers && batch.customers.length > 0) setCustomers(batch.customers);
      if (batch.kasirUsers && batch.kasirUsers.length > 0) {
        setKasirUsers(batch.kasirUsers);
        setKasirList(batch.kasirUsers.map((u) => u.nama));
      }
      if (batch.settings) {
        setSettings((prev) => ({
          ...prev,
          ...batch.settings,
          cashier: localStorage.getItem('strukku_logged_kasir') || prev.cashier || batch.settings.cashier || 'Admin',
          rekening: (batch.settings?.rekening && batch.settings.rekening.trim()) ? batch.settings.rekening : (prev.rekening || ''),
        }));
      }
      if (batch.nextInvoiceNo) {
        setInvoiceNo(batch.nextInvoiceNo);
      }

      const syncTimeString = fTime(new Date());
      setLastSyncTime(syncTimeString);
      setIsConnected(true);
      ok = true;
    } catch (err) {
      console.warn('Sync failed:', err);
      setIsConnected(false);
    } finally {
      setIsSyncing(false);
    }

    return ok;
  }, []);

  // Realtime Firebase Listeners Setup
  useEffect(() => {
    const unsubProducts = subscribeProducts((list) => {
      if (list.length > 0) setProducts(list);
    });

    const handleLocalProductsUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail) && e.detail.length > 0) {
        setProducts(e.detail);
      }
    };
    window.addEventListener('strukku-products-updated', handleLocalProductsUpdated);

    const unsubCustomers = subscribeCustomers((list) => {
      setCustomers(list);
    });

    const unsubKasir = subscribeKasirUsers((list) => {
      if (list.length > 0) {
        setKasirUsers(list);
        setKasirList(list.map((u) => u.nama));
      }
    });

    const unsubSettings = subscribeSettings((cfg) => {
      setSettings((prev) => ({
        ...prev,
        ...cfg,
        cashier: localStorage.getItem('strukku_logged_kasir') || prev.cashier || cfg.cashier || 'Admin',
      }));
    });

    const unsubInvoices = subscribeInvoices((invList) => {
      setAllInvoices(invList);
    });

    const unsubDeletedInvoices = subscribeDeletedInvoices((deletedList) => {
      const delSet = new Set(deletedList.map((s) => s.trim().toLowerCase()));
      setAllInvoices((prev) => prev.filter((it) => it.invoiceNo && !delSet.has(it.invoiceNo.trim().toLowerCase())));
    });

    const unsubDeletedProducts = subscribeDeletedProducts((deletedList) => {
      setProducts((prev) =>
        prev.filter((p) => {
          return !deletedList.some(
            (d) =>
              (d.kode && p.kode && d.kode.trim().toLowerCase() === p.kode.trim().toLowerCase()) ||
              (d.nama && p.nama && d.nama.trim().toLowerCase() === p.nama.trim().toLowerCase())
          );
        })
      );
    });

    const unsubVendors = subscribeVendors((vendorList) => {
      if (vendorList && vendorList.length > 0) {
        saveVendorsLocally(vendorList);
        window.dispatchEvent(new CustomEvent('strukku-vendors-updated'));
      }
    });

    const unsubStockIn = subscribeStockIn((stockInList) => {
      if (stockInList && stockInList.length > 0) {
        localStorage.setItem('strukku_stock_in_history', JSON.stringify(stockInList));
      }
    });

    const unsubExpenses = subscribeExpenses((expenseList) => {
      if (expenseList && expenseList.length > 0) {
        saveExpenses(expenseList);
        window.dispatchEvent(new CustomEvent('strukku-expenses-updated'));
      }
    });

    const unsubDeletedExpenses = subscribeDeletedExpenses((delList) => {
      if (delList && delList.length >= 0) {
        window.dispatchEvent(new CustomEvent('strukku-expenses-updated'));
      }
    });

    return () => {
      unsubProducts();
      window.removeEventListener('strukku-products-updated', handleLocalProductsUpdated);
      unsubCustomers();
      unsubKasir();
      unsubSettings();
      unsubInvoices();
      unsubDeletedInvoices();
      unsubDeletedProducts();
      unsubVendors();
      unsubStockIn();
      unsubExpenses();
      unsubDeletedExpenses();
    };
  }, []);

  // 3-Layer Auto-Checkpoint Timer Engine (Runs background check every 60s)
  useEffect(() => {
    const timer = setInterval(() => {
      const cfg = getAutoCheckpointConfig();
      if (!cfg.enabled || !cfg.intervalMinutes) return;
      if (products.length === 0) return;

      const lastTime = cfg.lastCheckpointTime ? new Date(cfg.lastCheckpointTime).getTime() : 0;
      const now = Date.now();
      const intervalMs = cfg.intervalMinutes * 60 * 1000;

      if (now - lastTime >= intervalMs) {
        create3LayerCheckpoint({
          trigger: 'AUTO_TIMER',
          label: `Auto Checkpoint Rutin (Tiap ${cfg.intervalMinutes} Menit)`,
          operator: 'Sistem (Timer Rutin)',
          data: {
            products,
            customers,
            invoices: allInvoices,
            expenses: getStoredExpenses(),
            stockIn: getLocalStockInHistory(),
            stockOpnames: getStoredStockOpnames(),
            kasirUsers,
            settings,
            vendors: getStoredVendors(),
          },
        }).then((cp) => {
          console.log('✓ Auto Checkpoint (Timer 3-Lapis) created:', cp.id);
        }).catch((err) => {
          console.warn('Auto Checkpoint (Timer) failed:', err);
        });
      }
    }, 60 * 1000);

    return () => clearInterval(timer);
  }, [products, customers, allInvoices, kasirUsers, settings]);

  // Background Auto Re-Sync Pasca Limit & Offline Recovery
  useEffect(() => {
    const stopAutoSync = startAutoSyncEngine((msg, type) => {
      showToast(msg, type || 'info');
    });
    return stopAutoSync;
  }, [showToast]);

  // Trigger 3-Layer Auto-Checkpoint on new transaction using aggressive debouncing & dirty state checking
  const triggerAutoCheckpointOnTransaction = useCallback((newInvoice?: Invoice) => {
    transactionsSinceCheckpointRef.current += 1;
    const cfg = getAutoCheckpointConfig();
    if (!cfg.enabled || !cfg.triggerOnTransactionsCount || cfg.triggerOnTransactionsCount <= 0) return;

    if (transactionsSinceCheckpointRef.current >= cfg.triggerOnTransactionsCount) {
      transactionsSinceCheckpointRef.current = 0;
      
      const updatedInvoices = newInvoice
        ? [newInvoice, ...allInvoices.filter(i => (i.invoiceNo || i.noInvoice) !== (newInvoice.invoiceNo || newInvoice.noInvoice))]
        : allInvoices;

      // Coalesce rapid transaction bursts with a 15-second debounce delay
      scheduleDebouncedAutoCheckpoint({
        trigger: 'AUTO_TRANSACTION',
        label: `Auto: Pasca ${cfg.triggerOnTransactionsCount} Transaksi (${newInvoice?.noInvoice || newInvoice?.invoiceNo || 'Order'})`,
        operator: currentUser || 'Kasir',
        data: {
          products,
          customers,
          invoices: updatedInvoices,
          expenses: getStoredExpenses(),
          stockIn: getLocalStockInHistory(),
          stockOpnames: getStoredStockOpnames(),
          kasirUsers,
          settings,
          vendors: getStoredVendors(),
        },
      }, 15000);
    }
  }, [allInvoices, products, customers, kasirUsers, settings, currentUser]);

  // Handle restored payload from backup / checkpoint
  const handleRestorePayload = useCallback((payload: CheckpointPayload) => {
    if (payload.invoices && Array.isArray(payload.invoices)) {
      const formattedInvoices: Invoice[] = payload.invoices.map((inv: any) => {
        const invNo = (inv.invoiceNo || inv.noInvoice || '').trim();
        const method = inv.payMethod || inv.metodePembayaran || 'Tunai';
        return {
          invoiceNo: invNo,
          noInvoice: invNo,
          date: inv.date || inv.tanggal || '',
          time: inv.time || inv.jam || '',
          customer: inv.customer || inv.pelanggan || 'Umum',
          cashier: inv.cashier || inv.kasir || 'Admin',
          payMethod: method,
          metodePembayaran: method,
          subtotal: Number(inv.subtotal || inv.total || 0),
          discPct: Number(inv.discPct || inv.diskonPct || 0),
          discAmt: Number(inv.discAmt || inv.diskonNominal || 0),
          taxPct: Number(inv.taxPct || inv.pajakPct || 0),
          taxAmt: Number(inv.taxAmt || inv.pajakNominal || 0),
          negoAmt: Number(inv.negoAmt || inv.negoNominal || 0),
          total: Number(inv.total || 0),
          dp: Number(inv.dp || inv.bayarDp || 0),
          sisa: Number(inv.sisa || inv.sisaPiutang || 0),
          kembalian: Number(inv.kembalian || 0),
          deadline: inv.deadline || '',
          status: inv.status || (Number(inv.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
          items: Array.isArray(inv.items) ? inv.items : [],
          pelunasanHistory: Array.isArray(inv.pelunasanHistory) ? inv.pelunasanHistory : (Array.isArray(inv.historiPelunasan) ? inv.historiPelunasan : []),
        };
      });
      formattedInvoices.sort(compareInvoicesDesc);
      setAllInvoices(formattedInvoices);
    }
    if (payload.products && Array.isArray(payload.products)) {
      setProducts(payload.products);
    }
    if (payload.customers && Array.isArray(payload.customers)) {
      setCustomers(payload.customers);
    }
    if (payload.kasirUsers && Array.isArray(payload.kasirUsers)) {
      setKasirUsers(payload.kasirUsers);
      setKasirList(payload.kasirUsers.map((u) => u.nama));
    }
    if (payload.vendors && Array.isArray(payload.vendors)) {
      saveVendorsLocally(payload.vendors);
      window.dispatchEvent(new CustomEvent('strukku-vendors-updated'));
    }
    if (payload.expenses && Array.isArray(payload.expenses)) {
      saveExpenses(payload.expenses);
    }
    if (payload.settings) {
      setSettings((prev) => ({ ...prev, ...payload.settings }));
    }
    const restoredSheetUrl = (payload.sheetUrl || (payload.settings as any)?.sheetUrl || '').trim();
    if (restoredSheetUrl) {
      setSheetUrl(restoredSheetUrl);
      setIsConnected(true);
    }
  }, []);

  // Listen for broadcast restore event
  useEffect(() => {
    const handleBackupEvent = (e: any) => {
      if (e.detail) {
        handleRestorePayload(e.detail);
      }
    };
    window.addEventListener('strukku-backup-restored', handleBackupEvent);
    return () => window.removeEventListener('strukku-backup-restored', handleBackupEvent);
  }, [handleRestorePayload]);

  // Ref for tracking last user activity / interaction timestamp
  const lastActivityRef = React.useRef<number>(Date.now());

  const touchActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
  }, []);

  // User Auth Handlers
  const handleLogout = useCallback((reason?: string | React.MouseEvent) => {
    localStorage.removeItem('strukku_logged_kasir');
    setCurrentUser(null);
    showToast(typeof reason === 'string' ? reason : 'Anda telah keluar dari akun kasir', 'info');
  }, [showToast]);

  const handleLoginSuccess = (kasirName: string) => {
    localStorage.setItem('strukku_logged_kasir', kasirName);
    setCurrentUser(kasirName);
    setSettings((prev) => ({ ...prev, cashier: kasirName }));
    lastActivityRef.current = Date.now();
  };

  // On App Mount & 10-Minute Periodic Background Sync
  useEffect(() => {
    handleSyncData();
    loadNewInvoiceNumber();

    // Load local device settings if present
    const localSetting = localStorage.getItem('strukku_settings');
    if (localSetting) {
      try {
        const parsed = JSON.parse(localSetting);
        setSettings((prev) => ({
          ...prev,
          ...(parsed.cashier ? { cashier: parsed.cashier } : {}),
          ...(typeof parsed.autoLogoutMinutes === 'number' ? { autoLogoutMinutes: parsed.autoLogoutMinutes } : {}),
          ...(parsed.rekening ? { rekening: parsed.rekening } : {}),
        }));
      } catch {}
    }

    // Auto Background Sync Every 10 Minutes (10 * 60 * 1000 = 600,000 ms)
    const intervalId = setInterval(() => {
      handleSyncData();
    }, 10 * 60 * 1000);

    return () => clearInterval(intervalId);
  }, [handleSyncData, loadNewInvoiceNumber]);

  // Inactivity & Auto Logout Watcher
  useEffect(() => {
    if (!currentUser) return;

    // Reset timestamp on user activity events
    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'];
    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    events.forEach((evt) => window.addEventListener(evt, handleUserActivity, { passive: true }));

    const logoutMinutes = settings.autoLogoutMinutes ?? 15;

    const checkInterval = setInterval(() => {
      if (logoutMinutes <= 0) return; // 0 = disabled

      const inactiveMs = Date.now() - lastActivityRef.current;
      const limitMs = logoutMinutes * 60 * 1000;

      if (inactiveMs >= limitMs) {
        handleLogout(`Sesi kasir berakhir otomatis karena tidak ada aktivitas selama ${logoutMinutes} menit`);
      }
    }, 10000); // Check every 10 seconds

    return () => {
      events.forEach((evt) => window.removeEventListener(evt, handleUserActivity));
      clearInterval(checkInterval);
    };
  }, [currentUser, settings.autoLogoutMinutes, handleLogout]);

  // Handle Item Spec Modal Confirmation
  const handleConfirmSpecItem = (newItem: InvoiceItem) => {
    setInvoiceItems((prev) => [...prev, newItem]);
    setIsSpecModalOpen(false);
    showToast(`"${newItem.nama}" ditambahkan ke order`, 'success');
  };

  // Stepper Qty Update
  const handleUpdateQty = (index: number, delta: number) => {
    setInvoiceItems((prev) => {
      const updated = [...prev];
      const cur = updated[index];
      const curQty = typeof cur.qty === 'number' ? cur.qty : parseFloat(String(cur.qty).replace(',', '.')) || 1;
      let effectiveDelta = delta;
      if (curQty < 1 && Math.abs(delta) === 1) {
        effectiveDelta = delta > 0 ? 0.1 : -0.1;
      }
      const newQty = Math.max(0.01, parseFloat((curQty + effectiveDelta).toFixed(2)));
      updated[index] = {
        ...cur,
        qty: newQty,
        totalItem: computeItemTotal({ ...cur, qty: newQty }),
      };
      return updated;
    });
  };

  // Direct Qty Set (e.g. typed 0.1)
  const handleSetQty = (index: number, newQtyVal: number | string) => {
    const parsed = typeof newQtyVal === 'number' ? newQtyVal : parseFloat(String(newQtyVal).replace(',', '.'));
    if (isNaN(parsed) || parsed <= 0) return;
    setInvoiceItems((prev) => {
      const updated = [...prev];
      const cur = updated[index];
      updated[index] = {
        ...cur,
        qty: parsed,
        totalItem: computeItemTotal({ ...cur, qty: parsed }),
      };
      return updated;
    });
  };

  // Remove Item
  const handleRemoveItem = (index: number) => {
    setInvoiceItems((prev) => prev.filter((_, i) => i !== index));
    showToast('Item dihapus dari order', 'info');
  };

  // Delete Customer
  const handleDeleteCustomer = async (cName: string) => {
    deleteCustomerFirebase(cName).catch(() => {});
    const res = await deleteCustomer(cName);
    setCustomers((prev) => prev.filter((c) => c.nama.trim().toLowerCase() !== cName.trim().toLowerCase()));
    showToast(res.message, 'success');
  };

  // Delete Product (Khusus Owner & SPV)
  const handleDeleteProduct = async (kode: string, nama: string, authorizedBy?: string) => {
    deleteProductFirebase(kode, nama).catch(() => {});
    const res = await deleteProduct(kode, nama);
    setProducts((prev) =>
      prev.filter((p) => {
        const matchKode = kode && p.kode && p.kode.trim().toLowerCase() === kode.trim().toLowerCase();
        const matchNama = nama && p.nama && p.nama.trim().toLowerCase() === nama.trim().toLowerCase();
        return !(matchKode || matchNama);
      })
    );
    const authNote = authorizedBy ? ` [Otorisator: ${authorizedBy}]` : '';
    showToast(`${res.message}${authNote}`, 'success');
  };

  // Reset to New Order
  const handleNewOrder = async () => {
    setInvoiceItems([]);
    setSelectedCustomer('');
    setDiscountPct(0);
    setNegoAmt(0);
    setTaxPct(0);
    setDpAmount('');
    setPayMethod('Tunai');
    setOrderDate(fDateInput(new Date()));
    setDeadlineDate('');
    await loadNewInvoiceNumber();
    showToast('Order baru dibuat', 'info');
  };

  // Compute Current Invoice Calculations
  const subtotal = invoiceItems.reduce((s, i) => s + computeItemTotal(i), 0);
  const discAmt = (subtotal * discountPct) / 100;
  const afterDisc = Math.max(0, subtotal - discAmt - negoAmt);
  const taxAmt = (afterDisc * taxPct) / 100;
  const total = Math.max(0, afterDisc) + taxAmt;

  const dp = typeof dpAmount === 'number' ? dpAmount : parseFloat(String(dpAmount).replace(',', '.')) || 0;
  const sisa = Math.max(0, total - dp);
  const kembalian = dp > total ? dp - total : 0;

  const selectedCustClean = (selectedCustomer || '').trim().toLowerCase();
  const selectedCustObj = customers.find(
    (c) => Boolean(c?.nama && c.nama.trim().toLowerCase() === selectedCustClean)
  );

  const activeCashierName = currentUser || localStorage.getItem('strukku_logged_kasir') || settings.cashier || 'Admin';

  const effectiveSettings = useMemo(() => ({
    ...settings,
    cashier: activeCashierName,
  }), [settings, activeCashierName]);

  const currentInvoiceData: Partial<Invoice> = {
    invoiceNo,
    date: fDate(new Date()),
    time: fTime(new Date()),
    customer: (selectedCustomer || '').trim(),
    customerPhone: selectedCustObj ? selectedCustObj.telepon : '',
    customerAddress: selectedCustObj ? selectedCustObj.alamat : '',
    cashier: activeCashierName,
    kasir: activeCashierName,
    operator: activeCashierName,
    subtotal,
    discPct: discountPct,
    discAmt,
    taxPct,
    taxAmt,
    negoAmt,
    total,
    payMethod: dp > 0 ? (payMethod || 'Tunai') : 'Belum Bayar',
    dp,
    sisa,
    kembalian,
    deadline: deadlineDate ? formatDateFromInput(deadlineDate) : '',
    status: sisa > 0 ? (dp > 0 ? 'DP' : 'BELUM BAYAR') : 'LUNAS',
    items: invoiceItems,
  };

  // Save Transaction to Google Sheets & Firebase
  const saveTransactionToSheets = async () => {
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return false;
    }
    if (isTransactionSaved) return true;

    setIsSaving(true);
    const activeMethod = dp > 0 ? (payMethod || 'Tunai') : 'Belum Bayar';
    const payload: any = {
      ...currentInvoiceData,
      noInvoice: currentInvoiceData.invoiceNo || invoiceNo,
      tanggal: currentInvoiceData.date || fDate(new Date()),
      jam: currentInvoiceData.time || fTime(new Date()),
      pelanggan: selectedCustomer.trim(),
      cashier: activeCashierName,
      kasir: activeCashierName,
      operator: activeCashierName,
      payMethod: activeMethod,
      metodePembayaran: activeMethod,
      deadline: deadlineDate ? formatDateFromInput(deadlineDate) : '',
      items: invoiceItems.map((i) => ({
        ...i,
        totalItem: computeItemTotal(i),
      })),
    };

    // Update local cache instantly
    addRecentInvoiceToLocal(payload);

    // Save to Firebase Firestore instantly
    saveInvoiceFirebase(payload as Invoice).catch((err) => {
      console.warn('Firebase saveInvoice failed:', err);
    });

    // Save copy to ERVO Payroll Cloud Firestore instantly (non-blocking)
    syncCashierTransactionToPayroll(payload).catch((err) => {
      console.warn('ERVO Payroll async sync error:', err);
    });

    // Save to Google Sheets asynchronously in background (non-blocking)
    saveTransaction(payload).then((res) => {
      if (!res.success) {
        console.warn('Google Sheets async save notice:', res.message);
      }
    }).catch((err) => {
      console.warn('Google Sheets async save error:', err);
    });

    // Trigger 3-Layer Auto-Checkpoint on new transaction
    triggerAutoCheckpointOnTransaction(payload as Invoice);

    setIsSaving(false);
    setIsTransactionSaved(true);
    return true;
  };

  // Reset order state cleanly without showToast noise
  const resetOrderState = async () => {
    setInvoiceItems([]);
    setSelectedCustomer('');
    setDiscountPct(0);
    setNegoAmt(0);
    setTaxPct(0);
    setDpAmount('');
    setPayMethod('Tunai');
    setOrderDate(fDateInput(new Date()));
    setDeadlineDate('');
    await loadNewInvoiceNumber();
  };

  // Selesaikan Pembayaran Handler (Save & Sync without opening print dialog)
  const handleCompletePayment = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const saved = await saveTransactionToSheets();
    if (saved) {
      await resetOrderState();
      showToast('Pembayaran berhasil diselesaikan & disinkronkan ke ERVO Payroll!', 'success');
    }
  };

  // Print Thermal Handler
  const handlePrintThermal = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const saved = await saveTransactionToSheets();
    if (saved) {
      const html = generateThermalHTML(currentInvoiceData, effectiveSettings);
      openPrintWindow(html, 'Struk ' + invoiceNo);
      await resetOrderState();
      showToast('Transaksi selesai! Order baru otomatis disiapkan.', 'success');
    }
  };

  // Print A5 Invoice Handler
  const handlePrintA5 = async () => {
    if (invoiceItems.length === 0) return;
    if (!selectedCustomer || !selectedCustomer.trim()) {
      showToast('Nama Pelanggan / Pemesan wajib diisi!', 'error');
      return;
    }
    const saved = await saveTransactionToSheets();
    if (saved) {
      const html = generateA5HTML(currentInvoiceData, effectiveSettings);
      openPrintWindow(html, 'Invoice A5 ' + invoiceNo);
      await resetOrderState();
      showToast('Transaksi selesai! Order baru otomatis disiapkan.', 'success');
    }
  };

  // Sample Data Loading
  const handleLoadSampleData = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.setItem('strukku_products', JSON.stringify(INITIAL_PRODUCTS));
    showToast(`Data contoh dimuat (${INITIAL_PRODUCTS.length} produk)`, 'success');
  };

  // CSV Import Confirmation
  const handleConfirmImportProducts = (imported: Product[]) => {
    setProducts(imported);
    localStorage.setItem('strukku_products', JSON.stringify(imported));
  };

  if (!currentUser) {
    return (
      <>
        {toast && (
          <div className="fixed top-4 right-4 z-50 max-w-sm animate-fade-in">
            <div
              className={`px-4 py-3 rounded-xl shadow-xl font-bold text-xs text-white flex items-center gap-2 ${
                toast.type === 'success'
                  ? 'bg-emerald-700'
                  : toast.type === 'error'
                  ? 'bg-red-700'
                  : 'bg-stone-800'
              }`}
            >
              <span>{toast.msg}</span>
            </div>
          </div>
        )}
        <LoginScreen
          kasirUsers={kasirUsers}
          settings={settings}
          onLoginSuccess={handleLoginSuccess}
          onRefreshKasir={async () => {
            await handleSyncData();
          }}
          onUpdateKasirUsers={(newUsers) => setKasirUsers(newUsers)}
          onShowToast={showToast}
        />
      </>
    );
  }

  return (
    <div className={`min-h-screen lg:h-screen lg:overflow-hidden bg-stone-100 flex flex-col font-sans text-stone-900 ${mainViewTab === 'transaksi' ? 'pb-16 lg:pb-0' : 'pb-2 lg:pb-0'}`}>
      {/* Toast Banner */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 max-w-sm animate-fade-in">
          <div
            className={`px-4 py-3 rounded-xl shadow-xl font-bold text-xs text-white flex items-center gap-2 ${
              toast.type === 'success'
                ? 'bg-emerald-700'
                : toast.type === 'error'
                ? 'bg-red-700'
                : 'bg-stone-800'
            }`}
          >
            <span>{toast.msg}</span>
          </div>
        </div>
      )}

      {/* Quota Exceeded Alert Banner */}
      {quotaAlert && (
        <div className="bg-amber-600 text-white px-4 py-2.5 text-xs sm:text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-md relative z-50">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 flex-shrink-0 text-amber-200 animate-pulse" />
            <div>
              <p className="font-bold tracking-wide">Batas Kuota Harian Firestore (Free Tier) Tercapai</p>
              <p className="text-[11px] text-amber-100 leading-relaxed">
                Sistem otomatis beralih ke Mode Offline (Penyimpanan Cache Lokal). Kasir tetap dapat membuat transaksi, mencetak nota, dan melihat katalog secara normal. Kuota free tier akan di-reset otomatis besok hari.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto flex-shrink-0">
            <button
              onClick={() => {
                resetFirestoreQuotaSession();
                setQuotaAlert(false);
                showToast('Mereset status kuota & mencoba menghubungkan kembali...', 'info');
                setTimeout(() => {
                  window.location.reload();
                }, 300);
              }}
              className="px-2.5 py-1 bg-amber-800 text-white font-bold rounded-lg text-xs hover:bg-amber-900 transition-colors shadow-sm flex items-center gap-1 cursor-pointer"
              title="Coba hubungkan kembali ke Firestore"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Coba Ulang</span>
            </button>
            <a
              href="https://console.firebase.google.com/project/responsive-crossing-b5jvd/firestore/databases/ai-studio-ervostore-5d8b9daa-41d8-4ad1-a296-d9a995b48463/data?openUpgradeDialog=true"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1 bg-white text-amber-900 font-bold rounded-lg text-xs hover:bg-amber-50 transition-colors shadow-sm flex items-center gap-1.5"
            >
              <span>Upgrade Kuota Database</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setQuotaAlert(false)}
              className="p-1 text-white/80 hover:text-white rounded hover:bg-amber-700/50"
              title="Tutup pemberitahuan"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Header */}
      <Header
        settings={effectiveSettings}
        currentUser={currentUser}
        isConnected={isConnected}
        isSyncing={isSyncing}
        lastSyncTime={lastSyncTime}
        onSync={async () => {
          const ok = await handleSyncData();
          if (ok) showToast('Sinkronisasi data Google Sheets berhasil!', 'success');
          else showToast('Gagal terhubung ke Google Sheets', 'error');
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenReprint={() => setIsReprintOpen(true)}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
        onOpenBackup={() => setIsBackupModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Responsive Work Area */}
      <main className="flex-1 min-h-0 max-w-[1600px] w-full mx-auto p-2 sm:p-3 overflow-hidden flex flex-col">
        <div className="flex flex-col lg:flex-row gap-2 lg:gap-3 flex-1 min-h-0 h-full overflow-hidden">
          {/* Submenu Navigation Sidebar (Desktop: left sidebar, Mobile: top scrollable bar) */}
          <div className="shrink-0 lg:h-full flex flex-col overflow-hidden">
            <SidebarNav
              activeTab={mainViewTab}
              onChangeTab={(tab) => {
                if (tab === 'reprint') {
                  setIsReprintOpen(true);
                } else {
                  setMainViewTab(tab);
                }
              }}
              cartCount={invoiceItems.length}
              currentUser={currentUser}
              onLogout={handleLogout}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          </div>

          {/* Single Main Content Pane for all screen sizes */}
          <div className="flex-1 min-w-0 h-full min-h-0 overflow-hidden flex flex-col">
            {mainViewTab === 'dashboard' && (
              <DashboardView
                products={products}
                onNavigateToTransaksi={() => setMainViewTab('transaksi')}
                onNavigateToBarangMasuk={(productToRestock) => {
                  setSelectedRestockProduct(productToRestock || null);
                  setMainViewTab('barang_masuk');
                }}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'transaksi' && (
              <>
                {/* Desktop 3-Column Layout */}
                <div className="hidden lg:grid grid-cols-12 gap-3 h-full min-h-0 overflow-hidden">
                  {/* Column 1: Catalog */}
                  <div className="col-span-5 h-full min-h-0 overflow-hidden flex flex-col">
                    <ProductCatalog
                      products={products}
                      onSelectProduct={(p) => {
                        setSpecProduct(p);
                        setIsSpecModalOpen(true);
                      }}
                      onLoadSample={handleLoadSampleData}
                    />
                  </div>

                  {/* Column 2: Order Cart */}
                  <div className="col-span-4 h-full min-h-0 overflow-hidden flex flex-col">
                    <OrderCart
                      invoiceNo={invoiceNo}
                      invoiceDate={fDate(new Date())}
                      items={invoiceItems}
                      customers={customers}
                      selectedCustomer={selectedCustomer}
                      setSelectedCustomer={setSelectedCustomer}
                      orderDate={orderDate}
                      setOrderDate={setOrderDate}
                      deadlineDate={deadlineDate}
                      setDeadlineDate={setDeadlineDate}
                      discountPct={discountPct}
                      setDiscountPct={setDiscountPct}
                      taxPct={taxPct}
                      setTaxPct={setTaxPct}
                      negoAmt={negoAmt}
                      setNegoAmt={setNegoAmt}
                      payMethod={payMethod}
                      setPayMethod={setPayMethod}
                      dpAmount={dpAmount}
                      setDpAmount={setDpAmount}
                      onUpdateQty={handleUpdateQty}
                      onSetQty={handleSetQty}
                      onRemoveItem={handleRemoveItem}
                      onNewInvoice={handleNewOrder}
                      onPrintThermal={handlePrintThermal}
                      onPrintA5={handlePrintA5}
                      onCompletePayment={handleCompletePayment}
                      onOpenPelunasan={() => setIsPelunasanOpen(true)}
                      onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
                      isSaving={isSaving}
                    />
                  </div>

                  {/* Column 3: Thermal Preview */}
                  <div className="col-span-3 h-full min-h-0 overflow-hidden flex flex-col">
                    <ReceiptPreview
                      invoice={currentInvoiceData}
                      settings={effectiveSettings}
                      onPrintThermal={handlePrintThermal}
                      onPrintA5={handlePrintA5}
                    />
                  </div>
                </div>

                {/* Mobile Single-Tab View */}
                <div className="lg:hidden flex-1 min-h-0 overflow-y-auto pb-16">
                  {activeTab === 'catalog' && (
                    <ProductCatalog
                      products={products}
                      onSelectProduct={(p) => {
                        setSpecProduct(p);
                        setIsSpecModalOpen(true);
                      }}
                      onLoadSample={handleLoadSampleData}
                    />
                  )}

                  {activeTab === 'cart' && (
                    <OrderCart
                      invoiceNo={invoiceNo}
                      invoiceDate={fDate(new Date())}
                      items={invoiceItems}
                      customers={customers}
                      selectedCustomer={selectedCustomer}
                      setSelectedCustomer={setSelectedCustomer}
                      orderDate={orderDate}
                      setOrderDate={setOrderDate}
                      deadlineDate={deadlineDate}
                      setDeadlineDate={setDeadlineDate}
                      discountPct={discountPct}
                      setDiscountPct={setDiscountPct}
                      taxPct={taxPct}
                      setTaxPct={setTaxPct}
                      negoAmt={negoAmt}
                      setNegoAmt={setNegoAmt}
                      payMethod={payMethod}
                      setPayMethod={setPayMethod}
                      dpAmount={dpAmount}
                      setDpAmount={setDpAmount}
                      onUpdateQty={handleUpdateQty}
                      onSetQty={handleSetQty}
                      onRemoveItem={handleRemoveItem}
                      onNewInvoice={handleNewOrder}
                      onPrintThermal={handlePrintThermal}
                      onPrintA5={handlePrintA5}
                      onCompletePayment={handleCompletePayment}
                      onOpenPelunasan={() => setIsPelunasanOpen(true)}
                      onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
                      isSaving={isSaving}
                    />
                  )}

                  {activeTab === 'preview' && (
                    <ReceiptPreview
                      invoice={currentInvoiceData}
                      settings={effectiveSettings}
                      onPrintThermal={handlePrintThermal}
                      onPrintA5={handlePrintA5}
                    />
                  )}

                  {activeTab === 'pelunasan' && (
                    <div className="bg-white border border-stone-200 rounded-xl p-4 h-full overflow-y-auto">
                      <h3 className="font-extrabold text-stone-900 text-base mb-2">
                        Pelunasan & Piutang Pelanggan
                      </h3>
                      <p className="text-xs text-stone-600 mb-4">
                        Cari invoice dengan sisa pembayaran (DP) dari Google Sheets untuk memproses pelunasan.
                      </p>
                      <button
                        onClick={() => setIsPelunasanOpen(true)}
                        className="w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                      >
                        Buka Modal Pelunasan Piutang
                      </button>
                    </div>
                  )}

                  {activeTab === 'settings' && (
                    <div className="bg-white border border-stone-200 rounded-xl p-4 h-full overflow-y-auto space-y-3">
                      <h3 className="font-extrabold text-stone-900 text-base">Menu & Pengaturan</h3>
                      <button
                        onClick={() => setIsSettingsOpen(true)}
                        className="w-full py-2.5 px-4 bg-orange-700 text-white text-xs font-bold rounded-xl text-left flex items-center justify-between shadow-xs"
                      >
                        <span>Pengaturan Kasir & Connect Google Sheets</span>
                        <span>→</span>
                      </button>
                      <button
                        onClick={() => setIsReprintOpen(true)}
                        className="w-full py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl text-left flex items-center justify-between transition"
                      >
                        <span>Cetak Ulang Invoice Struk</span>
                        <span>→</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}

            {mainViewTab === 'barang_masuk' && (
              <BarangMasukView
                products={products}
                currentCashier={currentUser || 'Admin'}
                kasirUsers={kasirUsers}
                onRefreshProducts={handleSyncData}
                onShowToast={showToast}
                initialSelectedProduct={selectedRestockProduct}
                onDeleteProduct={handleDeleteProduct}
                onNavigateToVendor={() => setMainViewTab('vendor')}
                initialVendorName={selectedVendorForPo || undefined}
                settings={settings}
              />
            )}

            {mainViewTab === 'vendor' && (
              <VendorView
                onNavigateToBarangMasuk={(vendorName) => {
                  if (vendorName) {
                    setSelectedVendorForPo(vendorName);
                  }
                  setMainViewTab('barang_masuk');
                }}
                onShowToast={showToast}
              />
            )}

            {mainViewTab === 'laporan' && (
              <LaporanView
                onOpenReprint={() => setIsReprintOpen(true)}
                onShowToast={showToast}
                currentUser={currentUser || undefined}
                settings={settings}
                kasirUsers={kasirUsers}
                customers={customers}
                products={products}
                onRefreshProducts={handleSyncData}
              />
            )}

            {mainViewTab === 'pelanggan' && (
              <PelangganView
                customers={customers}
                onOpenAddCustomer={() => {
                  setCustomerToEdit(null);
                  setIsAddCustomerOpen(true);
                }}
                onEditCustomer={(cust) => {
                  setCustomerToEdit(cust);
                  setIsAddCustomerOpen(true);
                }}
                onSelectCustomerToOrder={(cName, cDisc) => {
                  setSelectedCustomer(cName);
                  if (cDisc) setDiscountPct(cDisc);
                  setMainViewTab('transaksi');
                  showToast(`Pelanggan "${cName}" dipilih untuk order`, 'success');
                }}
                onDeleteCustomer={handleDeleteCustomer}
              />
            )}
          </div>
        </div>
      </main>

      {/* Mobile Bottom Navigation - Tampil khusus saat di menu Kasir POS */}
      {mainViewTab === 'transaksi' && (
        <MobileBottomNav
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          cartCount={invoiceItems.length}
          cartTotal={total}
          onOpenReprint={() => setIsReprintOpen(true)}
        />
      )}

      {/* Item Specs Dialog Modal */}
      <SpecModal
        product={specProduct}
        isOpen={isSpecModalOpen}
        onClose={() => setIsSpecModalOpen(false)}
        onConfirm={handleConfirmSpecItem}
      />

      {/* Pelunasan Modal */}
      <PelunasanModal
        isOpen={isPelunasanOpen}
        onClose={() => setIsPelunasanOpen(false)}
        settings={settings}
        onShowToast={showToast}
      />

      {/* Reprint Modal */}
      <ReprintModal
        isOpen={isReprintOpen}
        onClose={() => setIsReprintOpen(false)}
        settings={settings}
        kasirUsers={kasirUsers}
        customers={customers}
        products={products}
        currentUser={currentUser}
        onShowToast={showToast}
      />

      {/* CSV Import Modal */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onConfirmImport={handleConfirmImportProducts}
        onShowToast={showToast}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        kasirList={kasirList}
        kasirUsers={kasirUsers}
        customers={customers}
        currentUser={currentUser}
        onUpdateKasirUsers={(updated) => {
          setKasirUsers(updated);
          setKasirList(updated.map((u) => u.nama));
          localStorage.setItem('strukku_kasir_users', JSON.stringify(updated));
          localStorage.setItem('strukku_kasir_list', JSON.stringify(updated.map((u) => u.nama)));
        }}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          localStorage.setItem('strukku_settings', JSON.stringify(newSettings));
          saveSettingsFirebase(newSettings).catch(console.error);
        }}
        onSync={handleSyncData}
        onShowToast={showToast}
        onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
        onOpenBackup={() => setIsBackupModalOpen(true)}
      />

      {/* 3-Layer Backup & Auto Checkpoint Modal */}
      {isBackupModalOpen && (
        <BackupCheckpointModal
          isOpen={isBackupModalOpen}
          onClose={() => setIsBackupModalOpen(false)}
          currentUser={currentUser || 'Admin'}
          kasirUsers={kasirUsers}
          currentData={{
            products,
            customers,
            invoices: allInvoices,
            expenses: getStoredExpenses(),
            stockIn: getLocalStockInHistory(),
            stockOpnames: getStoredStockOpnames(),
            kasirUsers,
            settings: {
              ...settings,
              sheetUrl: getSheetUrl(),
            },
            vendors: getStoredVendors(),
          }}
          isConnectedSheets={isConnected}
          onRefreshAllData={handleSyncData}
          onRestorePayload={handleRestorePayload}
          onShowToast={showToast}
        />
      )}

      {/* Add / Edit Customer Modal */}
      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => {
          setIsAddCustomerOpen(false);
          setCustomerToEdit(null);
        }}
        onCustomerAdded={handleCustomerAdded}
        onShowToast={showToast}
        initialName={selectedCustomer}
        customerToEdit={customerToEdit}
        onOpenGasGuide={() => setIsGasGuideOpen(true)}
      />

      {/* Google Apps Script Setup Guide Modal */}
      <GasSetupGuideModal
        isOpen={isGasGuideOpen}
        onClose={() => setIsGasGuideOpen(false)}
        onShowToast={showToast}
      />
    </div>
  );
}
