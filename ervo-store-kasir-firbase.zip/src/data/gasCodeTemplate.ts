export const GAS_SCRIPT_V5 = `/**
 * STRUKKU - BACKEND GOOGLE APPS SCRIPT v6 (Fast Batch Sync & High Performance)
 * ========================================================================
 * CARA UPDATE:
 *   1. Buka Google Sheets Anda > Extensions (Ekstensi) > Apps Script
 *   2. Hapus SEMUA kode lama di Code.gs, lalu paste seluruh kode v6 ini
 *   3. Tekan Ctrl+S (Simpan)
 *   4. Pilih fungsi "init" dari dropdown atas lalu klik ▶ Run (Jalankan)
 *   5. Klik Deploy (Terapkan) > Manage deployments (Kelola penerapan)
 *   6. Klik ikon Pensil (Edit) > Version: New version (Versi baru) > Klik Deploy
 */

var SHEET_TRANSAKSI    = 'Transaksi';
var SHEET_DETAIL       = 'Detail';
var SHEET_PRODUK       = 'Produk';
var SHEET_BARANG_MASUK = 'BarangMasuk';
var SHEET_PELANGGAN    = 'Pelanggan';
var SHEET_PELUNASAN    = 'Pelunasan';
var SHEET_PENGATURAN   = 'Pengaturan';
var SHEET_KASIR        = 'Kasir';
var SHEET_PENGELUARAN   = 'Pengeluaran';

function formatPhoneVal(val) {
  var s = String(val || '').trim();
  if (!s) return '';
  if (s.charAt(0) === "'") s = s.substring(1);
  if (/^8\\d{8,12}$/.test(s)) {
    s = '0' + s;
  }
  return s;
}

function formatPhoneForSheet(val) {
  var s = formatPhoneVal(val);
  if (!s) return '';
  return "'" + s;
}

function doPost(e) {
  try {
    var data = {};
    try { data = JSON.parse(e.postData.contents); } catch(err) {}
    var action = (e.parameter && e.parameter.action) ? e.parameter.action : (data.action || 'saveTransaction');
    var ss     = SpreadsheetApp.getActiveSpreadsheet();

    if (action === 'init' || action === 'initSheets') return handleInitSheets(ss);
    if (action === 'pelunasan')       return handlePelunasan(ss, data);
    if (action === 'saveSettings')    return handleSaveSettings(ss, data);
    if (action === 'updatePassword')  return handleUpdatePassword(ss, data);
    if (action === 'addCustomer')     return handleAddCustomer(ss, data);
    if (action === 'deleteCustomer')  return handleDeleteCustomer(ss, data);
    if (action === 'deleteProduct')   return handleDeleteProduct(ss, data);
    if (action === 'addProduct' || action === 'updateProduct') return handleAddProduct(ss, data);
    if (action === 'addStockIn')      return handleAddStockIn(ss, data);
    if (action === 'addExpense')      return handleAddExpense(ss, data);
    if (action === 'deleteExpense')   return handleDeleteExpenseRemote(ss, data);
    if (action === 'updateInvoice')   return handleUpdateInvoiceRemote(ss, data);
    if (action === 'deleteInvoice')   return handleDeleteInvoiceRemote(ss, data);
    if (action === 'logBackup')       return handleLogBackup(ss, data);
    if (action === 'getInvoice')      return getInvoiceData(ss, data.invoiceNo || '');

    if (action !== 'saveTransaction') {
      return jsonOutput({ success: false, message: 'Action tidak dikenal untuk doPost: ' + action });
    }

    var trans  = getOrCreateTransSheet(ss);
    var detail = getOrCreateDetailSheet(ss);
    var status = Number(data.sisa || 0) > 0 ? 'DP' : 'LUNAS';

    trans.appendRow([
      data.invoiceNo  || '',
      data.date       || '',
      data.time       || '',
      data.customer   || 'Umum',
      data.cashier    || '',
      Number(data.subtotal  || 0),
      Number(data.discPct   || 0),
      Number(data.discAmt   || 0),
      Number(data.taxPct    || 0),
      Number(data.taxAmt    || 0),
      Number(data.total     || 0),
      data.payMethod  || '',
      Number(data.dp        || 0),
      Number(data.sisa      || 0),
      Number(data.kembalian || 0),
      data.deadline   || '',
      status,
      Number(data.negoAmt   || 0),
      formatPhoneForSheet(data.customerPhone),
      data.customerAddress || ''
    ]);

    (data.items || []).forEach(function(it) {
      detail.appendRow([
        data.invoiceNo   || '',
        it.kode          || '',
        it.nama          || '',
        Number(it.harga  || 0),
        Number(it.qty    || 0),
        Number(it.totalItem || (Number(it.harga||0) * Number(it.qty||0))),
        Number(it.panjang || 0),
        Number(it.lebar   || 0),
        it.bahan          || '',
        it.catatan        || '',
        Number(it.diskonItem || 0)
      ]);

      if (it.kode || it.nama) {
        try {
          var prodSheet = getOrCreateProdukSheet(ss);
          var pRows     = prodSheet.getDataRange().getValues();
          for (var p = 1; p < pRows.length; p++) {
            var matchKode = it.kode && String(pRows[p][0]).trim().toUpperCase() === String(it.kode).trim().toUpperCase();
            var matchNama = it.nama && String(pRows[p][1]).trim().toLowerCase() === String(it.nama).trim().toLowerCase();
            if (matchKode || matchNama) {
              var curVal = pRows[p][4];
              if (curVal !== '' && curVal !== null && !isNaN(Number(curVal))) {
                var newStock = Math.max(0, Number(curVal) - Number(it.qty || 0));
                prodSheet.getRange(p + 1, 5).setValue(newStock);
              }
              break;
            }
          }
        } catch (stkErr) {}
      }
    });

    return jsonOutput({ success: true, message: 'Transaksi tersimpan (' + status + ')' });
  } catch(err) {
    return jsonOutput({ success: false, message: 'Error: ' + err.message });
  }
}

function handleAddProduct(ss, data) {
  var pKode   = String(data.kode || '').trim().toUpperCase();
  var pNama   = String(data.nama || '').trim();
  var oldKode = String(data.oldKode || data.originalKode || '').trim().toUpperCase();
  var oldNama = String(data.oldNama || data.originalNama || '').trim().toLowerCase();

  if (!pNama) return jsonOutput({ success: false, message: 'Nama produk tidak boleh kosong' });

  var pSheet = getOrCreateProdukSheet(ss);
  var rows   = pSheet.getDataRange().getValues();
  var found  = false;
  var targetRow = -1;

  for (var i = 1; i < rows.length; i++) {
    var rowKode = String(rows[i][0] || '').trim().toUpperCase();
    var rowNama = String(rows[i][1] || '').trim().toLowerCase();
    if (
      (oldKode && rowKode === oldKode) ||
      (pKode && rowKode === pKode) ||
      (oldNama && rowNama === oldNama) ||
      (pNama && rowNama === pNama.toLowerCase())
    ) {
      targetRow = i + 1;
      found = true;
      break;
    }
  }

  var harga    = Number(data.harga || 0);
  var kategori = String(data.kategori || 'Lainnya').trim();
  var stok     = (data.stok !== undefined && data.stok !== null) ? String(data.stok).trim() : '';
  var satuan   = String(data.satuan || 'pcs').trim();
  var tipe     = String(data.tipeHarga || 'fix').trim();

  if (found) {
    pSheet.getRange(targetRow, 1).setValue(pKode || rows[targetRow - 1][0]);
    pSheet.getRange(targetRow, 2).setValue(pNama);
    pSheet.getRange(targetRow, 3).setValue(harga);
    pSheet.getRange(targetRow, 4).setValue(kategori);
    pSheet.getRange(targetRow, 5).setValue(stok);
    pSheet.getRange(targetRow, 6).setValue(satuan);
    pSheet.getRange(targetRow, 7).setValue(tipe);

    return jsonOutput({ success: true, message: 'Produk "' + pNama + '" berhasil diperbarui di Sheet Produk' });
  } else {
    pSheet.appendRow([pKode, pNama, harga, kategori, stok, satuan, tipe]);
    return jsonOutput({ success: true, message: 'Produk baru "' + pNama + '" berhasil ditambahkan ke Sheet Produk' });
  }
}

function handleDeleteProduct(ss, data) {
  var pKode = String(data.kode || data.kodeProduct || '').trim().toUpperCase();
  var pNama = String(data.nama || data.namaProduct || '').trim().toLowerCase();
  if (!pKode && !pNama) return jsonOutput({ success: false, message: 'Kode atau Nama produk tidak boleh kosong' });

  var pSheet = getOrCreateProdukSheet(ss);
  var rows   = pSheet.getDataRange().getValues();

  for (var i = 1; i < rows.length; i++) {
    var rowKode = String(rows[i][0] || '').trim().toUpperCase();
    var rowNama = String(rows[i][1] || '').trim().toLowerCase();
    if ((pKode && rowKode === pKode) || (pNama && rowNama === pNama)) {
      var deletedName = rows[i][1] || pKode;
      pSheet.deleteRow(i + 1);
      return jsonOutput({ success: true, message: 'Produk "' + deletedName + '" berhasil dihapus dari Sheet Produk' });
    }
  }
  return jsonOutput({ success: true, message: 'Produk sudah tidak ada di Sheet Produk' });
}

function handleAddStockIn(ss, data) {
  var pKode = String(data.kode || '').trim().toUpperCase();
  var pNama = String(data.nama || '').trim();
  var qty   = parseFloat(String(data.qty || 0).replace(',', '.')) || 0;

  if (qty < 0) {
    return jsonOutput({ success: false, message: 'Jumlah barang masuk tidak boleh negatif' });
  }

  var bmSheet = getOrCreateBarangMasukSheet(ss);
  bmSheet.appendRow([
    data.id || ('STK-' + Date.now()),
    pKode,
    pNama,
    qty,
    data.satuan || 'pcs',
    data.supplier || 'Vendor / Suplier Umum',
    data.cashier || 'Admin',
    data.date || '',
    data.time || '',
    data.catatan || ''
  ]);

  if (qty > 0) {
    var pSheet = getOrCreateProdukSheet(ss);
    var rows   = pSheet.getDataRange().getValues();
    var found  = false;

    for (var i = 1; i < rows.length; i++) {
      var rowKode = String(rows[i][0] || '').trim().toUpperCase();
      var rowNama = String(rows[i][1] || '').trim().toLowerCase();
      if ((pKode && rowKode === pKode) || (pNama && rowNama === pNama.toLowerCase())) {
        var curStokNum = parseFloat(String(rows[i][4] || '0').replace(',', '.')) || 0;
        var newStok    = Math.round((curStokNum + qty) * 1000) / 1000;
        pSheet.getRange(i + 1, 5).setValue(newStok);
        found = true;
        break;
      }
    }

    if (!found && pNama) {
      pSheet.appendRow([pKode, pNama, 0, 'Bahan Baku', qty, data.satuan || 'pcs', 'fix']);
    }
  }

  return jsonOutput({
    success: true,
    message: 'Barang masuk "' + pNama + '"' + (qty > 0 ? ' (+' + qty + ')' : '') + ' berhasil tersimpan di Sheet BarangMasuk' + (qty > 0 ? ' & Produk!' : '!')
  });
}

function handleAddCustomer(ss, data) {
  var cNama = String(data.nama || data.pelanggan || '').trim();
  if (!cNama) return jsonOutput({ success: false, message: 'Nama pelanggan tidak boleh kosong' });

  var cSheet = getOrCreatePelangganSheet(ss);
  var rows   = cSheet.getDataRange().getValues();
  var found  = false;
  var targetRow = -1;

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0] || '').trim().toLowerCase() === cNama.toLowerCase()) {
      targetRow = i + 1;
      found = true;
      break;
    }
  }

  var kelas   = String(data.kelas || 'Reguler').trim();
  var diskon  = Number(data.diskon || 0);
  var telepon = formatPhoneForSheet(data.telepon);
  var catatan = String(data.catatan || '').trim();
  var alamat  = String(data.alamat || '').trim();

  if (found) {
    cSheet.getRange(targetRow, 2).setValue(kelas);
    cSheet.getRange(targetRow, 3).setValue(diskon);
    if (telepon) cSheet.getRange(targetRow, 4).setValue(telepon);
    if (catatan) cSheet.getRange(targetRow, 5).setValue(catatan);
    if (alamat)  cSheet.getRange(targetRow, 6).setValue(alamat);
    return jsonOutput({ success: true, message: 'Data pelanggan "' + cNama + '" berhasil diperbarui di Sheet Pelanggan' });
  } else {
    cSheet.appendRow([cNama, kelas, diskon, telepon, catatan, alamat]);
    return jsonOutput({ success: true, message: 'Pelanggan baru "' + cNama + '" berhasil ditambahkan ke Sheet Pelanggan' });
  }
}

function handleDeleteCustomer(ss, data) {
  var cNama = String(data.nama || data.customerName || data.pelanggan || '').trim();
  if (!cNama) return jsonOutput({ success: false, message: 'Nama pelanggan tidak boleh kosong' });

  var cSheet = getOrCreatePelangganSheet(ss);
  var rows   = cSheet.getDataRange().getValues();

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0] || '').trim().toLowerCase() === cNama.toLowerCase()) {
      cSheet.deleteRow(i + 1);
      return jsonOutput({ success: true, message: 'Pelanggan "' + cNama + '" berhasil dihapus dari Spreadsheet' });
    }
  }
  return jsonOutput({ success: true, message: 'Pelanggan "' + cNama + '" sudah tidak ada di Spreadsheet' });
}

function handleSaveSettings(ss, data) {
  var sheet = getOrCreatePengaturanSheet(ss);
  var rekValue = data.Rekening || data.NoRekening || data.RekeningPembayaran || '';
  var keys  = {
    NamaToko: data.NamaToko,
    Alamat: data.Alamat,
    Telepon: data.Telepon,
    Footer: data.Footer,
    PrefixInvoice: data.PrefixInvoice,
    Rekening: rekValue
  };
  var rows  = sheet.getDataRange().getValues();

  Object.keys(keys).forEach(function(key) {
    if (keys[key] === undefined) return;
    var found = false;
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][0]).trim() === key) {
        sheet.getRange(i+1, 2).setValue(keys[key]);
        found = true; break;
      }
    }
    if (!found) sheet.appendRow([key, keys[key]]);
  });
  return jsonOutput({ success: true, message: 'Pengaturan toko tersimpan' });
}

function handleUpdatePassword(ss, data) {
  var kKasir    = String(data.kasir || data.nama || '').trim();
  var newPass   = String(data.newPassword || data.password || '').trim();
  if (!kKasir) return jsonOutput({ success: false, message: 'Nama kasir tidak boleh kosong' });

  var kSheet = getOrCreateKasirSheet(ss);
  var rows   = kSheet.getDataRange().getValues();
  var found  = false;

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0] || '').trim().toLowerCase() === kKasir.toLowerCase()) {
      kSheet.getRange(i + 1, 2).setValue(newPass);
      found = true;
      break;
    }
  }

  if (!found) {
    kSheet.appendRow([kKasir, newPass || 'ervo123']);
  }

  return jsonOutput({ success: true, message: 'Password kasir ' + kKasir + ' berhasil diperbarui' });
}

function handleLogBackup(ss, data) {
  var sheet = ss.getSheetByName('Log_Backup');
  if (!sheet) {
    sheet = ss.insertSheet('Log_Backup');
    sheet.appendRow(['ID Checkpoint', 'Waktu', 'Trigger', 'Label / Catatan', 'Operator', 'Rincian Counts', 'Ukuran KB']);
    var hRange = sheet.getRange(1, 1, 1, 7);
    hRange.setFontWeight('bold');
    hRange.setBackground('#F3F4F6');
  }
  sheet.appendRow([
    data.id || '',
    data.timestamp || new Date().toISOString(),
    data.trigger || '',
    data.label || '',
    data.operator || '',
    typeof data.counts === 'string' ? data.counts : JSON.stringify(data.counts || {}),
    Number(data.sizeKb || 0)
  ]);
  return jsonOutput({ success: true, message: 'Log checkpoint berhasil dicatat di Sheet Log_Backup' });
}

function handlePelunasan(ss, data) {
  var transSheet = ss.getSheetByName(SHEET_TRANSAKSI);
  if (!transSheet) return jsonOutput({ success: false, message: 'Sheet Transaksi tidak ditemukan' });

  var rows = transSheet.getDataRange().getValues();
  var targetRow = -1, curSisa = 0, pelanggan = '', total = 0;

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === String(data.invoiceNo || '').trim()) {
      targetRow = i + 1;
      curSisa   = Number(rows[i][13]) || 0;
      pelanggan = String(rows[i][3]   || '');
      total     = Number(rows[i][10]  || 0);
      break;
    }
  }

  if (targetRow === -1) return jsonOutput({ success: false, message: 'Invoice tidak ditemukan: ' + data.invoiceNo });
  if (curSisa <= 0)     return jsonOutput({ success: false, message: 'Invoice ini sudah LUNAS', alreadyLunas: true });

  var bayar     = Number(data.jumlahBayar || 0);
  var newSisa   = Math.max(0, curSisa - bayar);
  var kembalian = bayar > curSisa ? bayar - curSisa : 0;
  var newStatus = newSisa <= 0 ? 'LUNAS' : 'DP';

  transSheet.getRange(targetRow, 14).setValue(newSisa);
  transSheet.getRange(targetRow, 17).setValue(newStatus);

  var pelSheet = getOrCreatePelunasanSheet(ss);
  pelSheet.appendRow([data.invoiceNo||'', data.date||'', data.time||'', pelanggan,
    data.cashier||'', data.payMethod||'Tunai', bayar, newSisa, kembalian, data.catatan||'']);

  return jsonOutput({ success: true,
    message  : newStatus === 'LUNAS' ? 'Pelunasan berhasil — Invoice LUNAS ✓' : 'Pembayaran sebagian tersimpan',
    newSisa: newSisa, kembalian: kembalian, status: newStatus, total: total, pelanggan: pelanggan });
}

function doGet(e) {
  try {
    var action = e ? e.parameter.action : '';
    var ss     = SpreadsheetApp.getActiveSpreadsheet();

    if (action === 'ping') return jsonOutput({ success: true, message: 'Koneksi OK' });
    if (action === 'init' || action === 'initSheets') return handleInitSheets(ss);

    if (action === 'getAllData' || action === 'syncAll' || action === 'getAll') {
      var pSheet = getOrCreateProdukSheet(ss);
      var pRows  = pSheet.getDataRange().getValues();
      var products = [];
      for (var p = 1; p < pRows.length; p++) {
        if (!pRows[p][0] && !pRows[p][1]) continue;
        var katClean = String(pRows[p][3] || 'Lainnya').trim().replace(/[\\r\\n]+/g, '');
        products.push({
          kode     : String(pRows[p][0] || '').trim(),
          nama     : String(pRows[p][1] || '').trim(),
          harga    : Number(pRows[p][2] || 0),
          kategori : katClean || 'Lainnya',
          stok     : (pRows[p][4] !== null && pRows[p][4] !== undefined && String(pRows[p][4]).trim() !== '')
                       ? String(pRows[p][4]).trim() : '',
          satuan   : String(pRows[p][5] || 'pcs').trim(),
          tipeHarga: String(pRows[p][6] || 'fix').trim()
        });
      }

      var cSheet = getOrCreatePelangganSheet(ss);
      var crows  = cSheet.getDataRange().getDisplayValues();
      var customers = [];
      for (var c = 1; c < crows.length; c++) {
        if (!crows[c][0]) continue;
        customers.push({
          nama: String(crows[c][0]||'').trim(),
          kelas: String(crows[c][1]||'').trim(),
          diskon: Number(crows[c][2]||0),
          telepon: formatPhoneVal(crows[c][3]),
          catatan: String(crows[c][4]||'').trim(),
          alamat: String(crows[c][5]||'').trim()
        });
      }

      var kSheet = getOrCreateKasirSheet(ss);
      var kRows  = kSheet.getDataRange().getValues();
      var kasirArr = [];
      for (var k = 1; k < kRows.length; k++) {
        if (kRows[k][0]) {
          var kNama = String(kRows[k][0]).trim();
          var kPass = String(kRows[k][1] || '').trim();
          if (!kPass) kPass = 'ervo123';
          kasirArr.push({ nama: kNama, password: kPass });
        }
      }

      var setSheet = getOrCreatePengaturanSheet(ss);
      var setRows  = setSheet.getDataRange().getValues();
      var settings = {};
      for (var s = 1; s < setRows.length; s++) {
        if (setRows[s][0]) settings[String(setRows[s][0]).trim()] = String(setRows[s][1] || '');
      }

      var bmSheet = getOrCreateBarangMasukSheet(ss);
      var bmRows  = bmSheet.getDataRange().getValues();
      var stockIn = [];
      for (var b = bmRows.length - 1; b >= 1; b--) {
        if (!bmRows[b][0] && !bmRows[b][1] && !bmRows[b][2]) continue;
        stockIn.push({
          id       : String(bmRows[b][0] || ''),
          kode     : String(bmRows[b][1] || ''),
          nama     : String(bmRows[b][2] || ''),
          qty      : Number(bmRows[b][3] || 0),
          satuan   : String(bmRows[b][4] || 'pcs'),
          supplier : String(bmRows[b][5] || ''),
          cashier  : String(bmRows[b][6] || ''),
          date     : formatCellValue(ss, bmRows[b][7]),
          time     : formatCellValue(ss, bmRows[b][8]),
          catatan  : String(bmRows[b][9] || '')
        });
      }

      var nextInvoiceObj = getNextInvoiceNumber(ss);
      var nextInvoiceNo = nextInvoiceObj && nextInvoiceObj.invoiceNo ? nextInvoiceObj.invoiceNo : '';

      return jsonOutput({
        success: true,
        data: {
          products: products,
          customers: customers,
          kasir: kasirArr,
          settings: settings,
          stockIn: stockIn,
          nextInvoiceNo: nextInvoiceNo
        }
      });
    }

    if (action === 'getNextInvoiceNo') {
      return getNextInvoiceNumber(ss);
    }

    if (action === 'getSettings') {
      var pSheet = getOrCreatePengaturanSheet(ss);
      var pRows  = pSheet.getDataRange().getValues();
      var cfg    = {};
      for (var s = 1; s < pRows.length; s++) {
        if (pRows[s][0]) cfg[String(pRows[s][0]).trim()] = String(pRows[s][1] || '');
      }
      return jsonOutput({ success: true, data: cfg });
    }

    if (action === 'getKasir') {
      var kSheet   = getOrCreateKasirSheet(ss);
      var kRows    = kSheet.getDataRange().getValues();
      var kasirArr = [];
      for (var k = 1; k < kRows.length; k++) {
        if (kRows[k][0]) {
          var kNama = String(kRows[k][0]).trim();
          var kPass = String(kRows[k][1] || '').trim();
          if (!kPass) kPass = 'ervo123';
          kasirArr.push({ nama: kNama, password: kPass });
        }
      }
      return jsonOutput({ success: true, data: kasirArr });
    }

    if (action === 'getProducts') {
      var sheet = getOrCreateProdukSheet(ss);
      var rows  = sheet.getDataRange().getValues();
      var list  = [];
      for (var p = 1; p < rows.length; p++) {
        if (!rows[p][0] && !rows[p][1]) continue;
        var katClean = String(rows[p][3] || 'Lainnya').trim().replace(/[\\r\\n]+/g, '');
        list.push({
          kode     : String(rows[p][0] || '').trim(),
          nama     : String(rows[p][1] || '').trim(),
          harga    : Number(rows[p][2] || 0),
          kategori : katClean || 'Lainnya',
          stok     : (rows[p][4] !== null && rows[p][4] !== undefined && String(rows[p][4]).trim() !== '')
                       ? String(rows[p][4]).trim() : '',
          satuan   : String(rows[p][5] || 'pcs').trim(),
          tipeHarga: String(rows[p][6] || 'fix').trim()
        });
      }
      return jsonOutput({ success: true, data: list });
    }

    if (action === 'getStockIn') {
      var bmSheet = getOrCreateBarangMasukSheet(ss);
      var bmRows  = bmSheet.getDataRange().getValues();
      var bmList  = [];
      for (var b = bmRows.length - 1; b >= 1; b--) {
        if (!bmRows[b][0] && !bmRows[b][1] && !bmRows[b][2]) continue;
        bmList.push({
          id       : String(bmRows[b][0] || ''),
          kode     : String(bmRows[b][1] || ''),
          nama     : String(bmRows[b][2] || ''),
          qty      : Number(bmRows[b][3] || 0),
          satuan   : String(bmRows[b][4] || 'pcs'),
          supplier : String(bmRows[b][5] || ''),
          cashier  : String(bmRows[b][6] || ''),
          date     : formatCellValue(ss, bmRows[b][7]),
          time     : formatCellValue(ss, bmRows[b][8]),
          catatan  : String(bmRows[b][9] || '')
        });
      }
      return jsonOutput({ success: true, data: bmList });
    }

    if (action === 'getCustomers') {
      var cSheet = getOrCreatePelangganSheet(ss);
      var crows  = cSheet.getDataRange().getDisplayValues();
      var clist  = [];
      for (var c = 1; c < crows.length; c++) {
        if (!crows[c][0]) continue;
        clist.push({
          nama: String(crows[c][0]||'').trim(),
          kelas: String(crows[c][1]||'').trim(),
          diskon: Number(crows[c][2]||0),
          telepon: formatPhoneVal(crows[c][3]),
          catatan: String(crows[c][4]||'').trim(),
          alamat: String(crows[c][5]||'').trim()
        });
      }
      return jsonOutput({ success: true, data: clist });
    }

    if (action === 'getExpenses') {
      var expSheet = getOrCreatePengeluaranSheet(ss);
      var expRows  = expSheet.getDataRange().getValues();
      var expList  = [];
      for (var ex = expRows.length - 1; ex >= 1; ex--) {
        if (!expRows[ex][0] && !expRows[ex][3]) continue;
        expList.push({
          id        : String(expRows[ex][0] || ''),
          tanggal   : formatCellValue(ss, expRows[ex][1]),
          kategori  : String(expRows[ex][2] || 'Lain-lain'),
          keterangan: String(expRows[ex][3] || ''),
          pj        : String(expRows[ex][4] || 'Kasir'),
          nominal   : Number(expRows[ex][5] || 0)
        });
      }
      return jsonOutput({ success: true, data: expList });
    }

    if (action === 'getInvoice') {
      return getInvoiceData(ss, e ? e.parameter.invoiceNo : '');
    }

    if (action === 'getPiutang' || action === 'getRecentInvoices') {
      var tSheet = ss.getSheetByName(SHEET_TRANSAKSI);
      if (!tSheet) return jsonOutput({ success: true, data: [] });

      var pelSheet = ss.getSheetByName(SHEET_PELUNASAN);
      var pelMap = {};
      if (pelSheet) {
        var pRows = pelSheet.getDataRange().getValues();
        for (var p = 1; p < pRows.length; p++) {
          var pInv = String(pRows[p][0] || '').trim().toLowerCase();
          if (!pInv) continue;
          if (!pelMap[pInv]) pelMap[pInv] = [];
          pelMap[pInv].push({
            invoiceNo: String(pRows[p][0] || '').trim(),
            date: formatCellValue(ss, pRows[p][1]),
            time: formatCellValue(ss, pRows[p][2]),
            customer: String(pRows[p][3] || ''),
            cashier: String(pRows[p][4] || ''),
            payMethod: String(pRows[p][5] || 'Tunai'),
            jumlahBayar: Number(pRows[p][6] || 0),
            newSisa: Number(pRows[p][7] || 0),
            kembalian: Number(pRows[p][8] || 0),
            catatan: String(pRows[p][9] || '')
          });
        }
      }

      if (action === 'getPiutang') {
        var pRows2 = tSheet.getDataRange().getValues();
        var piutang = [];
        for (var x = 1; x < pRows2.length; x++) {
          var stVal = String(pRows2[x][16] || '').trim().toUpperCase();
          var sisaVal = Number(pRows2[x][13] || 0);
          if (stVal === 'DP' || sisaVal > 0) {
            var invKeyP = String(pRows2[x][0] || '').trim().toLowerCase();
            piutang.push({
              invoiceNo: String(pRows2[x][0] || ''),
              date: formatCellValue(ss, pRows2[x][1]),
              customer: String(pRows2[x][3] || 'Umum'),
              total: Number(pRows2[x][10] || 0),
              dp: Number(pRows2[x][12] || 0),
              sisa: sisaVal,
              deadline: formatCellValue(ss, pRows2[x][15]),
              historiPelunasan: pelMap[invKeyP] || []
            });
          }
        }
        return jsonOutput({ success: true, data: piutang });
      }

      if (action === 'getRecentInvoices') {
        var rows = tSheet.getDataRange().getValues();
        var list = [];
        for (var i = rows.length - 1; i >= 1; i--) {
          if (!rows[i][0]) continue;
          var invKeyR = String(rows[i][0] || '').trim().toLowerCase();
          list.push({
            invoiceNo: String(rows[i][0] || ''),
            date: formatCellValue(ss, rows[i][1]),
            time: formatCellValue(ss, rows[i][2]),
            customer: String(rows[i][3] || 'Umum'),
            cashier: String(rows[i][4] || ''),
            payMethod: String(rows[i][11] || 'Tunai'),
            metodePembayaran: String(rows[i][11] || 'Tunai'),
            total: Number(rows[i][10] || 0),
            dp: Number(rows[i][12] || 0),
            sisa: Number(rows[i][13] || 0),
            status: String(rows[i][16] || (Number(rows[i][13] || 0) > 0 ? 'DP' : 'LUNAS')),
            historiPelunasan: pelMap[invKeyR] || []
          });
        }
        return jsonOutput({ success: true, data: list });
      }
    }

    return jsonOutput({ success: false, message: 'Action tidak dikenal: ' + action });
  } catch(err) {
    return jsonOutput({ success: false, message: 'Error: ' + err.message });
  }
}

function getNextInvoiceNumber(ss) {
  var pSheet   = getOrCreatePengaturanSheet(ss);
  var pRows    = pSheet.getDataRange().getValues();
  var prefixKode = 'INV';
  for (var p = 1; p < pRows.length; p++) {
    if (String(pRows[p][0]) === 'PrefixInvoice' && String(pRows[p][1] || '').trim()) {
      prefixKode = String(pRows[p][1]).trim();
      break;
    }
  }

  var d        = new Date();
  var yearMonth = d.getFullYear() + String(d.getMonth()+1).padStart(2,'0');
  var prefix   = prefixKode + '-' + yearMonth + '-';

  var maxSeq = 0;
  var tSheet = ss.getSheetByName(SHEET_TRANSAKSI);
  if (tSheet) {
    var rows = tSheet.getDataRange().getValues();
    for (var i = 1; i < rows.length; i++) {
      var inv = String(rows[i][0] || '');
      if (inv.indexOf(prefixKode + '-' + yearMonth) === 0 || inv.indexOf(prefix) === 0) {
        var parts = inv.split('-');
        if (parts.length >= 2) {
          var seq = parseInt(parts[parts.length - 1], 10);
          if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
        }
      }
    }
  }
  return jsonOutput({ success: true, invoiceNo: prefix + String(maxSeq + 1).padStart(3, '0') });
}

var _cachedTz = null;
function formatCellValue(ss, val) {
  if (Object.prototype.toString.call(val) !== '[object Date]') return val;
  if (!_cachedTz && ss && typeof ss.getSpreadsheetTimeZone === 'function') {
    try { _cachedTz = ss.getSpreadsheetTimeZone(); } catch(e) {}
  }
  var tz = _cachedTz || 'Asia/Jakarta';
  var isTimeOnly = val.getFullYear() === 1899 && val.getMonth() === 11 && val.getDate() === 30;
  return Utilities.formatDate(val, tz, isTimeOnly ? 'HH:mm' : 'dd/MM/yyyy');
}

function getInvoiceData(ss, invoiceNoRaw) {
  var invoiceNo = String(invoiceNoRaw || '').trim();
  if (!invoiceNo) return jsonOutput({ success: false, message: 'Nomor invoice kosong' });

  var tSheet = ss.getSheetByName(SHEET_TRANSAKSI);
  var dSheet = ss.getSheetByName(SHEET_DETAIL);
  if (!tSheet || !dSheet) return jsonOutput({ success: false, message: 'Belum ada data transaksi' });

  var tRows = tSheet.getDataRange().getValues();
  var hRow  = null;
  for (var t = 1; t < tRows.length; t++) {
    if (String(tRows[t][0]).trim() === invoiceNo) { hRow = tRows[t]; break; }
  }
  if (!hRow) return jsonOutput({ success: false, message: 'Invoice tidak ditemukan: ' + invoiceNo });

  var dRows = dSheet.getDataRange().getValues();
  var items = [];
  for (var d = 1; d < dRows.length; d++) {
    if (String(dRows[d][0]).trim() === invoiceNo) {
      items.push({ kode: dRows[d][1], nama: dRows[d][2],
        harga: Number(dRows[d][3]||0), qty: Number(dRows[d][4]||0),
        totalItem: Number(dRows[d][5]||0),
        panjang: Number(dRows[d][6]||0), lebar: Number(dRows[d][7]||0),
        bahan: String(dRows[d][8]||''), catatan: String(dRows[d][9]||''),
        diskonItem: Number(dRows[d][10]||0),
        satuan: 'pcs',
        tipeHarga: (Number(dRows[d][6])>0 && Number(dRows[d][7])>0) ? 'ukuran' : 'fix'
      });
    }
  }

  var pelSheet = ss.getSheetByName(SHEET_PELUNASAN);
  var historiPelunasan = [];
  if (pelSheet) {
    var pRows = pelSheet.getDataRange().getValues();
    for (var p = 1; p < pRows.length; p++) {
      if (String(pRows[p][0] || '').trim().toLowerCase() === invoiceNo.toLowerCase()) {
        historiPelunasan.push({
          invoiceNo: String(pRows[p][0] || '').trim(),
          date: formatCellValue(ss, pRows[p][1]),
          time: formatCellValue(ss, pRows[p][2]),
          customer: String(pRows[p][3] || ''),
          cashier: String(pRows[p][4] || ''),
          payMethod: String(pRows[p][5] || 'Tunai'),
          jumlahBayar: Number(pRows[p][6] || 0),
          newSisa: Number(pRows[p][7] || 0),
          kembalian: Number(pRows[p][8] || 0),
          catatan: String(pRows[p][9] || '')
        });
      }
    }
  }

  return jsonOutput({ success: true, data: {
    invoiceNo: hRow[0], date: formatCellValue(ss, hRow[1]), time: formatCellValue(ss, hRow[2]),
    customer: hRow[3], cashier: hRow[4],
    subtotal: hRow[5], discPct: hRow[6], discAmt: hRow[7], taxPct: hRow[8], taxAmt: hRow[9],
    total: hRow[10], payMethod: hRow[11], dp: hRow[12], sisa: hRow[13],
    kembalian: hRow[14], deadline: formatCellValue(ss, hRow[15]), status: hRow[16]||'LUNAS',
    negoAmt: Number(hRow[17]||0),
    customerPhone: formatPhoneVal(hRow[18]), customerAddress: String(hRow[19]||''),
    items: items,
    historiPelunasan: historiPelunasan
  }});
}

function handleInitSheets(ss) {
  var list = initSheets(ss);
  return jsonOutput({
    success: true,
    message: 'Inisialisasi & sinkronisasi sheet v5 berhasil!',
    sheets: list
  });
}

function onOpen() {
  try {
    var ui = SpreadsheetApp.getUi();
    ui.createMenu('🚀 Strukku POS')
      .addItem('🔄 Inisialisasi / Reset Header Sheet (Init)', 'init')
      .addToUi();
  } catch (e) {}
}

function init() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = initSheets(ss);
  try {
    SpreadsheetApp.getUi().alert('✓ Inisialisasi Berhasil!\\n\\nSeluruh Sheet berikut telah disesuaikan & siap (v5):\\n- ' + sheets.join('\\n- '));
  } catch(e) {
    Logger.log('Inisialisasi v5 selesai: ' + sheets.join(', '));
  }
  return sheets;
}

function initSheets(ss) {
  if (!ss) ss = SpreadsheetApp.getActiveSpreadsheet();
  
  getOrCreatePengaturanSheet(ss);
  getOrCreateKasirSheet(ss);
  getOrCreateProdukSheet(ss);
  getOrCreateBarangMasukSheet(ss);
  getOrCreatePelangganSheet(ss);
  getOrCreateTransSheet(ss);
  getOrCreateDetailSheet(ss);
  getOrCreatePelunasanSheet(ss);
  getOrCreatePengeluaranSheet(ss);

  return [
    SHEET_PENGATURAN,
    SHEET_KASIR,
    SHEET_PRODUK,
    SHEET_BARANG_MASUK,
    SHEET_PELANGGAN,
    SHEET_TRANSAKSI,
    SHEET_DETAIL,
    SHEET_PELUNASAN,
    SHEET_PENGELUARAN
  ];
}

function getOrCreatePengaturanSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_PENGATURAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PENGATURAN);
    sheet.appendRow(['Key', 'Value']);
    sheet.appendRow(['NamaToko', 'ERVO PRINT']);
    sheet.appendRow(['Alamat', 'Jl. HOS Cokroaminoto No.17, Ciamis - Jawa Barat 46211']);
    sheet.appendRow(['Telepon', '0812-2247-2007']);
    sheet.appendRow(['Footer', 'Terima Kasih Atas Kunjungan Anda']);
    sheet.appendRow(['PrefixInvoice', 'INV']);
    sheet.appendRow(['Rekening', 'BCA 123456789 a/n ERVO PRINT']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:B1').setFontWeight('bold');
  } else {
    var rows = sheet.getDataRange().getValues();
    var hasRekening = false;
    var hasPrefix = false;
    for (var r = 1; r < rows.length; r++) {
      var k = String(rows[r][0] || '').trim().toLowerCase();
      if (k === 'rekening') hasRekening = true;
      if (k === 'prefixinvoice') hasPrefix = true;
    }
    if (!hasPrefix) sheet.appendRow(['PrefixInvoice', 'INV']);
    if (!hasRekening) sheet.appendRow(['Rekening', 'BCA 123456789 a/n ERVO PRINT']);
  }
  return sheet;
}

function getOrCreateKasirSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_KASIR);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_KASIR);
    sheet.appendRow(['Nama Kasir', 'Password']);
    sheet.appendRow(['Admin', 'ervo123']);
    sheet.appendRow(['Clara', 'ervo123']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:B1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreateTransSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_TRANSAKSI);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_TRANSAKSI);
    sheet.appendRow(['No Invoice','Tanggal','Jam','Pelanggan','Kasir',
      'Subtotal','Diskon %','Diskon Rp','Pajak %','Pajak Rp',
      'Total','Metode Bayar','DP / Bayar Muka','Sisa Bayar','Kembalian',
      'Est. Selesai','Status','Nego Rp','No HP Pelanggan','Alamat Pelanggan']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:T1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreateDetailSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_DETAIL);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_DETAIL);
    sheet.appendRow(['No Invoice','Kode','Nama Barang','Harga','Qty','Subtotal','Panjang','Lebar','Bahan/Finishing','Keterangan','Diskon Item Rp']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:K1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreatePelunasanSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_PELUNASAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PELUNASAN);
    sheet.appendRow(['No Invoice','Tgl Bayar','Jam','Pelanggan','Kasir','Metode Bayar','Jumlah Bayar','Sisa Setelah','Kembalian','Catatan']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:J1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreateProdukSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_PRODUK);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PRODUK);
    sheet.appendRow(['Kode','Nama','Harga','Kategori','Stok','Satuan','TipeHarga']);
    sheet.appendRow(['BNR','Cetak Banner / Spanduk',35000,'Banner','','m²','ukuran']);
    sheet.appendRow(['SBL','Cetak Sublime',85000,'Sublime','','m²','ukuran']);
    sheet.appendRow(['A3P','Cetak A3+',5000,'Kertas',500,'lembar','fix']);
    sheet.appendRow(['DTF','Cetak DTF UV',45000,'DTF','','m²','ukuran']);
    sheet.appendRow(['SUV','Stiker UV',55000,'Stiker','','m²','ukuran']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:G1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreateBarangMasukSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_BARANG_MASUK);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_BARANG_MASUK);
    sheet.appendRow(['ID Log','Kode','Nama Barang','Qty Masuk','Satuan','Supplier / Vendor','Petugas / Kasir','Tanggal','Jam','Catatan']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:J1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreatePelangganSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_PELANGGAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PELANGGAN);
    sheet.appendRow(['Nama','Kelas','Diskon %','Telepon','Catatan','Alamat']);
    sheet.appendRow(['Umum','Reguler',0,'','Pelanggan tanpa data khusus','']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:F1').setFontWeight('bold');
  }
  return sheet;
}

function getOrCreatePengeluaranSheet(ss) {
  var sheet = ss.getSheetByName(SHEET_PENGELUARAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PENGELUARAN);
    sheet.appendRow(['ID Pengeluaran','Tanggal','Kategori','Keterangan / Pengeluaran','PJ / Kasir','Nominal Biaya']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:F1').setFontWeight('bold');
  }
  return sheet;
}

function handleAddExpense(ss, data) {
  var id         = String(data.id || ('EXP-' + Date.now().toString().slice(-6))).trim();
  var tanggal    = String(data.tanggal || new Date().toISOString().split('T')[0]).trim();
  var kategori   = String(data.kategori || 'Lain-lain').trim();
  var keterangan = String(data.keterangan || '').trim();
  var pj         = String(data.pj || 'Kasir').trim();
  var nominal    = Number(data.nominal || 0);

  if (!keterangan) {
    return jsonOutput({ success: false, message: 'Keterangan pengeluaran tidak boleh kosong' });
  }

  var expSheet = getOrCreatePengeluaranSheet(ss);
  var rows     = expSheet.getDataRange().getValues();
  var foundRow = -1;

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === id) {
      foundRow = i + 1;
      break;
    }
  }

  if (foundRow > -1) {
    expSheet.getRange(foundRow, 2).setValue(tanggal);
    expSheet.getRange(foundRow, 3).setValue(kategori);
    expSheet.getRange(foundRow, 4).setValue(keterangan);
    expSheet.getRange(foundRow, 5).setValue(pj);
    expSheet.getRange(foundRow, 6).setValue(nominal);
    return jsonOutput({ success: true, message: 'Pengeluaran ' + id + ' berhasil diperbarui', id: id });
  } else {
    expSheet.appendRow([id, tanggal, kategori, keterangan, pj, nominal]);
    return jsonOutput({ success: true, message: 'Pengeluaran ' + id + ' berhasil ditambahkan', id: id });
  }
}

function handleDeleteExpenseRemote(ss, data) {
  var id = String(data.id || '').trim();
  if (!id) return jsonOutput({ success: false, message: 'ID Pengeluaran kosong' });

  var expSheet = getOrCreatePengeluaranSheet(ss);
  var rows     = expSheet.getDataRange().getValues();
  var deleted  = false;

  for (var i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === id) {
      expSheet.deleteRow(i + 1);
      deleted = true;
      break;
    }
  }

  if (deleted) {
    return jsonOutput({ success: true, message: 'Pengeluaran ' + id + ' berhasil dihapus' });
  } else {
    return jsonOutput({ success: false, message: 'Pengeluaran ' + id + ' tidak ditemukan' });
  }
}

function handleUpdateInvoiceRemote(ss, data) {
  var invNo = String(data.invoiceNo || data.noInvoice || '').trim();
  if (!invNo) return jsonOutput({ success: false, message: 'Nomor invoice kosong' });

  var invLower = invNo.toLowerCase();
  var tSheet = getOrCreateTransSheet(ss);
  var updated = false;

  if (tSheet) {
    var rows = tSheet.getDataRange().getValues();
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][0] || '').trim().toLowerCase() === invLower) {
        var status = Number(data.sisa || 0) > 0 ? 'DP' : 'LUNAS';
        tSheet.getRange(i + 1, 1, 1, 20).setValues([[
          invNo,
          data.date || rows[i][1] || '',
          data.time || rows[i][2] || '',
          data.customer || 'Umum',
          data.cashier || rows[i][4] || '',
          Number(data.subtotal || 0),
          Number(data.discPct || 0),
          Number(data.discAmt || 0),
          Number(data.taxPct || 0),
          Number(data.taxAmt || 0),
          Number(data.total || 0),
          data.payMethod || rows[i][11] || '',
          Number(data.dp || 0),
          Number(data.sisa || 0),
          Number(data.kembalian || 0),
          data.deadline || '',
          status,
          Number(data.negoAmt || 0),
          formatPhoneForSheet(data.customerPhone),
          data.customerAddress || ''
        ]]);
        updated = true;
        break;
      }
    }
  }

  // Update Detail sheet if items provided
  if (Array.isArray(data.items) && data.items.length > 0) {
    var dSheet = getOrCreateDetailSheet(ss);
    if (dSheet) {
      var dRows = dSheet.getDataRange().getValues();
      for (var j = dRows.length - 1; j >= 1; j--) {
        if (String(dRows[j][0] || '').trim().toLowerCase() === invLower) {
          dSheet.deleteRow(j + 1);
        }
      }
      for (var m = 0; m < data.items.length; m++) {
        var item = data.items[m];
        dSheet.appendRow([
          invNo,
          item.nama || item.name || '',
          Number(item.qty || 1),
          item.satuan || 'pcs',
          Number(item.harga || 0),
          Number(item.totalItem || (Number(item.qty || 1) * Number(item.harga || 0))),
          item.kategori || 'Produk',
          Number(item.panjang || 0),
          Number(item.lebar || 0),
          item.finishing || '',
          item.catatan || '',
          Number(item.diskonItem || 0)
        ]);
      }
    }
  }

  return jsonOutput({
    success: true,
    message: updated
      ? 'Invoice #' + invNo + ' berhasil diperbarui di Google Sheets'
      : 'Invoice #' + invNo + ' dicatat di sistem'
  });
}

function handleDeleteInvoiceRemote(ss, data) {
  var invNo = String(data.invoiceNo || data.noInvoice || '').trim();
  if (!invNo) return jsonOutput({ success: false, message: 'Nomor invoice kosong' });

  var invLower = invNo.toLowerCase();
  var deletedCount = 0;

  // 1. Delete from SHEET_TRANSAKSI
  var tSheet = getOrCreateTransSheet(ss);
  if (tSheet) {
    var rows = tSheet.getDataRange().getValues();
    for (var i = rows.length - 1; i >= 1; i--) {
      if (String(rows[i][0] || '').trim().toLowerCase() === invLower) {
        tSheet.deleteRow(i + 1);
        deletedCount++;
      }
    }
  }

  // 2. Delete from SHEET_DETAIL
  var dSheet = getOrCreateDetailSheet(ss);
  if (dSheet) {
    var dRows = dSheet.getDataRange().getValues();
    for (var j = dRows.length - 1; j >= 1; j--) {
      if (String(dRows[j][0] || '').trim().toLowerCase() === invLower) {
        dSheet.deleteRow(j + 1);
      }
    }
  }

  // 3. Delete from SHEET_PELUNASAN if exists
  var pSheet = ss.getSheetByName(SHEET_PELUNASAN);
  if (pSheet) {
    var pRows = pSheet.getDataRange().getValues();
    for (var k = pRows.length - 1; k >= 1; k--) {
      if (String(pRows[k][0] || '').trim().toLowerCase() === invLower) {
        pSheet.deleteRow(k + 1);
      }
    }
  }

  return jsonOutput({
    success: true,
    message: 'Invoice #' + invNo + ' berhasil dihapus dari Google Sheets (' + deletedCount + ' baris transaksi)'
  });
}

function jsonOutput(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
`;