import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Product, StockInRecord, KasirUser, StoreSettings } from '../types';
import { addStockIn, fetchStockInHistory, deleteStockInRecord, addNewProduct, updateProductDetails } from '../services/gasService';
import { saveStockInFirebase, deleteStockInFirebase, saveProductFirebase, updateProductFirebase, subscribeStockIn, productsManager } from '../services/firebaseService';
import { addExpenseRecord } from '../services/expenseService';
import { fDateInput, fTime, fRp, checkIsSpvOrOwner } from '../utils/formatters';
import { 
  PackagePlus, 
  RotateCw, 
  Search, 
  History, 
  CheckCircle2, 
  Truck, 
  Layers,
  Calendar, 
  User, 
  AlertCircle, 
  PlusCircle, 
  Tag, 
  DollarSign, 
  Boxes, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  ShieldCheck, 
  ShieldAlert, 
  KeyRound, 
  Lock,
  Plus,
  X,
  ChevronDown,
  ChevronRight,
  Filter,
  Warehouse,
  Wallet,
  FileText,
  Check,
  Maximize2,
  Sparkles,
  Building2,
  Pencil,
  Printer
} from 'lucide-react';
import { getStoredVendors, saveVendorRecord } from '../services/vendorService';
import { Vendor } from '../types';
import { generateStockInHistoryPdf } from '../utils/pdfGenerator';

interface BarangMasukViewProps {
  products: Product[];
  currentCashier: string;
  kasirUsers?: KasirUser[];
  onRefreshProducts: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  initialSelectedProduct?: Product | null;
  onDeleteProduct?: (kode: string, nama: string, authorizedBy?: string) => Promise<void> | void;
  onNavigateToVendor?: () => void;
  initialVendorName?: string;
  settings?: StoreSettings;
}

interface PoItemRow {
  id: string;
  product: Product | null;
  qty: number | string;
  satuan: string;
  hargaBeli: number | string;
  warna: string;
  lotBatch: string;
  isEceran: boolean;
}

const GUDANG_OPTIONS = [
  'Gudang Utama',
  'Toko / Etalase Display',
  'Workshop Cetak & Produksi',
  'Gudang Bahan Baku A3 & Offset',
  'Gudang Outdoor Banner',
  'Gudang Merchandise & Garment',
  'Gudang Transit / Ekspedisi'
];

const COMMON_COLORS = [
  'Hitam',
  'Putih',
  'Navy',
  'Merah Cabai',
  'Maroon',
  'Kuning Kenari',
  'Hijau Botol',
  'Abu Misty',
  'Coklat Susu',
  'Transparan',
  'Glossy',
  'Matte / Doff'
];

// Helper to parse decimal numbers safely supporting both comma (0,1) and dot (0.1)
export const parseNumberInput = (val: string | number | undefined | null): number => {
  if (val === undefined || val === null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const cleaned = String(val).trim().replace(',', '.');
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
};

export const BarangMasukView: React.FC<BarangMasukViewProps> = ({
  products,
  currentCashier,
  kasirUsers = [],
  onRefreshProducts,
  onShowToast,
  initialSelectedProduct,
  onDeleteProduct,
  onNavigateToVendor,
  initialVendorName,
  settings,
}) => {
  // Sub-Tab Mode: 'restock' (PO & Bahan Masuk) | 'history' (Riwayat Log) | 'new_product' | 'edit_product'
  const [formMode, setFormMode] = useState<'restock' | 'history' | 'new_product' | 'edit_product'>('restock');

  // Master vendor list from vendorService
  const [vendorList, setVendorList] = useState<Vendor[]>(() => getStoredVendors());

  useEffect(() => {
    setVendorList(getStoredVendors());
    const handleSync = () => {
      setVendorList(getStoredVendors());
    };
    window.addEventListener('strukku-vendors-updated', handleSync);
    window.addEventListener('strukku-backup-restored', handleSync);
    return () => {
      window.removeEventListener('strukku-vendors-updated', handleSync);
      window.removeEventListener('strukku-backup-restored', handleSync);
    };
  }, []);

  // Quick Vendor Add / Edit Modal state directly inside BarangMasukView
  const [isQuickVendorModalOpen, setIsQuickVendorModalOpen] = useState<boolean>(false);
  const [vendorModalMode, setVendorModalMode] = useState<'add' | 'edit'>('add');
  const [editingVendorId, setEditingVendorId] = useState<string | null>(null);
  const [quickVendorNama, setQuickVendorNama] = useState<string>('');
  const [quickVendorKategori, setQuickVendorKategori] = useState<string>('Umum');
  const [quickVendorTelepon, setQuickVendorTelepon] = useState<string>('');
  const [quickVendorEmail, setQuickVendorEmail] = useState<string>('');
  const [quickVendorAlamat, setQuickVendorAlamat] = useState<string>('');
  const [quickVendorKontakPerson, setQuickVendorKontakPerson] = useState<string>('');
  const [quickVendorNomorRekening, setQuickVendorNomorRekening] = useState<string>('');
  const [quickVendorCatatan, setQuickVendorCatatan] = useState<string>('');
  const [isSavingQuickVendor, setIsSavingQuickVendor] = useState<boolean>(false);

  const handleOpenAddVendorModal = (initialName?: string) => {
    setVendorModalMode('add');
    setEditingVendorId(null);
    setQuickVendorNama(initialName || '');
    setQuickVendorKategori('Umum');
    setQuickVendorTelepon('');
    setQuickVendorEmail('');
    setQuickVendorAlamat('');
    setQuickVendorKontakPerson('');
    setQuickVendorNomorRekening('');
    setQuickVendorCatatan('');
    setIsQuickVendorModalOpen(true);
  };

  const handleOpenEditVendorModal = (v: Vendor) => {
    setVendorModalMode('edit');
    setEditingVendorId(v.id);
    setQuickVendorNama(v.nama);
    setQuickVendorKategori(v.kategori || 'Umum');
    setQuickVendorTelepon(v.telepon || '');
    setQuickVendorEmail(v.email || '');
    setQuickVendorAlamat(v.alamat || '');
    setQuickVendorKontakPerson(v.kontakPerson || '');
    setQuickVendorNomorRekening(v.nomorRekening || '');
    setQuickVendorCatatan(v.catatan || '');
    setIsQuickVendorModalOpen(true);
  };

  const handleSaveQuickVendor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickVendorNama.trim()) {
      onShowToast('Nama vendor wajib diisi!', 'error');
      return;
    }
    setIsSavingQuickVendor(true);
    try {
      const saved = await saveVendorRecord({
        id: editingVendorId || undefined,
        nama: quickVendorNama.trim(),
        kategori: quickVendorKategori.trim(),
        telepon: quickVendorTelepon.trim(),
        email: quickVendorEmail.trim(),
        alamat: quickVendorAlamat.trim(),
        kontakPerson: quickVendorKontakPerson.trim(),
        nomorRekening: quickVendorNomorRekening.trim(),
        catatan: quickVendorCatatan.trim(),
      });
      setVendorList(getStoredVendors());
      setVendorInput(saved.nama);
      setIsQuickVendorModalOpen(false);
      onShowToast(
        vendorModalMode === 'edit'
          ? `Data vendor "${saved.nama}" berhasil diperbarui!`
          : `Vendor baru "${saved.nama}" berhasil disimpan!`,
        'success'
      );
    } catch (err) {
      console.error(err);
      onShowToast('Gagal menyimpan vendor', 'error');
    } finally {
      setIsSavingQuickVendor(false);
    }
  };

  const handleQuickSaveTypedVendor = async () => {
    const trimmed = vendorInput.trim();
    if (!trimmed) return;
    try {
      const saved = await saveVendorRecord({
        nama: trimmed,
        kategori: 'Umum',
      });
      setVendorList(getStoredVendors());
      setVendorInput(saved.nama);
      onShowToast(`Vendor "${saved.nama}" berhasil ditambahkan ke master!`, 'success');
    } catch (err) {
      console.error(err);
      onShowToast('Gagal menyimpan vendor', 'error');
    }
  };

  // Quick "+ + Bahan Baru" Modal
  const [isQuickAddModalOpen, setIsQuickAddModalOpen] = useState<boolean>(false);
  const [targetRowForNewProduct, setTargetRowForNewProduct] = useState<string | null>(null);

  // Active product selector dropdown popup in PO row
  const [activePickerRowId, setActivePickerRowId] = useState<string | null>(null);
  const [pickerSearch, setPickerSearch] = useState<string>('');
  const [pickerCategory, setPickerCategory] = useState<string>('Semua');

  const pickerCategories = useMemo(() => {
    const s = new Set<string>();
    (products || []).forEach((p) => {
      if (p.kategori && p.kategori.trim()) s.add(p.kategori.trim());
    });
    return ['Semua', ...Array.from(s).sort()];
  }, [products]);

  // Auto-generate PO Number
  const generatePoNumber = () => {
    const year = new Date().getFullYear();
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `PO-${year}-${rand}`;
  };

  // -------------------------------------------------------------
  // PO FORM STATE
  // -------------------------------------------------------------
  const [noPo, setNoPo] = useState<string>(() => generatePoNumber());
  const [tanggalKedatangan, setTanggalKedatangan] = useState<string>(() => fDateInput(new Date()));
  const [vendorInput, setVendorInput] = useState<string>(() => {
    return initialVendorName || '';
  });

  useEffect(() => {
    if (initialVendorName) {
      setVendorInput(initialVendorName);
    }
  }, [initialVendorName]);

  // Keep vendorInput synchronized with available vendorList from Master Data
  useEffect(() => {
    const inputClean = (vendorInput || '').trim().toLowerCase();
    if (inputClean) {
      const exists = vendorList.some((v) => Boolean(v?.nama && v.nama.trim().toLowerCase() === inputClean));
      if (!exists && !initialVendorName && inputClean === 'pt. knitto tekstil indonesia (cbd)') {
        setVendorInput('');
      }
    }
  }, [vendorList, initialVendorName, vendorInput]);

  const selectedVendorObj = useMemo(() => {
    const inputClean = (vendorInput || '').trim().toLowerCase();
    if (!inputClean) return undefined;
    return vendorList.find(
      (v) => Boolean(v?.nama && v.nama.trim().toLowerCase() === inputClean)
    );
  }, [vendorList, vendorInput]);

  const isKnownVendor = useMemo(() => {
    const inputClean = (vendorInput || '').trim().toLowerCase();
    if (!inputClean) return false;
    return vendorList.some((v) => Boolean(v?.nama && v.nama.trim().toLowerCase() === inputClean));
  }, [vendorList, vendorInput]);
  const [gudangInput, setGudangInput] = useState<string>('Gudang Utama');
  const [catatanPembelian, setCatatanPembelian] = useState<string>('');

  // Automatic Expense Recording Feature (User request)
  const [catatPengeluaran, setCatatPengeluaran] = useState<boolean>(true);
  const [sumberKas, setSumberKas] = useState<string>('Kas Operasional Toko');
  const [kategoriPengeluaran, setKategoriPengeluaran] = useState<string>('Bahan Baku');

  // SPV/Owner Protection for unchecking catatPengeluaran
  const [isUncheckAuthModalOpen, setIsUncheckAuthModalOpen] = useState<boolean>(false);
  const [uncheckAuthSpvUser, setUncheckAuthSpvUser] = useState<string>('');
  const [uncheckAuthPassword, setUncheckAuthPassword] = useState<string>('');
  const [uncheckAuthError, setUncheckAuthError] = useState<string | null>(null);
  const [uncheckReason, setUncheckReason] = useState<string>('Pembayaran ditangani terpisah oleh Owner / Tempo khusus');
  const [uncheckApprovedBy, setUncheckApprovedBy] = useState<string | null>(null);

  // PO Item Rows - Default starts clean and unselected (waiting for user choice)
  const createEmptyRow = (prod: Product | null = null): PoItemRow => ({
    id: 'ROW-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    product: prod,
    qty: prod ? 1 : '',
    satuan: prod?.satuan || 'pcs',
    hargaBeli: prod ? Math.round((prod.harga || 10000) * 0.7) : '',
    warna: 'Standar',
    lotBatch: '',
    isEceran: false,
  });

  const [poRows, setPoRows] = useState<PoItemRow[]>([createEmptyRow(null)]);

  // Sync initialSelectedProduct if navigated from Dashboard restock button
  useEffect(() => {
    if (initialSelectedProduct) {
      setFormMode('restock');
      const latest = products.find(
        (p) =>
          (p.kode && p.kode === initialSelectedProduct.kode) ||
          p.nama.toLowerCase() === initialSelectedProduct.nama.toLowerCase()
      ) || initialSelectedProduct;

      setPoRows([
        {
          id: 'ROW-' + Date.now(),
          product: latest,
          qty: 10,
          satuan: latest.satuan || 'pcs',
          hargaBeli: Math.round((latest.harga || 10000) * 0.7),
          warna: 'Standar',
          lotBatch: '',
          isEceran: false,
        }
      ]);
    }
  }, [initialSelectedProduct, products]);

  // Row operations - Starts with an empty row waiting for user selection
  const handleAddRow = () => {
    const newRow = createEmptyRow(null);
    setPoRows((prev) => [...prev, newRow]);
  };

  const handleUpdateRow = (id: string, updates: Partial<PoItemRow>) => {
    setPoRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = { ...r, ...updates };
        if (updates.product) {
          updated.satuan = updates.product.satuan || 'pcs';
          if (!r.hargaBeli || Number(r.hargaBeli) === 0) {
            updated.hargaBeli = Math.round((updates.product.harga || 10000) * 0.7);
          }
          if (!r.qty || Number(r.qty) === 0) {
            updated.qty = 1;
          }
        }
        return updated;
      })
    );
  };

  const handleResetOrDeleteRow = (id: string) => {
    if (poRows.length === 1) {
      // Reset single row to empty
      setPoRows([createEmptyRow(null)]);
      onShowToast('Baris item dikosongkan', 'info');
    } else {
      setPoRows((prev) => prev.filter((r) => r.id !== id));
    }
  };

  // Total Tagihan PO Calculation
  const totalTagihanPo = useMemo(() => {
    return poRows.reduce((acc, row) => {
      const q = parseNumberInput(row.qty);
      const h = parseNumberInput(row.hargaBeli);
      return acc + (q * h);
    }, 0);
  }, [poRows]);

  const totalQtyPo = useMemo(() => {
    return poRows.reduce((acc, row) => acc + parseNumberInput(row.qty), 0);
  }, [poRows]);

  // -------------------------------------------------------------
  // QUICK ADD MASTER BAHAN / PRODUK MODAL STATE
  // -------------------------------------------------------------
  const [quickKode, setQuickKode] = useState<string>('');
  const [quickNama, setQuickNama] = useState<string>('');
  const [quickKategori, setQuickKategori] = useState<string>('Bahan Baku');
  const [quickSatuan, setQuickSatuan] = useState<string>('kg');
  const [quickHargaJual, setQuickHargaJual] = useState<number | string>('');
  const [quickHargaBeli, setQuickHargaBeli] = useState<number | string>('');
  const [quickStokAwal, setQuickStokAwal] = useState<number | string>(0);
  const [quickSupplier, setQuickSupplier] = useState<string>('');
  const [quickCatatan, setQuickCatatan] = useState<string>('');

  const generateUniqueKode = (prefix = 'PRD-') => {
    let nextNum = products.length + 1;
    let candidate = prefix + String(nextNum).padStart(3, '0');
    while (products.some((p) => (p.kode || '').trim().toUpperCase() === candidate.toUpperCase())) {
      nextNum++;
      candidate = prefix + String(nextNum).padStart(3, '0');
    }
    return candidate;
  };

  const handleOpenQuickAddModal = (rowId?: string) => {
    setTargetRowForNewProduct(rowId || null);
    setQuickKode(generateUniqueKode());
    setQuickNama('');
    setQuickKategori('Bahan Baku');
    setQuickSatuan('kg');
    setQuickHargaJual('');
    setQuickHargaBeli('');
    setQuickStokAwal(0);
    setQuickSupplier(vendorInput || '');
    setQuickCatatan('');
    setIsQuickAddModalOpen(true);
  };

  const duplicateQuickProductByKode = products.find(
    (p) => quickKode.trim() && (p.kode || '').trim().toUpperCase() === quickKode.trim().toUpperCase()
  );

  const duplicateQuickProductByNama = products.find(
    (p) => quickNama.trim() && (p.nama || '').trim().toLowerCase() === quickNama.trim().toLowerCase()
  );

  const handleSaveQuickProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickKode.trim() || !quickNama.trim()) {
      onShowToast('Kode dan Nama Bahan/Produk wajib diisi', 'error');
      return;
    }
    if (duplicateQuickProductByKode) {
      onShowToast(`Kode "${quickKode}" sudah dipakai oleh "${duplicateQuickProductByKode.nama}"`, 'error');
      return;
    }

    const hargaJualNum = Number(quickHargaJual) || 0;
    const hargaBeliNum = Number(quickHargaBeli) || Math.round(hargaJualNum * 0.7);
    const stokAwalNum = Number(quickStokAwal) || 0;

    const newProd: Product = {
      kode: quickKode.trim().toUpperCase(),
      nama: quickNama.trim(),
      harga: hargaJualNum,
      kategori: quickKategori.trim() || 'Bahan Baku',
      satuan: quickSatuan.trim() || 'kg',
      stok: stokAwalNum.toString(),
      tipeHarga: quickKategori === 'Banner' ? 'ukuran' : 'fix',
    };

    setIsSubmitting(true);
    try {
      // 1. Save to Firebase and GAS
      saveProductFirebase(newProd).catch(() => {});
      await addNewProduct(newProd);

      // If initial stock was given, record stock-in
      if (stokAwalNum > 0) {
        const now = new Date();
        await addStockIn({
          kode: newProd.kode,
          nama: newProd.nama,
          qty: stokAwalNum,
          satuan: newProd.satuan,
          supplier: quickSupplier.trim() || vendorInput || 'Pendaftaran Bahan Baru',
          cashier: currentCashier || 'Admin',
          date: fDateInput(now),
          time: fTime(now),
          catatan: `[Stok Awal Bahan Baru] ${quickCatatan}`.trim(),
        });
      }

      onShowToast(`Bahan baru "${newProd.nama}" berhasil didaftarkan ke master data!`, 'success');
      onRefreshProducts();

      // If a row was waiting for this product, assign it
      if (targetRowForNewProduct) {
        handleUpdateRow(targetRowForNewProduct, {
          product: newProd,
          satuan: newProd.satuan,
          hargaBeli: hargaBeliNum > 0 ? hargaBeliNum : 90000,
        });
      } else {
        // Or update first row if empty or append new row
        setPoRows((prev) => {
          if (prev.length > 0 && !prev[0].product) {
            return [{ ...prev[0], product: newProd, satuan: newProd.satuan, hargaBeli: hargaBeliNum || 90000 }];
          }
          return [
            ...prev,
            {
              id: 'ROW-' + Date.now(),
              product: newProd,
              qty: 50,
              satuan: newProd.satuan,
              hargaBeli: hargaBeliNum || 90000,
              warna: 'Hitam',
              lotBatch: '',
              isEceran: false,
            }
          ];
        });
      }

      setIsQuickAddModalOpen(false);
      setTargetRowForNewProduct(null);
    } catch (err: any) {
      onShowToast(`Gagal menambahkan master bahan: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // -------------------------------------------------------------
  // TAB 2: STANDALONE NEW PRODUCT STATE
  // -------------------------------------------------------------
  const [newKode, setNewKode] = useState<string>('');
  const [newNama, setNewNama] = useState<string>('');
  const [newKategori, setNewKategori] = useState<string>('Banner');
  const [newPricingScheme, setNewPricingScheme] = useState<'meter_fix' | 'per_meter' | 'per_cm' | 'a3_plus' | 'lembaran_custom'>('meter_fix');
  const [newHarga, setNewHarga] = useState<number | string>('');
  const [newSatuan, setNewSatuan] = useState<string>('pcs');
  const [newStokAwal, setNewStokAwal] = useState<number | string>(10);
  const [newSupplier, setNewSupplier] = useState<string>('');
  const [newCatatan, setNewCatatan] = useState<string>('');

  useEffect(() => {
    if (formMode === 'new_product' && !newKode) {
      setNewKode(generateUniqueKode());
    }
  }, [formMode, products]);

  // -------------------------------------------------------------
  // TAB 3: EDIT PRODUCT STATE
  // -------------------------------------------------------------
  const [editSelectedProduct, setEditSelectedProduct] = useState<Product | null>(null);
  const [editSearch, setEditSearch] = useState<string>('');
  const [editKode, setEditKode] = useState<string>('');
  const [editNama, setEditNama] = useState<string>('');
  const [editKategori, setEditKategori] = useState<string>('Bahan Baku');
  const [editPricingScheme, setEditPricingScheme] = useState<'meter_fix' | 'per_meter' | 'per_cm' | 'a3_plus' | 'lembaran_custom'>('meter_fix');
  const [editHarga, setEditHarga] = useState<number | string>('');
  const [editSatuan, setEditSatuan] = useState<string>('pcs');
  const [editStok, setEditStok] = useState<number | string>(0);
  const [editCatatan, setEditCatatan] = useState<string>('');

  const startEditProduct = (p: Product) => {
    setFormMode('edit_product');
    setEditSelectedProduct(p);
    setEditKode(p.kode || '');
    setEditNama(p.nama || '');
    setEditKategori(p.kategori || 'Lainnya');
    setEditPricingScheme((p.pricingScheme as any) || (p.tipeHarga === 'ukuran' ? 'per_meter' : 'meter_fix'));
    setEditHarga(p.harga || 0);
    setEditSatuan(p.satuan || 'pcs');
    setEditStok(p.stok || '0');
    setEditCatatan('');
  };

  const handleCancelEditProduct = () => {
    setEditSelectedProduct(null);
    setEditSearch('');
    setEditKode('');
    setEditNama('');
    setEditKategori('Bahan Baku');
    setEditPricingScheme('meter_fix');
    setEditHarga('');
    setEditSatuan('pcs');
    setEditStok(0);
    setEditCatatan('');
    setIsStokUnlocked(false);
    onShowToast('Pengeditan produk dibatalkan', 'info');
  };

  const duplicateProductByEditKode = useMemo(() => {
    if (!editKode.trim() || !editSelectedProduct) return null;
    const cleanKode = editKode.trim().toLowerCase();
    const originalKode = editSelectedProduct.kode.trim().toLowerCase();
    if (cleanKode === originalKode) return null;
    return products.find(
      (p) => p.kode.trim().toLowerCase() === cleanKode
    ) || null;
  }, [editKode, editSelectedProduct, products]);

  const filteredEditProducts = products.filter((p) => {
    const q = editSearch.toLowerCase().trim();
    if (!q) return true;
    return p.nama.toLowerCase().includes(q) || p.kode.toLowerCase().includes(q) || p.kategori.toLowerCase().includes(q);
  });

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Authorization for deletion: Only Owner & SPV
  const isCurrentCashierSpv = checkIsSpvOrOwner(currentCashier, kasirUsers);
  const [authSpvUser, setAuthSpvUser] = useState<string>('');
  const [authPassword, setAuthPassword] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Authorization for Manual Stock Edit in "Kelola / Hapus": Only Owner & SPV
  const [isStokUnlocked, setIsStokUnlocked] = useState<boolean>(false);
  const [isStokAuthModalOpen, setIsStokAuthModalOpen] = useState<boolean>(false);
  const [stokAuthSpvUser, setStokAuthSpvUser] = useState<string>('');
  const [stokAuthPassword, setStokAuthPassword] = useState<string>('');
  const [stokAuthError, setStokAuthError] = useState<string | null>(null);

  const canEditStok = isCurrentCashierSpv || isStokUnlocked;

  useEffect(() => {
    if (isCurrentCashierSpv) {
      setStokAuthSpvUser(currentCashier);
    } else {
      const spvCandidates = (kasirUsers || []).filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (spvCandidates.length > 0) {
        setStokAuthSpvUser(spvCandidates[0].nama);
      } else {
        setStokAuthSpvUser('Owner');
      }
    }
  }, [currentCashier, kasirUsers, isCurrentCashierSpv]);

  const handleVerifyStokAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setStokAuthError(null);

    if (!stokAuthSpvUser) {
      setStokAuthError('Pilih akun Owner atau SPV sebagai otorisator.');
      return;
    }

    if (!checkIsSpvOrOwner(stokAuthSpvUser, kasirUsers) && 
        stokAuthSpvUser.toLowerCase() !== 'owner' && 
        stokAuthSpvUser.toLowerCase() !== 'spv') {
      setStokAuthError(`Akses Ditolak: Akun "${stokAuthSpvUser}" bukan Supervisor atau Owner!`);
      return;
    }

    const targetUser = (kasirUsers || []).find((u) => u.nama.trim().toLowerCase() === stokAuthSpvUser.trim().toLowerCase());
    const validPass = targetUser?.password?.trim() || 'ervo123';

    if (stokAuthPassword.trim() !== validPass) {
      setStokAuthError('Password otorisasi salah. Hubungi SPV/Owner untuk mendapatkan izin.');
      return;
    }

    setIsStokUnlocked(true);
    setIsStokAuthModalOpen(false);
    setStokAuthPassword('');
    setStokAuthError(null);
    onShowToast(`✓ Otorisasi Berhasil: Izin ubah stok diberikan oleh ${stokAuthSpvUser}`, 'success');
  };

  const handleRequestDelete = (prod: Product) => {
    setProductToDelete(prod);
    setAuthPassword('');
    setAuthError(null);
    if (isCurrentCashierSpv) {
      setAuthSpvUser(currentCashier);
    } else {
      const spvCandidates = (kasirUsers || []).filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else {
        setAuthSpvUser('Owner');
      }
    }
  };

  const handleDeleteConfirmed = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!productToDelete) return;
    setAuthError(null);

    let authorizedOperator = currentCashier;

    if (!isCurrentCashierSpv) {
      if (!authSpvUser) {
        setAuthError('Pilih akun Owner atau SPV sebagai otorisator.');
        return;
      }
      if (!checkIsSpvOrOwner(authSpvUser, kasirUsers) && authSpvUser.toLowerCase() !== 'owner' && authSpvUser.toLowerCase() !== 'spv') {
        setAuthError(`Akses Ditolak: Akun "${authSpvUser}" bukan Supervisor atau Owner!`);
        return;
      }
      const targetUser = (kasirUsers || []).find((u) => u.nama.trim().toLowerCase() === authSpvUser.trim().toLowerCase());
      const validPass = targetUser?.password?.trim() || 'ervo123';
      if (authPassword.trim() !== validPass) {
        setAuthError(`Password / PIN otorisasi untuk ${authSpvUser} salah! Akses hapus produk ditolak.`);
        return;
      }
      authorizedOperator = authSpvUser;
    }

    setIsDeleting(true);
    try {
      if (onDeleteProduct) {
        await onDeleteProduct(productToDelete.kode, productToDelete.nama, authorizedOperator);
      }
      if (editSelectedProduct && (editSelectedProduct.kode === productToDelete.kode || editSelectedProduct.nama === productToDelete.nama)) {
        setEditSelectedProduct(null);
      }
      setProductToDelete(null);
      setAuthPassword('');
      setAuthError(null);
      onRefreshProducts();
    } catch (err: any) {
      onShowToast(`Gagal menghapus produk: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // History List
  const [history, setHistory] = useState<StockInRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(false);

  const loadHistory = async () => {
    setIsLoadingHistory(true);
    const data = await fetchStockInHistory();
    setHistory(data);
    setIsLoadingHistory(false);
  };

  useEffect(() => {
    loadHistory();
    const unsub = subscribeStockIn((records) => {
      if (records && records.length > 0) {
        setHistory(records);
      }
    });
    return () => unsub();
  }, []);

  // Delete Stock In Record state & handlers (Active only for SPV & Owner)
  const [stockInToDelete, setStockInToDelete] = useState<StockInRecord | null>(null);
  const [rollbackStockOnDelete, setRollbackStockOnDelete] = useState<boolean>(true);
  const [isDeletingStockIn, setIsDeletingStockIn] = useState<boolean>(false);

  const handleRequestDeleteStockIn = (record: StockInRecord) => {
    if (!isCurrentCashierSpv) {
      onShowToast('Akses Ditolak: Fitur hapus riwayat barang masuk hanya aktif saat login sebagai SPV atau Owner!', 'error');
      return;
    }
    setStockInToDelete(record);
    setRollbackStockOnDelete(Number(record.qty) > 0);
  };

  const handleConfirmDeleteStockIn = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!stockInToDelete) return;
    if (!isCurrentCashierSpv) {
      onShowToast('Akses Ditolak: Hanya SPV atau Owner yang berwenang menghapus riwayat barang masuk!', 'error');
      setStockInToDelete(null);
      return;
    }

    setIsDeletingStockIn(true);
    try {
      const qtyNum = Number(stockInToDelete.qty) || 0;
      const prodKode = stockInToDelete.kode || stockInToDelete.kodeProduct || '';
      const prodNama = stockInToDelete.nama || stockInToDelete.namaProduct || '';

      // 1. Delete in Firebase (and rollback stock if opted)
      deleteStockInFirebase(
        stockInToDelete.id,
        rollbackStockOnDelete && qtyNum > 0 && prodKode ? { kode: prodKode, qty: qtyNum } : undefined
      ).catch((err) => console.warn('deleteStockInFirebase error:', err));

      // 2. Delete in GAS & local cache
      await deleteStockInRecord(stockInToDelete.id, {
        kode: prodKode,
        nama: prodNama,
        qty: qtyNum,
        rollbackStock: rollbackStockOnDelete,
      });

      // 3. Update component state
      setHistory((prev) => prev.filter((r) => r.id !== stockInToDelete.id));

      // 4. Refresh product list if stock rolled back
      if (rollbackStockOnDelete && qtyNum > 0) {
        onRefreshProducts();
      }

      const rollbackMsg = rollbackStockOnDelete && qtyNum > 0
        ? ` & stok produk disesuaikan (-${qtyNum} ${stockInToDelete.satuan})`
        : '';
      onShowToast(`✓ Catatan barang masuk "${prodNama || stockInToDelete.id}" berhasil dihapus${rollbackMsg}!`, 'success');

      setStockInToDelete(null);
    } catch (err: any) {
      console.error(err);
      onShowToast(`Gagal menghapus riwayat barang masuk: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsDeletingStockIn(false);
    }
  };

  // History Filters & Stats for Dedicated Riwayat Sub-Tab
  const [historySearch, setHistorySearch] = useState<string>('');
  const [historyFilterSupplier, setHistoryFilterSupplier] = useState<string>('ALL');
  const [historyFilterType, setHistoryFilterType] = useState<string>('ALL');

  const filteredHistory = useMemo(() => {
    return (history || []).filter((item) => {
      // 1. Search query
      if (historySearch.trim()) {
        const q = historySearch.toLowerCase().trim();
        const matchesName = (item.nama || '').toLowerCase().includes(q);
        const matchesCode = (item.kode || '').toLowerCase().includes(q);
        const matchesPo = (item.noPo || '').toLowerCase().includes(q);
        const matchesSupp = (item.supplier || '').toLowerCase().includes(q);
        const matchesCashier = (item.cashier || '').toLowerCase().includes(q);
        const matchesNotes = (item.catatan || '').toLowerCase().includes(q);
        if (!matchesName && !matchesCode && !matchesPo && !matchesSupp && !matchesCashier && !matchesNotes) {
          return false;
        }
      }

      // 2. Filter Supplier
      if (historyFilterSupplier !== 'ALL') {
        if ((item.supplier || '').trim().toLowerCase() !== historyFilterSupplier.trim().toLowerCase()) {
          return false;
        }
      }

      // 3. Filter Type
      if (historyFilterType === 'po') {
        if (!item.noPo) return false;
      } else if (historyFilterType === 'restock') {
        if (item.noPo || Number(item.qty) <= 0) return false;
      } else if (historyFilterType === 'edit') {
        if (Number(item.qty) > 0) return false;
      }

      return true;
    });
  }, [history, historySearch, historyFilterSupplier, historyFilterType]);

  const uniqueHistorySuppliers = useMemo(() => {
    const set = new Set<string>();
    (history || []).forEach((it) => {
      if (it.supplier && it.supplier.trim() && it.supplier !== '-') {
        set.add(it.supplier.trim());
      }
    });
    return Array.from(set).sort();
  }, [history]);

  const historyStats = useMemo(() => {
    let totalQty = 0;
    let totalBiaya = 0;
    const poSet = new Set<string>();

    (history || []).forEach((h) => {
      const q = Number(h.qty) || 0;
      if (q > 0) totalQty += q;
      const b = Number(h.totalBiaya) || 0;
      if (b > 0) totalBiaya += b;
      if (h.noPo && h.noPo.trim()) {
        poSet.add(h.noPo.trim());
      }
    });

    return {
      totalLogs: history.length,
      totalQty,
      totalBiaya,
      totalPoCount: poSet.size,
    };
  }, [history]);

  // -------------------------------------------------------------
  // HANDLE SUBMIT PO & RESTOCK BARANG MASUK
  // -------------------------------------------------------------
  const handleSavePoStockIn = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!noPo.trim()) {
      onShowToast('Nomor PO / Faktur Masuk wajib diisi', 'error');
      return;
    }

    if (!vendorInput.trim()) {
      onShowToast('Pilih atau ketik Vendor / Supplier pengirim', 'error');
      return;
    }

    // Filter valid rows with a product and qty > 0 (supports decimal like 0,1 or 0.1)
    const validRows = poRows.filter((r) => r.product && parseNumberInput(r.qty) > 0);
    if (validRows.length === 0) {
      onShowToast('Tambahkan minimal 1 baris bahan baku/produk dengan jumlah valid (misal 0,1 atau 1)', 'error');
      return;
    }

    setIsSubmitting(true);
    const now = new Date();
    const timeNow = fTime(now);
    const dateFormatted = tanggalKedatangan || fDateInput(now);

    try {
      // Process Stock In for all items in the PO
      for (const row of validRows) {
        const prod = row.product!;
        const qtyNum = parseNumberInput(row.qty);
        const hargaBeliNum = parseNumberInput(row.hargaBeli);

        // Formulate detailed note
        const detailParts: string[] = [`[${noPo}]`];
        if (row.warna && row.warna !== 'Standar') detailParts.push(`Warna: ${row.warna}`);
        if (row.lotBatch) detailParts.push(`Lot: ${row.lotBatch}`);
        if (row.isEceran) detailParts.push(`(Eceran/Pecahan)`);
        if (gudangInput) detailParts.push(`Gudang: ${gudangInput}`);
        if (catatanPembelian.trim()) detailParts.push(catatanPembelian.trim());

        const noteText = detailParts.join(' • ');

        const payload: Omit<StockInRecord, 'id'> = {
          kode: prod.kode,
          nama: prod.nama,
          qty: qtyNum,
          satuan: row.satuan || prod.satuan || 'pcs',
          supplier: vendorInput.trim(),
          cashier: currentCashier || 'Admin',
          date: dateFormatted,
          time: timeNow,
          catatan: noteText,
          noPo: noPo.trim(),
          hargaBeli: hargaBeliNum,
          totalBiaya: qtyNum * hargaBeliNum,
          gudang: gudangInput,
        };

        // Save to Firebase (persisting stock-in log & exactly once stock increment)
        await saveStockInFirebase({
          id: `STOCKIN-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          ...payload,
        }).catch((err) => {
          console.warn('Firebase saveStockIn notice:', err);
        });

        // Save to Google Sheets without duplicate local stock increment
        await addStockIn(payload, { updateLocalStock: false });
      }

      // 2. USER REQUIREMENT: Automatic Expense Recording
      if (catatPengeluaran && totalTagihanPo > 0) {
        const itemSummary = validRows
          .map((r) => `${r.product?.nama} (${r.qty} ${r.satuan})`)
          .slice(0, 3)
          .join(', ') + (validRows.length > 3 ? ` +${validRows.length - 3} lainnya` : '');

        const expenseKeterangan = `Pembelian Bahan/Stok [${noPo}] - ${vendorInput}: ${itemSummary}${catatanPembelian ? ' | ' + catatanPembelian : ''}`;

        addExpenseRecord({
          tanggal: dateFormatted,
          kategori: kategoriPengeluaran || 'Bahan Baku',
          keterangan: expenseKeterangan,
          nominal: totalTagihanPo,
          pj: `${currentCashier || 'Kasir'} (${sumberKas})`,
        });
      }

      // Success notification
      const expenseMsg = catatPengeluaran && totalTagihanPo > 0 
        ? ` & pengeluaran ${fRp(totalTagihanPo)} tercatat otomatis!` 
        : uncheckApprovedBy
        ? ` (Pengeluaran tidak dicatat atas izin ${uncheckApprovedBy})`
        : '!';
      const displayTotalQty = Number.isInteger(totalQtyPo) ? totalQtyPo : parseFloat(totalQtyPo.toFixed(2));
      onShowToast(`PO "${noPo}" berhasil disimpan! Stok bertambah (+${displayTotalQty} unit)${expenseMsg}`, 'success');

      // Reset form & generate fresh PO
      setNoPo(generatePoNumber());
      setVendorInput('');
      setCatatanPembelian('');
      setPoRows([createEmptyRow(null)]);
      setCatatPengeluaran(true); // Return to default active state for safety
      setUncheckApprovedBy(null);

      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast(`Gagal memproses pembelian PO: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // -------------------------------------------------------------
  // SPV / OWNER AUTHORIZATION TO UNCHECK EXPENSE RECORDING
  // -------------------------------------------------------------
  const handleToggleCatatPengeluaran = (targetChecked: boolean) => {
    if (targetChecked) {
      // Re-activating automatic recording is always allowed without approval
      setCatatPengeluaran(true);
      setUncheckApprovedBy(null);
      onShowToast('Otomatis catat pengeluaran ke pembukuan diaktifkan kembali', 'info');
    } else {
      // Unchecking requires SPV or Owner approval
      setUncheckAuthPassword('');
      setUncheckAuthError(null);
      setUncheckReason('Pembayaran ditangani terpisah oleh Owner / Tempo khusus');

      if (isCurrentCashierSpv) {
        setUncheckAuthSpvUser(currentCashier);
      } else {
        const spvCandidates = (kasirUsers || []).filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
        if (spvCandidates.length > 0) {
          setUncheckAuthSpvUser(spvCandidates[0].nama);
        } else {
          setUncheckAuthSpvUser('Owner');
        }
      }
      setIsUncheckAuthModalOpen(true);
    }
  };

  const handleConfirmUncheck = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setUncheckAuthError(null);

    if (!uncheckAuthSpvUser) {
      setUncheckAuthError('Pilih akun Owner atau SPV sebagai otorisator.');
      return;
    }

    if (!checkIsSpvOrOwner(uncheckAuthSpvUser, kasirUsers) && 
        uncheckAuthSpvUser.toLowerCase() !== 'owner' && 
        uncheckAuthSpvUser.toLowerCase() !== 'spv') {
      setUncheckAuthError(`Akses Ditolak: Akun "${uncheckAuthSpvUser}" bukan Supervisor atau Owner!`);
      return;
    }

    const targetUser = (kasirUsers || []).find(
      (u) => u.nama.trim().toLowerCase() === uncheckAuthSpvUser.trim().toLowerCase()
    );
    const validPass = targetUser?.password?.trim() || 'ervo123';

    if (uncheckAuthPassword.trim() !== validPass) {
      setUncheckAuthError(`Password / PIN otorisasi untuk ${uncheckAuthSpvUser} salah! Akses ditolak.`);
      return;
    }

    // Success!
    setCatatPengeluaran(false);
    setUncheckApprovedBy(uncheckAuthSpvUser);
    setIsUncheckAuthModalOpen(false);
    onShowToast(`Pencatatan pembukuan otomatis dinonaktifkan (Disetujui oleh: ${uncheckAuthSpvUser})`, 'success');
  };

  // -------------------------------------------------------------
  // HANDLE SAVE STANDALONE NEW PRODUCT
  // -------------------------------------------------------------
  const handleSaveNewProduct = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newKode.trim() || !newNama.trim()) {
      onShowToast('Kode dan Nama Produk wajib diisi', 'error');
      return;
    }

    const duplicateProductByKode = products.find(
      (p) => newKode.trim() && (p.kode || '').trim().toUpperCase() === newKode.trim().toUpperCase()
    );
    if (duplicateProductByKode) {
      onShowToast(`Kode produk "${newKode.trim().toUpperCase()}" sudah digunakan oleh "${duplicateProductByKode.nama}". Gunakan kode unik lain!`, 'error');
      return;
    }

    const hargaNum = Number(newHarga);
    if (isNaN(hargaNum) || hargaNum < 0) {
      onShowToast('Harga jual produk tidak valid', 'error');
      return;
    }

    const stokAwalNum = parseNumberInput(newStokAwal);

    setIsSubmitting(true);
    const now = new Date();

    const createdProduct: Product = {
      kode: newKode.trim().toUpperCase(),
      nama: newNama.trim(),
      harga: hargaNum,
      kategori: newKategori.trim() || 'Umum',
      satuan: newSatuan.trim() || 'pcs',
      stok: String(newStokAwal).includes(',') ? String(stokAwalNum) : String(newStokAwal || '0'),
      tipeHarga: newPricingScheme === 'per_meter' || newPricingScheme === 'per_cm' ? 'ukuran' : 'fix',
      pricingScheme: newPricingScheme,
    };

    try {
      saveProductFirebase(createdProduct).catch(() => {});
      await addNewProduct(createdProduct);

      if (stokAwalNum > 0) {
        const stockInPayload = {
          kode: createdProduct.kode,
          nama: createdProduct.nama,
          qty: stokAwalNum,
          satuan: createdProduct.satuan,
          supplier: newSupplier.trim() || 'Stok Awal Pendaftaran',
          cashier: currentCashier || 'Admin',
          date: fDateInput(now),
          time: fTime(now),
          catatan: `[Produk Baru] ${newCatatan.trim()}`.trim(),
        };
        await addStockIn(stockInPayload);
      }

      onShowToast(`Produk baru "${createdProduct.nama}" berhasil ditambahkan ke katalog & Sheet!`, 'success');

      setNewNama('');
      setNewHarga('');
      setNewSupplier('');
      setNewCatatan('');
      setNewKode(generateUniqueKode());
      onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      onShowToast('Gagal menambahkan produk baru', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // -------------------------------------------------------------
  // HANDLE SAVE EDIT PRODUCT
  // -------------------------------------------------------------
  const handleSaveEditProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editSelectedProduct) {
      onShowToast('Pilih produk yang ingin diedit terlebih dahulu', 'error');
      return;
    }

    if (!editKode.trim()) {
      onShowToast('Kode produk tidak boleh kosong', 'error');
      return;
    }

    if (duplicateProductByEditKode) {
      onShowToast(`Kode produk "${editKode.trim()}" sudah digunakan oleh produk "${duplicateProductByEditKode.nama}"!`, 'error');
      return;
    }

    if (!editNama.trim()) {
      onShowToast('Nama produk tidak boleh kosong', 'error');
      return;
    }

    const hargaNum = Number(editHarga);
    if (isNaN(hargaNum) || hargaNum < 0) {
      onShowToast('Harga jual produk tidak valid', 'error');
      return;
    }

    setIsSubmitting(true);
    const now = new Date();

    const changes: string[] = [];
    if (editSelectedProduct.kode.trim() !== editKode.trim()) {
      changes.push(`Kode: "${editSelectedProduct.kode}" ➔ "${editKode.trim()}"`);
    }
    if (editSelectedProduct.nama.trim() !== editNama.trim()) {
      changes.push(`Nama: "${editSelectedProduct.nama}" ➔ "${editNama.trim()}"`);
    }
    if ((editSelectedProduct.kategori || '').trim() !== editKategori.trim()) {
      changes.push(`Kategori: "${editSelectedProduct.kategori || 'Lainnya'}" ➔ "${editKategori.trim()}"`);
    }
    if (Number(editSelectedProduct.harga) !== hargaNum) {
      changes.push(`Harga: ${fRp(Number(editSelectedProduct.harga))} ➔ ${fRp(hargaNum)}`);
    }
    if ((editSelectedProduct.satuan || '').trim() !== editSatuan.trim()) {
      changes.push(`Satuan: "${editSelectedProduct.satuan || 'pcs'}" ➔ "${editSatuan.trim()}"`);
    }
    const parsedEditStok = parseNumberInput(editStok);
    const parsedOrigStok = parseNumberInput(editSelectedProduct.stok);
    if (parsedOrigStok !== parsedEditStok) {
      if (!canEditStok) {
        onShowToast('Akses Ditolak: Hanya Owner dan SPV yang berhak mengubah kuantitas stok produk!', 'error');
        setStokAuthPassword('');
        setStokAuthError(null);
        setIsStokAuthModalOpen(true);
        setIsSubmitting(false);
        return;
      }
      changes.push(`Stok: ${editSelectedProduct.stok || '0'} ➔ ${editStok}`);
    }

    let changeNote = '[Edit Produk] ' + (changes.length > 0 ? changes.join(', ') : 'Penyesuaian Data');
    if (editCatatan.trim()) {
      changeNote += ` | ${editCatatan.trim()}`;
    }

    const cleanEditStok = String(editStok ?? '').trim().replace(',', '.');
    const parsedCleanEditStok = parseFloat(cleanEditStok);
    const finalStokStr = canEditStok
      ? (isNaN(parsedCleanEditStok) ? '0' : String(parsedCleanEditStok))
      : String(editSelectedProduct.stok ?? '0');

    const updatedProd: Product = {
      ...editSelectedProduct,
      kode: editKode.trim(),
      nama: editNama.trim(),
      kategori: editKategori.trim() || 'Lainnya',
      harga: hargaNum,
      satuan: editSatuan.trim() || 'pcs',
      stok: finalStokStr,
      tipeHarga: editPricingScheme === 'per_meter' || editPricingScheme === 'per_cm' ? 'ukuran' : 'fix',
      pricingScheme: editPricingScheme,
    };

    try {
      const stockInPayload = {
        kode: updatedProd.kode,
        nama: updatedProd.nama,
        qty: 0,
        satuan: updatedProd.satuan,
        supplier: 'Penyesuaian / Edit Produk',
        cashier: currentCashier || 'Admin',
        date: fDateInput(now),
        time: fTime(now),
        catatan: changeNote,
      };
      await addStockIn(stockInPayload);

      const auditStockInId = 'STK-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
      saveStockInFirebase({
        ...stockInPayload,
        id: auditStockInId,
      }).catch(() => {});

      // 1. Direct Firebase Firestore update (Primary Cloud Database)
      await updateProductFirebase(
        updatedProd,
        editSelectedProduct.kode,
        editSelectedProduct.nama
      );

      // 2. Also update via gasService (Google Sheets sync & local fallback)
      const res = await updateProductDetails(
        updatedProd,
        editSelectedProduct.kode,
        editSelectedProduct.nama
      );

      if (res.success) {
        onShowToast(`Produk "${updatedProd.nama}" & data berhasil diperbarui dan dicatat ke Riwayat!`, 'success');
      } else {
        onShowToast(`Produk "${updatedProd.nama}" diperbarui secara lokal dan dicatat di Riwayat.`, 'info');
      }

      setEditSelectedProduct(null);
      setEditSearch('');
      setEditCatatan('');
      await onRefreshProducts();
      await loadHistory();
    } catch (err: any) {
      console.error('Error updating product:', err);
      onShowToast('Gagal memperbarui data produk: ' + (err?.message || 'Terjadi kesalahan'), 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter products for the active row's dropdown picker
  const filteredPickerProducts = useMemo(() => {
    let list = products;
    if (pickerCategory && pickerCategory !== 'Semua') {
      list = list.filter((p) => (p.kategori || '').toLowerCase() === pickerCategory.toLowerCase());
    }
    const q = pickerSearch.toLowerCase().trim();
    if (!q) return list;
    return list.filter(
      (p) =>
        p.nama.toLowerCase().includes(q) ||
        p.kode.toLowerCase().includes(q) ||
        p.kategori.toLowerCase().includes(q)
    );
  }, [products, pickerSearch, pickerCategory]);

  // -------------------------------------------------------------
  // REUSABLE PO FORM CONTENT (Used in embedded card and modal dialog)
  // -------------------------------------------------------------
  const renderPoFormCore = () => (
    <form onSubmit={handleSavePoStockIn} className="space-y-4">
      {/* Top Form Fields (Grid 2 cols on md) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* No PO / Faktur Masuk */}
        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1">
            No PO / Faktur Masuk <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={noPo}
              onChange={(e) => setNoPo(e.target.value)}
              placeholder="Contoh: PO-2026-7658"
              className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <button
              type="button"
              onClick={() => setNoPo(generatePoNumber())}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded-lg border border-indigo-200 transition"
              title="Buat nomor PO acak baru"
            >
              Auto No
            </button>
          </div>
        </div>

        {/* Tanggal Kedatangan */}
        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1">
            Tanggal Kedatangan <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              type="date"
              required
              value={tanggalKedatangan}
              onChange={(e) => setTanggalKedatangan(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>

        {/* Pilih Vendor / Supplier */}
        <div className="md:col-span-2">
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
              <span>Pilih Vendor / Supplier</span>
              <span className="text-red-500">*</span>
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleOpenAddVendorModal(vendorInput)}
                className="text-[11px] font-extrabold text-emerald-600 hover:text-emerald-800 flex items-center gap-1 transition active:scale-95 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200"
                title="Tambah Vendor Baru Langsung"
              >
                <Plus className="w-3 h-3" />
                <span>+ Vendor Baru</span>
              </button>
              {onNavigateToVendor && (
                <button
                  type="button"
                  onClick={onNavigateToVendor}
                  className="text-[11px] font-extrabold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition active:scale-95 cursor-pointer"
                  title="Buka Halaman Khusus Kelola Vendor"
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Kelola Master Vendor →</span>
                </button>
              )}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="relative flex items-center gap-1.5">
              <div className="relative flex-1">
                <select
                  value={vendorInput || ''}
                  onChange={(e) => setVendorInput(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 appearance-none pr-8 shadow-2xs"
                >
                  {vendorList.length === 0 ? (
                    <option value="">-- Belum ada vendor di Master (Klik + Vendor Baru) --</option>
                  ) : (
                    <>
                      <option value="">-- Pilih Vendor / Suplier --</option>
                      {vendorList.map((v, vIdx) => {
                        const vName = v?.nama || '';
                        if (!vName.trim()) return null;
                        return (
                          <option key={`def-vendor-${v?.id || vName}-${vIdx}`} value={vName}>
                            {vName} {v?.kategori ? `[${v.kategori}]` : ''}
                          </option>
                        );
                      })}
                    </>
                  )}
                  {!isKnownVendor && Boolean(vendorInput && vendorInput.trim()) && (
                    <option key={`custom-vendor-${vendorInput}`} value={vendorInput}>{vendorInput} (Kustom)</option>
                  )}
                </select>
                <ChevronDown className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              {selectedVendorObj && (
                <button
                  type="button"
                  onClick={() => handleOpenEditVendorModal(selectedVendorObj)}
                  className="p-2 bg-stone-100 hover:bg-indigo-50 text-stone-600 hover:text-indigo-600 border border-stone-200 rounded-xl transition cursor-pointer shrink-0"
                  title="Edit Data Vendor Ini"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                placeholder="Atau ketik nama supplier khusus..."
                value={isKnownVendor ? '' : (vendorInput || '')}
                onChange={(e) => setVendorInput(e.target.value)}
                className="flex-1 text-xs text-stone-800 bg-stone-50 hover:bg-white px-3 py-2 rounded-xl border border-stone-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium shadow-2xs"
              />
              {!isKnownVendor && Boolean(vendorInput && vendorInput.trim()) && (
                <button
                  type="button"
                  onClick={handleQuickSaveTypedVendor}
                  className="px-2.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition active:scale-95 shrink-0 flex items-center gap-1"
                  title="Simpan vendor ini ke database master"
                >
                  <Plus className="w-3 h-3" />
                  <span>Simpan</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick info snippet of selected vendor */}
          {selectedVendorObj && (
            <div className="mt-2 px-3 py-2 bg-indigo-50/70 border border-indigo-100 rounded-xl text-[11px] text-stone-700 flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="font-bold text-indigo-900">
                Spesialisasi: {selectedVendorObj.kategori || 'Umum'}
              </span>
              {selectedVendorObj.kontakPerson && (
                <span>PIC: <strong className="text-stone-900">{selectedVendorObj.kontakPerson}</strong></span>
              )}
              {selectedVendorObj.telepon && selectedVendorObj.telepon !== '-' && (
                <span>Telp/WA: <strong className="text-stone-900">{selectedVendorObj.telepon}</strong></span>
              )}
              {selectedVendorObj.nomorRekening && selectedVendorObj.nomorRekening !== '-' && (
                <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-indigo-200 text-indigo-950">
                  Rek: {selectedVendorObj.nomorRekening}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Optimized Bahan Baku yang Dibeli Table Section */}
      <div className="border border-stone-200 rounded-2xl bg-white shadow-2xs overflow-hidden space-y-0">
        {/* Table Top Header */}
        <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 bg-stone-50/90 border-b border-stone-200">
          <div className="flex items-center gap-2">
            <Boxes className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-black text-stone-800 uppercase tracking-wide">
              Bahan Baku yang Dibeli (Penyesuaian Stok Masuk)
            </span>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
              {poRows.length} Baris
            </span>
          </div>
          <button
            type="button"
            onClick={handleAddRow}
            className="text-xs font-black text-indigo-600 hover:text-indigo-800 bg-white hover:bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-xl flex items-center gap-1 transition active:scale-95 shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Tambah Baris</span>
          </button>
        </div>

        {/* Responsive Table for Clean Alignment Without Overlapping - Lengthened downwards for ample room */}
        <div className="overflow-x-auto min-h-[480px] sm:min-h-[560px] pb-16 transition-all">
          <table className="w-full text-left border-collapse min-w-[850px] lg:min-w-[960px]">
            <thead>
              <tr className="border-b border-stone-200 bg-stone-100/80 text-[10px] sm:text-[11px] font-black text-stone-600 uppercase tracking-wider">
                <th className="py-3.5 px-4 w-12 text-center">#</th>
                <th className="py-3.5 px-4 min-w-[340px] sm:min-w-[420px] lg:min-w-[500px]">Bahan Baku / Produk</th>
                <th className="py-3.5 px-4 w-48 text-center">Jumlah Masuk (Stok +)</th>
                <th className="py-3.5 px-4 w-52 text-right">Harga Beli / Satuan</th>
                <th className="py-3.5 px-4 w-44 text-right">Subtotal</th>
                <th className="py-3.5 px-4 w-14 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200/80 bg-white">
              {poRows.map((row, index) => {
                const subtotal = parseNumberInput(row.qty) * parseNumberInput(row.hargaBeli);

                return (
                  <tr
                    key={`po-item-row-${row.id}-${index}`}
                    className="hover:bg-stone-50/70 transition"
                  >
                    {/* Column 1: Row Number */}
                    <td className="py-3.5 px-3.5 text-center align-middle">
                      <span className="w-6 h-6 rounded-lg bg-stone-100 text-stone-700 font-black text-xs inline-flex items-center justify-center">
                        {index + 1}
                      </span>
                    </td>

                    {/* Column 2: Product Selector Dropdown */}
                    <td className="py-3.5 px-4 align-middle">
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => {
                            setActivePickerRowId(activePickerRowId === row.id ? null : row.id);
                            setPickerSearch('');
                            setPickerCategory('Semua');
                          }}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-black flex items-center justify-between gap-3 shadow-2xs transition active:scale-95 border ${
                            row.product 
                              ? 'bg-indigo-50/50 hover:bg-indigo-50 border-indigo-200 text-stone-900' 
                              : 'bg-stone-50 hover:bg-stone-100/80 border-dashed border-stone-300 text-stone-500'
                          }`}
                        >
                          <div className="min-w-0 flex items-center gap-2.5 truncate">
                            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${row.product ? 'bg-indigo-600' : 'bg-stone-300'}`} />
                            <span className={`truncate font-black text-xs sm:text-sm uppercase tracking-wide ${row.product ? 'text-stone-900' : 'text-stone-500 font-bold'}`}>
                              {row.product ? row.product.nama : 'Pilih Bahan Baku di Sini...'}
                            </span>
                            {row.product && (
                              <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-md bg-white text-stone-600 border border-stone-200 shrink-0">
                                {row.product.kode}
                              </span>
                            )}
                            {row.product && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                                Stok: {row.product.stok ?? 0} {row.product.satuan}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className={`text-[11px] font-bold px-2.5 py-1 rounded-lg ${row.product ? 'text-indigo-700 bg-indigo-100/80' : 'text-stone-600 bg-stone-200/70'}`}>
                              {row.product ? 'Ubah' : 'Pilih Bahan'}
                            </span>
                            <ChevronDown className="w-4 h-4 text-stone-400" />
                          </div>
                        </button>

                        {/* Dropdown Popover for selecting product - Expanded and lengthened downwards */}
                        {activePickerRowId === row.id && (
                          <div className="absolute left-0 top-full mt-2 w-full min-w-[380px] sm:min-w-[560px] bg-white border border-stone-200 rounded-2xl shadow-2xl z-50 p-4 space-y-3 animate-fade-in ring-1 ring-black/5">
                            <div className="flex items-center justify-between pb-1.5 border-b border-stone-100">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-black text-stone-800">
                                  Pilih Bahan Baku / Produk
                                </span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700">
                                  {filteredPickerProducts.length} Item
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setActivePickerRowId(null);
                                  setPickerSearch('');
                                  setPickerCategory('Semua');
                                }}
                                className="text-stone-400 hover:text-stone-600 p-1 hover:bg-stone-100 rounded-lg transition cursor-pointer"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>

                            {/* Search Input Box */}
                            <div className="relative">
                              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                              <input
                                type="text"
                                autoFocus
                                placeholder="Cari nama bahan, kode (A3P01), kategori..."
                                value={pickerSearch}
                                onChange={(e) => setPickerSearch(e.target.value)}
                                className="w-full pl-9 pr-8 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                              />
                              {pickerSearch && (
                                <button
                                  type="button"
                                  onClick={() => setPickerSearch('')}
                                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>

                            {/* Category Filter Pills for rapid selection */}
                            {pickerCategories.length > 1 && (
                              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                                {pickerCategories.map((cat) => (
                                  <button
                                    key={cat}
                                    type="button"
                                    onClick={() => setPickerCategory(cat)}
                                    className={`px-2.5 py-1 rounded-lg font-bold whitespace-nowrap transition cursor-pointer ${
                                      pickerCategory === cat
                                        ? 'bg-indigo-600 text-white shadow-2xs'
                                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                                    }`}
                                  >
                                    {cat}
                                  </button>
                                ))}
                              </div>
                            )}

                            {/* Expanded, Taller Materials List */}
                            <div className="max-h-[340px] sm:max-h-[400px] overflow-y-auto divide-y divide-stone-100 pr-1 space-y-0.5">
                              {filteredPickerProducts.length === 0 ? (
                                <div className="p-6 text-center text-xs text-stone-400">
                                  Tidak ada bahan yang cocok dengan pencarian "{pickerSearch}".
                                </div>
                              ) : (
                                filteredPickerProducts.map((p, pIdx) => (
                                  <div
                                    key={`picker-item-${p.kode || 'bhn'}-${p.nama || ''}-${pIdx}`}
                                    onClick={() => {
                                      handleUpdateRow(row.id, {
                                        product: p,
                                        satuan: p.satuan || 'pcs',
                                        hargaBeli: Math.round((p.harga || 10000) * 0.7),
                                      });
                                      setActivePickerRowId(null);
                                    }}
                                    className="p-3 hover:bg-indigo-50/80 rounded-xl cursor-pointer transition flex items-center justify-between gap-3 group"
                                  >
                                    <div className="min-w-0">
                                      <div className="text-xs font-black text-stone-900 group-hover:text-indigo-900 truncate flex items-center gap-2">
                                        <span>{p.nama}</span>
                                        <span className="text-[10px] font-mono px-1.5 py-0.5 bg-stone-100 group-hover:bg-white text-stone-600 rounded border border-stone-200">
                                          {p.kode}
                                        </span>
                                      </div>
                                      <div className="text-[11px] text-stone-500 mt-1 flex items-center gap-2.5">
                                        <span className="font-semibold text-stone-600">{p.kategori || 'Umum'}</span>
                                        <span>•</span>
                                        <span className={`font-bold ${Number(p.stok) > 0 ? 'text-emerald-700' : 'text-amber-700'}`}>
                                          Stok: {p.stok || 0} {p.satuan}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="text-right shrink-0">
                                      <span className="text-xs font-black text-indigo-700 bg-indigo-50 group-hover:bg-indigo-100 px-2.5 py-1 rounded-lg border border-indigo-200 inline-block">
                                        {fRp(p.harga)}
                                      </span>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </td>

                    {/* Column 3: Quantity Input Group (Stok +) */}
                    <td className="py-3.5 px-4 align-middle text-center">
                      <div className="inline-flex items-center border border-stone-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 bg-white shadow-2xs">
                        <input
                          type="text"
                          inputMode="decimal"
                          required
                          value={row.qty}
                          onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9.,]/g, '');
                            handleUpdateRow(row.id, { qty: val });
                          }}
                          className="w-20 sm:w-24 px-3 py-2 text-center text-xs sm:text-sm font-black text-stone-900 focus:outline-none"
                          placeholder="0"
                        />
                        <span className="px-3 py-2 bg-stone-100 border-l border-stone-200 text-xs font-bold text-stone-600 select-none min-w-[38px] text-center">
                          {row.product ? (row.satuan || row.product.satuan || 'pcs') : '-'}
                        </span>
                      </div>
                    </td>

                    {/* Column 4: Price Input Group (Harga Beli) */}
                    <td className="py-3.5 px-4 align-middle text-right">
                      <div className="inline-flex items-center border border-stone-300 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 bg-white shadow-2xs w-full max-w-[190px]">
                        <span className="px-3 py-2 bg-stone-100 border-r border-stone-200 text-xs font-bold text-stone-500 select-none">
                          Rp
                        </span>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={row.hargaBeli}
                          onChange={(e) => handleUpdateRow(row.id, { hargaBeli: e.target.value.replace(/[^0-9]/g, '') })}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          className="w-full px-3 py-2 text-right text-xs sm:text-sm font-black text-stone-900 focus:outline-none"
                          placeholder="0"
                        />
                      </div>
                    </td>

                    {/* Column 5: Subtotal */}
                    <td className="py-3.5 px-4 align-middle text-right">
                      <span className="font-black text-xs sm:text-sm text-indigo-900">
                        {fRp(subtotal)}
                      </span>
                    </td>

                    {/* Column 6: Action Button */}
                    <td className="py-3.5 px-4 align-middle text-center">
                      <button
                        type="button"
                        onClick={() => handleResetOrDeleteRow(row.id)}
                        className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                        title={poRows.length === 1 ? 'Kosongkan Baris' : 'Hapus Baris'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {poRows.length === 1 && !activePickerRowId && (
                <tr>
                  <td colSpan={6} className="py-14 px-4 text-center bg-stone-50/40">
                    <div className="flex flex-col items-center justify-center gap-2.5 max-w-md mx-auto text-stone-400">
                      <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-2xs">
                        <Boxes className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-black text-stone-700">
                        Pilih Bahan Baku yang Masuk / Dibeli
                      </span>
                      <p className="text-[11px] text-stone-500 leading-relaxed">
                        Klik kolom <strong className="text-indigo-600 font-bold">"Pilih Bahan Baku di Sini..."</strong> pada baris di atas untuk memilih bahan yang dibeli, atau klik <strong className="text-stone-700 font-bold">+ Tambah Baris</strong> jika ingin membeli beberapa bahan sekaligus.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Bottom Footer: Total Tagihan PO */}
        <div className="px-5 py-3.5 bg-stone-50/90 border-t border-stone-200 flex items-center justify-between">
          <span className="text-xs sm:text-sm font-black tracking-tight text-stone-800">
            Total Tagihan PO ({poRows.length} item):
          </span>
          <span className="text-base sm:text-xl font-black text-indigo-600">
            {fRp(totalTagihanPo)}
          </span>
        </div>
      </div>

      {/* Side-by-Side Grid: Pembukuan Pengeluaran (Kiri) & Catatan Restock (Kanan) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-stretch">
        {/* Kolom Kiri: Catat Otomatis ke Pengeluaran */}
        <div className={`border transition-all duration-200 rounded-2xl p-4 flex flex-col justify-between space-y-3 ${
          catatPengeluaran 
            ? 'border-emerald-200 bg-emerald-50/50' 
            : 'border-amber-200 bg-amber-50/50'
        }`}>
          <div>
            <div 
              onClick={() => handleToggleCatatPengeluaran(!catatPengeluaran)}
              className="flex items-start gap-2.5 cursor-pointer select-none group"
            >
              <input
                type="checkbox"
                checked={catatPengeluaran}
                onChange={(e) => {
                  handleToggleCatatPengeluaran(e.target.checked);
                }}
                onClick={(e) => e.stopPropagation()}
                className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 h-4 w-4 cursor-pointer"
              />
              <div className="flex-1">
                <div className="text-xs font-black text-emerald-950 flex items-center flex-wrap gap-1.5">
                  <Wallet className={`w-3.5 h-3.5 ${catatPengeluaran ? 'text-emerald-700' : 'text-amber-700'}`} />
                  <span className={catatPengeluaran ? 'text-emerald-950' : 'text-stone-800'}>
                    Otomatis Catat ke Pembukuan Pengeluaran
                  </span>
                  {catatPengeluaran ? (
                    <span className="text-[9px] bg-emerald-200 text-emerald-900 px-1.5 py-0.2 rounded font-extrabold uppercase">
                      OTOMATIS
                    </span>
                  ) : (
                    <span className="text-[9px] bg-amber-200 text-amber-900 border border-amber-300 px-1.5 py-0.2 rounded font-extrabold uppercase">
                      NONAKTIF ({uncheckApprovedBy || 'SPV'})
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-100/90 border border-amber-200 px-2 py-0.5 rounded-full ml-auto">
                    <Lock className="w-2.5 h-2.5 text-amber-700" />
                    <span>Proteksi SPV</span>
                  </span>
                </div>
                <p className={`text-[11px] mt-1 leading-snug ${catatPengeluaran ? 'text-emerald-800' : 'text-amber-900 font-medium'}`}>
                  {catatPengeluaran ? (
                    <>
                      Total nominal <strong className="text-emerald-950">{fRp(totalTagihanPo)}</strong> otomatis masuk ke Laporan Pengeluaran kasir & Buku Kas.
                    </>
                  ) : (
                    <>
                      ⚠️ <strong className="text-amber-950">Pencatatan kas dinonaktifkan:</strong> Tagihan PO <strong className="text-stone-900">{fRp(totalTagihanPo)}</strong> tidak memotong kas toko (Disetujui: <strong className="text-amber-950">{uncheckApprovedBy || 'SPV/Owner'}</strong>).
                    </>
                  )}
                </p>
              </div>
            </div>
          </div>

          {catatPengeluaran ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2.5 border-t border-emerald-200/60 text-xs mt-auto">
              <div>
                <label className="block text-[10px] font-bold text-emerald-900 mb-1">
                  Kategori Pengeluaran:
                </label>
                <select
                  value={kategoriPengeluaran}
                  onChange={(e) => setKategoriPengeluaran(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none"
                >
                  <option value="Bahan Baku">Bahan Baku & Stok Cetak</option>
                  <option value="Operasional & Makanan">Operasional Toko</option>
                  <option value="Maintenance & Service">Maintenance & Perlengkapan</option>
                  <option value="Lain-lain">Lain-lain</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-emerald-900 mb-1">
                  Sumber Dana / Kas:
                </label>
                <select
                  value={sumberKas}
                  onChange={(e) => setSumberKas(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none"
                >
                  <option value="Kas Operasional Toko">Kas Operasional Toko / Laci Kasir</option>
                  <option value="Transfer Bank BCA Toko">Transfer Bank BCA Toko</option>
                  <option value="Transfer Bank Mandiri Toko">Transfer Bank Mandiri Toko</option>
                  <option value="Hutang Vendor (Tempo)">Hutang Vendor (Tempo / Belum Lunas)</option>
                </select>
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-amber-200/60 text-[11px] text-amber-800 flex items-center gap-1.5 mt-auto">
              <Lock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Proteksi Keamanan SPV / Owner aktif.</span>
            </div>
          )}
        </div>

        {/* Kolom Kanan: Catatan Pembelian / Restock */}
        <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col justify-between space-y-2.5">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                <span>Catatan Restock / Keterangan Masuk Barang</span>
              </label>
              <span className="text-[10px] text-stone-400 font-medium">Opsional</span>
            </div>

            {/* Quick Tag Helper for Cashiers */}
            <div className="flex flex-wrap items-center gap-1 mb-2">
              <span className="text-[10px] font-bold text-stone-500 mr-1">Pilihan Cepat:</span>
              {[
                'Surat Jalan Terlampir',
                'Kondisi Segel & Baik',
                'Restock Rutin',
                'Ekspedisi Cargo',
                'Ganti Stok Rusak',
              ].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => {
                    setCatatanPembelian((prev) => (prev.trim() ? `${prev.trim()}, ${tag}` : tag));
                  }}
                  className="text-[10px] font-semibold text-stone-600 bg-white hover:bg-indigo-50 hover:text-indigo-700 px-2 py-0.5 rounded-lg border border-stone-200 transition active:scale-95 cursor-pointer"
                >
                  + {tag}
                </button>
              ))}
            </div>
          </div>

          <textarea
            rows={2}
            value={catatanPembelian}
            onChange={(e) => setCatatanPembelian(e.target.value)}
            placeholder="Contoh: No. Surat Jalan SJ-2026/882, barang diterima lengkap dan dicek oleh kasir..."
            className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none mt-auto"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
        <button
          type="button"
          onClick={() => {
            setNoPo(generatePoNumber());
            setVendorInput('');
            setCatatanPembelian('');
            setPoRows([createEmptyRow(products.length > 0 ? products[0] : null)]);
          }}
          className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition"
        >
          Batal
        </button>

        <button
          type="submit"
          disabled={isSubmitting}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-2 transition active:scale-95"
        >
          {isSubmitting ? (
            <RotateCw className="w-4 h-4 animate-spin" />
          ) : (
            <CheckCircle2 className="w-4 h-4" />
          )}
          <span>Simpan & Tambah Stok Masuk</span>
        </button>
      </div>
    </form>
  );

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Banner Header */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-600 rounded-xl text-white shrink-0 shadow-sm">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Pencatatan Pembelian Bahan Baku Baru (PO)</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-500/40 uppercase">
                Restock & Pengeluaran
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Input barang masuk vendor, multi-item PO, sinkronisasi otomatis ke pembukuan pengeluaran kasir dan Google Sheets.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={loadHistory}
            disabled={isLoadingHistory}
            className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold flex items-center gap-2 border border-stone-700 transition"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isLoadingHistory ? 'animate-spin text-indigo-400' : ''}`} />
            <span>Segarkan</span>
          </button>
        </div>
      </div>

      {/* Sub-Tabs Navigation Bar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-1.5 shadow-2xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setFormMode('restock')}
            className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              formMode === 'restock'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Truck className="w-4 h-4 shrink-0" />
            <span>PO & Restock Bahan</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('new_product')}
            className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              formMode === 'new_product'
                ? 'bg-orange-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span>+ Tambah Produk Baru</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('edit_product')}
            className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              formMode === 'edit_product'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Edit3 className="w-4 h-4 shrink-0" />
            <span>Kelola / Hapus Produk</span>
          </button>

          <button
            type="button"
            onClick={() => setFormMode('history')}
            className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
              formMode === 'history'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <History className="w-4 h-4 shrink-0" />
            <span>Riwayat Barang Masuk & PO</span>
            <span
              className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                formMode === 'history' ? 'bg-white/20 text-white' : 'bg-indigo-100 text-indigo-700'
              }`}
            >
              {history.length}
            </span>
          </button>
        </div>

        {formMode === 'restock' && (
          <div className="flex items-center gap-2 px-2 py-1 text-xs text-stone-500">
            <span>Operator: <strong className="text-indigo-700 font-bold">{currentCashier}</strong></span>
          </div>
        )}
      </div>

      {/* SUB-TAB 1: RESTOCK / PO FORM (FULL WIDTH) */}
      {formMode === 'restock' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-stone-100 gap-2">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-indigo-600" />
              <h3 className="font-extrabold text-sm sm:text-base text-stone-900">
                Pencatatan Pembelian Bahan Baku Baru (PO)
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                Tampilan Luas
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setFormMode('history')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-xl border border-indigo-200 flex items-center gap-1 transition cursor-pointer"
              >
                <span>Lihat Riwayat & Log ({history.length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {renderPoFormCore()}

          <div className="mt-4 p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-500 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <span>
              Stok masuk PO akan otomatis bertambah ke master katalog, dicatat ke Sheet <strong>BarangMasuk</strong> & <strong>Firebase</strong>, dan jika opsi dicentang, langsung dibukukan ke <strong>Laporan Pengeluaran Kasir</strong>.
            </span>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: TAMBAH PRODUK BARU */}
      {formMode === 'new_product' && (
        <div className="max-w-4xl mx-auto w-full bg-white border border-stone-200 rounded-2xl p-5 sm:p-6 shadow-xs">
          <form onSubmit={handleSaveNewProduct} className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-1">
                  <h3 className="font-bold text-xs text-orange-900 flex items-center gap-1.5">
                    <PlusCircle className="w-3.5 h-3.5 text-orange-600" />
                    <span>Daftarkan Produk Baru ke Katalog Master</span>
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-stone-700">
                        Kode Produk <span className="text-red-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setNewKode(generateUniqueKode())}
                        className="text-[10px] text-orange-700 hover:text-orange-900 font-bold hover:underline"
                      >
                        Auto Kode Unik
                      </button>
                    </div>
                    <input
                      type="text"
                      value={newKode}
                      onChange={(e) => setNewKode(e.target.value)}
                      required
                      placeholder="Contoh: BNR05, PRD01"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Kategori
                    </label>
                    <select
                      value={newKategori}
                      onChange={(e) => setNewKategori(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    >
                      <option value="Bahan Baku">Bahan Baku</option>
                      <option value="Bahan Cetak">Bahan Cetak</option>
                      <option value="Banner">Banner</option>
                      <option value="Print A3">Print A3</option>
                      <option value="Finishing">Finishing</option>
                      <option value="Merchandise">Merchandise</option>
                      <option value="Display">Display</option>
                      <option value="Stiker">Stiker</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nama Produk / Bahan Cetak <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={newNama}
                    onChange={(e) => setNewNama(e.target.value)}
                    required
                    placeholder="Contoh: Banner Flexi Korchin 440gr, Pin Bros 58mm..."
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>

                {/* Skema Hitung Harga & Ukuran */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-stone-800">
                    Skema Hitung Harga & Ukuran <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                      <Pencil className="w-4 h-4 text-amber-500 fill-amber-300 stroke-stone-900 stroke-[1.8] transform -rotate-45" />
                    </div>
                    <select
                      value={newPricingScheme}
                      onChange={(e) => {
                        const val = e.target.value as 'meter_fix' | 'per_meter' | 'per_cm' | 'a3_plus' | 'lembaran_custom';
                        setNewPricingScheme(val);
                        if (val === 'meter_fix') setNewSatuan('pcs');
                        else if (val === 'per_meter') setNewSatuan('m²');
                        else if (val === 'per_cm') setNewSatuan('cm²');
                        else if (val === 'a3_plus') setNewSatuan('lembar');
                        else if (val === 'lembaran_custom') setNewSatuan('lembar');
                      }}
                      className="w-full pl-10 pr-10 py-2.5 bg-white border border-blue-200 hover:border-blue-400 rounded-2xl text-xs font-black text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 shadow-2xs appearance-none transition"
                    >
                      <option value="meter_fix">Meter Fix / Satuan Tetap (Qty × Harga)</option>
                      <option value="per_meter">Per Meter Persegi (P × L × Qty × Harga/m²)</option>
                      <option value="per_cm">Per Sentimeter Persegi (P × L × Qty × Harga/cm²)</option>
                      <option value="a3_plus">Cetak A3+ / Lembaran Digital</option>
                      <option value="lembaran_custom">Lembaran Custom / Bahan Baku Khusus</option>
                    </select>
                    <ChevronDown className="w-4 h-4 text-stone-600 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>

                  {/* Detailed Helper Callout */}
                  <div className="p-3 bg-blue-50/60 border border-blue-100 rounded-2xl text-[11px] text-stone-700 leading-relaxed shadow-2xs">
                    {newPricingScheme === 'meter_fix' && (
                      <p>
                        <strong className="text-stone-900 font-bold">Meter Fix / Satuan:</strong> Dihitung langsung Qty × Harga. Cocok untuk Meter Lari (DTF UV Roll per meter), Pcs, Lembar A3+, Rim, dll.
                      </p>
                    )}
                    {newPricingScheme === 'per_meter' && (
                      <p>
                        <strong className="text-stone-900 font-bold">Per Meter Persegi (m²):</strong> Dihitung berdasarkan rumus (Panjang × Lebar × Qty × Harga). Cocok untuk Spanduk, Banner Flexy, Backlite, Stiker Meteran.
                      </p>
                    )}
                    {newPricingScheme === 'per_cm' && (
                      <p>
                        <strong className="text-stone-900 font-bold">Per Sentimeter Persegi (cm²):</strong> Dihitung berdasarkan rumus (Panjang × Lebar × Qty × Harga/cm²). Cocok untuk Stiker Label Kecil, Akrilik Mini, dll.
                      </p>
                    )}
                    {newPricingScheme === 'a3_plus' && (
                      <p>
                        <strong className="text-stone-900 font-bold">Cetak A3+ / Lembaran Digital:</strong> Dihitung per lembar A3+ (32×48cm). Cocok untuk Brosur, Poster, Kartu Nama, dan Sertifikat.
                      </p>
                    )}
                    {newPricingScheme === 'lembaran_custom' && (
                      <p>
                        <strong className="text-stone-900 font-bold">Lembaran Custom:</strong> Dihitung berdasarkan dimensi lembaran plano atau ukuran khusus dengan kalkulasi muat potong.
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Harga Jual (Rp) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={newHarga}
                      onChange={(e) => setNewHarga(e.target.value.replace(/[^0-9]/g, ''))}
                      onFocus={(e) => (e.target as HTMLInputElement).select()}
                      required
                      placeholder="Contoh: 35000"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Satuan Stok
                    </label>
                    <select
                      value={newSatuan}
                      onChange={(e) => setNewSatuan(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    >
                      <option value="pcs">pcs</option>
                      <option value="kg">kg (Kilogram)</option>
                      <option value="meter">meter</option>
                      <option value="m²">m² (Meter Persegi)</option>
                      <option value="roll">roll</option>
                      <option value="lembar">lembar</option>
                      <option value="Pak">Pak</option>
                      <option value="Rim">Rim</option>
                      <option value="Liter">Liter (Ltr)</option>
                      <option value="box">box</option>
                      <option value="set">set</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Stok Awal Pendaftaran
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={newStokAwal}
                      onChange={(e) => {
                        const val = e.target.value.replace(/[^0-9.,]/g, '');
                        setNewStokAwal(val);
                      }}
                      placeholder="0,1"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-black text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Pemasok / Suplier
                    </label>
                    <input
                      type="text"
                      value={newSupplier}
                      onChange={(e) => setNewSupplier(e.target.value)}
                      placeholder="Pabrik / Vendor"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Keterangan Produk (Opsional)
                  </label>
                  <input
                    type="text"
                    value={newCatatan}
                    onChange={(e) => setNewCatatan(e.target.value)}
                    placeholder="Contoh: Bahan outdoor tahan panas & hujan..."
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                  />
                </div>

                <div className="flex items-center gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNewNama('');
                      setNewHarga('');
                      setNewSupplier('');
                      setNewCatatan('');
                      setNewKode(generateUniqueKode());
                      setFormMode('restock');
                    }}
                    disabled={isSubmitting}
                    className="py-3 px-5 sm:px-6 bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-900 font-extrabold text-xs rounded-xl border border-stone-300 transition active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <X className="w-4 h-4 text-stone-500" />
                    <span>Batal</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-3 bg-orange-700 hover:bg-orange-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <RotateCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    <span>+ Tambah & Daftarkan Produk Baru</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* SUB-TAB 4: KELOLA / HAPUS PRODUK */}
          {formMode === 'edit_product' && (
            <div className="max-w-4xl mx-auto w-full bg-white border border-stone-200 rounded-2xl p-5 sm:p-6 shadow-xs">
              <form onSubmit={handleSaveEditProduct} className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100 mb-1">
                  <h3 className="font-bold text-xs text-blue-900 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Edit Detail & Harga Produk (Dicatat ke Riwayat)</span>
                  </h3>
                  <span className="text-[11px] font-bold text-stone-500">
                    Operator: <strong className="text-blue-700">{currentCashier}</strong>
                  </span>
                </div>

                {/* Product Selector for Edit */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Pilih Produk yang Akan Diubah <span className="text-red-500">*</span>
                  </label>

                  {editSelectedProduct ? (
                    <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl flex items-center justify-between gap-2">
                      <div>
                        <div className="font-extrabold text-xs text-blue-950 flex items-center gap-1.5">
                          <span>{editSelectedProduct.nama}</span>
                          <span className="text-[10px] bg-blue-200 text-blue-900 px-1.5 py-0.2 rounded font-black">
                            {editSelectedProduct.kode}
                          </span>
                        </div>
                        <div className="text-[11px] text-blue-800 mt-0.5">
                          Harga Jual: <strong className="text-blue-950">{fRp(editSelectedProduct.harga)}</strong> • Stok: {editSelectedProduct.stok || '0'} {editSelectedProduct.satuan}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleRequestDelete(editSelectedProduct)}
                          className="px-2 py-1 bg-red-50 hover:bg-red-600 hover:text-white text-red-700 text-[11px] font-bold rounded-lg border border-red-200 transition flex items-center gap-1"
                          title={isCurrentCashierSpv ? "Hapus Produk" : "Perlu Otorisasi"}
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Hapus</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditSelectedProduct(null)}
                          className="px-2 py-1 bg-white hover:bg-blue-100 text-blue-900 text-[11px] font-bold rounded-lg border border-blue-300 transition"
                        >
                          Ganti
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                        <input
                          type="text"
                          placeholder="Cari kode atau nama produk untuk diedit..."
                          value={editSearch}
                          onChange={(e) => setEditSearch(e.target.value)}
                          className="w-full pl-8 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                      </div>

                      <div className="max-h-40 overflow-y-auto border border-stone-200 rounded-xl divide-y divide-stone-100 bg-stone-50/50">
                        {filteredEditProducts.length === 0 ? (
                          <div className="p-3 text-center text-xs text-stone-400">
                            Tidak ditemukan produk.
                          </div>
                        ) : (
                          filteredEditProducts.map((p, idx) => (
                            <div
                              key={`${p.kode}-${p.nama}-${idx}`}
                              className="w-full text-left p-2.5 hover:bg-blue-50/80 transition flex items-center justify-between gap-2 cursor-pointer"
                              onClick={() => startEditProduct(p)}
                            >
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-xs text-stone-800 truncate">{p.nama}</div>
                                <div className="text-[10px] text-stone-500">
                                  {p.kode} • Kat: {p.kategori}
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <span className="text-[11px] font-extrabold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-md border border-blue-200">
                                  {fRp(p.harga)}
                                </span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {editSelectedProduct && (
                  <div className="space-y-3 pt-2 border-t border-stone-100">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Kode Produk <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={editKode}
                          onChange={(e) => setEditKode(e.target.value)}
                          required
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Kategori
                        </label>
                        <select
                          value={editKategori}
                          onChange={(e) => setEditKategori(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-bold text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        >
                          <option value="Bahan Baku">Bahan Baku</option>
                          <option value="Bahan Cetak">Bahan Cetak</option>
                          <option value="Banner">Banner</option>
                          <option value="Print A3">Print A3</option>
                          <option value="Finishing">Finishing</option>
                          <option value="Merchandise">Merchandise</option>
                          <option value="Display">Display</option>
                          <option value="Stiker">Stiker</option>
                          <option value="Lainnya">Lainnya</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Nama Produk / Bahan Cetak <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={editNama}
                        onChange={(e) => setEditNama(e.target.value)}
                        required
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>

                    {/* Skema Hitung Harga & Ukuran di Form Edit */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-bold text-stone-800">
                        Skema Hitung Harga & Ukuran <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none">
                          <Pencil className="w-4 h-4 text-amber-500 fill-amber-300 stroke-stone-900 stroke-[1.8] transform -rotate-45" />
                        </div>
                        <select
                          value={editPricingScheme}
                          onChange={(e) => {
                            const val = e.target.value as 'meter_fix' | 'per_meter' | 'per_cm' | 'a3_plus' | 'lembaran_custom';
                            setEditPricingScheme(val);
                          }}
                          className="w-full pl-10 pr-10 py-2.5 bg-white border border-blue-200 hover:border-blue-400 rounded-2xl text-xs font-black text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 shadow-2xs appearance-none transition"
                        >
                          <option value="meter_fix">Meter Fix / Satuan Tetap (Qty × Harga)</option>
                          <option value="per_meter">Per Meter Persegi (P × L × Qty × Harga/m²)</option>
                          <option value="per_cm">Per Sentimeter Persegi (P × L × Qty × Harga/cm²)</option>
                          <option value="a3_plus">Cetak A3+ / Lembaran Digital</option>
                          <option value="lembaran_custom">Lembaran Custom / Bahan Baku Khusus</option>
                        </select>
                        <ChevronDown className="w-4 h-4 text-stone-600 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>

                      <div className="p-3 bg-blue-50/60 border border-blue-100 rounded-2xl text-[11px] text-stone-700 leading-relaxed shadow-2xs">
                        {editPricingScheme === 'meter_fix' && (
                          <p><strong className="text-stone-900 font-bold">Meter Fix / Satuan:</strong> Dihitung langsung Qty × Harga. Cocok untuk Meter Lari (DTF UV Roll per meter), Pcs, Lembar A3+, Rim, dll.</p>
                        )}
                        {editPricingScheme === 'per_meter' && (
                          <p><strong className="text-stone-900 font-bold">Per Meter Persegi (m²):</strong> Dihitung berdasarkan rumus (Panjang × Lebar × Qty × Harga). Cocok untuk Spanduk, Banner Flexy, Backlite, Stiker Meteran.</p>
                        )}
                        {editPricingScheme === 'per_cm' && (
                          <p><strong className="text-stone-900 font-bold">Per Sentimeter Persegi (cm²):</strong> Dihitung berdasarkan rumus (Panjang × Lebar × Qty × Harga/cm²). Cocok untuk Stiker Label Kecil, Akrilik Mini, dll.</p>
                        )}
                        {editPricingScheme === 'a3_plus' && (
                          <p><strong className="text-stone-900 font-bold">Cetak A3+ / Lembaran Digital:</strong> Dihitung per lembar A3+ (32×48cm). Cocok untuk Brosur, Poster, Kartu Nama, dan Sertifikat.</p>
                        )}
                        {editPricingScheme === 'lembaran_custom' && (
                          <p><strong className="text-stone-900 font-bold">Lembaran Custom:</strong> Dihitung berdasarkan dimensi lembaran plano atau ukuran khusus dengan kalkulasi muat potong.</p>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          Harga Jual Baru (Rp) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={editHarga}
                          onChange={(e) => setEditHarga(e.target.value.replace(/[^0-9]/g, ''))}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          required
                          className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl font-black text-xs text-blue-950 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-bold text-stone-700">
                            Kuantitas Stok
                          </label>
                          {isCurrentCashierSpv ? (
                            <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-blue-600" />
                              <span>Akses SPV / Owner</span>
                            </span>
                          ) : isStokUnlocked ? (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Diotorisasi {stokAuthSpvUser}</span>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setStokAuthPassword('');
                                setStokAuthError(null);
                                setIsStokAuthModalOpen(true);
                              }}
                              className="text-[10px] font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200 flex items-center gap-1 transition"
                            >
                              <Lock className="w-3 h-3 text-amber-600" />
                              <span>Buka Kunci (SPV/Owner)</span>
                            </button>
                          )}
                        </div>

                        <div className="relative">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={editStok}
                            disabled={!canEditStok}
                            readOnly={!canEditStok}
                            onClick={() => {
                              if (!canEditStok) {
                                setStokAuthPassword('');
                                setStokAuthError(null);
                                setIsStokAuthModalOpen(true);
                              }
                            }}
                            onChange={(e) => {
                              if (!canEditStok) return;
                              const val = e.target.value.replace(/[^0-9.,]/g, '');
                              setEditStok(val);
                            }}
                            placeholder="0,1"
                            className={`w-full px-3 py-2 rounded-xl font-black text-xs transition ${
                              canEditStok
                                ? 'bg-white border border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20'
                                : 'bg-stone-100 border border-dashed border-stone-300 text-stone-400 cursor-not-allowed select-none pl-8'
                            }`}
                          />
                          {!canEditStok && (
                            <div 
                              onClick={() => {
                                setStokAuthPassword('');
                                setStokAuthError(null);
                                setIsStokAuthModalOpen(true);
                              }}
                              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-amber-600 cursor-pointer"
                              title="Hanya Owner dan SPV yang berhak mengedit stok. Klik untuk otorisasi."
                            >
                              <Lock className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>

                        {!canEditStok ? (
                          <p className="text-[10px] text-amber-700 mt-1 flex items-center gap-1 font-medium">
                            <Lock className="w-2.5 h-2.5 shrink-0" />
                            <span>Hanya Owner & SPV yang berhak mengubah kuantitas stok manual di sini.</span>
                          </p>
                        ) : (
                          <p className="text-[10px] text-stone-400 mt-1">
                            Format angka desimal diperbolehkan (misal: 10,5)
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Catatan Perubahan Data
                      </label>
                      <input
                        type="text"
                        value={editCatatan}
                        onChange={(e) => setEditCatatan(e.target.value)}
                        placeholder="Contoh: Penyesuaian tarif / harga modal..."
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>

                    <div className="flex items-center gap-3 pt-2">
                      <button
                        type="button"
                        onClick={handleCancelEditProduct}
                        disabled={isSubmitting}
                        className="py-3 px-5 sm:px-6 bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-900 font-extrabold text-xs rounded-xl border border-stone-300 transition active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <X className="w-4 h-4 text-stone-500" />
                        <span>Batal</span>
                      </button>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="flex-1 py-3 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
                      >
                        {isSubmitting ? (
                          <RotateCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4" />
                        )}
                        <span>Simpan Perubahan Produk</span>
                      </button>
                    </div>
                  </div>
                )}
              </form>
            </div>
          )}

          {/* SUB-TAB 2: RIWAYAT BARANG MASUK & PO (DEDICATED FULL WIDTH SUB-TAB) */}
          {formMode === 'history' && (
            <div className="space-y-4">
              {/* Top KPI Summary Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-stone-500">Total Log Aktivitas</span>
                    <History className="w-4 h-4 text-indigo-600" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-stone-900">
                    {historyStats.totalLogs} <span className="text-xs font-medium text-stone-400">Catatan</span>
                  </div>
                </div>

                <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-stone-500">Total Stok Masuk</span>
                    <Boxes className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-emerald-700">
                    +{historyStats.totalQty.toLocaleString('id-ID')} <span className="text-xs font-medium text-stone-400">Satuan</span>
                  </div>
                </div>

                <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-stone-500">Transaksi No. PO</span>
                    <Truck className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-stone-900">
                    {historyStats.totalPoCount} <span className="text-xs font-medium text-stone-400">Faktur PO</span>
                  </div>
                </div>

                <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-stone-500">Total Belanja PO</span>
                    <Wallet className="w-4 h-4 text-amber-600" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-amber-800">
                    {fRp(historyStats.totalBiaya)}
                  </div>
                </div>
              </div>

              {/* Main Riwayat Card */}
              <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
                {/* Header & Main Actions */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-stone-100">
                  <div>
                    <h3 className="font-extrabold text-stone-900 text-base flex items-center gap-2">
                      <History className="w-5 h-5 text-indigo-600" />
                      <span>Daftar Riwayat Barang Masuk, PO & Restock Bahan</span>
                    </h3>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      <p className="text-xs text-stone-500">
                        Menampilkan {filteredHistory.length} dari total {history.length} catatan aktivitas barang masuk.
                      </p>
                      <span className="text-stone-300">•</span>
                      {isCurrentCashierSpv ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Fitur Hapus: <strong>Aktif ({currentCashier} - SPV/Owner)</strong></span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-stone-100 text-stone-500 border border-stone-200" title="Login sebagai SPV atau Owner untuk mengaktifkan fitur hapus riwayat barang masuk">
                          <Lock className="w-3.5 h-3.5 text-stone-400" />
                          <span>Fitur Hapus: <strong>Nonaktif (Khusus SPV/Owner)</strong></span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (!filteredHistory || filteredHistory.length === 0) {
                          onShowToast('Tidak ada data riwayat untuk dicetak.', 'info');
                          return;
                        }
                        generateStockInHistoryPdf(filteredHistory, settings, currentCashier);
                        onShowToast('✓ Laporan PDF Riwayat Barang Masuk berhasil diunduh!', 'success');
                      }}
                      disabled={filteredHistory.length === 0}
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-xs cursor-pointer"
                      title="Cetak PDF Laporan Riwayat Sesuai Filter"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak PDF Laporan</span>
                    </button>

                    <button
                      type="button"
                      onClick={loadHistory}
                      disabled={isLoadingHistory}
                      className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${isLoadingHistory ? 'animate-spin text-indigo-600' : ''}`} />
                      <span>Sync Data</span>
                    </button>
                  </div>
                </div>

                {/* Filter Toolbar */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5 bg-stone-50 p-3 rounded-xl border border-stone-200/80">
                  <div className="lg:col-span-6 relative">
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Cari bahan, kode (A3P01), no PO, supplier, atau kasir..."
                      value={historySearch}
                      onChange={(e) => setHistorySearch(e.target.value)}
                      className="w-full pl-9 pr-8 py-2 bg-white border border-stone-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-2xs"
                    />
                    {historySearch && (
                      <button
                        type="button"
                        onClick={() => setHistorySearch('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  <div className="lg:col-span-3">
                    <select
                      value={historyFilterSupplier}
                      onChange={(e) => setHistoryFilterSupplier(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-2xs"
                    >
                      <option value="ALL">Semua Suplier / Vendor</option>
                      {uniqueHistorySuppliers.map((supp, sIdx) => (
                        <option key={`supp-filter-${supp}-${sIdx}`} value={supp}>
                          {supp}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="lg:col-span-3">
                    <select
                      value={historyFilterType}
                      onChange={(e) => setHistoryFilterType(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-2xs"
                    >
                      <option value="ALL">Semua Jenis Log</option>
                      <option value="po">Hanya Transaksi PO</option>
                      <option value="restock">Hanya Restock Stok (+)</option>
                      <option value="edit">Hanya Edit / Koreksi Data</option>
                    </select>
                  </div>
                </div>

                {/* Full Width History Table */}
                <div className="overflow-x-auto border border-stone-200 rounded-2xl">
                  <table className="w-full text-left border-collapse min-w-[850px]">
                    <thead>
                      <tr className="border-b border-stone-200 bg-stone-100/80 text-[10px] sm:text-[11px] font-black text-stone-600 uppercase tracking-wider">
                        <th className="py-3 px-3.5 w-12 text-center">#</th>
                        <th className="py-3 px-3.5 w-36">Waktu & Tanggal</th>
                        <th className="py-3 px-3.5 w-36">No. PO / Tipe</th>
                        <th className="py-3 px-3.5 min-w-[220px]">Bahan Baku / Produk</th>
                        <th className="py-3 px-3.5 min-w-[160px]">Vendor / Suplier</th>
                        <th className="py-3 px-3.5 w-32 text-center">Qty Masuk</th>
                        <th className="py-3 px-3.5 w-36 text-right">Total Biaya</th>
                        <th className="py-3 px-3.5 w-28">Operator</th>
                        <th className="py-3 px-3.5 min-w-[180px]">Catatan</th>
                        <th className="py-3 px-3.5 w-36 text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/80 bg-white">
                      {filteredHistory.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="py-16 text-center text-stone-400">
                            <Layers className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                            <p className="text-xs font-semibold">Tidak ada data riwayat yang cocok dengan filter.</p>
                            <p className="text-[11px] text-stone-400 mt-0.5">
                              Coba bersihkan kata kunci pencarian atau ganti filter vendor.
                            </p>
                          </td>
                        </tr>
                      ) : (
                        filteredHistory.map((item, idx) => {
                          const targetProd = products.find(
                            (p) => p.kode === item.kode || p.nama.toLowerCase() === item.nama.toLowerCase()
                          );

                          return (
                            <tr key={`full-history-row-${item.id || 'stk'}-${idx}`} className="hover:bg-stone-50/80 transition">
                              <td className="py-3 px-3.5 text-center text-xs font-black text-stone-500">
                                {idx + 1}
                              </td>
                              <td className="py-3 px-3.5 text-xs text-stone-600 whitespace-nowrap">
                                <div className="font-bold text-stone-800">{item.date}</div>
                                <div className="text-[11px] text-stone-400 flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  <span>{item.time || '-'}</span>
                                </div>
                              </td>
                              <td className="py-3 px-3.5 text-xs">
                                {item.noPo ? (
                                  <span className="font-mono font-black text-[11px] px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg inline-block">
                                    {item.noPo}
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-bold px-2 py-0.5 bg-stone-100 text-stone-600 rounded-lg inline-block">
                                    Restock Langsung
                                  </span>
                                )}
                              </td>
                              <td className="py-3 px-3.5 text-xs">
                                <div className="font-black text-stone-900 flex items-center gap-1.5 flex-wrap">
                                  <span>{item.nama}</span>
                                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded border border-stone-200">
                                    {item.kode}
                                  </span>
                                </div>
                              </td>
                              <td className="py-3 px-3.5 text-xs font-semibold text-stone-700">
                                <div className="flex items-center gap-1.5">
                                  <Truck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                  <span>{item.supplier || 'Suplier Umum'}</span>
                                </div>
                              </td>
                              <td className="py-3 px-3.5 text-center whitespace-nowrap">
                                {item.qty > 0 ? (
                                  <span className="inline-block text-xs font-black text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200">
                                    +{item.qty} {item.satuan}
                                  </span>
                                ) : (
                                  <span className="inline-block text-[10px] font-extrabold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-md border border-blue-200">
                                    Koreksi Data
                                  </span>
                                )}
                              </td>
                              <td className="py-3 px-3.5 text-right font-black text-xs text-amber-800 whitespace-nowrap">
                                {item.totalBiaya ? fRp(item.totalBiaya) : '-'}
                              </td>
                              <td className="py-3 px-3.5 text-xs text-stone-600 whitespace-nowrap">
                                <div className="flex items-center gap-1">
                                  <User className="w-3 h-3 text-stone-400" />
                                  <span className="font-medium">{item.cashier}</span>
                                </div>
                              </td>
                              <td className="py-3 px-3.5 text-xs text-stone-600">
                                {item.catatan ? (
                                  <span className="bg-stone-50 px-2 py-1 rounded-lg border border-stone-200 text-[11px] block">
                                    {item.catatan}
                                  </span>
                                ) : (
                                  <span className="text-stone-300">-</span>
                                )}
                              </td>
                              <td className="py-3 px-3.5 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  {targetProd && (
                                    <button
                                      type="button"
                                      onClick={() => startEditProduct(targetProd)}
                                      className="px-2 py-1 bg-stone-100 hover:bg-blue-50 text-stone-700 hover:text-blue-700 font-bold text-[11px] rounded-lg border border-stone-200 hover:border-blue-200 transition cursor-pointer"
                                      title="Buka form kelola / edit untuk produk ini"
                                    >
                                      Kelola
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    disabled={!isCurrentCashierSpv}
                                    onClick={() => handleRequestDeleteStockIn(item)}
                                    className={`px-2 py-1 text-[11px] font-bold rounded-lg border transition flex items-center gap-1 ${
                                      isCurrentCashierSpv
                                        ? 'bg-red-50 hover:bg-red-600 hover:text-white text-red-700 border-red-200 cursor-pointer shadow-2xs active:scale-95'
                                        : 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed opacity-50'
                                    }`}
                                    title={
                                      isCurrentCashierSpv
                                        ? 'Hapus catatan riwayat barang masuk ini (Akses SPV / Owner aktif)'
                                        : 'Fitur Hapus Nonaktif: Hanya dapat diakses saat login sebagai SPV atau Owner'
                                    }
                                  >
                                    {isCurrentCashierSpv ? (
                                      <Trash2 className="w-3 h-3 text-red-600 group-hover:text-white" />
                                    ) : (
                                      <Lock className="w-3 h-3 text-stone-400" />
                                    )}
                                    <span>Hapus</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

      {/* ========================================================= */}
      {/* QUICK ADD MASTER BAHAN / PRODUK MODAL */}
      {/* ========================================================= */}
      {isQuickAddModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-stone-200">
            <form onSubmit={handleSaveQuickProduct}>
              <div className="p-5 pb-3 border-b border-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-xs">
                    <Boxes className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-stone-900 text-base">
                      + Tambah Master Bahan Baku / Produk Baru
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      Bahan akan langsung terdaftar di katalog dan dapat dipilih di baris PO
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsQuickAddModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-3 max-h-[75vh] overflow-y-auto text-left">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-stone-700">
                        Kode Bahan / Produk <span className="text-red-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setQuickKode(generateUniqueKode())}
                        className="text-[10px] text-indigo-600 font-bold hover:underline"
                      >
                        Auto
                      </button>
                    </div>
                    <input
                      type="text"
                      required
                      value={quickKode}
                      onChange={(e) => setQuickKode(e.target.value)}
                      placeholder="PRD-001"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                    {duplicateQuickProductByKode && (
                      <p className="text-[10px] text-red-600 mt-0.5 font-bold">
                        Kode sudah dipakai!
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Kategori Bahan
                    </label>
                    <select
                      value={quickKategori}
                      onChange={(e) => setQuickKategori(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold focus:outline-none"
                    >
                      <option value="Bahan Baku">Bahan Baku Kaos / Tekstil</option>
                      <option value="Bahan Cetak">Bahan Cetak & Kertas</option>
                      <option value="Banner">Banner & Vinyl</option>
                      <option value="Print A3">Print A3 & Offset</option>
                      <option value="Finishing">Finishing & Jilid</option>
                      <option value="Merchandise">Merchandise & Sablon</option>
                      <option value="Display">Display & Akrilik</option>
                      <option value="Stiker">Stiker & Polyflex</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nama Bahan Baku / Produk <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={quickNama}
                    onChange={(e) => setQuickNama(e.target.value)}
                    placeholder="Contoh: COTTON COMBED 30S, Art Carton 260g..."
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                  {duplicateQuickProductByNama && (
                    <p className="text-[10px] text-amber-700 mt-0.5 font-semibold">
                      Nama sudah ada di master (Kode: {duplicateQuickProductByNama.kode})
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Satuan Stok
                    </label>
                    <select
                      value={quickSatuan}
                      onChange={(e) => setQuickSatuan(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold focus:outline-none"
                    >
                      <option value="kg">kg (Kilogram)</option>
                      <option value="pcs">pcs</option>
                      <option value="meter">meter</option>
                      <option value="m²">m² (Meter Persegi)</option>
                      <option value="roll">roll</option>
                      <option value="lembar">lembar</option>
                      <option value="Rim">Rim</option>
                      <option value="Pak">Pak</option>
                      <option value="box">box</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Estimasi Harga Beli / Modal (Rp)
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={quickHargaBeli}
                      onChange={(e) => setQuickHargaBeli(e.target.value.replace(/[^0-9]/g, ''))}
                      onFocus={(e) => (e.target as HTMLInputElement).select()}
                      placeholder="Contoh: 90000"
                      className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-black text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Harga Jual Konsumen (Rp)
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={quickHargaJual}
                      onChange={(e) => setQuickHargaJual(e.target.value.replace(/[^0-9]/g, ''))}
                      onFocus={(e) => (e.target as HTMLInputElement).select()}
                      placeholder="Contoh: 120000"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Vendor / Suplier
                    </label>
                    <input
                      type="text"
                      value={quickSupplier}
                      onChange={(e) => setQuickSupplier(e.target.value)}
                      placeholder="PT. KNITTO TEKSTIL"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Spesifikasi / Catatan Bahan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={quickCatatan}
                    onChange={(e) => setQuickCatatan(e.target.value)}
                    placeholder="Contoh: Bahan reaktif lembut, gramasi 150-160 gsm..."
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsQuickAddModalOpen(false)}
                  className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95"
                >
                  {isSubmitting ? (
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  )}
                  <span>Simpan ke Master Bahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRMATION & OTORISASI MODAL HAPUS PRODUK (KHUSUS OWNER & SPV) */}
      {productToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
            <form onSubmit={handleDeleteConfirmed}>
              <div className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
                    isCurrentCashierSpv ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-amber-50 text-amber-600 border border-amber-200'
                  }`}>
                    {isCurrentCashierSpv ? (
                      <Trash2 className="w-5 h-5" />
                    ) : (
                      <ShieldAlert className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-stone-900 text-base">
                      Hapus Produk dari Sistem
                    </h3>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] font-extrabold tracking-wide uppercase px-2 py-0.5 rounded-full bg-red-100 text-red-700 border border-red-200">
                        Wewenang: Owner & SPV
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                  <div className="font-extrabold text-sm text-stone-900 truncate">
                    {productToDelete.nama}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-600">
                    <span>Kode: <strong className="text-stone-800">{productToDelete.kode || '-'}</strong></span>
                    <span>•</span>
                    <span>Kategori: <strong className="text-stone-800">{productToDelete.kategori || 'Umum'}</strong></span>
                    <span>•</span>
                    <span>Harga: <strong className="text-stone-900">{fRp(productToDelete.harga)}</strong></span>
                  </div>
                </div>

                {isCurrentCashierSpv ? (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-left">
                    <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-extrabold text-xs text-emerald-900 flex items-center gap-1.5">
                        <span>Wewenang Terverifikasi</span>
                        <span className="px-1.5 py-0.2 bg-emerald-200 text-emerald-800 text-[10px] rounded font-bold uppercase">
                          Owner / SPV
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-800 mt-1 leading-relaxed">
                        Anda login sebagai <strong className="text-emerald-950 font-bold">{currentCashier}</strong> dan memiliki wewenang untuk menghapus produk dari database kasir dan Google Sheets.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-left">
                      <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-extrabold text-xs text-amber-900">
                          Otorisasi Diperlukan
                        </div>
                        <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                          Operator kasir <strong className="text-stone-900">"{currentCashier}"</strong> tidak berwenang menghapus produk secara mandiri. Diperlukan persetujuan PIN/Password dari <strong>Owner</strong> atau <strong>Supervisor (SPV)</strong>.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2.5 text-left">
                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-stone-500" />
                          <span>Pilih Akun Otorisator (Owner / SPV)</span>
                        </label>
                        <select
                          value={authSpvUser}
                          onChange={(e) => {
                            setAuthSpvUser(e.target.value);
                            setAuthError(null);
                          }}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        >
                          {kasirUsers && kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, uIdx) => (
                            <option key={`bm-spv-${u.nama}-${uIdx}`} value={u.nama}>
                              {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(Owner / SPV)'}
                            </option>
                          ))}
                          {(!kasirUsers || kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0) && (
                            <>
                              <option key="bm-spv-fallback-owner" value="Owner">Owner / Pemilik Toko</option>
                              <option key="bm-spv-fallback-spv" value="SPV">Supervisor (SPV)</option>
                            </>
                          )}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                          <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                          <span>Password / PIN Otorisator</span>
                        </label>
                        <input
                          type="password"
                          value={authPassword}
                          onChange={(e) => {
                            setAuthPassword(e.target.value);
                            setAuthError(null);
                          }}
                          placeholder="Masukkan password atau PIN..."
                          autoFocus
                          required
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                        />
                      </div>

                      {authError && (
                        <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                          <span>{authError}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <p className="text-[11px] text-stone-500 text-left bg-stone-50 p-2.5 rounded-xl border border-stone-200 leading-relaxed">
                  <span className="font-bold text-stone-700">Perhatian:</span> Produk akan dihapus dari katalog kasir POS, database Firebase, dan baris produk Google Sheets.
                </p>
              </div>

              <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setProductToDelete(null);
                    setAuthPassword('');
                    setAuthError(null);
                  }}
                  disabled={isDeleting}
                  className="px-4 py-2 text-stone-700 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isDeleting}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  {isDeleting ? (
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  ) : isCurrentCashierSpv ? (
                    <Trash2 className="w-3.5 h-3.5" />
                  ) : (
                    <Lock className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {isDeleting
                      ? 'Menghapus...'
                      : isCurrentCashierSpv
                      ? 'Ya, Hapus Produk'
                      : 'Verifikasi & Hapus'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Otorisasi SPV/Owner untuk Menonaktifkan Pembukuan Otomatis */}
      {isUncheckAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-amber-500 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-white/20 rounded-xl">
                  <ShieldAlert className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm">Otorisasi SPV / Owner Diperlukan</h3>
                  <p className="text-[11px] text-amber-100 font-medium">
                    Proteksi Penonaktifan Catat Pembukuan Pengeluaran
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsUncheckAuthModalOpen(false);
                  setUncheckAuthPassword('');
                  setUncheckAuthError(null);
                }}
                className="p-1 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmUncheck} className="p-4 space-y-3.5">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 leading-relaxed space-y-1">
                <div className="font-black flex items-center gap-1.5 text-amber-950">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Peringatan SOP Keuangan Toko</span>
                </div>
                <p className="text-[11px] text-amber-800">
                  Menonaktifkan opsi ini berarti tagihan PO sebesar <strong className="text-amber-950 font-bold">{fRp(totalTagihanPo)}</strong> <strong>TIDAK AKAN</strong> dicatat ke Buku Kas & Laporan Pengeluaran Toko.
                </p>
                <p className="text-[11px] text-amber-800">
                  Untuk menghindari selisih kas, aksi ini <strong>wajib disetujui</strong> oleh Supervisor (SPV) atau Pemilik (Owner).
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span>Pilih Akun Otorisator (Owner / SPV)</span>
                </label>
                <select
                  value={uncheckAuthSpvUser}
                  onChange={(e) => {
                    setUncheckAuthSpvUser(e.target.value);
                    setUncheckAuthError(null);
                  }}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                >
                  {kasirUsers && kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, uIdx) => (
                    <option key={`uncheck-spv-${u.nama}-${uIdx}`} value={u.nama}>
                      {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(Owner / SPV)'}
                    </option>
                  ))}
                  {(!kasirUsers || kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0) && (
                    <>
                      <option key="uncheck-spv-fallback-owner" value="Owner">Owner / Pemilik Toko</option>
                      <option key="uncheck-spv-fallback-spv" value="SPV">Supervisor (SPV)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                  <span>Password / PIN Otorisator</span>
                </label>
                <input
                  type="password"
                  value={uncheckAuthPassword}
                  onChange={(e) => {
                    setUncheckAuthPassword(e.target.value);
                    setUncheckAuthError(null);
                  }}
                  placeholder="Masukkan password atau PIN otorisasi..."
                  autoFocus
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-stone-500" />
                  <span>Alasan Tidak Dicatat ke Kas Toko</span>
                </label>
                <select
                  value={uncheckReason}
                  onChange={(e) => setUncheckReason(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium text-stone-800 focus:bg-white focus:outline-none"
                >
                  <option value="Pembayaran via Rekening Pribadi Owner (Bukan Kas Toko)">
                    Pembayaran via Rekening Pribadi Owner (Bukan Kas Toko)
                  </option>
                  <option value="Barang Konsinyasi / Belum Bayar Tempo">
                    Barang Konsinyasi / Belum Bayar Tempo
                  </option>
                  <option value="Koreksi Stok Fisik / Bukan Pembelian Baru">
                    Koreksi Stok Fisik / Bukan Pembelian Baru
                  </option>
                  <option value="Telah Dicatat Terpisah di Pembukuan Lain">
                    Telah Dicatat Terpisah di Pembukuan Lain
                  </option>
                </select>
              </div>

              {uncheckAuthError && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{uncheckAuthError}</span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsUncheckAuthModalOpen(false);
                    setUncheckAuthPassword('');
                    setUncheckAuthError(null);
                  }}
                  className="px-4 py-2.5 text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl text-xs font-bold transition"
                >
                  Batal (Tetap Catat)
                </button>
                <button
                  type="submit"
                  className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verifikasi & Nonaktifkan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Vendor Add / Edit Modal */}
      {isQuickVendorModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-stone-900">
                    {vendorModalMode === 'edit' ? 'Edit Data Vendor Suplier' : 'Tambah Rekanan Vendor Baru'}
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    {vendorModalMode === 'edit'
                      ? 'Perbarui rincian kontak dan nomor rekening suplier'
                      : 'Data vendor akan otomatis tersimpan ke master suplier'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsQuickVendorModalOpen(false)}
                className="p-1.5 hover:bg-stone-200 text-stone-400 hover:text-stone-700 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickVendor} className="p-4 overflow-y-auto space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nama Vendor / Suplier <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PT. KNITTO TEKSTIL INDONESIA"
                  value={quickVendorNama}
                  onChange={(e) => setQuickVendorNama(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-bold text-stone-900 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Kategori Suplier
                  </label>
                  <select
                    value={quickVendorKategori}
                    onChange={(e) => setQuickVendorKategori(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="Tekstil & Garment">Tekstil & Garment</option>
                    <option value="Banner & Digital Printing">Banner & Digital Printing</option>
                    <option value="Kertas & Offset">Kertas & Offset</option>
                    <option value="Tinta & Sparepart">Tinta & Sparepart</option>
                    <option value="Sticker & Display">Sticker & Display</option>
                    <option value="Aksesoris & Finishing">Aksesoris & Finishing</option>
                    <option value="Logistik & Ekspedisi">Logistik & Ekspedisi</option>
                    <option value="Umum">Umum</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    PIC / Kontak Person
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Bpk. Hendra"
                    value={quickVendorKontakPerson}
                    onChange={(e) => setQuickVendorKontakPerson(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nomor Telepon / WA
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: 0812-3456-7890"
                    value={quickVendorTelepon}
                    onChange={(e) => setQuickVendorTelepon(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Email Suplier
                  </label>
                  <input
                    type="email"
                    placeholder="order@supplier.com"
                    value={quickVendorEmail}
                    onChange={(e) => setQuickVendorEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nomor Rekening Pembayaran
                </label>
                <input
                  type="text"
                  placeholder="Contoh: BCA 123-456-7890 a.n PT Supplier"
                  value={quickVendorNomorRekening}
                  onChange={(e) => setQuickVendorNomorRekening(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Alamat Suplier / Gudang
                </label>
                <textarea
                  rows={2}
                  placeholder="Alamat kantor / gudang suplier..."
                  value={quickVendorAlamat}
                  onChange={(e) => setQuickVendorAlamat(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Catatan Tambahan
                </label>
                <input
                  type="text"
                  placeholder="Catatan jenis bahan yang disuplai, diskon, dll..."
                  value={quickVendorCatatan}
                  onChange={(e) => setQuickVendorCatatan(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium text-stone-800 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsQuickVendorModalOpen(false)}
                  className="px-4 py-2 text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingQuickVendor}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSavingQuickVendor ? 'Menyimpan...' : 'Simpan Vendor'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS RIWAYAT BARANG MASUK (KHUSUS SPV & OWNER) */}
      {stockInToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
            <form onSubmit={handleConfirmDeleteStockIn}>
              <div className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center shrink-0">
                    <Trash2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-stone-900 text-base">
                      Hapus Riwayat Barang Masuk
                    </h3>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] font-extrabold tracking-wide uppercase px-2 py-0.5 rounded-full bg-red-100 text-red-700 border border-red-200">
                        Wewenang: SPV & Owner ({currentCashier})
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1.5 text-left">
                  <div className="font-extrabold text-sm text-stone-900 truncate">
                    {stockInToDelete.nama}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-600">
                    <span>Kode: <strong className="text-stone-800">{stockInToDelete.kode || '-'}</strong></span>
                    <span>•</span>
                    <span>Jumlah: <strong className="text-emerald-700">+{stockInToDelete.qty} {stockInToDelete.satuan}</strong></span>
                    <span>•</span>
                    <span>PO: <strong className="text-stone-800">{stockInToDelete.noPo || 'Restock Langsung'}</strong></span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-600 pt-1 border-t border-stone-200/60">
                    <span>Vendor: <strong className="text-stone-800">{stockInToDelete.supplier || '-'}</strong></span>
                    <span>•</span>
                    <span>Tanggal: <strong className="text-stone-800">{stockInToDelete.date} {stockInToDelete.time || ''}</strong></span>
                    {stockInToDelete.cashier && (
                      <>
                        <span>•</span>
                        <span>Petugas: <strong className="text-stone-800">{stockInToDelete.cashier}</strong></span>
                      </>
                    )}
                  </div>
                  {stockInToDelete.catatan && (
                    <div className="text-[11px] text-stone-500 bg-white p-2 rounded-lg border border-stone-200 mt-1">
                      Catatan: {stockInToDelete.catatan}
                    </div>
                  )}
                </div>

                {Number(stockInToDelete.qty) > 0 && (
                  <label className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 cursor-pointer text-left">
                    <input
                      type="checkbox"
                      checked={rollbackStockOnDelete}
                      onChange={(e) => setRollbackStockOnDelete(e.target.checked)}
                      className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 h-4 w-4 border-stone-300"
                    />
                    <div className="text-xs text-amber-900 leading-relaxed">
                      <span className="font-extrabold block text-amber-950">
                        Kurangi kembali stok produk otomatis (-{stockInToDelete.qty} {stockInToDelete.satuan})
                      </span>
                      <span className="text-[11px] text-amber-800 block mt-0.5">
                        Centang opsi ini agar penambahan stok dari catatan ini ditarik/dibatalkan kembali dari total stok produk di katalog.
                      </span>
                    </div>
                  </label>
                )}

                <p className="text-[11px] text-stone-500 text-left bg-stone-50 p-2.5 rounded-xl border border-stone-200 leading-relaxed">
                  <span className="font-bold text-stone-700">Pemberitahuan:</span> Baris riwayat barang masuk ini akan dihapus permanen dari daftar riwayat lokal dan database.
                </p>
              </div>

              <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStockInToDelete(null)}
                  disabled={isDeletingStockIn}
                  className="px-4 py-2 text-stone-700 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isDeletingStockIn}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                >
                  {isDeletingStockIn ? (
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isDeletingStockIn ? 'Menghapus...' : 'Ya, Hapus Catatan'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Otorisasi SPV / Owner untuk Pengubahan Kuantitas Stok */}
      {isStokAuthModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-amber-50/50">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center text-amber-700">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-sm">Otorisasi Ubah Stok Manual</h3>
                  <p className="text-[11px] text-stone-500">Khusus Supervisor (SPV) & Owner</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsStokAuthModalOpen(false);
                  setStokAuthError(null);
                  setStokAuthPassword('');
                }}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVerifyStokAuth} className="p-4 space-y-3">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-left">
                <p className="text-[11px] text-amber-900 leading-relaxed">
                  Pengubahan kuantitas stok produk secara manual hanya berhak dilakukan oleh <strong>Owner</strong> atau <strong>Supervisor (SPV)</strong>. Untuk kasir/operator biasa, penambahan stok harus dilakukan melalui menu <strong>PO & Restock</strong>.
                </p>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span>Pilih Akun Otorisator (Owner / SPV)</span>
                </label>
                <select
                  value={stokAuthSpvUser}
                  onChange={(e) => {
                    setStokAuthSpvUser(e.target.value);
                    setStokAuthError(null);
                  }}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                >
                  {kasirUsers && kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, uIdx) => (
                    <option key={`stok-spv-${u.nama}-${uIdx}`} value={u.nama}>
                      {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(Owner / SPV)'}
                    </option>
                  ))}
                  {(!kasirUsers || kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0) && (
                    <>
                      <option key="stok-spv-fallback-owner" value="Owner">Owner / Pemilik Toko</option>
                      <option key="stok-spv-fallback-spv" value="SPV">Supervisor (SPV)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                  <span>Password / PIN Otorisator</span>
                </label>
                <input
                  type="password"
                  value={stokAuthPassword}
                  onChange={(e) => {
                    setStokAuthPassword(e.target.value);
                    setStokAuthError(null);
                  }}
                  placeholder="Masukkan password atau PIN..."
                  autoFocus
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              {stokAuthError && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span>{stokAuthError}</span>
                </div>
              )}

              <div className="pt-2 border-t border-stone-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsStokAuthModalOpen(false);
                    setStokAuthError(null);
                    setStokAuthPassword('');
                  }}
                  className="px-4 py-2 text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Buka Kunci Stok</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
