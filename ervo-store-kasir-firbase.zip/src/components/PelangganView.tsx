import React, { useState } from 'react';
import { Customer } from '../types';
import { 
  Users, 
  Search, 
  UserPlus, 
  Phone, 
  MapPin, 
  Percent, 
  FileText,
  Building2,
  ShieldCheck,
  Trash2,
  AlertTriangle,
  Edit3
} from 'lucide-react';

interface PelangganViewProps {
  customers: Customer[];
  onOpenAddCustomer: () => void;
  onEditCustomer?: (customer: Customer) => void;
  onSelectCustomerToOrder?: (customerName: string, diskon?: number) => void;
  onDeleteCustomer?: (customerName: string) => void;
}

export const PelangganView: React.FC<PelangganViewProps> = ({
  customers,
  onOpenAddCustomer,
  onEditCustomer,
  onSelectCustomerToOrder,
  onDeleteCustomer,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  const filteredCustomers = customers.filter((c) => {
    const q = searchTerm.toLowerCase().trim();
    const matchesSearch =
      !q ||
      c.nama.toLowerCase().includes(q) ||
      c.telepon.toLowerCase().includes(q) ||
      (c.alamat && c.alamat.toLowerCase().includes(q));

    const matchesClass = selectedClass === 'all' || c.kelas.toLowerCase() === selectedClass.toLowerCase();

    return matchesSearch && matchesClass;
  });

  const classCategories = Array.from(new Set(customers.map((c) => c.kelas).filter(Boolean)));

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Banner */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-orange-600 rounded-xl text-white shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Database & Kelola Pelanggan</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-orange-500/30 text-orange-200 border border-orange-500/40 uppercase">
                {customers.length} Terdaftar
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Kelola kelas member, diskon khusus pelanggan, kontak WhatsApp, dan riwayat alamat pengiriman.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAddCustomer}
          className="px-3.5 py-2 bg-orange-700 hover:bg-orange-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-2 transition shrink-0 active:scale-95"
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Tambah Pelanggan Baru</span>
        </button>
      </div>

      {/* Controls Bar: Search & Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-stone-200 shadow-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            placeholder="Cari nama pelanggan, nomor HP, atau alamat..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-xs font-bold text-stone-500 whitespace-nowrap">Filter Kelas:</span>
          <button
            onClick={() => setSelectedClass('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
              selectedClass === 'all'
                ? 'bg-orange-700 text-white shadow-xs'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            Semua
          </button>
          {classCategories.map((cls, idx) => (
            <button
              key={`${cls}-${idx}`}
              onClick={() => setSelectedClass(cls)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                selectedClass === cls
                  ? 'bg-orange-700 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cls}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 flex-1">
        {filteredCustomers.length === 0 ? (
          <div className="col-span-full bg-white border border-stone-200 rounded-2xl p-12 text-center text-stone-400">
            <Users className="w-10 h-10 mx-auto text-stone-300 mb-2" />
            <p className="text-xs font-bold">Tidak ada data pelanggan yang cocok.</p>
          </div>
        ) : (
          filteredCustomers.map((c, idx) => (
            <div
              key={`${c.nama}-${idx}`}
              className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs hover:border-orange-300 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h4 className="font-extrabold text-sm text-stone-900">{c.nama}</h4>
                    <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-700 border border-stone-200 mt-1">
                      {c.kelas || 'Reguler'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {c.diskon > 0 && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-black px-2 py-1 rounded-lg bg-orange-100 text-orange-800 border border-orange-200">
                        <Percent className="w-3 h-3 text-orange-600" />
                        <span>Diskon {c.diskon}%</span>
                      </span>
                    )}

                    <button
                      type="button"
                      onClick={() => onEditCustomer && onEditCustomer(c)}
                      className="p-1.5 rounded-lg text-stone-500 hover:text-blue-700 hover:bg-blue-50 transition"
                      title="Edit Data Pelanggan"
                    >
                      <Edit3 className="w-4 h-4 text-blue-600" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setCustomerToDelete(c)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-red-700 hover:bg-red-50 transition"
                      title="Hapus Pelanggan"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-stone-600 mt-3 border-t border-stone-100 pt-3">
                  {c.telepon && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                      <a
                        href={`https://wa.me/${c.telepon.replace(/^0/, '62')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-orange-700 font-semibold hover:underline"
                      >
                        {c.telepon}
                      </a>
                    </div>
                  )}

                  {c.alamat && (
                    <div className="flex items-start gap-2">
                      <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                      <span className="text-stone-600 line-clamp-2">{c.alamat}</span>
                    </div>
                  )}

                  {c.catatan && (
                    <div className="flex items-start gap-2 text-stone-500 italic text-[11px] mt-1">
                      <FileText className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                      <span>"{c.catatan}"</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 mt-4">
                {onSelectCustomerToOrder && (
                  <button
                    onClick={() => onSelectCustomerToOrder(c.nama, c.diskon)}
                    className="flex-1 py-2 bg-stone-100 hover:bg-orange-700 hover:text-white text-stone-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <span>Pilih untuk Order Kasir</span>
                    <span>→</span>
                  </button>
                )}

                {onEditCustomer && (
                  <button
                    type="button"
                    onClick={() => onEditCustomer(c)}
                    className="px-3 py-2 bg-blue-50 hover:bg-blue-700 hover:text-white text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition flex items-center justify-center gap-1 shrink-0"
                    title="Edit Data Pelanggan"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setCustomerToDelete(c)}
                  className="px-3 py-2 bg-stone-100 hover:bg-red-600 hover:text-white text-stone-600 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1 shrink-0"
                  title="Hapus Pelanggan Ini"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Hapus</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CONFIRMATION MODAL HAPUS PELANGGAN */}
      {customerToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl overflow-hidden border border-stone-200">
            <div className="p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-stone-900 text-base">Hapus Pelanggan?</h3>
                <p className="text-xs text-stone-500 mt-1">
                  Apakah Anda yakin ingin menghapus data pelanggan <strong className="text-stone-900 font-bold">"{customerToDelete.nama}"</strong>?
                </p>
              </div>
            </div>

            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteCustomer && customerToDelete) {
                    onDeleteCustomer(customerToDelete.nama);
                  }
                  setCustomerToDelete(null);
                }}
                className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
