import React from 'react';
import { 
  Grid, 
  ShoppingCart, 
  Receipt, 
  BadgeDollarSign,
  Printer
} from 'lucide-react';
import { ViewTab } from '../types';
import { fRp } from '../utils/formatters';

interface MobileBottomNavProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  cartCount: number;
  cartTotal: number;
  onOpenReprint?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  onOpenReprint,
}) => {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-stone-200 px-1 py-1 shadow-lg">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Katalog */}
        <button
          onClick={() => setActiveTab('catalog')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition ${
            activeTab === 'catalog' ? 'text-orange-700 bg-orange-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Grid className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Katalog</span>
        </button>

        {/* Order / Keranjang with counter badge */}
        <button
          onClick={() => setActiveTab('cart')}
          className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition ${
            activeTab === 'cart' ? 'text-orange-700 bg-orange-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <div className="relative">
            <ShoppingCart className="w-5 h-5 mb-0.5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-orange-700 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] leading-tight">Order</span>
        </button>

        {/* Quick Cart Pill if items exist */}
        {cartCount > 0 && activeTab === 'catalog' && (
          <button
            onClick={() => setActiveTab('cart')}
            className="absolute -top-12 left-1/2 -translate-x-1/2 bg-orange-700 hover:bg-orange-800 text-white font-bold text-xs py-2 px-4 rounded-full shadow-xl flex items-center gap-2 border border-orange-600 transition active:scale-95"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{cartCount} Item ({fRp(cartTotal)})</span>
          </button>
        )}

        {/* Struk Preview */}
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition ${
            activeTab === 'preview' ? 'text-orange-700 bg-orange-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Receipt className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Struk</span>
        </button>

        {/* Pelunasan */}
        <button
          onClick={() => setActiveTab('pelunasan')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold transition ${
            activeTab === 'pelunasan' ? 'text-amber-700 bg-amber-50' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <BadgeDollarSign className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">Pelunasan</span>
        </button>

        {/* Cetak Ulang */}
        <button
          onClick={onOpenReprint}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-900 transition active:scale-95"
          title="Cetak Ulang Invoice Struk"
        >
          <Printer className="w-5 h-5 mb-0.5 text-stone-600" />
          <span className="text-[10px] leading-tight whitespace-nowrap">Cetak Ulang</span>
        </button>
      </div>
    </div>
  );
};
