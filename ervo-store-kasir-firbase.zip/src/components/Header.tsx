import React from 'react';
import { 
  Printer, 
  LogOut 
} from 'lucide-react';
import { StoreSettings } from '../types';

interface HeaderProps {
  settings: StoreSettings;
  currentUser?: string | null;
  isConnected?: boolean;
  isSyncing?: boolean;
  lastSyncTime?: string | null;
  onSync?: () => void;
  onOpenSettings?: () => void;
  onOpenReprint?: () => void;
  onOpenGasGuide?: () => void;
  onOpenBackup?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  currentUser,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-stone-200 shadow-xs shrink-0">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 h-16 flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-orange-700 flex items-center justify-center text-white font-bold shadow-xs shrink-0">
            <Printer className="w-6 h-6" />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 leading-none">
              <span className="font-black text-xl tracking-tight text-stone-900 truncate">
                {settings.name || 'ERVO PRINT'}
              </span>
              <span className="hidden sm:inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 border border-orange-200">
                Cepat / Tepat / Berkualitas
              </span>
            </div>
          </div>
        </div>

        {/* User & Logout Action */}
        <div className="flex items-center gap-2">
          {currentUser && (
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-stone-600 font-medium px-2.5 py-1 bg-stone-50 rounded-lg border border-stone-200">
              <span className="text-stone-400 font-normal">Kasir:</span>
              <span className="font-bold text-stone-800">{currentUser}</span>
            </div>
          )}
          {currentUser && onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="px-2.5 sm:px-3 py-1.5 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 cursor-pointer"
              title={`Keluar (${currentUser})`}
            >
              <LogOut className="w-3.5 h-3.5 text-red-600" />
              <span>Keluar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
