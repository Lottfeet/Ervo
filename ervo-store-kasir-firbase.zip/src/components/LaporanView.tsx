import React, { useState, useEffect, useMemo } from 'react';
import { fetchRecentInvoices, RecentInvoiceItem, fetchExpensesRemote, addExpenseRemote, deleteExpenseRemote, recalculateInvoiceSisaAndStatus, deleteInvoiceRemote, fetchStockOpnameHistory, deleteStockOpnameRecord, getInvoiceByNo, getDeletedInvoices, addDeletedInvoice, getDeletedExpenses, addDeletedExpense } from '../services/gasService';
import { subscribeInvoices, subscribeDeletedInvoices, subscribeExpenses, subscribeDeletedExpenses, saveExpenseFirebase, deleteExpenseFirebase, deleteInvoiceFirebase, subscribeStockOpname, deleteStockOpnameFirebase } from '../services/firebaseService';
import {
  getStoredExpenses,
  addExpenseRecord,
  updateExpenseRecord,
  deleteExpenseRecord,
  saveExpenses,
  deduplicateExpenses,
} from '../services/expenseService';
import { ExpenseRecord, StoreSettings, KasirUser, Customer, Product, Invoice, StockOpnameRecord, InvoiceItem } from '../types';
import { 
  fRp, 
  computeItemTotal,
  calculateCashInflowByPaymentMethod, 
  getInvoicePaymentCategory,
  calculatePeriodCashFlow,
  PeriodCashInflowBreakdown,
  PelunasanInflowItem,
  checkIsSpvOrOwner,
  compareInvoicesDesc,
} from '../utils/formatters';
import { 
  generateMonthlyReportPdf,
  generateCustomerBillingPdf,
  generateAllPiutangReportPdf,
  generateFinancialReportPdf,
  generateStockOpnamePdf,
  CustomerPiutangSummary,
} from '../utils/pdfGenerator';
import { exportUnifiedTransactionsToExcel } from '../utils/excelExporter';
import { TopProductsModal } from './TopProductsModal';
import { EditTransactionModal } from './EditTransactionModal';
import { StockOpnameModal } from './StockOpnameModal';
import { StockOpnameDetailModal } from './StockOpnameDetailModal';
import { 
  BarChart3, 
  Wallet, 
  BadgeDollarSign, 
  RotateCw, 
  Calendar, 
  TrendingUp, 
  TrendingDown,
  CreditCard, 
  FileText,
  AlertCircle,
  FileDown,
  Printer,
  X,
  Users,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Receipt,
  FileSpreadsheet,
  UserCheck,
  Plus,
  Trash2,
  PieChart,
  Tag,
  Building2,
  ReceiptText,
  Pencil,
  RefreshCw,
  Check,
  Award,
  Maximize2,
  ShieldCheck,
  Lock,
  KeyRound,
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  Play,
  Sparkles,
  Package
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

interface LaporanViewProps {
  onOpenReprint: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  currentUser?: string;
  settings?: StoreSettings;
  kasirUsers?: KasirUser[];
  customers?: Customer[];
  products?: Product[];
  onRefreshProducts?: () => void;
}

export const LaporanView: React.FC<LaporanViewProps> = ({
  onOpenReprint,
  onShowToast,
  currentUser,
  settings = {
    name: 'ERVO PRINT',
    address: 'Jl. HOS Cokroaminoto No.17, Ciamis',
    phone: '0812-2247-2007',
    footer: 'Terima Kasih Atas Kunjungan Anda',
    cashier: 'Admin',
    rekening: '',
  } as StoreSettings,
  kasirUsers = [],
  customers = [],
  products = [],
  onRefreshProducts,
}) => {
  const activeKasirName = (currentUser || localStorage.getItem('strukku_logged_kasir') || '').trim();
  const currentLoggedInUser = (currentUser || localStorage.getItem('strukku_logged_kasir') || settings?.cashier || 'Admin').trim();
  
  // Strict filter: Only accounts that are verified Supervisor (SPV) or Owner
  const spvAccounts = useMemo(() => {
    return kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
  }, [kasirUsers]);
  const [invoices, setInvoices] = useState<RecentInvoiceItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'keuangan' | 'sales' | 'pengeluaran' | 'piutang' | 'opname'>('keuangan');
  const [filterPeriod, setFilterPeriod] = useState<'today' | 'week' | 'month' | 'custom' | 'all'>('today');
  const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
  const [showExcelExportModal, setShowExcelExportModal] = useState<boolean>(false);
  const [isExportingExcel, setIsExportingExcel] = useState<boolean>(false);
  const [excelExportScope, setExcelExportScope] = useState<'filter' | 'all'>('filter');
  const [showTopProductsModal, setShowTopProductsModal] = useState<boolean>(false);

  // Stock Opname States
  const [stockOpnames, setStockOpnames] = useState<StockOpnameRecord[]>([]);
  const [opnameSearch, setOpnameSearch] = useState<string>('');
  const [opnameFilterStatus, setOpnameFilterStatus] = useState<string>('ALL');
  const [isOpnameModalOpen, setIsOpnameModalOpen] = useState<boolean>(false);
  const [activeDraftOpname, setActiveDraftOpname] = useState<StockOpnameRecord | null>(null);
  const [selectedOpnameForDetail, setSelectedOpnameForDetail] = useState<StockOpnameRecord | null>(null);
  const [opnameToDelete, setOpnameToDelete] = useState<StockOpnameRecord | null>(null);
  const [isDeletingOpname, setIsDeletingOpname] = useState<boolean>(false);

  // Edit / Koreksi Transaction State
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [invoiceToEdit, setInvoiceToEdit] = useState<Invoice | null>(null);

  // Delete Invoice State (Protected for SPV & Owner)
  const [invoiceToDelete, setInvoiceToDelete] = useState<any | null>(null);
  const [isDeleteSpvAuthorized, setIsDeleteSpvAuthorized] = useState<boolean>(false);
  const [deleteSpvUser, setDeleteSpvUser] = useState<string>('');
  const [deleteSpvPassword, setDeleteSpvPassword] = useState<string>('');
  const [deleteSpvError, setDeleteSpvError] = useState<string | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('Nota piutang dibatalkan / salah input');
  const [isDeletingInvoice, setIsDeletingInvoice] = useState<boolean>(false);

  // Item details expansion state for Piutang Pelanggan
  const [expandedInvoiceItems, setExpandedInvoiceItems] = useState<Record<string, boolean>>({});
  const [fetchedInvoiceItems, setFetchedInvoiceItems] = useState<Record<string, InvoiceItem[]>>({});
  const [loadingInvoiceItems, setLoadingInvoiceItems] = useState<Record<string, boolean>>({});

  // Synchronously resolve items for any invoice (checks invoice.items, fetched cache, or localStorage)
  const resolveInvoiceItems = (inv: RecentInvoiceItem): InvoiceItem[] => {
    if (Array.isArray(inv.items) && inv.items.length > 0) {
      return inv.items;
    }
    const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
    if (invNo && fetchedInvoiceItems[invNo] && fetchedInvoiceItems[invNo].length > 0) {
      return fetchedInvoiceItems[invNo];
    }
    try {
      const cached = localStorage.getItem('strukku_recent_invoices');
      if (cached) {
        const list: RecentInvoiceItem[] = JSON.parse(cached);
        const match = list.find((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === invNo.toLowerCase());
        if (match && Array.isArray(match.items) && match.items.length > 0) {
          return match.items;
        }
      }
    } catch {}
    return [];
  };

  // Asynchronously resolve items (fetches from backend if not yet in cache)
  const resolveInvoiceItemsAsync = async (inv: RecentInvoiceItem): Promise<InvoiceItem[]> => {
    const direct = resolveInvoiceItems(inv);
    if (direct.length > 0) return direct;

    const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
    if (!invNo) return [];

    try {
      const res = await getInvoiceByNo(invNo);
      if (res.success && res.data && Array.isArray(res.data.items) && res.data.items.length > 0) {
        setFetchedInvoiceItems((prev) => ({ ...prev, [invNo]: res.data!.items }));
        return res.data.items;
      }
    } catch (e) {
      console.warn('Failed to fetch items for invoice', invNo, e);
    }
    return [];
  };

  // Toggle single invoice items expansion in UI
  const handleToggleInvoiceItems = async (inv: RecentInvoiceItem) => {
    const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
    if (!invNo) return;

    const willExpand = !expandedInvoiceItems[invNo];
    setExpandedInvoiceItems((prev) => ({
      ...prev,
      [invNo]: willExpand,
    }));

    if (willExpand) {
      const currentItems = resolveInvoiceItems(inv);
      if (currentItems.length === 0) {
        setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: true }));
        try {
          const res = await getInvoiceByNo(invNo);
          if (res.success && res.data && Array.isArray(res.data.items)) {
            setFetchedInvoiceItems((prev) => ({ ...prev, [invNo]: res.data!.items }));
          }
        } catch (err) {
          console.warn('Error fetching items for invoice:', invNo, err);
        } finally {
          setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: false }));
        }
      }
    }
  };

  // Toggle all invoice items for a customer
  const handleToggleAllCustomerItems = async (summary: CustomerPiutangSummary) => {
    const allInvNos = summary.invoices
      .map((i) => (i.invoiceNo || (i as any).noInvoice || '').trim())
      .filter(Boolean);
    const areAllOpen = allInvNos.length > 0 && allInvNos.every((no) => Boolean(expandedInvoiceItems[no]));

    const newMap = { ...expandedInvoiceItems };
    allInvNos.forEach((no) => {
      newMap[no] = !areAllOpen;
    });
    setExpandedInvoiceItems(newMap);

    if (!areAllOpen) {
      // Need to open all: asynchronously fetch items for any invoice that does not have items yet
      for (const inv of summary.invoices) {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
        if (invNo && resolveInvoiceItems(inv).length === 0) {
          setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: true }));
          getInvoiceByNo(invNo)
            .then((res) => {
              if (res.success && res.data && Array.isArray(res.data.items)) {
                setFetchedInvoiceItems((prev) => ({ ...prev, [invNo]: res.data!.items }));
              }
            })
            .catch(() => {})
            .finally(() => {
              setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: false }));
            });
        }
      }
    }
  };

  const handleOpenEditInvoice = (rawInv: any) => {
    if (!rawInv) return;
    const inv: Invoice = {
      invoiceNo: rawInv.invoiceNo || rawInv.noInvoice || '',
      noInvoice: rawInv.invoiceNo || rawInv.noInvoice || '',
      date: rawInv.date || '',
      time: rawInv.time || '',
      customer: rawInv.customer || rawInv.pelanggan || 'Umum',
      pelanggan: rawInv.customer || rawInv.pelanggan || 'Umum',
      cashier: rawInv.cashier || rawInv.kasir || 'Admin',
      subtotal: rawInv.subtotal || rawInv.total || 0,
      discPct: rawInv.discPct || 0,
      discAmt: rawInv.discAmt || 0,
      taxPct: rawInv.taxPct || 0,
      taxAmt: rawInv.taxAmt || 0,
      negoAmt: rawInv.negoAmt || 0,
      total: rawInv.total || 0,
      payMethod: rawInv.payMethod || rawInv.metodePembayaran || (Number(rawInv.dp || 0) > 0 ? 'Tunai' : ''),
      metodePembayaran: rawInv.payMethod || rawInv.metodePembayaran || (Number(rawInv.dp || 0) > 0 ? 'Tunai' : ''),
      dp: rawInv.dp !== undefined ? rawInv.dp : (rawInv.total ? (rawInv.total - (rawInv.sisa || 0)) : 0),
      sisa: rawInv.sisa !== undefined ? rawInv.sisa : 0,
      kembalian: rawInv.kembalian || 0,
      deadline: rawInv.deadline || '',
      status: rawInv.status || ((rawInv.sisa || 0) <= 0 ? 'LUNAS' : 'DP'),
      customerPhone: rawInv.customerPhone || '',
      customerAddress: rawInv.customerAddress || '',
      items: Array.isArray(rawInv.items) ? rawInv.items : [],
      pelunasanHistory: Array.isArray(rawInv.pelunasanHistory) ? rawInv.pelunasanHistory : Array.isArray(rawInv.historiPelunasan) ? rawInv.historiPelunasan : [],
      historiPelunasan: Array.isArray(rawInv.historiPelunasan) ? rawInv.historiPelunasan : Array.isArray(rawInv.pelunasanHistory) ? rawInv.pelunasanHistory : [],
      lastEditedBy: rawInv.lastEditedBy,
      lastEditedAt: rawInv.lastEditedAt,
      editReason: rawInv.editReason,
      auditLogs: rawInv.auditLogs,
    };
    setInvoiceToEdit(inv);
    setIsEditModalOpen(true);
  };

  const handleOpenDeleteInvoice = (rawInv: any) => {
    if (!rawInv) return;
    setInvoiceToDelete(rawInv);
    setDeleteSpvPassword('');
    setDeleteSpvError(null);
    setDeleteReason('Nota piutang dibatalkan / salah input');

    const isCurrentActiveSpv = Boolean(activeKasirName && checkIsSpvOrOwner(activeKasirName, kasirUsers));
    if (isCurrentActiveSpv) {
      setIsDeleteSpvAuthorized(true);
      setDeleteSpvUser(activeKasirName);
    } else {
      setIsDeleteSpvAuthorized(false);
      const candidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (candidates.length > 0) {
        setDeleteSpvUser(candidates[0].nama);
      } else {
        setDeleteSpvUser('Owner');
      }
    }
  };

  const handleConfirmDeleteInvoice = async () => {
    if (!invoiceToDelete) return;
    setDeleteSpvError(null);

    // 1. Strict Security & Authorization Check
    let authorizer = activeKasirName;

    if (isDeleteSpvAuthorized) {
      // Re-verify that the active login user is genuinely an SPV or Owner
      if (!activeKasirName || !checkIsSpvOrOwner(activeKasirName, kasirUsers)) {
        setDeleteSpvError(`Akses Ditolak: Akun login aktif ("${activeKasirName || 'Tamu'}") bukan Supervisor atau Owner.`);
        setIsDeleteSpvAuthorized(false);
        return;
      }
      authorizer = activeKasirName;
    } else {
      // Must be authorized by a verified SPV or Owner account
      const selectedUser = (deleteSpvUser || '').trim();
      if (!selectedUser) {
        setDeleteSpvError('Pilih akun Supervisor (SPV) atau Owner untuk otorisasi.');
        return;
      }

      // CRITICAL: Block non-SPV / non-Owner accounts (e.g. regular cashiers)
      const isSelectedUserValidSpv = checkIsSpvOrOwner(selectedUser, kasirUsers) || selectedUser.toLowerCase() === 'owner' || selectedUser.toLowerCase() === 'spv';
      if (!isSelectedUserValidSpv) {
        setDeleteSpvError(`Akses Ditolak: Akun "${selectedUser}" bukan Supervisor atau Owner! Hanya Owner/SPV yang berhak menghapus data piutang.`);
        return;
      }

      if (!deleteSpvPassword.trim()) {
        setDeleteSpvError('Masukkan password / PIN otorisasi Supervisor / Owner.');
        return;
      }

      const targetUser = kasirUsers.find((u) => u.nama.trim().toLowerCase() === selectedUser.toLowerCase());
      const expectedPassword = targetUser?.password?.trim() || 'ervo123';

      if (deleteSpvPassword.trim() !== expectedPassword) {
        setDeleteSpvError(`Password / PIN otorisasi untuk ${selectedUser} salah.`);
        return;
      }

      authorizer = selectedUser;
    }

    const invNo = (invoiceToDelete.invoiceNo || invoiceToDelete.noInvoice || '').trim();
    if (!invNo) {
      onShowToast('Nomor invoice tidak valid', 'error');
      return;
    }

    setIsDeletingInvoice(true);
    try {
      // 1. Catat tombstone lokal & bersihkan cache seketika
      addDeletedInvoice(invNo);

      // 2. Hapus dari Cloud Firestore secara instan (< 300ms)
      await deleteInvoiceFirebase(invNo, authorizer, deleteReason || ('Dihapus oleh ' + authorizer));

      // 3. Langsung perbarui tampilan UI & tutup modal seketika
      setInvoices((prev) => prev.filter((it) => (it.invoiceNo || '').trim().toLowerCase() !== invNo.toLowerCase()));
      setInvoiceToDelete(null);
      onShowToast(`✓ Nota Piutang #${invNo} berhasil dihapus dari database oleh ${authorizer}!`, 'success');

      // 4. Sinkronisasi penghapusan baris Google Sheets dijalankan di latar belakang (background)
      // agar kasir/pengguna tidak menunggu loading lama (Google Sheets biasanya memakan waktu 15-40 detik)
      deleteInvoiceRemote(invNo).catch((err) => {
        console.warn('Background Sheets invoice delete error:', err);
      });
    } catch (err: any) {
      onShowToast('Gagal menghapus piutang: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsDeletingInvoice(false);
    }
  };

  // Expenses State
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [expenseSearch, setExpenseSearch] = useState<string>('');
  const [expenseCategoryFilter, setExpenseCategoryFilter] = useState<string>('ALL');
  const [showAddExpenseModal, setShowAddExpenseModal] = useState<boolean>(false);
  const [expenseToDelete, setExpenseToDelete] = useState<ExpenseRecord | null>(null);
  const [expenseToEdit, setExpenseToEdit] = useState<ExpenseRecord | null>(null);

  // Form State for Add Expense & Custom Date Filter
  const todayStr = new Date().toISOString().split('T')[0];
  const [expTanggal, setExpTanggal] = useState<string>(todayStr);
  const [expKategori, setExpKategori] = useState<string>('Bahan Baku');
  const [expKeterangan, setExpKeterangan] = useState<string>('');
  const [expNominal, setExpNominal] = useState<string>('');
  const [expPj, setExpPj] = useState<string>(() => currentLoggedInUser || 'Admin');

  // Handle opening add expense modal with fresh state & auto-filled logged in user
  const handleOpenAddExpense = () => {
    setExpTanggal(new Date().toISOString().split('T')[0]);
    setExpKategori('Bahan Baku');
    setExpKeterangan('');
    setExpNominal('');
    setExpPj(currentLoggedInUser || 'Admin');
    setShowAddExpenseModal(true);
  };

  // Form State for Edit Expense
  const [editExpTanggal, setEditExpTanggal] = useState<string>(todayStr);
  const [editExpKategori, setEditExpKategori] = useState<string>('Bahan Baku');
  const [editExpKeterangan, setEditExpKeterangan] = useState<string>('');
  const [editExpNominal, setEditExpNominal] = useState<string>('');
  const [editExpPj, setEditExpPj] = useState<string>('Admin / Kasir');

  // Custom Period Filter Dates
  const [customStartDate, setCustomStartDate] = useState<string>(todayStr);
  const [customEndDate, setCustomEndDate] = useState<string>(todayStr);

  const filterPeriodLabel = useMemo(() => {
    if (filterPeriod === 'today') return 'Hari Ini (' + new Date().toLocaleDateString('id-ID') + ')';
    if (filterPeriod === 'week') return '7 Hari Terakhir';
    if (filterPeriod === 'month') return 'Bulan Ini';
    if (filterPeriod === 'custom') return `Custom (${customStartDate} s/d ${customEndDate})`;
    return 'Semua Data';
  }, [filterPeriod, customStartDate, customEndDate]);

  // Daily Performance Chart State
  const [chartScope, setChartScope] = useState<'filter' | '7d' | '30d' | 'month'>('filter');
  const [chartViewMode, setChartViewMode] = useState<'both' | 'revenue' | 'count'>('both');
  const [showDailyTable, setShowDailyTable] = useState<boolean>(false);

  // Customer Piutang Search & Filters
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [selectedCustomerFilter, setSelectedCustomerFilter] = useState<string>('ALL');
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);

  // Month & Year selection for formal monthly PDF report
  const now = new Date();
  const [pdfMonth, setPdfMonth] = useState<number>(now.getMonth()); // 0 - 11
  const [pdfYear, setPdfYear] = useState<number>(now.getFullYear());

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const EXPENSE_CATEGORIES = [
    'Bahan Baku',
    'Gaji & Honorer',
    'Sewa & Utilitas',
    'Operasional & Makanan',
    'Maintenance & Service',
    'Adds & Promosi',
    'Lain-lain',
  ];

  const loadData = async () => {
    setIsLoading(true);
    const localExp = getStoredExpenses();
    setExpenses(localExp);

    try {
      const [res, remoteExp, remoteOpname] = await Promise.all([
        fetchRecentInvoices(),
        fetchExpensesRemote().catch((err) => {
          console.warn('Failed to sync remote expenses on loadData', err);
          return null;
        }),
        fetchStockOpnameHistory().catch((err) => {
          console.warn('Failed to sync remote opname on loadData', err);
          return [];
        }),
      ]);

      const deletedSet = getDeletedInvoices();
      const safeInvoices = (res.list || []).filter(
        (inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase())
      );
      if (safeInvoices.length > 0) {
        setInvoices((prev) => {
          const map = new Map<string, RecentInvoiceItem>();
          prev.forEach((inv) => {
            const k = (inv.invoiceNo || '').trim().toLowerCase();
            if (k && !deletedSet.has(k)) map.set(k, inv);
          });
          safeInvoices.forEach((inv) => {
            const k = (inv.invoiceNo || '').trim().toLowerCase();
            if (k && !deletedSet.has(k) && !map.has(k)) map.set(k, inv);
          });
          const list = Array.from(map.values());
          list.sort(compareInvoicesDesc);
          return list;
        });
      }
      if (remoteExp && remoteExp.length > 0) {
        const delExpSet = getDeletedExpenses();
        const curExp = getStoredExpenses().filter((it) => it && it.id && !delExpSet.has(it.id.trim().toLowerCase()));
        const safeRemote = remoteExp.filter((it) => it && it.id && !delExpSet.has(it.id.trim().toLowerCase()));
        const merged = deduplicateExpenses([...curExp, ...safeRemote]);
        saveExpenses(merged);
        setExpenses(merged);
      }
      if (remoteOpname && remoteOpname.length > 0) {
        setStockOpnames(remoteOpname);
      }
    } catch (err) {
      console.warn('Error loading data in LaporanView:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    const unsubInvoices = subscribeInvoices((list) => {
      const deletedSet = getDeletedInvoices();
      const safeList = (list as RecentInvoiceItem[]).filter(
        (inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase())
      );
      safeList.sort(compareInvoicesDesc);
      setInvoices(safeList);
    });

    const unsubDeletedInvoices = subscribeDeletedInvoices((deletedList) => {
      const delSet = new Set(deletedList.map((s) => s.trim().toLowerCase()));
      setInvoices((prev) => prev.filter((it) => it.invoiceNo && !delSet.has(it.invoiceNo.trim().toLowerCase())));
    });

    const unsubExpenses = subscribeExpenses((list) => {
      const delSet = getDeletedExpenses();
      const safeExpenses = (list || []).filter((it) => it && it.id && !delSet.has(it.id.trim().toLowerCase()));
      setExpenses(safeExpenses);
    });

    const unsubDeletedExpenses = subscribeDeletedExpenses((deletedList) => {
      const delSet = new Set(deletedList.map((s) => s.trim().toLowerCase()));
      setExpenses((prev) => prev.filter((it) => it.id && !delSet.has(it.id.trim().toLowerCase())));
    });

    const unsubStockOpname = subscribeStockOpname((list) => {
      if (list && list.length >= 0) {
        setStockOpnames(list);
      }
    });

    let isMounted = true;
    const handleDataChanged = () => {
      setTimeout(() => {
        if (isMounted) {
          loadData();
        }
      }, 0);
    };
    const handleLocalExpensesChanged = () => {
      setTimeout(() => {
        if (isMounted) {
          setExpenses(getStoredExpenses());
        }
      }, 0);
    };

    window.addEventListener('strukku-backup-restored', handleDataChanged);
    window.addEventListener('strukku-invoices-updated', handleDataChanged);
    window.addEventListener('strukku-expenses-updated', handleLocalExpensesChanged);

    return () => {
      isMounted = false;
      unsubInvoices();
      unsubDeletedInvoices();
      unsubExpenses();
      unsubDeletedExpenses();
      unsubStockOpname();
      window.removeEventListener('strukku-backup-restored', handleDataChanged);
      window.removeEventListener('strukku-invoices-updated', handleDataChanged);
      window.removeEventListener('strukku-expenses-updated', handleLocalExpensesChanged);
    };
  }, []);

  useEffect(() => {
    if (activeTab === 'piutang') {
      loadData();
    }
  }, [activeTab]);

  // Helper to parse any invoice date string into a local Date object (at 00:00:00 local time)
  const parseInvoiceDate = (dateStr?: string): Date | null => {
    if (!dateStr || typeof dateStr !== 'string' || !dateStr.trim()) return null;
    const cleaned = dateStr.trim();

    // Format 1: DD/MM/YYYY or DD/MM/YYYY HH:mm or D/M/YYYY
    if (cleaned.includes('/')) {
      const spaceSplit = cleaned.split(' ')[0];
      const parts = spaceSplit.split('/');
      if (parts.length === 3) {
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const year = parseInt(parts[2], 10);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
          return new Date(year, month, day);
        }
      }
    }

    // Format 2: YYYY-MM-DD or YYYY-MM-DD HH:mm or YYYY-MM-DDTHH:mm
    if (cleaned.includes('-')) {
      const spaceSplit = cleaned.split('T')[0].split(' ')[0];
      const parts = spaceSplit.split('-');
      if (parts.length === 3) {
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
          return new Date(year, month, day);
        }
      }
    }

    // Fallback standard parse
    const d = new Date(cleaned);
    if (!isNaN(d.getTime())) {
      return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    }

    return null;
  };

  const processedInvoices = useMemo(() => {
    const deletedSet = getDeletedInvoices();
    return (invoices || [])
      .filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()))
      .map((inv) => recalculateInvoiceSisaAndStatus(inv));
  }, [invoices]);

  // Filter Invoices by Period
  const filteredInvoices = useMemo(() => {
    if (filterPeriod === 'all') return processedInvoices;

    const now = new Date();
    const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    return processedInvoices.filter((inv) => {
      const itemDate = parseInvoiceDate(inv.date);
      if (!itemDate) return false;

      if (filterPeriod === 'today') {
        return (
          itemDate.getFullYear() === todayLocal.getFullYear() &&
          itemDate.getMonth() === todayLocal.getMonth() &&
          itemDate.getDate() === todayLocal.getDate()
        );
      }

      if (filterPeriod === 'week') {
        const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
        const endOfToday = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59, 999);
        return itemDate >= sevenDaysAgo && itemDate <= endOfToday;
      }

      if (filterPeriod === 'month') {
        return (
          itemDate.getFullYear() === todayLocal.getFullYear() &&
          itemDate.getMonth() === todayLocal.getMonth()
        );
      }

      if (filterPeriod === 'custom') {
        if (!customStartDate && !customEndDate) return true;
        const startD = customStartDate ? new Date(customStartDate + 'T00:00:00') : new Date(0);
        const endD = customEndDate ? new Date(customEndDate + 'T23:59:59.999') : new Date(8640000000000000);
        return itemDate >= startD && itemDate <= endD;
      }

      return true;
    });
  }, [invoices, filterPeriod, customStartDate, customEndDate]);

  // Toggle all invoice items for Daftar Transaksi Sales
  const handleToggleAllSalesItems = async () => {
    const allInvNos = filteredInvoices
      .map((i) => (i.invoiceNo || (i as any).noInvoice || '').trim())
      .filter(Boolean);
    const areAllOpen = allInvNos.length > 0 && allInvNos.every((no) => Boolean(expandedInvoiceItems[no]));

    const newMap = { ...expandedInvoiceItems };
    allInvNos.forEach((no) => {
      newMap[no] = !areAllOpen;
    });
    setExpandedInvoiceItems(newMap);

    if (!areAllOpen) {
      for (const inv of filteredInvoices) {
        const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
        if (invNo && resolveInvoiceItems(inv as any).length === 0) {
          setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: true }));
          getInvoiceByNo(invNo)
            .then((res) => {
              if (res.success && res.data && Array.isArray(res.data.items)) {
                setFetchedInvoiceItems((prev) => ({ ...prev, [invNo]: res.data!.items }));
              }
            })
            .catch(() => {})
            .finally(() => {
              setLoadingInvoiceItems((prev) => ({ ...prev, [invNo]: false }));
            });
        }
      }
    }
  };

  const areAllSalesItemsOpen = useMemo(() => {
    return filteredInvoices.length > 0 && filteredInvoices.every((inv) => Boolean(expandedInvoiceItems[(inv.invoiceNo || '').trim()]));
  }, [filteredInvoices, expandedInvoiceItems]);

  // Filter Expenses by Period, Search, & Category
  const filteredExpenses = useMemo(() => {
    const now = new Date();
    const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Deduplicate expenses array by ID or fallback composite key
    const seen = new Set<string>();
    const uniqueExpenses: typeof expenses = [];
    for (const exp of expenses) {
      if (!exp) continue;
      const key = exp.id && exp.id.trim() ? exp.id.trim() : `${exp.tanggal}-${exp.keterangan}-${exp.nominal}`;
      if (!seen.has(key)) {
        seen.add(key);
        uniqueExpenses.push(exp);
      }
    }

    return uniqueExpenses.filter((exp) => {
      // Period filter
      if (filterPeriod !== 'all') {
        const itemDate = parseInvoiceDate(exp.tanggal);
        if (itemDate) {
          if (filterPeriod === 'today') {
            if (
              itemDate.getFullYear() !== todayLocal.getFullYear() ||
              itemDate.getMonth() !== todayLocal.getMonth() ||
              itemDate.getDate() !== todayLocal.getDate()
            ) {
              return false;
            }
          } else if (filterPeriod === 'week') {
            const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
            const endOfToday = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59, 999);
            if (itemDate < sevenDaysAgo || itemDate > endOfToday) return false;
          } else if (filterPeriod === 'month') {
            if (
              itemDate.getFullYear() !== todayLocal.getFullYear() ||
              itemDate.getMonth() !== todayLocal.getMonth()
            ) {
              return false;
            }
          } else if (filterPeriod === 'custom') {
            const startD = customStartDate ? new Date(customStartDate + 'T00:00:00') : new Date(0);
            const endD = customEndDate ? new Date(customEndDate + 'T23:59:59.999') : new Date(8640000000000000);
            if (itemDate < startD || itemDate > endD) return false;
          }
        }
      }

      // Category filter
      if (expenseCategoryFilter !== 'ALL' && exp.kategori !== expenseCategoryFilter) {
        return false;
      }

      // Search filter
      if (expenseSearch.trim()) {
        const q = expenseSearch.toLowerCase();
        const matchKet = (exp.keterangan || '').toLowerCase().includes(q);
        const matchKat = (exp.kategori || '').toLowerCase().includes(q);
        const matchPj = (exp.pj || '').toLowerCase().includes(q);
        if (!matchKet && !matchKat && !matchPj) return false;
      }

      return true;
    });
  }, [expenses, filterPeriod, customStartDate, customEndDate, expenseCategoryFilter, expenseSearch]);

  // Expenses Statistics
  const totalExpenses = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + Number(e.nominal || 0), 0);
  }, [filteredExpenses]);

  // Expenses Category Breakdown
  const expensesByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    filteredExpenses.forEach((exp) => {
      const kat = exp.kategori || 'Lain-lain';
      map[kat] = (map[kat] || 0) + Number(exp.nominal || 0);
    });
    return map;
  }, [filteredExpenses]);

  // Period Cash Inflow Computation (includes direct Sales DP/Lunas in period + Cross-day Debt Pelunasan/Angsuran in period)
  const periodCashInflow = useMemo<PeriodCashInflowBreakdown>(() => {
    return calculatePeriodCashFlow(processedInvoices, filterPeriod, customStartDate, customEndDate);
  }, [processedInvoices, filterPeriod, customStartDate, customEndDate]);

  // Backward compatible cashInflowByMethod using the period cash flow calculation
  const cashInflowByMethod = periodCashInflow;

  // Analytics Computation for Sales Report
  const stats = useMemo(() => {
    let totalGross = 0;
    let totalPiutang = 0;
    let countLunas = 0;
    let countDP = 0;

    filteredInvoices.forEach((inv) => {
      const tot = Number(inv.total || 0);
      const sisa = Number(inv.sisa || 0);

      totalGross += tot;
      totalPiutang += sisa;

      if (sisa <= 0) countLunas++;
      else countDP++;
    });

    return {
      totalGross,
      totalPaid: periodCashInflow.Total,
      fromNewSales: periodCashInflow.fromNewSales,
      fromPelunasanPiutang: periodCashInflow.fromPelunasanPiutang,
      totalPiutang,
      count: filteredInvoices.length,
      countLunas,
      countDP,
      pelunasanCount: periodCashInflow.pelunasanItems.length,
    };
  }, [filteredInvoices, periodCashInflow]);

  // Aggregate Piutang per Customer Across All Invoices
  const customerPiutangSummaries = useMemo<CustomerPiutangSummary[]>(() => {
    const map = new Map<string, CustomerPiutangSummary>();

    processedInvoices.forEach((inv) => {
      const sisa = Number(inv.sisa || 0);
      if (sisa > 0) {
        const cName = (inv.customer || 'Umum').trim();
        const tot = Number(inv.total || 0);
        const paid = Math.max(0, tot - sisa);

        if (!map.has(cName)) {
          map.set(cName, {
            customerName: cName,
            invoices: [],
            totalGross: 0,
            totalPaid: 0,
            totalSisa: 0,
            count: 0,
          });
        }

        const item = map.get(cName)!;
        const exists = item.invoices.some((x) => x.invoiceNo && inv.invoiceNo && x.invoiceNo.trim().toLowerCase() === inv.invoiceNo.trim().toLowerCase());
        if (!exists) {
          item.invoices.push(inv);
          item.totalGross += tot;
          item.totalPaid += paid;
          item.totalSisa += sisa;
          item.count += 1;
        }
      }
    });

    return Array.from(map.values()).sort((a, b) => b.totalSisa - a.totalSisa);
  }, [invoices]);

  const grandTotalPiutang = useMemo(() => {
    return customerPiutangSummaries.reduce((acc, curr) => acc + curr.totalSisa, 0);
  }, [customerPiutangSummaries]);

  // Net Profit Computation
  const netProfit = stats.totalGross - totalExpenses;
  const profitMarginPct = stats.totalGross > 0 ? ((netProfit / stats.totalGross) * 100).toFixed(1) : '0';

  // Daily Performance Aggregation (Revenue & Transaction Count)
  const dailyPerformanceData = useMemo(() => {
    let sourceInvoices = filteredInvoices;

    const now = new Date();
    const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    if (chartScope === '7d') {
      const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
      sourceInvoices = invoices.filter((inv) => {
        const d = parseInvoiceDate(inv.date);
        return d && d >= sevenDaysAgo && d <= new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59);
      });
    } else if (chartScope === '30d') {
      const thirtyDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 29);
      sourceInvoices = invoices.filter((inv) => {
        const d = parseInvoiceDate(inv.date);
        return d && d >= thirtyDaysAgo && d <= new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59);
      });
    } else if (chartScope === 'month') {
      sourceInvoices = invoices.filter((inv) => {
        const d = parseInvoiceDate(inv.date);
        return d && d.getFullYear() === todayLocal.getFullYear() && d.getMonth() === todayLocal.getMonth();
      });
    }

    const map: Record<
      string,
      {
        rawDate: string;
        displayDate: string;
        shortDate: string;
        dayName: string;
        totalPendapatan: number;
        totalPaid: number;
        count: number;
        avgPerTx: number;
      }
    > = {};

    sourceInvoices.forEach((inv) => {
      const d = parseInvoiceDate(inv.date);
      if (!d) return;

      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const rawKey = `${yyyy}-${mm}-${dd}`;

      const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
      const monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];

      const dayName = dayNames[d.getDay()];
      const shortDate = `${d.getDate()} ${monthNamesShort[d.getMonth()]}`;
      const displayDate = `${dayName}, ${shortDate}`;

      const tot = Number(inv.total || 0);
      const sisa = Number(inv.sisa || 0);
      const paid = tot - sisa;

      if (!map[rawKey]) {
        map[rawKey] = {
          rawDate: rawKey,
          displayDate,
          shortDate,
          dayName,
          totalPendapatan: 0,
          totalPaid: 0,
          count: 0,
          avgPerTx: 0,
        };
      }

      map[rawKey].totalPendapatan += tot;
      map[rawKey].totalPaid += paid;
      map[rawKey].count += 1;
    });

    const sortedKeys = Object.keys(map).sort();
    return sortedKeys.map((k) => {
      const item = map[k];
      item.avgPerTx = item.count > 0 ? Math.round(item.totalPendapatan / item.count) : 0;
      return item;
    });
  }, [invoices, filteredInvoices, chartScope]);

  const dailyStats = useMemo(() => {
    const totalDays = dailyPerformanceData.length;
    const totalRev = dailyPerformanceData.reduce((sum, d) => sum + d.totalPendapatan, 0);
    const totalTx = dailyPerformanceData.reduce((sum, d) => sum + d.count, 0);
    const avgRevPerDay = totalDays > 0 ? Math.round(totalRev / totalDays) : 0;
    const avgTxPerDay = totalDays > 0 ? (totalTx / totalDays).toFixed(1) : '0';

    let peakDayItem = dailyPerformanceData.length > 0 ? dailyPerformanceData[0] : null;
    dailyPerformanceData.forEach((d) => {
      if (peakDayItem && d.totalPendapatan > peakDayItem.totalPendapatan) {
        peakDayItem = d;
      }
    });

    return {
      totalDays,
      totalRev,
      totalTx,
      avgRevPerDay,
      avgTxPerDay,
      peakDayItem,
    };
  }, [dailyPerformanceData]);

  // Sub-component Render function for Daily Performance Card & Recharts Chart
  const renderDailyPerformanceCard = () => {
    return (
      <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs flex flex-col gap-4">
        {/* Card Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-orange-100 text-orange-700 rounded-xl shadow-2xs">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-sm md:text-base flex items-center gap-2">
                <span>Performa Harian Kasir</span>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase">
                  Pendapatan & Transaksi
                </span>
              </h3>
              <p className="text-xs text-stone-500">
                Grafik total omset (pendapatan) dan jumlah nota transaksi yang diterbitkan per hari.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Toggle */}
            <div className="flex items-center bg-stone-100 p-1 rounded-xl text-xs font-bold text-stone-700 border border-stone-200/80">
              <button
                type="button"
                onClick={() => setChartViewMode('both')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  chartViewMode === 'both' ? 'bg-white text-stone-900 shadow-2xs font-extrabold' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setChartViewMode('revenue')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  chartViewMode === 'revenue' ? 'bg-emerald-600 text-white shadow-2xs font-extrabold' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                Pendapatan
              </button>
              <button
                type="button"
                onClick={() => setChartViewMode('count')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  chartViewMode === 'count' ? 'bg-orange-600 text-white shadow-2xs font-extrabold' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                Jumlah Tx
              </button>
            </div>

            {/* Chart Scope Select */}
            <select
              value={chartScope}
              onChange={(e) => setChartScope(e.target.value as any)}
              className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
            >
              <option value="filter">Ikuti Filter Periode</option>
              <option value="7d">7 Hari Terakhir</option>
              <option value="30d">30 Hari Terakhir</option>
              <option value="month">Bulan Ini</option>
            </select>

            <button
              type="button"
              onClick={() => setShowDailyTable(!showDailyTable)}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition flex items-center gap-1.5 ${
                showDailyTable
                  ? 'bg-stone-900 text-white border-stone-900'
                  : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>{showDailyTable ? 'Sembunyikan Tabel' : 'Tabel Harian'}</span>
            </button>
          </div>
        </div>

        {/* Quick KPI Highlights Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-xl p-2.5">
            <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block">Total Pendapatan</span>
            <span className="text-sm font-black text-emerald-950 block">{fRp(dailyStats.totalRev)}</span>
            <span className="text-[10px] font-bold text-emerald-700/80">{dailyStats.totalDays} Hari Beraktivitas</span>
          </div>

          <div className="bg-orange-50/80 border border-orange-200/80 rounded-xl p-2.5">
            <span className="text-[10px] font-extrabold text-orange-800 uppercase tracking-wider block">Total Transaksi</span>
            <span className="text-sm font-black text-orange-950 block">{dailyStats.totalTx} Nota</span>
            <span className="text-[10px] font-bold text-orange-700/80">Penjualan Diterbitkan</span>
          </div>

          <div className="bg-blue-50/80 border border-blue-200/80 rounded-xl p-2.5">
            <span className="text-[10px] font-extrabold text-blue-800 uppercase tracking-wider block">Rata-Rata Omset / Hari</span>
            <span className="text-sm font-black text-blue-950 block">{fRp(dailyStats.avgRevPerDay)}</span>
            <span className="text-[10px] font-bold text-blue-700/80">{dailyStats.avgTxPerDay} Nota / Hari</span>
          </div>

          <div className="bg-purple-50/80 border border-purple-200/80 rounded-xl p-2.5">
            <span className="text-[10px] font-extrabold text-purple-800 uppercase tracking-wider block">Hari Terramai</span>
            <span className="text-xs font-black text-purple-950 truncate block">
              {dailyStats.peakDayItem ? dailyStats.peakDayItem.displayDate : '-'}
            </span>
            <span className="text-[10px] font-bold text-purple-700/80">
              {dailyStats.peakDayItem ? `${fRp(dailyStats.peakDayItem.totalPendapatan)} (${dailyStats.peakDayItem.count} Nota)` : '-'}
            </span>
          </div>
        </div>

        {/* Recharts Graphical Chart */}
        {dailyPerformanceData.length === 0 ? (
          <div className="p-10 text-center text-stone-400 text-xs font-medium border border-dashed border-stone-200 rounded-xl">
            Belum ada data transaksi harian pada cakupan periode ini.
          </div>
        ) : (
          <div className="w-full h-64 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={dailyPerformanceData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f4" />
                <XAxis
                  dataKey="shortDate"
                  tick={{ fontSize: 11, fill: '#78716c', fontWeight: 600 }}
                  tickLine={false}
                  axisLine={{ stroke: '#e7e5e4' }}
                />
                <YAxis
                  yAxisId="left"
                  orientation="left"
                  tick={{ fontSize: 10, fill: '#059669', fontWeight: 700 }}
                  tickFormatter={(v) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : v >= 1000 ? `${(v/1000).toFixed(0)}k` : `${v}`}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fontSize: 10, fill: '#ea580c', fontWeight: 700 }}
                  tickFormatter={(v) => `${v} tx`}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-stone-900 text-white p-3 rounded-xl shadow-xl border border-stone-700 text-xs space-y-1.5 min-w-[190px]">
                          <p className="font-extrabold text-orange-400 border-b border-stone-700 pb-1 flex items-center justify-between">
                            <span>{data.displayDate}</span>
                            <span className="text-[10px] text-stone-400 font-mono">({data.rawDate})</span>
                          </p>
                          <div className="flex items-center justify-between text-stone-200">
                            <span className="flex items-center gap-1 font-bold text-emerald-400">
                              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                              Pendapatan:
                            </span>
                            <span className="font-extrabold font-mono text-emerald-300">{fRp(data.totalPendapatan)}</span>
                          </div>
                          <div className="flex items-center justify-between text-stone-200">
                            <span className="flex items-center gap-1 font-bold text-orange-400">
                              <span className="w-2 h-2 rounded-full bg-orange-400 inline-block"></span>
                              Jumlah Transaksi:
                            </span>
                            <span className="font-extrabold font-mono text-white">{data.count} Nota</span>
                          </div>
                          <div className="flex items-center justify-between text-stone-400 pt-1 border-t border-stone-800 text-[10px]">
                            <span>Rata-Rata / Nota:</span>
                            <span className="font-bold text-stone-200">{fRp(data.avgPerTx)}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: '8px', fontSize: '11px', fontWeight: 700 }} />

                {(chartViewMode === 'both' || chartViewMode === 'revenue') && (
                  <Bar
                    yAxisId="left"
                    dataKey="totalPendapatan"
                    name="Total Pendapatan (Rp)"
                    fill="#10b981"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={40}
                  />
                )}

                {(chartViewMode === 'both' || chartViewMode === 'count') && (
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="count"
                    name="Jumlah Transaksi (Nota)"
                    stroke="#ea580c"
                    strokeWidth={3}
                    dot={{ r: 4, fill: '#ea580c', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6, fill: '#c2410c' }}
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Detailed Daily Breakdown Table */}
        {showDailyTable && dailyPerformanceData.length > 0 && (
          <div className="mt-2 border-t border-stone-200/80 pt-3 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-stone-800 text-xs flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-orange-600" />
                <span>Rincian Performa Harian ({dailyPerformanceData.length} Hari)</span>
              </h4>
              <span className="text-[11px] text-stone-500 font-bold">
                Total Omset: <span className="text-emerald-700 font-black">{fRp(dailyStats.totalRev)}</span>
              </span>
            </div>

            <div className="overflow-x-auto max-h-60 overflow-y-auto border border-stone-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-stone-100 text-stone-700 font-bold uppercase text-[10px] border-b border-stone-200 z-10">
                  <tr>
                    <th className="p-2.5">Tanggal & Hari</th>
                    <th className="p-2.5 text-center">Jumlah Transaksi</th>
                    <th className="p-2.5 text-right">Total Pendapatan</th>
                    <th className="p-2.5 text-right">Uang Masuk</th>
                    <th className="p-2.5 text-right">Rata-Rata / Nota</th>
                    <th className="p-2.5 text-center">Status Performa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                  {dailyPerformanceData.slice().reverse().map((row, rIdx) => {
                    const isAboveAvg = row.totalPendapatan >= dailyStats.avgRevPerDay;
                    return (
                      <tr key={`${row.rawDate || 'date'}-${rIdx}`} className="hover:bg-stone-50/80 transition">
                        <td className="p-2.5 font-bold text-stone-900">{row.displayDate}</td>
                        <td className="p-2.5 text-center">
                          <span className="px-2 py-0.5 bg-orange-100 text-orange-800 font-extrabold rounded-full text-[11px]">
                            {row.count} Nota
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-black text-emerald-700">{fRp(row.totalPendapatan)}</td>
                        <td className="p-2.5 text-right font-mono font-bold text-stone-700">{fRp(row.totalPaid)}</td>
                        <td className="p-2.5 text-right font-mono text-stone-600">{fRp(row.avgPerTx)}</td>
                        <td className="p-2.5 text-center">
                          {isAboveAvg ? (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[10px]">
                              High Sales
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-stone-100 text-stone-600 font-bold rounded-full text-[10px]">
                              Normal
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Top Selling Products derived from filteredInvoices (which follows the active period filter)
  const topProductsData = useMemo(() => {
    const itemMap: Record<string, { fullName: string; jumlahOrder: number; totalNilai: number }> = {};
    let totalItemsFound = 0;

    filteredInvoices.forEach((inv) => {
      if (inv.items && Array.isArray(inv.items) && inv.items.length > 0) {
        inv.items.forEach((it) => {
          if (!it.nama) return;
          const nameKey = it.nama.trim();
          if (!itemMap[nameKey]) {
            itemMap[nameKey] = { fullName: nameKey, jumlahOrder: 0, totalNilai: 0 };
          }
          const qty = Number(it.qty || 1);
          const price = Number(it.harga || 0);
          const tot = Number(it.totalItem || (qty * price));
          itemMap[nameKey].jumlahOrder += qty;
          itemMap[nameKey].totalNilai += tot;
          totalItemsFound++;
        });
      }
    });

    if (totalItemsFound > 0) {
      return Object.values(itemMap)
        .sort((a, b) => b.jumlahOrder - a.jumlahOrder)
        .slice(0, 5)
        .map((p) => ({
          name: p.fullName.length > 18 ? p.fullName.substring(0, 18) + '...' : p.fullName,
          fullName: p.fullName,
          jumlahOrder: p.jumlahOrder,
          totalNilai: p.totalNilai,
        }));
    }

    return [];
  }, [filteredInvoices]);

  // Sub-component Render function for Top Products Card
  const renderTopProductsCard = () => {
    return (
      <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-2 border-b border-stone-100 gap-2">
          <div>
            <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
              <Award className="w-4 h-4 text-orange-600" />
              <span>Barang & Jasa Cetak Terlaris (Periode Ini)</span>
            </h3>
            <p className="text-[11px] text-stone-500">
              Peringkat produk/jasa cetak dengan volume order terbanyak berdasarkan transaksi penjualan pada periode ini.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
            <span className="text-[10px] font-extrabold px-2.5 py-1 bg-orange-50 text-orange-800 rounded-lg border border-orange-200">
              Terlaris Periode Terpilih
            </span>
            <button
              type="button"
              onClick={() => setShowTopProductsModal(true)}
              className="px-2.5 py-1.5 bg-stone-900 hover:bg-orange-700 text-white text-xs font-extrabold rounded-xl transition shadow-2xs flex items-center gap-1.5 active:scale-95 cursor-pointer shrink-0"
              title="Buka Modal Analisis Lengkap Barang/Jasa Cetak Terlaris"
            >
              <Maximize2 className="w-3.5 h-3.5 text-orange-400" />
              <span>Modal Terlaris</span>
            </button>
          </div>
        </div>

        {topProductsData.length === 0 ? (
          <div className="py-8 text-center text-stone-400 text-xs font-medium">
            Belum ada data rincian item barang/jasa cetak pada transaksi penjualan periode ini.
          </div>
        ) : (
          <div className="h-60 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topProductsData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <XAxis type="number" tick={{ fontSize: 10, fill: '#78716c' }} />
                <YAxis dataKey="name" type="category" width={115} tick={{ fontSize: 11, fill: '#44403c', fontWeight: 600 }} />
                <Tooltip 
                  formatter={(value: any, name: any) => [
                    name === 'jumlahOrder' ? `${value} x Order` : fRp(Number(value)),
                    name === 'jumlahOrder' ? 'Total Order' : 'Est. Omzet'
                  ]}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="jumlahOrder" fill="#c2410c" radius={[0, 8, 8, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    );
  };
  const handleAddExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nominalNum = parseFloat(String(expNominal).replace(',', '.')) || 0;
    if (isNaN(nominalNum) || nominalNum <= 0) {
      onShowToast('Nominal pengeluaran harus berupa angka lebih dari 0', 'error');
      return;
    }

    if (!expKeterangan.trim()) {
      onShowToast('Keterangan pengeluaran wajib diisi', 'error');
      return;
    }

    const newRec = addExpenseRecord({
      tanggal: expTanggal,
      kategori: expKategori,
      keterangan: expKeterangan.trim(),
      nominal: nominalNum,
      pj: (expPj || currentLoggedInUser || 'Admin').trim(),
    });

    setExpenses(getStoredExpenses());
    setShowAddExpenseModal(false);
    setExpKeterangan('');
    setExpNominal('');
    onShowToast(`Pengeluaran "${newRec.keterangan}" sebesar ${fRp(newRec.nominal)} berhasil dicatat!`, 'success');
  };

  // Open Edit Expense Modal
  const handleOpenEditExpense = (exp: ExpenseRecord) => {
    setExpenseToEdit(exp);
    setEditExpTanggal(exp.tanggal || todayStr);
    setEditExpKategori(exp.kategori || 'Bahan Baku');
    setEditExpKeterangan(exp.keterangan || '');
    setEditExpNominal(exp.nominal ? exp.nominal.toString() : '');
    setEditExpPj(exp.pj || 'Admin / Kasir');
  };

  // Handle Submit Edit Expense
  const handleEditExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseToEdit) return;

    const nominalNum = parseFloat(String(editExpNominal).replace(',', '.')) || 0;
    if (isNaN(nominalNum) || nominalNum <= 0) {
      onShowToast('Nominal pengeluaran harus berupa angka lebih dari 0', 'error');
      return;
    }

    if (!editExpKeterangan.trim()) {
      onShowToast('Keterangan pengeluaran wajib diisi', 'error');
      return;
    }

    updateExpenseRecord(expenseToEdit.id, {
      tanggal: editExpTanggal,
      kategori: editExpKategori,
      keterangan: editExpKeterangan.trim(),
      nominal: nominalNum,
      pj: editExpPj.trim() || 'Admin / Kasir',
    });

    setExpenses(getStoredExpenses());
    setExpenseToEdit(null);
    onShowToast(`Pengeluaran "${editExpKeterangan.trim()}" berhasil diperbarui!`, 'success');
  };

  // Handle Confirm Delete Expense
  const handleConfirmDeleteExpense = () => {
    if (!expenseToDelete) return;
    const target = expenseToDelete;
    deleteExpenseRecord(target.id);
    setExpenses(getStoredExpenses());
    setExpenseToDelete(null);
    onShowToast(`Catatan pengeluaran "${target.keterangan}" berhasil dihapus`, 'info');
  };

  // Handle Download PDF Financial Report
  const handleDownloadFinancialPdf = () => {
    let periodText = 'Hari Ini';
    if (filterPeriod === 'week') periodText = '7 Hari Terakhir';
    else if (filterPeriod === 'month') periodText = 'Bulan Ini';
    else if (filterPeriod === 'custom') periodText = `Periode Custom (${customStartDate} s/d ${customEndDate})`;
    else if (filterPeriod === 'all') periodText = 'Semua Transaksi';

    generateFinancialReportPdf({
      periodLabel: periodText,
      totalOmset: stats.totalGross,
      totalPaid: periodCashInflow.Total,
      totalPiutang: stats.totalPiutang,
      totalExpenses,
      expenses: filteredExpenses,
      expensesByCategory,
      invoices: filteredInvoices,
      allInvoices: processedInvoices,
      printedBy: activeKasirName,
      periodCashInflow: periodCashInflow,
      pelunasanItems: periodCashInflow.pelunasanItems,
      fromNewSales: periodCashInflow.fromNewSales,
      fromPelunasanPiutang: periodCashInflow.fromPelunasanPiutang,
    });

    onShowToast('Laporan Keuangan Perusahaan PDF berhasil diunduh!', 'success');
  };

  const uniqueCustomerNames = useMemo(() => {
    return customerPiutangSummaries.map((c) => c.customerName);
  }, [customerPiutangSummaries]);

  const filteredCustomerSummaries = useMemo(() => {
    return customerPiutangSummaries.filter((c) => {
      const matchesSearch = c.customerName.toLowerCase().includes(customerSearch.toLowerCase());
      const matchesDropdown = selectedCustomerFilter === 'ALL' || c.customerName === selectedCustomerFilter;
      return matchesSearch && matchesDropdown;
    });
  }, [customerPiutangSummaries, customerSearch, selectedCustomerFilter]);

  // Handle Printing Single Customer Billing PDF (Buku Besar Piutang / Kartu Piutang)
  const handlePrintCustomerBilling = async (summary: CustomerPiutangSummary) => {
    try {
      // Find customer detail if available
      const custObj = customers.find(
        (c) => c.nama.toLowerCase().trim() === summary.customerName.toLowerCase().trim()
      );

      // Ensure all invoices have their items populated
      const enrichedInvoices = await Promise.all(
        summary.invoices.map(async (inv) => {
          const items = await resolveInvoiceItemsAsync(inv);
          return {
            ...inv,
            items,
          };
        })
      );

      generateCustomerBillingPdf({
        customerName: summary.customerName,
        customerPhone: custObj?.telepon,
        customerAddress: custObj?.alamat,
        customerClass: custObj?.kelas,
        invoices: enrichedInvoices,
        printedBy: activeKasirName,
        rekening: settings?.rekening || undefined,
        storeName: settings?.name || undefined,
        storeAddress: settings?.address || undefined,
        storePhone: settings?.phone || undefined,
      });
      onShowToast(`Buku Besar & Surat Tagihan Piutang untuk ${summary.customerName} berhasil diunduh!`, 'success');
    } catch (err) {
      console.error('Failed to generate billing PDF:', err);
      onShowToast('Gagal mencetak Buku Besar Piutang PDF', 'error');
    }
  };

  // Handle Printing All Piutang PDF
  const handlePrintAllPiutang = () => {
    try {
      if (customerPiutangSummaries.length === 0) {
        onShowToast('Tidak ada data piutang pelanggan saat ini', 'info');
        return;
      }
      generateAllPiutangReportPdf({
        customerSummaries: customerPiutangSummaries,
        totalPiutang: grandTotalPiutang,
        printedBy: activeKasirName,
      });
      onShowToast('Rekapitulasi PDF Seluruh Piutang berhasil diunduh!', 'success');
    } catch (err) {
      console.error('Failed to generate overall piutang PDF:', err);
      onShowToast('Gagal mencetak Rekap Piutang PDF', 'error');
    }
  };

  // Handle Export Piutang to CSV Spreadsheet (Excel)
  const handleExportPiutangSpreadsheet = () => {
    if (customerPiutangSummaries.length === 0) {
      onShowToast('Tidak ada data piutang pelanggan untuk diexport', 'info');
      return;
    }

    try {
      const headers = [
        'Nama Pelanggan',
        'No Invoice / Nota',
        'Tanggal Transaksi',
        'Rincian Item Yang Dibeli',
        'Total Nota (Rp)',
        'Telah Dibayar (Rp)',
        'Sisa Piutang (Rp)',
        'Status Pembayaran'
      ];

      const rows: string[][] = [];

      customerPiutangSummaries.forEach((summary) => {
        summary.invoices.forEach((inv) => {
          const totalNota = Number(inv.total || 0);
          const sisa = Number(inv.sisa || 0);
          const dibayar = Math.max(0, totalNota - sisa);
          const itemsList = resolveInvoiceItems(inv);
          const itemsSummaryStr = itemsList.length > 0
            ? itemsList.map((it) => `${it.nama || 'Item'} (${it.qty || 1} ${it.satuan || 'pcs'})${it.catatan ? ` [Catatan/File: ${it.catatan}]` : ''}`).join('; ')
            : '-';

          rows.push([
            `"${summary.customerName.replace(/"/g, '""')}"`,
            `"${inv.invoiceNo || ''}"`,
            `"${inv.date || ''}"`,
            `"${itemsSummaryStr.replace(/"/g, '""')}"`,
            `${totalNota}`,
            `${dibayar}`,
            `${sisa}`,
            `"${inv.status || (sisa <= 0 ? 'LUNAS' : 'DP/SISA')}"`
          ]);
        });
      });

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      link.setAttribute('href', url);
      link.setAttribute('download', `Backup_Data_Piutang_Pelanggan_${dateStr}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      onShowToast('Data piutang berhasil di-export ke file Spreadsheet (.CSV)!', 'success');
    } catch (err) {
      console.error('Export CSV error:', err);
      onShowToast('Gagal meng-export data piutang ke CSV', 'error');
    }
  };

  // Handle Export Excel (.xlsx) matching exact format from pic1
  const handleExportExcelPic1 = async (scope: 'filter' | 'all' = excelExportScope) => {
    try {
      setIsExportingExcel(true);
      onShowToast('Menyiapkan file Excel (.xlsx)...', 'info');

      const isAll = scope === 'all' || filterPeriod === 'all';
      const targetInvoicesRaw = isAll ? processedInvoices : filteredInvoices;
      const targetExpensesRaw = isAll ? expenses : filteredExpenses;

      if (targetInvoicesRaw.length === 0 && targetExpensesRaw.length === 0) {
        onShowToast('Tidak ada data transaksi atau pengeluaran untuk diexport', 'info');
        setIsExportingExcel(false);
        return;
      }

      // Enrich invoices with items asynchronously
      const enrichedInvoices = await Promise.all(
        targetInvoicesRaw.map(async (inv) => {
          const items = await resolveInvoiceItemsAsync(inv as any);
          return {
            ...inv,
            items: items.length > 0 ? items : (inv.items || []),
          };
        })
      );

      const dateSuffix = isAll
        ? 'FULL_BACKUP'
        : (filterPeriod === 'today' ? 'HARI_INI' : (filterPeriod === 'month' ? 'BULAN_INI' : 'FILTER'));

      const nowStr = new Date().toISOString().split('T')[0];
      const fileName = `Laporan_Transaksi_ERVO_${dateSuffix}_${nowStr}.xlsx`;

      const result = exportUnifiedTransactionsToExcel({
        invoices: enrichedInvoices,
        expenses: targetExpensesRaw,
        products,
        activeKasir: activeKasirName || settings.cashier || 'Kasir Ervo 1',
        fileName,
      });

      if (result.success) {
        onShowToast(`Export Excel berhasil! ${result.rowCount} baris transaksi tersimpan ke ${fileName}`, 'success');
        setShowExcelExportModal(false);
      } else {
        onShowToast(`Gagal export Excel: ${result.error || 'Terjadi kesalahan'}`, 'error');
      }
    } catch (err: any) {
      console.error('Export Excel error:', err);
      onShowToast(`Gagal export Excel: ${err?.message || 'Terjadi kesalahan'}`, 'error');
    } finally {
      setIsExportingExcel(false);
    }
  };

  // Handle Export PDF directly for Active Filter or Selected Month (Menyertakan Rincian Item seperti Buku Besar Piutang)
  const handleDownloadPdfActive = async () => {
    try {
      let label = 'Laporan Penjualan';
      if (filterPeriod === 'today') label = 'Hari Ini (' + new Date().toLocaleDateString('id-ID') + ')';
      else if (filterPeriod === 'week') label = '7 Hari Terakhir';
      else if (filterPeriod === 'month') label = `Bulan ${monthNames[now.getMonth()]} ${now.getFullYear()}`;
      else if (filterPeriod === 'custom') label = `Periode Custom (${customStartDate} s/d ${customEndDate})`;
      else label = 'Semua Periode Transaksi';

      onShowToast('Menyiapkan rincian barang untuk laporan PDF...', 'info');

      // Pastikan seluruh invoice terisi rincian itemnya (seperti pada cetak PDF Buku Besar Piutang)
      const enrichedInvoices = await Promise.all(
        filteredInvoices.map(async (inv) => {
          const items = await resolveInvoiceItemsAsync(inv as any);
          return {
            ...inv,
            items,
          };
        })
      );

      generateMonthlyReportPdf({
        periodLabel: label,
        invoices: enrichedInvoices,
        stats: stats,
        printedBy: activeKasirName,
        periodCashInflow: periodCashInflow,
        pelunasanItems: periodCashInflow.pelunasanItems,
      });

      onShowToast('Laporan PDF Penjualan Sales berhasil diunduh!', 'success');
    } catch (err: any) {
      console.error('Failed to generate PDF:', err);
      onShowToast('Gagal mengunduh laporan PDF', 'error');
    }
  };

  const handleDownloadPdfSpecificMonth = async () => {
    try {
      const monthlyInvoices = processedInvoices.filter((inv) => {
        const itemDate = parseInvoiceDate(inv.date);
        if (!itemDate) return false;
        return itemDate.getMonth() === pdfMonth && itemDate.getFullYear() === pdfYear;
      });

      const mCashInflow = calculatePeriodCashFlow(
        monthlyInvoices,
        (invDateStr) => {
          const d = parseInvoiceDate(invDateStr);
          if (!d) return false;
          return d.getMonth() === pdfMonth && d.getFullYear() === pdfYear;
        },
        processedInvoices
      );

      let totalGross = 0;
      let totalPaid = 0;
      let totalPiutang = 0;
      let countLunas = 0;
      let countDP = 0;

      monthlyInvoices.forEach((inv) => {
        const tot = Number(inv.total || 0);
        const sisa = Number(inv.sisa || 0);
        const paid = tot - sisa;

        totalGross += tot;
        totalPaid += paid;
        totalPiutang += sisa;

        if (sisa <= 0) countLunas++;
        else countDP++;
      });

      const mStats = {
        totalGross,
        totalPaid: mCashInflow.totalCashIn,
        totalPiutang,
        count: monthlyInvoices.length,
        countLunas,
        countDP,
        fromNewSales: mCashInflow.fromNewSales,
        fromPelunasanPiutang: mCashInflow.fromPelunasanPiutang,
      };

      const label = `Bulan ${monthNames[pdfMonth]} ${pdfYear}`;

      onShowToast('Menyiapkan rincian barang untuk laporan PDF...', 'info');

      // Pastikan seluruh invoice bulanan terisi rincian itemnya
      const enrichedMonthlyInvoices = await Promise.all(
        monthlyInvoices.map(async (inv) => {
          const items = await resolveInvoiceItemsAsync(inv as any);
          return {
            ...inv,
            items,
          };
        })
      );

      generateMonthlyReportPdf({
        periodLabel: label,
        invoices: enrichedMonthlyInvoices,
        stats: mStats,
        printedBy: activeKasirName,
        periodCashInflow: mCashInflow,
        pelunasanItems: mCashInflow.pelunasanItems,
      });

      setShowPdfModal(false);
      onShowToast(`Laporan PDF ${label} berhasil diunduh!`, 'success');
    } catch (err: any) {
      console.error('Failed to generate PDF:', err);
      onShowToast('Gagal mengunduh laporan PDF', 'error');
    }
  };

  // Filtered Stock Opname records based on search and status
  const filteredStockOpnames = useMemo(() => {
    return stockOpnames.filter((rec) => {
      const isDraft = rec.status === 'DRAFT';
      if (opnameFilterStatus === 'draft' && !isDraft) return false;
      if (opnameFilterStatus === 'approved' && isDraft) return false;
      if (opnameFilterStatus === 'diff' && (rec.totalItemSelisih || 0) === 0) return false;
      if (opnameFilterStatus === 'match' && (rec.totalItemSelisih || 0) > 0) return false;
      if (opnameSearch.trim()) {
        const q = opnameSearch.toLowerCase();
        const matchId = (rec.id || '').toLowerCase().includes(q);
        const matchKasir = (rec.pjKasir || '').toLowerCase().includes(q);
        const matchSpv = (rec.authorizedBy || '').toLowerCase().includes(q);
        const matchCatatan = (rec.catatanUmum || '').toLowerCase().includes(q);
        if (!matchId && !matchKasir && !matchSpv && !matchCatatan) return false;
      }
      return true;
    });
  }, [stockOpnames, opnameFilterStatus, opnameSearch]);

  // Overall Stock Opname statistics
  const opnameAllStats = useMemo(() => {
    let totalItemsAudited = 0;
    let totalItemsDiff = 0;
    let totalKurang = 0;
    let totalLebih = 0;
    let totalNominal = 0;
    let totalDrafts = 0;
    let totalApproved = 0;

    stockOpnames.forEach((rec) => {
      if (rec.status === 'DRAFT') {
        totalDrafts += 1;
      } else {
        totalApproved += 1;
      }
      totalItemsAudited += rec.totalItemDiperiksa || 0;
      totalItemsDiff += rec.totalItemSelisih || 0;
      totalKurang += rec.totalSelisihKurangQty || 0;
      totalLebih += rec.totalSelisihLebihQty || 0;
      totalNominal += rec.totalSelisihNominalRp || 0;
    });

    return {
      totalSessions: stockOpnames.length,
      totalDrafts,
      totalApproved,
      totalItemsAudited,
      totalItemsDiff,
      totalKurang: Math.round(totalKurang * 100) / 100,
      totalLebih: Math.round(totalLebih * 100) / 100,
      totalNominal: Math.round(totalNominal),
    };
  }, [stockOpnames]);

  const handleDownloadOpnamePdf = (record: StockOpnameRecord) => {
    try {
      generateStockOpnamePdf(record, settings);
      onShowToast(`Berita Acara Opname #${record.id} berhasil diunduh!`, 'success');
    } catch (err: any) {
      console.error('Failed to generate opname PDF:', err);
      onShowToast('Gagal mengunduh Berita Acara PDF: ' + (err?.message || ''), 'error');
    }
  };

  const handleConfirmDeleteOpname = async () => {
    if (!opnameToDelete) return;
    setIsDeletingOpname(true);
    try {
      await deleteStockOpnameFirebase(opnameToDelete.id);
      await deleteStockOpnameRecord(opnameToDelete.id);
      setStockOpnames((prev) => prev.filter((r) => r.id !== opnameToDelete.id));
      onShowToast(`Berita Acara #${opnameToDelete.id} berhasil dihapus`, 'info');
      setOpnameToDelete(null);
    } catch (err: any) {
      onShowToast('Gagal menghapus sesi opname: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsDeletingOpname(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Banner */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-orange-600 rounded-xl text-white shrink-0 shadow-md">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Laporan Keuangan & Operasional Studio</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-orange-500/30 text-orange-200 border border-orange-500/40 uppercase">
                Integrasi Real-Time
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Rekap omset penjualan, pengeluaran operasional, laba rugi bersih, dan piutang pelanggan.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          <button
            onClick={handleOpenAddExpense}
            className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Pengeluaran</span>
          </button>

          <button
            onClick={handleDownloadFinancialPdf}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition active:scale-95 shrink-0"
          >
            <FileDown className="w-4 h-4" />
            <span>Cetak PDF Laporan Keuangan</span>
          </button>

          <button
            onClick={() => setShowExcelExportModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-xs transition active:scale-95 shrink-0 cursor-pointer"
            title="Export Excel (.xlsx) Transaksi Penjualan & Kas Keluar"
          >
            <FileSpreadsheet className="w-4 h-4 text-teal-200" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={loadData}
            disabled={isLoading}
            className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition active:scale-95 shrink-0"
            title="Refresh Data"
          >
            <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Sub-Navigation Bar */}
      <div className="bg-white border border-stone-200/80 rounded-2xl p-1.5 shadow-xs flex flex-wrap sm:flex-nowrap items-center gap-1">
        <button
          onClick={() => setActiveTab('keuangan')}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            activeTab === 'keuangan'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <PieChart className="w-4 h-4 text-orange-500" />
          <span>Laporan Keuangan</span>
        </button>

        <button
          onClick={() => setActiveTab('sales')}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            activeTab === 'sales'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-500" />
          <span>Laporan Sales ({filteredInvoices.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('pengeluaran')}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            activeTab === 'pengeluaran'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <TrendingDown className="w-4 h-4 text-red-500" />
          <span>Pengeluaran ({filteredExpenses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('piutang')}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            activeTab === 'piutang'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Users className="w-4 h-4 text-amber-500" />
          <span>Piutang Pelanggan ({customerPiutangSummaries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('opname')}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
            activeTab === 'opname'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <ClipboardCheck className="w-4 h-4 text-purple-500" />
          <span>Stok Opname ({stockOpnames.length})</span>
        </button>
      </div>

      {/* Global Filter Period Bar */}
      <div className="bg-stone-50 border border-stone-200/80 rounded-2xl p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-stone-700">
          <Calendar className="w-4 h-4 text-orange-600" />
          <span>Filter Periode Laporan:</span>
        </div>

        <div className="flex items-center gap-1 bg-white p-1 border border-stone-200 rounded-xl shadow-2xs flex-wrap">
          {[
            { key: 'today', label: 'Hari Ini' },
            { key: 'week', label: '7 Hari Terakhir' },
            { key: 'month', label: 'Bulan Ini' },
            { key: 'custom', label: 'Periode Custom' },
            { key: 'all', label: 'Semua Transaksi' },
          ].map((period) => (
            <button
              key={period.key}
              onClick={() => setFilterPeriod(period.key as any)}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition ${
                filterPeriod === period.key
                  ? 'bg-orange-600 text-white shadow-2xs'
                  : 'text-stone-600 hover:bg-stone-100'
              }`}
            >
              {period.label}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Date Range Picker inputs when 'custom' is selected */}
      {filterPeriod === 'custom' && (
        <div className="bg-orange-50/80 border border-orange-200/90 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs animate-fadeIn">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-extrabold text-orange-950 flex items-center gap-1.5 shrink-0 mr-1">
              <Calendar className="w-4 h-4 text-orange-600" />
              <span>Pilih Rentang Tanggal:</span>
            </span>

            <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 border border-stone-300 rounded-xl shadow-2xs">
              <span className="text-stone-500 font-bold text-[11px]">Dari:</span>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="font-bold text-xs text-stone-800 focus:outline-none bg-transparent cursor-pointer"
              />
            </div>

            <span className="text-stone-400 font-bold">s/d</span>

            <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 border border-stone-300 rounded-xl shadow-2xs">
              <span className="text-stone-500 font-bold text-[11px]">Sampai:</span>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="font-bold text-xs text-stone-800 focus:outline-none bg-transparent cursor-pointer"
              />
            </div>
          </div>

          <div className="text-[11px] font-bold text-orange-900 bg-white/90 px-3 py-1 rounded-xl border border-orange-200/80 shadow-2xs flex items-center gap-1">
            <span>Menampilkan data:</span>
            <strong className="text-orange-950">{customStartDate}</strong>
            <span>s/d</span>
            <strong className="text-orange-950">{customEndDate}</strong>
          </div>
        </div>
      )}

      {/* TAB 1: LAPORAN KEUANGAN PERUSAHAAN (Laba Rugi & Executive Summary) */}
      {activeTab === 'keuangan' && (
        <div className="flex flex-col gap-4">
          {/* Executive Financial Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Omset Card */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50/50 border border-blue-200/80 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-blue-900 uppercase tracking-wider">Total Omset</span>
                <div className="p-2 bg-blue-600 rounded-xl text-white">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-blue-950">{fRp(stats.totalGross)}</p>
              <div className="mt-2 text-[11px] font-semibold text-blue-800/80 flex items-center justify-between border-t border-blue-200/60 pt-2">
                <span>Lunas: {fRp(stats.totalPaid)}</span>
                <span className="text-amber-700">Piutang: {fRp(stats.totalPiutang)}</span>
              </div>
            </div>

            {/* Expenses Card */}
            <div className="bg-gradient-to-br from-red-50 to-rose-50/50 border border-red-200/80 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-red-900 uppercase tracking-wider">Total Pengeluaran</span>
                <div className="p-2 bg-red-600 rounded-xl text-white">
                  <TrendingDown className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-red-950">{fRp(totalExpenses)}</p>
              <div className="mt-2 text-[11px] font-semibold text-red-800/80 flex items-center justify-between border-t border-red-200/60 pt-2">
                <span>{filteredExpenses.length} Transaksi Biaya</span>
                <span>Operasional</span>
              </div>
            </div>

            {/* Net Profit Card */}
            <div className={`border rounded-2xl p-4 shadow-xs ${
              netProfit >= 0
                ? 'bg-gradient-to-br from-emerald-50 to-teal-50/50 border-emerald-200/80'
                : 'bg-gradient-to-br from-amber-50 to-orange-50/50 border-amber-200/80'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs font-extrabold uppercase tracking-wider ${
                  netProfit >= 0 ? 'text-emerald-900' : 'text-amber-900'
                }`}>
                  {netProfit >= 0 ? 'Laba Bersih (Profit)' : 'Rugi Bersih (Defisit)'}
                </span>
                <div className={`p-2 rounded-xl text-white ${netProfit >= 0 ? 'bg-emerald-600' : 'bg-amber-600'}`}>
                  <BadgeDollarSign className="w-4 h-4" />
                </div>
              </div>
              <p className={`text-xl font-black ${netProfit >= 0 ? 'text-emerald-950' : 'text-amber-950'}`}>
                {fRp(netProfit)}
              </p>
              <div className={`mt-2 text-[11px] font-semibold border-t pt-2 flex items-center justify-between ${
                netProfit >= 0 ? 'text-emerald-800/80 border-emerald-200/60' : 'text-amber-800/80 border-amber-200/60'
              }`}>
                <span>Profit Margin</span>
                <span className="font-extrabold">{profitMarginPct}%</span>
              </div>
            </div>

            {/* Net Cashflow Card */}
            <div className="bg-gradient-to-br from-stone-900 to-stone-800 text-white rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-stone-300 uppercase tracking-wider">Arus Kas Masuk (Real)</span>
                <div className="p-2 bg-orange-600 rounded-xl text-white">
                  <Wallet className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-white">{fRp(stats.totalPaid - totalExpenses)}</p>
              <div className="mt-2 text-[11px] font-semibold text-stone-400 flex items-center justify-between border-t border-stone-700/80 pt-2">
                <span>Uang Masuk - Biaya</span>
                <span className="text-orange-400 font-bold">Kas Nyata</span>
              </div>
            </div>
          </div>

          {/* Rincian Kas Masuk Berdasarkan Metode Pembayaran (Full Width Bar) */}
          <div className="bg-white border border-stone-200/90 rounded-2xl p-3.5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 mb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-orange-100 text-orange-700 shadow-2xs">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-stone-900 uppercase tracking-wider">
                    Rincian Arus Kas Masuk Menurut Metode Pembayaran
                  </h4>
                  <p className="text-[10px] text-stone-500 font-medium">
                    Total penerimaan kas nyata (DP & Pelunasan) yang dikelompokkan berdasarkan metode
                  </p>
                </div>
              </div>
              <div className="text-[11px] font-bold text-stone-700 bg-stone-100/90 border border-stone-200 px-3 py-1 rounded-xl self-start sm:self-auto">
                Total Penerimaan: <span className="text-emerald-700 font-black">{fRp(cashInflowByMethod.Total)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Tunai */}
              <div className="bg-gradient-to-br from-emerald-50/90 to-teal-50/60 border border-emerald-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
                <div>
                  <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block mb-0.5">
                    Kas Tunai
                  </span>
                  <span className="text-sm sm:text-base font-black text-emerald-950">
                    {fRp(cashInflowByMethod.Tunai)}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-emerald-700 bg-emerald-100/90 px-2 py-0.5 rounded-md">
                  {cashInflowByMethod.counts.Tunai} Trx
                </div>
              </div>

              {/* Transfer */}
              <div className="bg-gradient-to-br from-blue-50/90 to-indigo-50/60 border border-blue-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
                <div>
                  <span className="text-[10px] font-extrabold text-blue-800 uppercase tracking-wider block mb-0.5">
                    Transfer Bank
                  </span>
                  <span className="text-sm sm:text-base font-black text-blue-950">
                    {fRp(cashInflowByMethod.Transfer)}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-blue-700 bg-blue-100/90 px-2 py-0.5 rounded-md">
                  {cashInflowByMethod.counts.Transfer} Trx
                </div>
              </div>

              {/* Debet */}
              <div className="bg-gradient-to-br from-purple-50/90 to-fuchsia-50/60 border border-purple-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
                <div>
                  <span className="text-[10px] font-extrabold text-purple-800 uppercase tracking-wider block mb-0.5">
                    Kartu Debet
                  </span>
                  <span className="text-sm sm:text-base font-black text-purple-950">
                    {fRp(cashInflowByMethod.Debet)}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-purple-700 bg-purple-100/90 px-2 py-0.5 rounded-md">
                  {cashInflowByMethod.counts.Debet} Trx
                </div>
              </div>

              {/* QRIS */}
              <div className="bg-gradient-to-br from-amber-50/90 to-orange-50/60 border border-amber-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
                <div>
                  <span className="text-[10px] font-extrabold text-amber-800 uppercase tracking-wider block mb-0.5">
                    QRIS
                  </span>
                  <span className="text-sm sm:text-base font-black text-amber-950">
                    {fRp(cashInflowByMethod.QRIS)}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-amber-700 bg-amber-100/90 px-2 py-0.5 rounded-md">
                  {cashInflowByMethod.counts.QRIS} Trx
                </div>
              </div>
            </div>
          </div>

          {/* Section: Grafik Performa Harian */}
          {renderDailyPerformanceCard()}

          {/* Section: Rincian Kategori Pengeluaran */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3 border-b border-stone-100 pb-2">
                <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-orange-600" />
                  <span>Distribusi Biaya Operasional</span>
                </h3>
                <span className="text-xs font-bold text-red-600 bg-red-50 px-2.5 py-0.5 rounded-full border border-red-200">
                  Total: {fRp(totalExpenses)}
                </span>
              </div>

              {Object.keys(expensesByCategory).length === 0 ? (
                <div className="p-8 text-center text-stone-400 text-xs font-medium">
                  Belum ada data pengeluaran dicatat pada periode ini.
                </div>
              ) : (
                <div className="space-y-3 my-2">
                  {Object.entries(expensesByCategory).map(([kat, nom], kIdx) => {
                    const nomVal = Number(nom || 0);
                    const pct = totalExpenses > 0 ? Math.round((nomVal / totalExpenses) * 100) : 0;
                    return (
                      <div key={`exp-kat-${kat}-${kIdx}`} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-stone-800 flex items-center gap-1.5">
                            <Tag className="w-3 h-3 text-orange-500" />
                            {kat}
                          </span>
                          <span className="font-mono font-bold text-stone-900">{fRp(nomVal)} ({pct}%)</span>
                        </div>
                        <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-red-500 h-full rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(pct, 100)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
              <button
                onClick={() => setActiveTab('pengeluaran')}
                className="text-xs font-extrabold text-orange-600 hover:text-orange-700 flex items-center gap-1 hover:underline"
              >
                <span>Lihat & Kelola Semua Rincian Biaya &rarr;</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LAPORAN PENJUALAN (SALES) */}
      {activeTab === 'sales' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50/50 border border-blue-200/80 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-blue-900 uppercase tracking-wider">Total Omset Penjualan</span>
                <div className="p-2 bg-blue-600 rounded-xl text-white">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-blue-950">{fRp(stats.totalGross)}</p>
              <div className="mt-2 text-[11px] font-semibold text-blue-800/80 border-t border-blue-200/60 pt-2 flex items-center justify-between">
                <span>{stats.count} Transaksi</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50/50 border border-emerald-200/80 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-emerald-900 uppercase tracking-wider">Total Kas Masuk (Cash-In)</span>
                <div className="p-2 bg-emerald-600 rounded-xl text-white">
                  <Wallet className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-emerald-950">{fRp(stats.totalPaid)}</p>
              <div className="mt-2 text-[10px] font-semibold text-emerald-900/90 border-t border-emerald-200/60 pt-2 flex items-center justify-between flex-wrap gap-1">
                <span>Sales Baru: <strong>{fRp(stats.fromNewSales)}</strong></span>
                <span>•</span>
                <span>Pelunasan: <strong>{fRp(stats.fromPelunasanPiutang)}</strong></span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-orange-50/50 border border-amber-200/80 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-amber-900 uppercase tracking-wider">Sisa Piutang Penjualan</span>
                <div className="p-2 bg-amber-600 rounded-xl text-white">
                  <Receipt className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xl font-black text-amber-950">{fRp(stats.totalPiutang)}</p>
              <div className="mt-2 text-[11px] font-semibold text-amber-800/80 border-t border-amber-200/60 pt-2 flex items-center justify-between">
                <span>{stats.countDP} Nota Belum Lunas</span>
              </div>
            </div>
          </div>

          {/* Section: Grafik Performa Harian */}
          {renderDailyPerformanceCard()}

          {/* Section: Barang & Jasa Cetak Terlaris */}
          {renderTopProductsCard()}

          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between mb-3 border-b border-stone-100 pb-2 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-orange-600" />
                <h3 className="font-extrabold text-stone-900 text-sm">Daftar Transaksi Sales</h3>
                <span className="text-xs text-stone-400 font-bold">({filteredInvoices.length} Transaksi)</span>
              </div>
              <div className="flex items-center gap-2">
                {filteredInvoices.length > 0 && (
                  <button
                    type="button"
                    onClick={handleToggleAllSalesItems}
                    className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                    title="Buka atau tutup seluruh rincian barang transaksi di bawah ini"
                  >
                    <Package className="w-3.5 h-3.5 text-amber-700" />
                    <span>{areAllSalesItemsOpen ? 'Tutup Rincian Barang' : 'Buka Rincian Barang'}</span>
                  </button>
                )}
                <button
                  onClick={handleDownloadPdfActive}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 hover:underline cursor-pointer ml-1"
                  title="Unduh PDF Daftar Transaksi Sales sesuai periode filter yang dipilih"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Cetak PDF</span>
                </button>
                <button
                  onClick={() => setShowExcelExportModal(true)}
                  className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 hover:underline cursor-pointer ml-1"
                  title="Export Excel (.xlsx) Transaksi Penjualan & Kas Keluar"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-teal-600" />
                  <span>Export Excel</span>
                </button>
              </div>
            </div>

            {filteredInvoices.length === 0 ? (
              <div className="p-8 text-center text-stone-400 text-xs font-medium">
                Belum ada transaksi penjualan pada periode ini.
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[520px] overflow-y-auto border border-stone-200/80 rounded-xl relative shadow-2xs custom-scrollbar">
                <table className="w-full text-left text-xs">
                  <thead className="sticky top-0 z-10 bg-stone-100 border-b border-stone-200 shadow-2xs">
                    <tr className="text-stone-700 font-bold uppercase text-[10px]">
                      <th className="p-2.5">No. Invoice & Item</th>
                      <th className="p-2.5">Tanggal</th>
                      <th className="p-2.5">Pelanggan</th>
                      <th className="p-2.5">Kasir</th>
                      <th className="p-2.5 text-center">Metode Utama</th>
                      <th className="p-2.5 text-right">Total</th>
                      <th className="p-2.5 text-right">Dibayar</th>
                      <th className="p-2.5 text-right">Sisa</th>
                      <th className="p-2.5 text-center">Status</th>
                      <th className="p-2.5 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredInvoices.map((inv, idx) => {
                      const tot = Number(inv.total || 0);
                      const sisa = Number(inv.sisa || 0);
                      const paid = tot - sisa;
                      const isLunas = sisa <= 0;
                      const category = getInvoicePaymentCategory(inv);
                      const method = category;

                      const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
                      const isItemExpanded = Boolean(expandedInvoiceItems[invNo]);
                      const items = resolveInvoiceItems(inv as any);
                      const isLoadingItems = Boolean(loadingInvoiceItems[invNo]);
                      const totalItemCount = items.length;

                      const getMethodBadgeClass = (cat: string) => {
                        if (cat === 'Belum Bayar') return 'bg-red-50 text-red-700 border-red-200 font-extrabold';
                        if (cat === 'Tunai') return 'bg-emerald-50 text-emerald-800 border-emerald-200';
                        if (cat === 'Transfer') return 'bg-blue-50 text-blue-800 border-blue-200';
                        if (cat === 'Debet') return 'bg-purple-50 text-purple-800 border-purple-200';
                        if (cat === 'QRIS') return 'bg-amber-50 text-amber-800 border-amber-200';
                        return 'bg-stone-100 text-stone-800 border-stone-200';
                      };

                      return (
                        <React.Fragment key={`${inv.invoiceNo}-${idx}`}>
                          <tr className={`hover:bg-stone-50/80 transition ${isItemExpanded ? 'bg-amber-50/20' : ''}`}>
                            <td className="p-2.5">
                              <div className="flex flex-col gap-1">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-mono font-bold text-stone-900">{inv.invoiceNo}</span>
                                  {inv.lastEditedBy && (
                                    <span
                                      className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded text-[9px] font-bold"
                                      title={`Telah dikoreksi oleh ${inv.lastEditedBy} pada ${inv.lastEditedAt || ''}${inv.editReason ? ` (Alasan: ${inv.editReason})` : ''}`}
                                    >
                                      Edited
                                    </span>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => handleToggleInvoiceItems(inv as any)}
                                    className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold flex items-center gap-1 transition cursor-pointer border ${
                                      isItemExpanded
                                        ? 'bg-amber-600 text-white border-amber-700 shadow-2xs'
                                        : 'bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 border-stone-200'
                                    }`}
                                    title="Klik untuk melihat rincian barang yang dibeli pada nota ini"
                                  >
                                    <Package className="w-3 h-3" />
                                    <span>
                                      {isLoadingItems ? 'Memuat...' : totalItemCount > 0 ? `${totalItemCount} Item` : 'Rincian Item'}
                                    </span>
                                    {isItemExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                  </button>
                                </div>
                                {/* Preview text of items if collapsed */}
                                {!isItemExpanded && items.length > 0 && (
                                  <div className="flex flex-col gap-0.5 max-w-[280px]">
                                    <span
                                      className="text-[10px] text-stone-500 truncate block"
                                      title={items.map((it) => it.nama).join(', ')}
                                    >
                                      📦 {items.map((it) => `${it.nama} (${it.qty} ${it.satuan || 'pcs'})`).join(', ')}
                                    </span>
                                    {items.some((it) => it.catatan) && (
                                      <span
                                        className="text-[10px] text-amber-900 font-semibold truncate block bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200/80"
                                        title={items.filter((it) => it.catatan).map((it) => `${it.nama}: ${it.catatan}`).join(' | ')}
                                      >
                                        📁 File: {items.filter((it) => it.catatan).map((it) => it.catatan).join(', ')}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="p-2.5 text-stone-600">{inv.date || '-'}</td>
                            <td className="p-2.5 font-semibold text-stone-800">{inv.customer || 'Umum'}</td>
                            <td className="p-2.5 text-stone-500">{inv.cashier || 'Admin'}</td>
                            <td className="p-2.5 text-center">
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase border ${getMethodBadgeClass(category)}`}>
                                {method}
                              </span>
                            </td>
                            <td className="p-2.5 text-right font-bold text-stone-900">{fRp(tot)}</td>
                            <td className="p-2.5 text-right text-emerald-600 font-semibold">{fRp(paid)}</td>
                            <td className="p-2.5 text-right text-amber-600 font-semibold">{fRp(sisa)}</td>
                            <td className="p-2.5 text-center">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                                isLunas ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {isLunas ? 'LUNAS' : 'DP/SISA'}
                              </span>
                            </td>
                            <td className="p-2.5 text-center">
                              <div className="inline-flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditInvoice(inv)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition-all border bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-600 hover:text-white cursor-pointer shadow-2xs active:scale-95"
                                  title="Edit / Koreksi Transaksi (Khusus SPV/Owner)"
                                >
                                  <Pencil className="w-3 h-3" />
                                  <span>Edit</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenDeleteInvoice(inv)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition-all border bg-red-50 text-red-700 border-red-200 hover:bg-red-600 hover:text-white cursor-pointer shadow-2xs active:scale-95"
                                  title="Hapus Transaksi (Khusus SPV/Owner)"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span>Hapus</span>
                                </button>
                              </div>
                            </td>
                          </tr>

                          {/* Expandable Sub-Row for Item Details (Sesuai Desain di Daftar Piutang) */}
                          {isItemExpanded && (
                            <tr className="bg-amber-50/20 border-b border-amber-200/60">
                              <td colSpan={10} className="p-2.5 sm:p-3.5 bg-amber-50/30">
                                <div className="bg-white rounded-xl border border-amber-200/90 p-3 shadow-xs space-y-2.5">
                                  <div className="flex items-center justify-between pb-2 border-b border-stone-200 flex-wrap gap-2">
                                    <div className="flex items-center gap-2">
                                      <div className="p-1.5 bg-amber-100 text-amber-800 rounded-lg">
                                        <Package className="w-4 h-4" />
                                      </div>
                                      <div>
                                        <div className="flex items-center gap-2 flex-wrap">
                                          <span className="font-extrabold text-stone-900 text-xs">
                                            Rincian Barang Yang Dibeli - {inv.invoiceNo}
                                          </span>
                                          <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full text-[10px] font-black">
                                            {items.length} Item
                                          </span>
                                        </div>
                                        <p className="text-[10px] text-stone-500">
                                          Pelanggan: <strong className="text-stone-700">{inv.customer || 'Umum'}</strong> | Tgl Order: {inv.date || '-'} {inv.cashier ? `| Kasir: ${inv.cashier}` : ''}
                                        </p>
                                      </div>
                                    </div>

                                    <div className="text-right">
                                      <span className="text-[10px] text-stone-400 font-bold uppercase block">
                                        {sisa > 0 ? 'Sisa Piutang Nota' : 'Total Transaksi'}
                                      </span>
                                      <span className={`text-xs font-black ${sisa > 0 ? 'text-amber-600' : 'text-emerald-700'}`}>
                                        {fRp(sisa > 0 ? sisa : tot)}
                                      </span>
                                    </div>
                                  </div>

                                  {isLoadingItems ? (
                                    <div className="py-6 text-center text-xs text-stone-500 flex items-center justify-center gap-2">
                                      <RotateCw className="w-4 h-4 animate-spin text-amber-600" />
                                      <span>Sedang memuat rincian item nota {inv.invoiceNo}...</span>
                                    </div>
                                  ) : items.length === 0 ? (
                                    <div className="py-4 text-center text-xs text-stone-500 italic bg-stone-50 rounded-lg border border-dashed border-stone-200">
                                      Rincian item produk tidak tercatat pada sistem untuk nota ini (arsip transaksi lama).
                                    </div>
                                  ) : (
                                    <div className="space-y-2">
                                      <div className="overflow-x-auto rounded-lg border border-stone-200">
                                        <table className="w-full text-left text-xs whitespace-normal">
                                          <thead className="bg-stone-100 text-stone-700 font-bold uppercase text-[10px]">
                                            <tr>
                                              <th className="p-2 text-center w-8">No</th>
                                              <th className="p-2">Nama Produk / Jasa</th>
                                              <th className="p-2 min-w-[150px]">Catatan/ Nama File Cetak</th>
                                              <th className="p-2">Spesifikasi & Bahan</th>
                                              <th className="p-2 text-center">Qty</th>
                                              <th className="p-2 text-right">Harga Satuan</th>
                                              <th className="p-2 text-right">Subtotal Item</th>
                                            </tr>
                                          </thead>
                                          <tbody className="divide-y divide-stone-100 text-stone-800 text-[11px]">
                                            {items.map((it, itIdx) => {
                                              const lineTotal = computeItemTotal(it) || Number(it.totalItem || 0) || (Number(it.qty || 1) * Number(it.harga || 0));
                                              return (
                                                <tr key={itIdx} className="hover:bg-stone-50/70">
                                                  <td className="p-2 text-center text-stone-400 font-mono font-bold">{itIdx + 1}</td>
                                                  <td className="p-2 font-bold text-stone-900">
                                                    <div>{it.nama || 'Produk Custom'}</div>
                                                  </td>
                                                  <td className="p-2">
                                                    {it.catatan ? (
                                                      <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-950 bg-amber-100/90 px-2 py-1 rounded-md border border-amber-300 shadow-2xs">
                                                        <span className="text-amber-700">📁</span>
                                                        <span>{it.catatan}</span>
                                                      </span>
                                                    ) : (
                                                      <span className="text-stone-400 text-[11px] italic">-</span>
                                                    )}
                                                  </td>
                                                  <td className="p-2 text-stone-600">
                                                    {it.tipeHarga === 'ukuran' && it.panjang > 0 && it.lebar > 0 ? (
                                                      <span className="font-mono text-[10px] bg-stone-100 px-1.5 py-0.5 rounded text-stone-700 font-bold">
                                                        {it.panjang} × {it.lebar} m ({(it.panjang * it.lebar).toFixed(2)} m²)
                                                      </span>
                                                    ) : (
                                                      <span className="text-stone-500 text-[10px]">Fix / Satuan</span>
                                                    )}
                                                    {it.bahan && (
                                                      <span className="ml-1.5 text-[10px] text-stone-600 font-medium">
                                                        • {it.bahan}
                                                      </span>
                                                    )}
                                                  </td>
                                                  <td className="p-2 text-center font-black text-stone-800">
                                                    {it.qty} <span className="text-[10px] font-normal text-stone-500">{it.satuan || 'pcs'}</span>
                                                  </td>
                                                  <td className="p-2 text-right font-mono text-stone-700">
                                                    {fRp(it.harga)}
                                                    {it.diskonItem && it.diskonItem > 0 ? (
                                                      <div className="text-[9px] text-emerald-600 font-bold">Disc: -{fRp(it.diskonItem)}</div>
                                                    ) : null}
                                                  </td>
                                                  <td className="p-2 text-right font-bold font-mono text-stone-900">
                                                    {fRp(lineTotal)}
                                                  </td>
                                                </tr>
                                              );
                                            })}
                                          </tbody>
                                          <tfoot className="bg-stone-50 border-t border-stone-200 text-stone-700 font-bold text-[11px]">
                                            <tr>
                                              <td colSpan={5} className="p-2 text-right text-stone-500 uppercase text-[10px]">
                                                Total Rincian Item:
                                              </td>
                                              <td colSpan={2} className="p-2 text-right font-mono text-stone-900 font-black">
                                                {fRp(items.reduce((sum, it) => sum + (computeItemTotal(it) || Number(it.totalItem || 0) || (Number(it.qty || 1) * Number(it.harga || 0))), 0))}
                                              </td>
                                            </tr>
                                          </tfoot>
                                        </table>
                                      </div>
                                      {Boolean((inv as any).catatan) && (
                                        <div className="p-2 mt-2 bg-amber-50/80 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-center gap-2">
                                          <span className="font-bold text-[10px] uppercase bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">
                                            Catatan Nota:
                                          </span>
                                          <span className="font-medium">{(inv as any).catatan}</span>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Section: Daftar Penerimaan Pelunasan & Angsuran Piutang Periode Ini */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-3 border-b border-stone-100 gap-2">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-100 text-purple-700 shadow-2xs">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                    <span>Daftar Penerimaan Pelunasan & Angsuran Piutang Lintas Hari</span>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200">
                      {periodCashInflow.pelunasanItems.length} Pembayaran
                    </span>
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    Mencatat penerimaan pembayaran angsuran & pelunasan piutang lintas hari pada periode ini (khusus atas nota piutang hari/bulan sebelumnya).
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-bold text-stone-700 bg-purple-50/90 border border-purple-200/80 px-3 py-1.5 rounded-xl self-start sm:self-auto flex items-center gap-1.5">
                <span>Total Kas Piutang Lintas Hari:</span>
                <strong className="text-purple-950 font-black text-xs">{fRp(periodCashInflow.fromPelunasanPiutang)}</strong>
              </div>
            </div>

            {periodCashInflow.pelunasanItems.length === 0 ? (
              <div className="py-8 text-center text-stone-400 text-xs font-medium border border-dashed border-stone-200 rounded-xl bg-stone-50/50">
                Tidak ada penerimaan pembayaran angsuran/pelunasan piutang lintas hari pada periode ini.
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[380px] overflow-y-auto border border-stone-200/80 rounded-xl relative shadow-2xs custom-scrollbar">
                <table className="w-full text-left text-xs">
                  <thead className="sticky top-0 z-10 bg-stone-100 border-b border-stone-200 shadow-2xs">
                    <tr className="text-stone-700 font-bold uppercase text-[10px]">
                      <th className="p-2.5">No. Invoice</th>
                      <th className="p-2.5">Tanggal Bayar</th>
                      <th className="p-2.5">Pelanggan</th>
                      <th className="p-2.5">Kasir</th>
                      <th className="p-2.5 text-center">Metode</th>
                      <th className="p-2.5 text-right">Jumlah Dibayar</th>
                      <th className="p-2.5 text-right">Sisa Piutang</th>
                      <th className="p-2.5 text-center">Status Pelunasan</th>
                      <th className="p-2.5">Catatan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {periodCashInflow.pelunasanItems.map((item, pIdx) => {
                      const getMethodBadgeClass = (cat: string) => {
                        if (cat === 'Tunai') return 'bg-emerald-50 text-emerald-800 border-emerald-200';
                        if (cat === 'Transfer') return 'bg-blue-50 text-blue-800 border-blue-200';
                        if (cat === 'Debet') return 'bg-purple-50 text-purple-800 border-purple-200';
                        if (cat === 'QRIS') return 'bg-amber-50 text-amber-800 border-amber-200';
                        return 'bg-stone-100 text-stone-800 border-stone-200';
                      };

                      return (
                        <tr key={`pelunasan-row-${pIdx}`} className="hover:bg-purple-50/30 transition">
                          <td className="p-2.5 font-mono font-bold text-stone-900">
                            {item.invoiceNo}
                          </td>
                          <td className="p-2.5">
                            <div className="font-semibold text-stone-800">{item.date} {item.time ? `• ${item.time}` : ''}</div>
                            {item.isCrossDate && (
                              <span className="inline-block mt-0.5 text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-purple-100 text-purple-800 border border-purple-200">
                                Lintas Hari (Nota: {item.invoiceDate})
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 font-semibold text-stone-800">{item.customer}</td>
                          <td className="p-2.5 text-stone-500">{item.cashier}</td>
                          <td className="p-2.5 text-center">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase border ${getMethodBadgeClass(item.category)}`}>
                              {item.payMethod}
                            </span>
                          </td>
                          <td className="p-2.5 text-right font-black text-emerald-700">
                            {fRp(item.jumlahBayar)}
                          </td>
                          <td className="p-2.5 text-right font-semibold text-stone-700">
                            {fRp(item.sisaSetelahBayar)}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                              item.sisaSetelahBayar <= 0
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : 'bg-amber-100 text-amber-800 border border-amber-300'
                            }`}>
                              {item.sisaSetelahBayar <= 0 ? 'LUNAS' : 'ANGSURAN'}
                            </span>
                          </td>
                          <td className="p-2.5 text-stone-500 text-[11px] max-w-[160px] truncate">
                            {item.catatan || '-'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: LAPORAN PENGELUARAN PERUSAHAAN */}
      {activeTab === 'pengeluaran' && (
        <div className="space-y-4">
          {/* Header Controls for Expenses */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={expenseSearch}
                  onChange={(e) => setExpenseSearch(e.target.value)}
                  placeholder="Cari keterangan/kategori..."
                  className="w-full pl-9 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                />
              </div>

              <select
                value={expenseCategoryFilter}
                onChange={(e) => setExpenseCategoryFilter(e.target.value)}
                className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-700 focus:outline-none"
              >
                <option value="ALL">Semua Kategori</option>
                {EXPENSE_CATEGORIES.map((cat, cIdx) => (
                  <option key={`exp-cat-filter-${cat}-${cIdx}`} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
              <div className="text-right">
                <span className="text-[10px] text-stone-400 font-bold uppercase">Total Biaya Operasional</span>
                <p className="text-sm font-black text-red-600">{fRp(totalExpenses)}</p>
              </div>

              <button
                onClick={() => setShowExcelExportModal(true)}
                className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 shrink-0 cursor-pointer"
                title="Export Excel (.xlsx) Transaksi & Biaya"
              >
                <FileSpreadsheet className="w-4 h-4 text-teal-200" />
                <span>Export Excel</span>
              </button>

              <button
                onClick={handleOpenAddExpense}
                className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>+ Catat Biaya Baru</span>
              </button>
            </div>
          </div>

          {/* Expenses Table */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs">
            {filteredExpenses.length === 0 ? (
              <div className="p-10 text-center text-stone-400 text-xs font-medium">
                Belum ada pengeluaran yang dicatat pada filter periode atau pencarian ini.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-stone-100 text-stone-700 font-bold uppercase text-[10px] border-b border-stone-200">
                      <th className="p-2.5">ID / Tanggal</th>
                      <th className="p-2.5">Kategori</th>
                      <th className="p-2.5">Keterangan / Pengeluaran</th>
                      <th className="p-2.5">PJ / Kasir</th>
                      <th className="p-2.5 text-right">Nominal Biaya</th>
                      <th className="p-2.5 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredExpenses.map((exp, expIdx) => (
                      <tr key={`${exp.id || 'exp'}-${expIdx}`} className="hover:bg-red-50/20 transition">
                        <td className="p-2.5 font-mono text-stone-600">
                          <span className="font-bold text-stone-900 block">{exp.tanggal}</span>
                          <span className="text-[10px] text-stone-400">{exp.id}</span>
                        </td>
                        <td className="p-2.5">
                          <span className="px-2 py-0.5 bg-stone-100 text-stone-800 rounded-md font-bold text-[10px] border border-stone-200">
                            {exp.kategori}
                          </span>
                        </td>
                        <td className="p-2.5 font-semibold text-stone-900">{exp.keterangan}</td>
                        <td className="p-2.5 text-stone-500">{exp.pj}</td>
                        <td className="p-2.5 text-right font-black text-red-600">{fRp(exp.nominal)}</td>
                        <td className="p-2.5 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleOpenEditExpense(exp)}
                              className="p-1 text-stone-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                              title="Edit Pengeluaran"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setExpenseToDelete(exp)}
                              className="p-1 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                              title="Hapus Pengeluaran"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-red-50/60 font-black text-stone-900 border-t border-red-200">
                      <td colSpan={4} className="p-2.5 text-right uppercase text-xs">Total Seluruh Pengeluaran:</td>
                      <td className="p-2.5 text-right text-red-700 text-sm">{fRp(totalExpenses)}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: PIUTANG PELANGGAN */}
      {activeTab === 'piutang' && (
        <div className="space-y-4">
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  placeholder="Cari nama pelanggan..."
                  className="w-full pl-9 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-between md:justify-end">
              <div className="text-right mr-1">
                <span className="text-[10px] text-stone-400 font-bold uppercase">Total Seluruh Piutang</span>
                <p className="text-sm font-black text-amber-600">{fRp(grandTotalPiutang)}</p>
              </div>

              <button
                onClick={handlePrintAllPiutang}
                disabled={customerPiutangSummaries.length === 0}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 shrink-0 cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                <span>Cetak PDF</span>
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {filteredCustomerSummaries.length === 0 ? (
              <div className="bg-white border border-stone-200 rounded-2xl p-10 text-center text-stone-400 text-xs font-medium">
                Tidak ada data piutang pelanggan pada filter ini. Seluruh tagihan pelanggan telah lunas!
              </div>
            ) : (
              filteredCustomerSummaries.map((cSummary, idx) => {
                const isExpanded = expandedCustomer === cSummary.customerName;

                return (
                  <div key={`${cSummary.customerName}-${idx}`} className="bg-white border border-stone-200/80 rounded-2xl overflow-hidden shadow-xs">
                    <div
                      onClick={() => setExpandedCustomer(isExpanded ? null : cSummary.customerName)}
                      className="p-4 flex items-center justify-between cursor-pointer hover:bg-stone-50 transition"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-amber-100 text-amber-800 rounded-xl font-bold">
                          <Users className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-stone-900 text-sm">{cSummary.customerName}</h4>
                          <p className="text-xs text-stone-500">
                            {cSummary.count} Nota Belum Lunas
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <span className="text-[10px] text-stone-400 font-bold uppercase">Sisa Tagihan</span>
                          <p className="text-sm font-black text-amber-600">{fRp(cSummary.totalSisa)}</p>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePrintCustomerBilling(cSummary);
                          }}
                          className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-extrabold text-xs rounded-xl border border-amber-200 flex items-center gap-1.5 transition cursor-pointer shadow-xs"
                          title="Cetak Buku Besar & Surat Tagihan Piutang (PDF)"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Buku Besar Piutang</span>
                        </button>

                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-stone-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-stone-400" />
                        )}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="bg-stone-50 border-t border-stone-200 p-3 space-y-2">
                        {/* Horizontal Navigation Toolbar */}
                        <div className="flex items-center justify-between gap-2 px-1 flex-wrap">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs text-stone-800 font-extrabold">
                              Rincian Nota Piutang ({cSummary.invoices.length}):
                            </span>
                            <button
                              type="button"
                              onClick={() => handleToggleAllCustomerItems(cSummary)}
                              className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition active:scale-95 shadow-2xs cursor-pointer"
                              title="Tampilkan / Sembunyikan Rincian Barang Untuk Seluruh Invoice Pelanggan Ini"
                            >
                              <Package className="w-3.5 h-3.5 text-amber-600" />
                              <span>
                                {cSummary.invoices.every((i) => expandedInvoiceItems[(i.invoiceNo || (i as any).noInvoice || '').trim()])
                                  ? 'Tutup Rincian Barang'
                                  : 'Lihat Rincian Barang (Semua Nota)'}
                              </span>
                            </button>
                            <span className="hidden sm:inline-block text-[11px] font-normal text-stone-500">
                              (Geser tabel ke samping untuk tombol aksi)
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[10px] font-semibold text-stone-400 sm:hidden">Navigasi:</span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const el = document.getElementById(`piutang-table-wrap-${idx}`);
                                if (el) el.scrollBy({ left: -220, behavior: 'smooth' });
                              }}
                              className="px-2.5 py-1 bg-white hover:bg-stone-100 text-stone-700 active:bg-stone-200 border border-stone-300 rounded-lg text-xs font-extrabold flex items-center gap-1 transition shadow-2xs cursor-pointer active:scale-95"
                              title="Geser Tabel ke Kiri"
                            >
                              <ChevronLeft className="w-4 h-4 text-stone-700" />
                              <span className="text-[11px]">Kiri</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const el = document.getElementById(`piutang-table-wrap-${idx}`);
                                if (el) el.scrollBy({ left: 220, behavior: 'smooth' });
                              }}
                              className="px-2.5 py-1 bg-white hover:bg-stone-100 text-stone-700 active:bg-stone-200 border border-stone-300 rounded-lg text-xs font-extrabold flex items-center gap-1 transition shadow-2xs cursor-pointer active:scale-95"
                              title="Geser Tabel ke Kanan"
                            >
                              <span className="text-[11px]">Kanan</span>
                              <ChevronRight className="w-4 h-4 text-stone-700" />
                            </button>
                          </div>
                        </div>

                        {/* Scrollable Table Container */}
                        <div
                          id={`piutang-table-wrap-${idx}`}
                          className="overflow-x-auto scroll-smooth rounded-xl border border-stone-200 shadow-2xs custom-scrollbar bg-white"
                        >
                          <table className="w-full min-w-[620px] text-left text-xs whitespace-nowrap">
                            <thead>
                              <tr className="bg-stone-100 text-stone-700 font-bold uppercase text-[10px] border-b border-stone-200">
                                <th className="p-2.5 sticky left-0 bg-stone-100 z-1 shadow-2xs">No. Invoice & Item</th>
                                <th className="p-2.5">Tanggal</th>
                                <th className="p-2.5 text-right">Total Nota</th>
                                <th className="p-2.5 text-right">Telah Dibayar</th>
                                <th className="p-2.5 text-right">Sisa Piutang</th>
                                <th className="p-2.5 text-center">Aksi (Owner & SPV)</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                              {cSummary.invoices.map((inv, iIdx) => {
                                const invNo = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
                                const isItemExpanded = Boolean(expandedInvoiceItems[invNo]);
                                const items = resolveInvoiceItems(inv);
                                const isLoadingItems = Boolean(loadingInvoiceItems[invNo]);
                                const totalItemCount = items.length;

                                return (
                                  <React.Fragment key={`${invNo}-${iIdx}`}>
                                    <tr className={`hover:bg-amber-50/40 transition ${isItemExpanded ? 'bg-amber-50/20' : ''}`}>
                                      <td className="p-2.5 sticky left-0 bg-white hover:bg-amber-50/40 z-1 shadow-2xs">
                                        <div className="flex flex-col gap-1">
                                          <div className="flex items-center gap-1.5 flex-wrap">
                                            <span className="font-mono font-bold text-stone-900">{inv.invoiceNo}</span>
                                            <button
                                              type="button"
                                              onClick={() => handleToggleInvoiceItems(inv)}
                                              className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold flex items-center gap-1 transition cursor-pointer border ${
                                                isItemExpanded
                                                  ? 'bg-amber-600 text-white border-amber-700 shadow-2xs'
                                                  : 'bg-stone-100 hover:bg-amber-100 text-stone-700 hover:text-amber-900 border-stone-200'
                                              }`}
                                              title="Klik untuk melihat rincian barang yang dibeli pada nota ini"
                                            >
                                              <Package className="w-3 h-3" />
                                              <span>
                                                {isLoadingItems ? 'Memuat...' : totalItemCount > 0 ? `${totalItemCount} Item` : 'Rincian Item'}
                                              </span>
                                              {isItemExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                            </button>
                                          </div>
                                          {/* Preview text of items if collapsed */}
                                          {!isItemExpanded && items.length > 0 && (
                                            <div className="flex flex-col gap-0.5 max-w-[280px]">
                                              <span
                                                className="text-[10px] text-stone-500 truncate block"
                                                title={items.map((it) => it.nama).join(', ')}
                                              >
                                                📦 {items.map((it) => `${it.nama} (${it.qty} ${it.satuan || 'pcs'})`).join(', ')}
                                              </span>
                                              {items.some((it) => it.catatan) && (
                                                <span
                                                  className="text-[10px] text-amber-900 font-semibold truncate block bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200/80"
                                                  title={items.filter((it) => it.catatan).map((it) => `${it.nama}: ${it.catatan}`).join(' | ')}
                                                >
                                                  📁 File: {items.filter((it) => it.catatan).map((it) => it.catatan).join(', ')}
                                                </span>
                                              )}
                                            </div>
                                          )}
                                        </div>
                                      </td>
                                      <td className="p-2.5 text-stone-600">{inv.date}</td>
                                      <td className="p-2.5 text-right font-semibold">{fRp(Number(inv.total || 0))}</td>
                                      <td className="p-2.5 text-right text-emerald-600 font-semibold">
                                        {fRp(Math.max(0, Number(inv.total || 0) - Number(inv.sisa || 0)))}
                                      </td>
                                      <td className="p-2.5 text-right text-amber-600 font-bold">{fRp(Number(inv.sisa || 0))}</td>
                                      <td className="p-2.5 text-center">
                                        <div className="flex items-center justify-center gap-1.5">
                                          <button
                                            type="button"
                                            onClick={() => handleOpenEditInvoice(inv)}
                                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-700 font-bold text-[11px] rounded-lg border border-blue-200 flex items-center gap-1 transition shadow-2xs active:scale-95 cursor-pointer"
                                            title="Edit / Koreksi Transaksi Piutang (Khusus Owner & SPV)"
                                          >
                                            <Pencil className="w-3 h-3" />
                                            <span>Edit</span>
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => handleOpenDeleteInvoice(inv)}
                                            className="px-2.5 py-1 bg-red-50 hover:bg-red-600 hover:text-white text-red-700 font-bold text-[11px] rounded-lg border border-red-200 flex items-center gap-1 transition shadow-2xs active:scale-95 cursor-pointer"
                                            title="Hapus Piutang / Invoice Ini (Khusus Owner & SPV)"
                                          >
                                            <Trash2 className="w-3 h-3" />
                                            <span>Hapus</span>
                                          </button>
                                        </div>
                                      </td>
                                    </tr>

                                    {/* Expandable Sub-Row for Item Details */}
                                    {isItemExpanded && (
                                      <tr className="bg-amber-50/20 border-b border-amber-200/60">
                                        <td colSpan={6} className="p-2.5 sm:p-3.5 bg-amber-50/30">
                                          <div className="bg-white rounded-xl border border-amber-200/90 p-3 shadow-xs space-y-2.5">
                                            <div className="flex items-center justify-between pb-2 border-b border-stone-200 flex-wrap gap-2">
                                              <div className="flex items-center gap-2">
                                                <div className="p-1.5 bg-amber-100 text-amber-800 rounded-lg">
                                                  <Package className="w-4 h-4" />
                                                </div>
                                                <div>
                                                  <div className="flex items-center gap-2 flex-wrap">
                                                    <span className="font-extrabold text-stone-900 text-xs">
                                                      Rincian Barang Yang Dibeli - {inv.invoiceNo}
                                                    </span>
                                                    <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full text-[10px] font-black">
                                                      {items.length} Item
                                                    </span>
                                                  </div>
                                                  <p className="text-[10px] text-stone-500">
                                                    Pelanggan: <strong className="text-stone-700">{cSummary.customerName}</strong> | Tgl Order: {inv.date || '-'}
                                                  </p>
                                                </div>
                                              </div>

                                              <div className="text-right">
                                                <span className="text-[10px] text-stone-400 font-bold uppercase block">Sisa Piutang Nota</span>
                                                <span className="text-xs font-black text-amber-600">{fRp(Number(inv.sisa || 0))}</span>
                                              </div>
                                            </div>

                                            {isLoadingItems ? (
                                              <div className="py-6 text-center text-xs text-stone-500 flex items-center justify-center gap-2">
                                                <RotateCw className="w-4 h-4 animate-spin text-amber-600" />
                                                <span>Sedang memuat rincian item nota {inv.invoiceNo}...</span>
                                              </div>
                                            ) : items.length === 0 ? (
                                              <div className="py-4 text-center text-xs text-stone-500 italic bg-stone-50 rounded-lg border border-dashed border-stone-200">
                                                Rincian item produk tidak tercatat pada sistem untuk nota ini (arsip transaksi lama).
                                              </div>
                                            ) : (
                                              <div className="space-y-2">
                                                <div className="overflow-x-auto rounded-lg border border-stone-200">
                                                <table className="w-full text-left text-xs whitespace-normal">
                                                  <thead className="bg-stone-100 text-stone-700 font-bold uppercase text-[10px]">
                                                    <tr>
                                                      <th className="p-2 text-center w-8">No</th>
                                                      <th className="p-2">Nama Produk / Jasa</th>
                                                      <th className="p-2 min-w-[150px]">Catatan/ Nama File Cetak</th>
                                                      <th className="p-2">Spesifikasi & Bahan</th>
                                                      <th className="p-2 text-center">Qty</th>
                                                      <th className="p-2 text-right">Harga Satuan</th>
                                                      <th className="p-2 text-right">Subtotal Item</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody className="divide-y divide-stone-100 text-stone-800 text-[11px]">
                                                    {items.map((it, itIdx) => {
                                                      const lineTotal = computeItemTotal(it) || Number(it.totalItem || 0) || (Number(it.qty || 1) * Number(it.harga || 0));
                                                      return (
                                                        <tr key={itIdx} className="hover:bg-stone-50/70">
                                                          <td className="p-2 text-center text-stone-400 font-mono font-bold">{itIdx + 1}</td>
                                                          <td className="p-2 font-bold text-stone-900">
                                                            <div>{it.nama || 'Produk Custom'}</div>
                                                          </td>
                                                          <td className="p-2">
                                                            {it.catatan ? (
                                                              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-950 bg-amber-100/90 px-2 py-1 rounded-md border border-amber-300 shadow-2xs">
                                                                <span className="text-amber-700">📁</span>
                                                                <span>{it.catatan}</span>
                                                             </span>
                                                            ) : (
                                                              <span className="text-stone-400 text-[11px] italic">-</span>
                                                            )}
                                                          </td>
                                                          <td className="p-2 text-stone-600">
                                                            {it.tipeHarga === 'ukuran' && it.panjang > 0 && it.lebar > 0 ? (
                                                              <span className="font-mono text-[10px] bg-stone-100 px-1.5 py-0.5 rounded text-stone-700 font-bold">
                                                                {it.panjang} × {it.lebar} m ({(it.panjang * it.lebar).toFixed(2)} m²)
                                                              </span>
                                                            ) : (
                                                              <span className="text-stone-500 text-[10px]">Fix / Satuan</span>
                                                            )}
                                                            {it.bahan && (
                                                              <span className="ml-1.5 text-[10px] text-stone-600 font-medium">
                                                                • {it.bahan}
                                                              </span>
                                                            )}
                                                          </td>
                                                          <td className="p-2 text-center font-black text-stone-800">
                                                            {it.qty} <span className="text-[10px] font-normal text-stone-500">{it.satuan || 'pcs'}</span>
                                                          </td>
                                                          <td className="p-2 text-right font-mono text-stone-700">
                                                            {fRp(it.harga)}
                                                            {it.diskonItem && it.diskonItem > 0 ? (
                                                              <div className="text-[9px] text-emerald-600 font-bold">Disc: -{fRp(it.diskonItem)}</div>
                                                            ) : null}
                                                          </td>
                                                          <td className="p-2 text-right font-bold font-mono text-stone-900">
                                                            {fRp(lineTotal)}
                                                          </td>
                                                        </tr>
                                                      );
                                                    })}
                                                  </tbody>
                                                  <tfoot className="bg-stone-50 border-t border-stone-200 text-stone-700 font-bold text-[11px]">
                                                    <tr>
                                                      <td colSpan={5} className="p-2 text-right text-stone-500 uppercase text-[10px]">
                                                        Total Rincian Item:
                                                      </td>
                                                      <td colSpan={2} className="p-2 text-right font-mono text-stone-900 font-black">
                                                        {fRp(items.reduce((sum, it) => sum + (computeItemTotal(it) || Number(it.totalItem || 0) || (Number(it.qty || 1) * Number(it.harga || 0))), 0))}
                                                      </td>
                                                    </tr>
                                                  </tfoot>
                                                </table>
                                              </div>
                                              {Boolean((inv as any).catatan) && (
                                                <div className="p-2 mt-2 bg-amber-50/80 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-center gap-2">
                                                  <span className="font-bold text-[10px] uppercase bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">
                                                    Catatan Nota:
                                                  </span>
                                                  <span className="font-medium">{(inv as any).catatan}</span>
                                                </div>
                                              )}
                                            </div>
                                          )}
                                          </div>
                                        </td>
                                      </tr>
                                    )}
                                  </React.Fragment>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>

                        {/* Mobile bottom swipe guide & quick jump buttons */}
                        <div className="flex items-center justify-between text-[11px] text-stone-500 px-1 pt-0.5">
                          <span className="flex items-center gap-1">
                            <span>↔</span>
                            <span>Bisa digeser sentuh ke kanan / kiri</span>
                          </span>
                          <div className="flex items-center gap-1 text-[11px]">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const el = document.getElementById(`piutang-table-wrap-${idx}`);
                                if (el) el.scrollTo({ left: 0, behavior: 'smooth' });
                              }}
                              className="text-stone-500 hover:text-stone-900 font-bold underline px-1 cursor-pointer"
                            >
                              Ke Awal
                            </button>
                            <span className="text-stone-300">•</span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const el = document.getElementById(`piutang-table-wrap-${idx}`);
                                if (el) el.scrollTo({ left: el.scrollWidth, behavior: 'smooth' });
                              }}
                              className="text-amber-700 hover:text-amber-900 font-bold underline px-1 cursor-pointer"
                            >
                              Ke Tombol Aksi →
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: STOK OPNAME & AUDIT INVENTARIS FISIK                                */}
      {/* ========================================================================= */}
      {activeTab === 'opname' && (
        <div className="space-y-4">
          {/* Header Card & Primary Action */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-600 text-white rounded-xl shadow-xs shrink-0">
                <ClipboardCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base sm:text-lg font-black text-stone-900">
                    Stok Opname & Audit Inventaris
                  </h2>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200 uppercase">
                    Audit Lapangan
                  </span>
                </div>
                <p className="text-xs text-stone-500 mt-0.5 max-w-2xl">
                  Pencocokan stok fisik nyata di etalase / gudang Ervo Print dengan sistem. Setiap koreksi akan memperbarui master stok dan menghasilkan Berita Acara resmi bertanda tangan SPV/Owner.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto shrink-0">
              <button
                type="button"
                onClick={() => setIsOpnameModalOpen(true)}
                className="w-full md:w-auto px-4 py-2.5 bg-purple-600 hover:bg-purple-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Buat Sesi Opname Baru</span>
              </button>
            </div>
          </div>

          {/* KPI Analytics Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white border border-stone-200/80 rounded-2xl p-3.5 shadow-2xs">
              <div className="flex items-center justify-between text-stone-400 mb-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500">Total Sesi Audit</span>
                <ClipboardCheck className="w-4 h-4 text-purple-600" />
              </div>
              <p className="text-lg sm:text-xl font-black text-stone-900">{opnameAllStats.totalSessions} Sesi</p>
              <p className="text-[11px] text-stone-500 mt-0.5">Tercatat dalam sistem</p>
            </div>

            <div className="bg-white border border-stone-200/80 rounded-2xl p-3.5 shadow-2xs">
              <div className="flex items-center justify-between text-stone-400 mb-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500">Total Item Diperiksa</span>
                <Tag className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-lg sm:text-xl font-black text-stone-900">{opnameAllStats.totalItemsAudited} SKU</p>
              <p className="text-[11px] text-stone-500 mt-0.5">Akumulasi seluruh sesi</p>
            </div>

            <div className="bg-white border border-stone-200/80 rounded-2xl p-3.5 shadow-2xs">
              <div className="flex items-center justify-between text-stone-400 mb-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500">Item Selisih Terdeteksi</span>
                <AlertTriangle className="w-4 h-4 text-amber-500" />
              </div>
              <p className={`text-lg sm:text-xl font-black ${opnameAllStats.totalItemsDiff > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                {opnameAllStats.totalItemsDiff} Item
              </p>
              <p className="text-[11px] text-stone-500 mt-0.5">
                Kurang: <strong className="text-red-600 font-mono">-{opnameAllStats.totalKurang}</strong> • Lebih: <strong className="text-emerald-600 font-mono">+{opnameAllStats.totalLebih}</strong>
              </p>
            </div>

            <div className="bg-white border border-stone-200/80 rounded-2xl p-3.5 shadow-2xs">
              <div className="flex items-center justify-between text-stone-400 mb-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500">Net Selisih Nilai Aset</span>
                <BadgeDollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              <p className={`text-lg sm:text-xl font-black font-mono ${
                opnameAllStats.totalNominal < 0 
                  ? 'text-red-600' 
                  : opnameAllStats.totalNominal > 0 
                  ? 'text-emerald-700' 
                  : 'text-stone-800'
              }`}>
                {opnameAllStats.totalNominal > 0 ? `+${fRp(opnameAllStats.totalNominal)}` : fRp(opnameAllStats.totalNominal)}
              </p>
              <p className="text-[11px] text-stone-500 mt-0.5">
                {opnameAllStats.totalNominal < 0 ? 'Potensi kerugian/waste' : 'Net selisih akumulasi'}
              </p>
            </div>
          </div>

          {/* Search and Filters Toolbar */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-3 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-2.5">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={opnameSearch}
                onChange={(e) => setOpnameSearch(e.target.value)}
                placeholder="Cari No. Berita Acara, Petugas, SPV..."
                className="w-full pl-9 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
              />
            </div>

            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setOpnameFilterStatus('ALL')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                  opnameFilterStatus === 'ALL'
                    ? 'bg-stone-900 text-white shadow-2xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Semua Sesi ({stockOpnames.length})
              </button>
              {opnameAllStats.totalDrafts > 0 && (
                <button
                  type="button"
                  onClick={() => setOpnameFilterStatus('draft')}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                    opnameFilterStatus === 'draft'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-300'
                  }`}
                >
                  🟡 Draf Berjalan ({opnameAllStats.totalDrafts})
                </button>
              )}
              <button
                type="button"
                onClick={() => setOpnameFilterStatus('approved')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                  opnameFilterStatus === 'approved'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                🟢 Disetujui SPV ({opnameAllStats.totalApproved})
              </button>
              <button
                type="button"
                onClick={() => setOpnameFilterStatus('diff')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                  opnameFilterStatus === 'diff'
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                Ada Selisih ({stockOpnames.filter(s => (s.totalItemSelisih || 0) > 0).length})
              </button>
              <button
                type="button"
                onClick={() => setOpnameFilterStatus('match')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                  opnameFilterStatus === 'match'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                Sesuai / Klop ({stockOpnames.filter(s => (s.totalItemSelisih || 0) === 0).length})
              </button>
            </div>
          </div>

          {/* Banner Multi-Hari: Sesi Draf Berjalan */}
          {opnameAllStats.totalDrafts > 0 && opnameFilterStatus !== 'approved' && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-amber-950">
                    Ada {opnameAllStats.totalDrafts} Sesi Draf Stok Opname Sedang Berjalan (Multi-Hari)
                  </h4>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Data hitungan fisik tersimpan aman dan tidak mengubah stok toko sebelum disahkan oleh SPV/Owner. Anda dapat melanjutkan pencatatan kapan saja.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const latestDraft = stockOpnames.find(s => s.status === 'DRAFT');
                  if (latestDraft) {
                    setActiveDraftOpname(latestDraft);
                    setIsOpnameModalOpen(true);
                  }
                }}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-xl text-xs font-extrabold shadow-2xs transition flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Lanjutkan Draf Terakhir</span>
              </button>
            </div>
          )}

          {/* History List Table */}
          <div className="bg-white border border-stone-200/80 rounded-2xl shadow-xs overflow-hidden">
            {filteredStockOpnames.length === 0 ? (
              <div className="text-center py-16 px-4 space-y-3">
                <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center mx-auto border border-purple-100">
                  <ClipboardCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-stone-800">
                    {opnameSearch || opnameFilterStatus !== 'ALL'
                      ? 'Tidak ada data opname yang cocok dengan pencarian'
                      : 'Belum Ada Sesi Stok Opname'}
                  </h3>
                  <p className="text-xs text-stone-500 max-w-md mx-auto mt-1">
                    {opnameSearch || opnameFilterStatus !== 'ALL'
                      ? 'Coba ganti kata kunci pencarian atau ubah filter filter di atas.'
                      : 'Lakukan audit stok fisik barang secara berkala untuk menjaga keakuratan stok dan meminimalkan kerugian inventaris toko.'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsOpnameModalOpen(true)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-extrabold shadow-xs transition active:scale-95 inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Buat Sesi Opname Pertama</span>
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-stone-50/80 border-b border-stone-200/80 text-[11px] font-black text-stone-600 uppercase tracking-wider">
                      <th className="py-3 px-3.5">No. Berita Acara</th>
                      <th className="py-3 px-3">Tanggal & Waktu</th>
                      <th className="py-3 px-3">Petugas / Kasir</th>
                      <th className="py-3 px-3">Otorisasi SPV</th>
                      <th className="py-3 px-3 text-center">Item Diperiksa</th>
                      <th className="py-3 px-3 text-center">Selisih Qty</th>
                      <th className="py-3 px-3 text-right">Selisih Nilai (Rp)</th>
                      <th className="py-3 px-3.5 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredStockOpnames.map((record, rIdx) => {
                      const isDraft = record.status === 'DRAFT';
                      const hasDiff = (record.totalItemSelisih || 0) > 0;
                      const nominal = record.totalSelisihNominalRp || 0;
                      const hasInterim = (record.totalPenjualanInterimQty || 0) > 0;

                      return (
                        <tr key={`opname-row-${record.id || 'rec'}-${rIdx}`} className={`transition group ${isDraft ? 'bg-amber-50/30 hover:bg-amber-50/60' : 'hover:bg-stone-50/60'}`}>
                          {/* No. Berita Acara & Status */}
                          <td className="py-3 px-3.5 align-middle">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-mono font-black text-stone-900 text-xs">
                                #{record.id}
                              </span>
                              {isDraft ? (
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
                                  🟡 Draf Berjalan
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  Disetujui SPV
                                </span>
                              )}
                              {record.metodePenyesuaian === 'DELTA' && (
                                <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                                  Delta
                                </span>
                              )}
                            </div>
                            {record.catatanUmum && (
                              <p className="text-[10px] text-stone-500 truncate max-w-xs mt-0.5">
                                {record.catatanUmum}
                              </p>
                            )}
                            {hasInterim && (
                              <span className="text-[9px] text-blue-700 font-bold block mt-0.5">
                                ⚡ {record.totalPenjualanInterimQty} unit terjual selama sesi
                              </span>
                            )}
                          </td>

                          {/* Tanggal & Waktu */}
                          <td className="py-3 px-3 align-middle text-stone-600 font-medium">
                            <span className="block font-bold text-stone-800">
                              {record.tanggalSelesai && record.tanggalSelesai !== record.tanggal 
                                ? `${record.tanggal} - ${record.tanggalSelesai}` 
                                : record.tanggal}
                            </span>
                            <span className="text-[10px] text-stone-400 font-mono">
                              {record.waktu || record.jam || '-'} WIB
                            </span>
                          </td>

                          {/* Petugas */}
                          <td className="py-3 px-3 align-middle">
                            <span className="font-bold text-stone-800 block text-xs">{record.pjKasir || 'Admin'}</span>
                            <span className="text-[10px] text-stone-400">Petugas Lapangan</span>
                          </td>

                          {/* Supervisor */}
                          <td className="py-3 px-3 align-middle">
                            {isDraft ? (
                              <span className="text-[11px] text-amber-700 font-bold italic">
                                Belum Disahkan
                              </span>
                            ) : (
                              <>
                                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-900">
                                  <ShieldCheck className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                                  <span>{record.authorizedBy || 'Supervisor'}</span>
                                </div>
                                <span className="text-[10px] text-stone-400">Otoritas Valid</span>
                              </>
                            )}
                          </td>

                          {/* Item Diperiksa */}
                          <td className="py-3 px-3 align-middle text-center">
                            <span className="font-mono font-extrabold text-stone-800">
                              {record.totalItemDiperiksa} Item
                            </span>
                            {hasDiff ? (
                              <span className="block text-[10px] font-bold text-amber-600">
                                {record.totalItemSelisih} Berselisih
                              </span>
                            ) : (
                              <span className="block text-[10px] font-bold text-emerald-600">
                                100% Klop
                              </span>
                            )}
                          </td>

                          {/* Selisih Qty */}
                          <td className="py-3 px-3 align-middle text-center">
                            {hasDiff ? (
                              <div className="inline-flex items-center gap-1 font-mono text-xs font-black">
                                {(record.totalSelisihKurangQty || 0) > 0 && (
                                  <span className="px-1.5 py-0.5 rounded bg-red-100 text-red-700">
                                    -{record.totalSelisihKurangQty}
                                  </span>
                                )}
                                {(record.totalSelisihLebihQty || 0) > 0 && (
                                  <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700">
                                    +{record.totalSelisihLebihQty}
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-[11px] font-bold text-stone-400 font-mono">0</span>
                            )}
                          </td>

                          {/* Selisih Nilai (Rp) */}
                          <td className="py-3 px-3 align-middle text-right font-mono">
                            <span className={`font-black text-xs block ${
                              nominal < 0 
                                ? 'text-red-600' 
                                : nominal > 0 
                                ? 'text-emerald-700' 
                                : 'text-stone-600'
                            }`}>
                              {nominal > 0 ? `+${fRp(nominal)}` : fRp(nominal)}
                            </span>
                            <span className="text-[9px] text-stone-400">HPP / Modal</span>
                          </td>

                          {/* Tombol Aksi */}
                          <td className="py-3 px-3.5 align-middle text-center">
                            <div className="flex items-center justify-center gap-1">
                              {isDraft && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveDraftOpname(record);
                                    setIsOpnameModalOpen(true);
                                  }}
                                  className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-lg text-xs font-extrabold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                                  title="Lanjutkan Perhitungan Fisik"
                                >
                                  <Play className="w-3.5 h-3.5" />
                                  <span>Lanjutkan</span>
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => setSelectedOpnameForDetail(record)}
                                className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                title="Lihat Rincian Selisih Item"
                              >
                                <FileText className="w-3.5 h-3.5 text-purple-600" />
                                <span>Rincian</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleDownloadOpnamePdf(record)}
                                className="px-2.5 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                title="Unduh PDF Berita Acara"
                              >
                                <FileDown className="w-3.5 h-3.5 text-orange-600" />
                                <span>PDF</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => setOpnameToDelete(record)}
                                className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                title="Hapus Riwayat Sesi Ini"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: CATAT PENGELUARAN BARU */}
      {showAddExpenseModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-red-100 text-red-700 rounded-xl">
                  <TrendingDown className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-base">Catat Pengeluaran Operasional</h3>
                  <p className="text-xs text-stone-500">Input biaya perusahaan untuk rekap keuangan.</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddExpenseModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddExpenseSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tanggal Pengeluaran <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={expTanggal}
                  onChange={(e) => setExpTanggal(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Kategori Pengeluaran <span className="text-red-500">*</span>
                </label>
                <select
                  value={expKategori}
                  onChange={(e) => setExpKategori(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                >
                  {EXPENSE_CATEGORIES.map((cat, cIdx) => (
                    <option key={`exp-cat-add-${cat}-${cIdx}`} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Keterangan / Deskripsi <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={expKeterangan}
                  onChange={(e) => setExpKeterangan(e.target.value)}
                  required
                  placeholder="Contoh: Beli Kertas Art Paper 230g, Bayar Token Listrik..."
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nominal Pengeluaran (Rp) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={expNominal}
                  onChange={(e) => setExpNominal(e.target.value.replace(/[^0-9.,]/g, ''))}
                  onFocus={(e) => (e.target as HTMLInputElement).select()}
                  required
                  placeholder="Contoh: 150000"
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-sm font-black text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
                {expNominal && !isNaN(parseFloat(String(expNominal).replace(',', '.'))) && (
                  <p className="mt-1 text-[11px] font-bold text-stone-500">
                    Sama dengan: <span className="text-red-600">{fRp(parseFloat(String(expNominal).replace(',', '.')))}</span>
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-700">
                    Penanggung Jawab / Kasir
                  </label>
                  <span className="text-[10px] text-stone-500 font-semibold bg-stone-100 px-2 py-0.5 rounded-md border border-stone-200">
                    Otomatis (User Login)
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={expPj || currentLoggedInUser || 'Admin'}
                    readOnly
                    tabIndex={-1}
                    className="w-full px-3 py-2 pr-9 bg-stone-100/90 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 cursor-not-allowed select-none focus:outline-none focus:ring-0 shadow-inner"
                    title="Penanggung jawab otomatis diisi oleh user yang login dan bersifat read-only"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 pointer-events-none" title="Terkunci otomatis sesuai akun login">
                    <Lock className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddExpenseModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95"
                >
                  Simpan Biaya
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL EDIT PENGELUARAN */}
      {expenseToEdit && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-xl">
                  <Pencil className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-base">Edit Catatan Pengeluaran</h3>
                  <p className="text-xs text-stone-500">Perbarui data pengeluaran ID: {expenseToEdit.id}</p>
                </div>
              </div>
              <button
                onClick={() => setExpenseToEdit(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditExpenseSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tanggal Pengeluaran <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={editExpTanggal}
                  onChange={(e) => setEditExpTanggal(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Kategori Pengeluaran <span className="text-red-500">*</span>
                </label>
                <select
                  value={editExpKategori}
                  onChange={(e) => setEditExpKategori(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                >
                  {EXPENSE_CATEGORIES.map((cat, cIdx) => (
                    <option key={`exp-cat-edit-${cat}-${cIdx}`} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Keterangan / Deskripsi <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={editExpKeterangan}
                  onChange={(e) => setEditExpKeterangan(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nominal Pengeluaran (Rp) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={editExpNominal}
                  onChange={(e) => setEditExpNominal(e.target.value.replace(/[^0-9.,]/g, ''))}
                  onFocus={(e) => (e.target as HTMLInputElement).select()}
                  required
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-sm font-black text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
                {editExpNominal && !isNaN(parseFloat(String(editExpNominal).replace(',', '.'))) && (
                  <p className="mt-1 text-[11px] font-bold text-stone-500">
                    Sama dengan: <span className="text-blue-700">{fRp(parseFloat(String(editExpNominal).replace(',', '.')))}</span>
                  </p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-700">
                    Penanggung Jawab / Kasir
                  </label>
                  <span className="text-[10px] text-stone-500 font-semibold bg-stone-100 px-2 py-0.5 rounded-md border border-stone-200">
                    Tercatat (Read-only)
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={editExpPj || currentLoggedInUser || 'Admin'}
                    readOnly
                    tabIndex={-1}
                    className="w-full px-3 py-2 pr-9 bg-stone-100/90 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 cursor-not-allowed select-none focus:outline-none focus:ring-0 shadow-inner"
                    title="Penanggung jawab tercatat pada sistem dan bersifat read-only"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 pointer-events-none" title="Terkunci read-only">
                    <Lock className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setExpenseToEdit(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS PENGELUARAN */}
      {expenseToDelete && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center gap-3 border-b border-stone-100 pb-3">
              <div className="p-2.5 bg-red-100 text-red-600 rounded-2xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-stone-900 text-base">Hapus Catatan Pengeluaran?</h3>
                <p className="text-xs text-stone-500">Tindakan ini akan menghapus data permanen.</p>
              </div>
            </div>

            <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs space-y-1">
              <p className="text-stone-500">Keterangan:</p>
              <p className="font-bold text-stone-900">{expenseToDelete.keterangan}</p>
              <div className="flex items-center justify-between pt-1 border-t border-stone-200/80">
                <span className="text-stone-500">Nominal:</span>
                <span className="font-black text-red-600">{fRp(expenseToDelete.nominal)}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteExpense}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Data</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL CETAK PDF LAPORAN BULANAN */}
      {showPdfModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <FileDown className="w-5 h-5 text-orange-600" />
                <h3 className="font-extrabold text-stone-900 text-base">Cetak PDF Bulanan</h3>
              </div>
              <button
                onClick={() => setShowPdfModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Pilih Bulan Laporan
                </label>
                <select
                  value={pdfMonth}
                  onChange={(e) => setPdfMonth(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                >
                  {monthNames.map((name, idx) => (
                    <option key={name} value={idx}>{name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Pilih Tahun Laporan
                </label>
                <select
                  value={pdfYear}
                  onChange={(e) => setPdfYear(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                >
                  {[now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1].map((y, yIdx) => (
                    <option key={`year-opt-${y}-${yIdx}`} value={y}>{y}</option>
                  ))}
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPdfModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleDownloadPdfSpecificMonth}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95"
                >
                  Unduh PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL EXPORT EXCEL SESUAI FORMAT PIC1 */}
      {showExcelExportModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow-xs">
                  <FileSpreadsheet className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-base">Export Excel Transaksi & Biaya</h3>
                  <p className="text-[11px] text-stone-500 font-medium">Format backup pembukuan keuangan (.xlsx)</p>
                </div>
              </div>
              <button
                onClick={() => setShowExcelExportModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5">
              {/* Scope Selection */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-2">
                  Pilih Cakupan Data yang Ingin Di-export:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div
                    onClick={() => setExcelExportScope('filter')}
                    className={`p-3 rounded-xl border-2 cursor-pointer transition flex flex-col justify-between ${
                      excelExportScope === 'filter'
                        ? 'border-teal-600 bg-teal-50/70 text-teal-950 shadow-2xs'
                        : 'border-stone-200 bg-stone-50 hover:bg-stone-100/80 text-stone-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs">Sesuai Filter Aktif</span>
                      <input
                        type="radio"
                        name="excelScope"
                        checked={excelExportScope === 'filter'}
                        onChange={() => setExcelExportScope('filter')}
                        className="text-teal-600 focus:ring-teal-500"
                      />
                    </div>
                    <p className="text-[11px] text-stone-500 font-medium leading-tight">
                      Periode: {filterPeriodLabel}
                    </p>
                    <p className="text-[10px] font-bold text-teal-800 mt-2">
                      {filteredInvoices.length} Penjualan • {filteredExpenses.length} Kas Keluar
                    </p>
                  </div>

                  <div
                    onClick={() => setExcelExportScope('all')}
                    className={`p-3 rounded-xl border-2 cursor-pointer transition flex flex-col justify-between ${
                      excelExportScope === 'all'
                        ? 'border-teal-600 bg-teal-50/70 text-teal-950 shadow-2xs'
                        : 'border-stone-200 bg-stone-50 hover:bg-stone-100/80 text-stone-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-xs">Semua Data (Full Backup)</span>
                      <input
                        type="radio"
                        name="excelScope"
                        checked={excelExportScope === 'all'}
                        onChange={() => setExcelExportScope('all')}
                        className="text-teal-600 focus:ring-teal-500"
                      />
                    </div>
                    <p className="text-[11px] text-stone-500 font-medium leading-tight">
                      Seluruh riwayat database kasir
                    </p>
                    <p className="text-[10px] font-bold text-teal-800 mt-2">
                      {processedInvoices.length} Penjualan • {expenses.length} Kas Keluar
                    </p>
                  </div>
                </div>
              </div>

              {/* Format Preview Card matching pic1 */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                    Struktur Kolom Excel (Format Standar pic1)
                  </span>
                  <span className="text-[10px] font-mono text-stone-400 font-bold">8 Kolom Utama</span>
                </div>
                <div className="bg-white border border-stone-200 rounded-lg p-2 overflow-x-auto text-[10px] font-mono custom-scrollbar">
                  <table className="w-full text-left whitespace-nowrap">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-600 font-bold bg-stone-100/70">
                        <th className="px-1.5 py-1">No Struk</th>
                        <th className="px-1.5 py-1">Tanggal Transaksi</th>
                        <th className="px-1.5 py-1">Kasir / Operator</th>
                        <th className="px-1.5 py-1">Metode Bayar</th>
                        <th className="px-1.5 py-1">Kategori Penjualan</th>
                        <th className="px-1.5 py-1 text-right">Total Penjualan / Omzet (Rp)</th>
                        <th className="px-1.5 py-1 text-right">Kas Keluar / Biaya (Rp)</th>
                        <th className="px-1.5 py-1">Keterangan</th>
                      </tr>
                    </thead>
                    <tbody className="text-stone-500">
                      <tr>
                        <td className="px-1.5 py-1 text-stone-800 font-bold">STRUK-4048-001</td>
                        <td className="px-1.5 py-1">2026-09-01</td>
                        <td className="px-1.5 py-1">Kasir Ervo 1</td>
                        <td className="px-1.5 py-1">QRIS</td>
                        <td className="px-1.5 py-1">Retail Print</td>
                        <td className="px-1.5 py-1 text-right font-bold text-emerald-600">850000</td>
                        <td className="px-1.5 py-1 text-right">0</td>
                        <td className="px-1.5 py-1">Cetak Stiker Kiss-Cut &amp; Kartu Nama</td>
                      </tr>
                      <tr className="bg-stone-50/50">
                        <td className="px-1.5 py-1 text-stone-800 font-bold">EXP-101</td>
                        <td className="px-1.5 py-1">2026-09-01</td>
                        <td className="px-1.5 py-1">Kasir Ervo 1</td>
                        <td className="px-1.5 py-1">Tunai</td>
                        <td className="px-1.5 py-1">Bahan Baku</td>
                        <td className="px-1.5 py-1 text-right">0</td>
                        <td className="px-1.5 py-1 text-right font-bold text-red-600">45000</td>
                        <td className="px-1.5 py-1">Beli Lakban Bening &amp; Cutter Toko</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-[10px] text-stone-500 leading-tight">
                  ✓ Berkas <strong>.xlsx</strong> langsung dapat dibuka di Microsoft Excel, Google Sheets, LibreOffice, atau diarsipkan sebagai cadangan mandiri bila server bermasalah.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowExcelExportModal(false)}
                  disabled={isExportingExcel}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl cursor-pointer transition"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => handleExportExcelPic1(excelExportScope)}
                  disabled={isExportingExcel}
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 disabled:bg-teal-400 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
                >
                  {isExportingExcel ? (
                    <>
                      <RotateCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Sedang Mengenerate Excel...</span>
                    </>
                  ) : (
                    <>
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Unduh File Excel (.xlsx)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Top Products Analytics Modal */}
      <TopProductsModal
        isOpen={showTopProductsModal}
        onClose={() => setShowTopProductsModal(false)}
        invoices={invoices}
        initialScope={
          filterPeriod === 'week'
            ? '7d'
            : filterPeriod === 'month'
            ? 'month'
            : filterPeriod === 'today'
            ? 'today'
            : filterPeriod === 'custom'
            ? 'custom'
            : '30d'
        }
      />

      {/* Edit / Koreksi Transaksi Modal (SPV / Owner Authorization) */}
      {isEditModalOpen && invoiceToEdit && (
        <EditTransactionModal
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setInvoiceToEdit(null);
          }}
          invoice={invoiceToEdit}
          settings={settings}
          kasirUsers={kasirUsers}
          customers={customers}
          products={products}
          currentUser={currentUser}
          onSaveSuccess={(updated) => {
            // Update invoice in state
            setInvoices((prev) =>
              prev.map((it) => {
                if (it.invoiceNo === updated.invoiceNo) {
                  return {
                    ...it,
                    ...updated,
                    total: updated.total,
                    sisa: updated.sisa,
                    customer: updated.customer,
                    payMethod: updated.payMethod,
                    lastEditedBy: updated.lastEditedBy,
                    lastEditedAt: updated.lastEditedAt,
                    editReason: updated.editReason,
                    auditLogs: updated.auditLogs,
                  };
                }
                return it;
              })
            );
            setIsEditModalOpen(false);
            setInvoiceToEdit(null);
            onShowToast(`✓ Transaksi #${updated.invoiceNo} berhasil dikoreksi!`, 'success');
          }}
          onShowToast={onShowToast}
        />
      )}

      {/* Delete / Hapus Invoice Piutang Modal (Khusus Owner & SPV) */}
      {invoiceToDelete && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-red-100 text-red-700 rounded-xl">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-base">Hapus Data Piutang / Invoice</h3>
                  <p className="text-xs text-stone-500">Khusus Otorisasi Owner & Supervisor (SPV)</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Invoice Summary Card */}
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center border-b border-stone-200/80 pb-2">
                <span className="text-stone-500 font-medium">No. Invoice:</span>
                <span className="font-mono font-black text-stone-900 text-sm">
                  {invoiceToDelete.invoiceNo || invoiceToDelete.noInvoice}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Pelanggan:</span>
                <span className="font-bold text-stone-800">
                  {invoiceToDelete.customer || invoiceToDelete.pelanggan || 'Umum'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Tanggal Transaksi:</span>
                <span className="text-stone-700">{invoiceToDelete.date}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Total Transaksi:</span>
                <span className="font-semibold text-stone-900">{fRp(Number(invoiceToDelete.total || 0))}</span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-stone-200/80">
                <span className="text-amber-800 font-bold">Sisa Piutang:</span>
                <span className="font-black text-amber-700 text-sm">
                  {fRp(Number(invoiceToDelete.sisa || 0))}
                </span>
              </div>
            </div>

            {/* Security Authorization Gate */}
            {isDeleteSpvAuthorized ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2.5 text-emerald-900 text-xs">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="font-extrabold flex items-center gap-1">
                    <span>Terverifikasi Sebagai Owner / SPV:</span>
                    <strong className="underline">{deleteSpvUser}</strong>
                  </p>
                  <p className="text-[11px] text-emerald-700 mt-0.5">
                    Wewenang Supervisor aktif. Tindakan penghapusan ini akan dicatat dan invoice akan dihapus secara permanen.
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center gap-2 text-amber-900 text-xs font-extrabold">
                  <Lock className="w-4 h-4 text-amber-600" />
                  <span>Otorisasi Supervisor / Owner Diperlukan</span>
                </div>
                <p className="text-[11px] text-amber-800">
                  Penghapusan data piutang diproteksi. Masukkan akun dan PIN / Password Supervisor (SPV) atau Owner untuk melanjutkan.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-700 mb-1">Supervisor / Owner</label>
                    <select
                      value={deleteSpvUser}
                      onChange={(e) => {
                        setDeleteSpvUser(e.target.value);
                        setDeleteSpvError(null);
                      }}
                      className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-bold text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      {spvAccounts.length > 0 ? (
                        spvAccounts.map((u, uIdx) => (
                          <option key={`${u.nama}-${uIdx}`} value={u.nama}>
                            {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(SPV/OWNER)'}
                          </option>
                        ))
                      ) : (
                        <>
                          <option value="Owner">Owner / Pimpinan</option>
                          <option value="SPV">Supervisor (SPV)</option>
                        </>
                      )}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-700 mb-1">Password / PIN SPV</label>
                    <input
                      type="password"
                      value={deleteSpvPassword}
                      onChange={(e) => {
                        setDeleteSpvPassword(e.target.value);
                        setDeleteSpvError(null);
                      }}
                      placeholder="PIN / Password"
                      className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>

                {deleteSpvError && (
                  <div className="text-red-600 text-xs font-bold flex items-center gap-1 pt-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{deleteSpvError}</span>
                  </div>
                )}
              </div>
            )}

            {/* Reason Selection */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Alasan Penghapusan Piutang:
              </label>
              <select
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500/20"
              >
                <option value="Nota piutang dibatalkan / salah input">Nota piutang dibatalkan / salah input</option>
                <option value="Pelanggan melakukan retur total">Pelanggan melakukan retur total</option>
                <option value="Transaksi ganda / duplikat">Transaksi ganda / duplikat</option>
                <option value="Penyelesaian di luar sistem / dispensasi Owner">Penyelesaian di luar sistem / dispensasi Owner</option>
                <option value="Lainnya">Lainnya</option>
              </select>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                disabled={isDeletingInvoice}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteInvoice}
                disabled={isDeletingInvoice}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                {isDeletingInvoice ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Piutang</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stock Opname Audit Wizard Modal */}
      {isOpnameModalOpen && (
        <StockOpnameModal
          isOpen={isOpnameModalOpen}
          onClose={() => {
            setIsOpnameModalOpen(false);
            setActiveDraftOpname(null);
          }}
          currentUser={currentUser}
          kasirUsers={kasirUsers}
          products={products}
          settings={settings}
          initialDraft={activeDraftOpname}
          onShowToast={onShowToast}
          onOpnameSaved={(savedRecord) => {
            setStockOpnames((prev) => [savedRecord, ...prev.filter((it) => it.id !== savedRecord.id)]);
            onRefreshProducts?.();
            const actionMsg = savedRecord.status === 'DRAFT'
              ? `✓ Draf Sesi Opname #${savedRecord.id} berhasil disimpan (belum mengubah stok)`
              : `✓ Berita Acara #${savedRecord.id} berhasil disahkan & stok disinkronkan!`;
            onShowToast(actionMsg, 'success');
            setActiveDraftOpname(null);
          }}
        />
      )}

      {/* Stock Opname Detail & Export Modal */}
      {selectedOpnameForDetail && (
        <StockOpnameDetailModal
          isOpen={selectedOpnameForDetail !== null}
          record={selectedOpnameForDetail}
          onClose={() => setSelectedOpnameForDetail(null)}
          settings={settings}
          onShowToast={onShowToast}
        />
      )}

      {/* Delete Opname Session Modal */}
      {opnameToDelete && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-red-100 text-red-700 rounded-xl">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-base">Hapus Berita Acara Opname</h3>
                  <p className="text-xs text-stone-500">ID: #{opnameToDelete.id}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpnameToDelete(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Tanggal Sesi:</span>
                <span className="font-bold text-stone-800">{opnameToDelete.tanggal} ({opnameToDelete.waktu})</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Petugas / Kasir:</span>
                <span className="font-bold text-stone-800">{opnameToDelete.pjKasir}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Otorisasi SPV:</span>
                <span className="font-bold text-purple-700">{opnameToDelete.authorizedBy}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-stone-500">Item Diperiksa:</span>
                <span className="font-bold text-stone-900">{opnameToDelete.totalItemDiperiksa} SKU ({opnameToDelete.totalItemSelisih} Berselisih)</span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-stone-200/80">
                <span className="text-stone-700 font-bold">Net Selisih:</span>
                <span className="font-black text-stone-900 font-mono">{fRp(opnameToDelete.totalSelisihNominalRp)}</span>
              </div>
            </div>

            <p className="text-xs text-amber-800 bg-amber-50 p-2.5 rounded-xl border border-amber-200 font-medium">
              ⚠️ Catatan: Menghapus riwayat berita acara ini tidak membatalkan nilai stok yang sudah dikoreksi di katalog master, namun dokumen audit ini akan dihapus dari riwayat.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setOpnameToDelete(null)}
                disabled={isDeletingOpname}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteOpname}
                disabled={isDeletingOpname}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                {isDeletingOpname ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Dokumen</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
