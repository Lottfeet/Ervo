import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  KeyRound, 
  AlertCircle, 
  CheckCircle2, 
  Save, 
  Receipt, 
  CreditCard, 
  Banknote, 
  QrCode, 
  Building2, 
  UserCheck, 
  Calendar, 
  Clock, 
  User, 
  FileText, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Printer, 
  Layers,
  ChevronRight,
  Info,
  History,
  Search,
  Package,
  Sparkles,
  ArrowLeftRight,
  Check,
  Tag
} from 'lucide-react';
import { Invoice, InvoiceItem, StoreSettings, KasirUser, Customer, Product, PelunasanRecord } from '../types';
import { fRp, fDateInput, formatDateFromInput, computeItemTotal, checkIsSpvOrOwner } from '../utils/formatters';
import { updateInvoiceFirebase, reconcileInvoiceStockFirebase } from '../services/firebaseService';
import { updateInvoiceRemote, updateInvoiceInLocalCache, getPelunasanHistory, mergePelunasanHistories } from '../services/gasService';
import { generateThermalHTML, generateA5HTML, openPrintWindow } from '../utils/printUtils';

interface EditTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  settings: StoreSettings;
  kasirUsers: KasirUser[];
  customers?: Customer[];
  products?: Product[];
  currentUser?: string | null;
  onSaveSuccess?: (updatedInvoice: Invoice) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  onClose,
  invoice,
  settings,
  kasirUsers,
  customers = [],
  products = [],
  currentUser,
  onSaveSuccess,
  onShowToast,
}) => {
  // Authorization Gate State
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  const [authorizedBy, setAuthorizedBy] = useState<string>('');
  const [authSpvUser, setAuthSpvUser] = useState<string>('');
  const [authPassword, setAuthPassword] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Form Editing State
  const [activeSubTab, setActiveSubTab] = useState<'pembayaran' | 'items' | 'pelunasan' | 'audit'>('pembayaran');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Editable Fields
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [transactionDate, setTransactionDate] = useState<string>('');
  const [transactionTime, setTransactionTime] = useState<string>('');
  const [deadlineDate, setDeadlineDate] = useState<string>('');
  const [cashierName, setCashierName] = useState<string>('');

  // Payment Details
  const [payMethod, setPayMethod] = useState<string>('Tunai');
  const [dpAmount, setDpAmount] = useState<number>(0);
  const [discPct, setDiscPct] = useState<number>(0);
  const [taxPct, setTaxPct] = useState<number>(0);
  const [negoAmt, setNegoAmt] = useState<number>(0);

  // Items List
  const [items, setItems] = useState<InvoiceItem[]>([]);

  // Pelunasan History (Installments)
  const [pelunasanHistory, setPelunasanHistory] = useState<PelunasanRecord[]>([]);

  // Audit Reason
  const [editReasonCategory, setEditReasonCategory] = useState<string>('Salah input metode pembayaran');
  const [editReasonCustom, setEditReasonCustom] = useState<string>('');

  // Product Catalog Picker State
  const [isCatalogModalOpen, setIsCatalogModalOpen] = useState<boolean>(false);
  const [targetSwapIndex, setTargetSwapIndex] = useState<number | null>(null);
  const [catalogSearchQuery, setCatalogSearchQuery] = useState<string>('');
  const [catalogSelectedCategory, setCatalogSelectedCategory] = useState<string>('ALL');
  const [activeSuggestIndex, setActiveSuggestIndex] = useState<number | null>(null);

  // Post-Save Print Dialog
  const [savedInvoice, setSavedInvoice] = useState<Invoice | null>(null);

  // Initialize and check role whenever modal opens or invoice changes
  useEffect(() => {
    if (!isOpen || !invoice) {
      setIsAuthorized(false);
      setAuthorizedBy('');
      setAuthPassword('');
      setAuthError(null);
      setSavedInvoice(null);
      return;
    }

    const activeUser = currentUser || settings.cashier || localStorage.getItem('strukku_logged_kasir') || '';
    const isUserSpv = checkIsSpvOrOwner(activeUser, kasirUsers);

    if (isUserSpv) {
      setIsAuthorized(true);
      setAuthorizedBy(activeUser);
    } else {
      setIsAuthorized(false);
      const spvCandidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else {
        setAuthSpvUser('Owner');
      }
    }

    // Populate invoice fields
    setCustomerName(invoice.customer || invoice.pelanggan || 'Umum');
    setCustomerPhone(invoice.customerPhone || '');
    setCustomerAddress(invoice.customerAddress || '');
    setTransactionDate(invoice.date || fDateInput(new Date()));
    setTransactionTime(invoice.time || '12:00');
    setDeadlineDate(invoice.deadline || '');
    setCashierName(invoice.cashier || 'Admin');

    setPayMethod(invoice.payMethod || (invoice as any).metodePembayaran || 'Tunai');
    setDpAmount(Number(invoice.dp || 0));
    setDiscPct(Number(invoice.discPct || 0));
    setTaxPct(Number(invoice.taxPct || 0));
    setNegoAmt(Number(invoice.negoAmt || 0));

    setItems(Array.isArray(invoice.items) ? JSON.parse(JSON.stringify(invoice.items)) : []);
    
    const backendHist = Array.isArray(invoice.pelunasanHistory) && invoice.pelunasanHistory.length > 0
      ? invoice.pelunasanHistory 
      : (Array.isArray(invoice.historiPelunasan) ? invoice.historiPelunasan : []);
    const localHist = invoice.invoiceNo ? getPelunasanHistory(invoice.invoiceNo) : [];
    const hist = mergePelunasanHistories(backendHist, localHist);
    setPelunasanHistory(JSON.parse(JSON.stringify(hist)));

    setEditReasonCategory('Salah input metode pembayaran');
    setEditReasonCustom('');
    setActiveSubTab('pembayaran');
  }, [isOpen, invoice, currentUser, settings.cashier, kasirUsers]);

  if (!isOpen || !invoice) return null;

  // Handle SPV Verification
  const handleVerifyAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (!authSpvUser) {
      setAuthError('Pilih akun SPV / Owner.');
      return;
    }

    if (!checkIsSpvOrOwner(authSpvUser, kasirUsers) && authSpvUser.toLowerCase() !== 'owner' && authSpvUser.toLowerCase() !== 'spv') {
      setAuthError(`Akses Ditolak: Akun "${authSpvUser}" bukan Supervisor atau Owner.`);
      return;
    }

    const targetUser = kasirUsers.find((u) => u.nama.trim().toLowerCase() === authSpvUser.trim().toLowerCase());
    const validPass = targetUser?.password?.trim() || 'ervo123';

    if (authPassword.trim() === validPass) {
      setIsAuthorized(true);
      setAuthorizedBy(authSpvUser);
      onShowToast(`Otorisasi diterima dari ${authSpvUser}`, 'success');
    } else {
      setAuthError(`Password / PIN otorisasi untuk ${authSpvUser} salah!`);
    }
  };

  // Calculations
  const calculatedSubtotal = items.reduce((acc, item) => acc + computeItemTotal(item), 0);
  const calculatedDiscAmt = discPct > 0 ? (calculatedSubtotal * discPct) / 100 : 0;
  const afterDisc = Math.max(0, calculatedSubtotal - calculatedDiscAmt);
  const calculatedTaxAmt = taxPct > 0 ? (afterDisc * taxPct) / 100 : 0;
  const calculatedTotal = Math.max(0, afterDisc + calculatedTaxAmt - (negoAmt || 0));

  const totalPelunasanPaid = pelunasanHistory.reduce((acc, p) => acc + Number(p.jumlahBayar || 0), 0);
  const totalPaid = dpAmount + totalPelunasanPaid;
  const calculatedSisa = Math.max(0, calculatedTotal - totalPaid);
  const calculatedStatus = calculatedSisa <= 0 ? 'LUNAS' : 'DP';

  // Handle Item Changes
  const handleItemChange = (index: number, field: keyof InvoiceItem, val: any) => {
    setItems((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: val };
      return updated;
    });
  };

  // Extract catalog categories
  const catalogCategories = useMemo(() => {
    const cats = new Set<string>();
    products.forEach((p) => {
      if (p.kategori) {
        p.kategori.split(/[,;/]/).forEach((c) => {
          const trimmed = c.trim();
          if (trimmed) cats.add(trimmed);
        });
      }
    });
    return Array.from(cats);
  }, [products]);

  // Filtered Catalog Products
  const filteredCatalogProducts = useMemo(() => {
    const q = catalogSearchQuery.trim().toLowerCase();
    return products.filter((p) => {
      const matchCat =
        catalogSelectedCategory === 'ALL' ||
        (p.kategori && p.kategori.toLowerCase().includes(catalogSelectedCategory.toLowerCase()));
      if (!matchCat) return false;

      if (!q) return true;
      const matchName = (p.nama || '').toLowerCase().includes(q);
      const matchCode = (p.kode || '').toLowerCase().includes(q);
      const matchKategori = (p.kategori || '').toLowerCase().includes(q);
      return matchName || matchCode || matchKategori;
    });
  }, [products, catalogSearchQuery, catalogSelectedCategory]);

  const handleOpenCatalogForNew = () => {
    setTargetSwapIndex(null);
    setCatalogSearchQuery('');
    setCatalogSelectedCategory('ALL');
    setIsCatalogModalOpen(true);
  };

  const handleOpenCatalogForSwap = (index: number) => {
    setTargetSwapIndex(index);
    setCatalogSearchQuery('');
    setCatalogSelectedCategory('ALL');
    setIsCatalogModalOpen(true);
  };

  const handleSelectProduct = (prod: Product) => {
    if (targetSwapIndex !== null && targetSwapIndex >= 0 && targetSwapIndex < items.length) {
      setItems((prev) => {
        const updated = [...prev];
        updated[targetSwapIndex] = {
          ...updated[targetSwapIndex],
          kode: prod.kode || 'CUSTOM',
          nama: prod.nama,
          harga: prod.harga || 0,
          satuan: prod.satuan || 'pcs',
          tipeHarga: prod.tipeHarga || 'fix',
        };
        return updated;
      });
      onShowToast(`✓ Berhasil menukar item menjadi "${prod.nama}"`, 'success');
    } else {
      handleAddItem(prod);
      onShowToast(`✓ "${prod.nama}" ditambahkan ke nota!`, 'success');
    }
    setIsCatalogModalOpen(false);
    setTargetSwapIndex(null);
    setActiveSuggestIndex(null);
  };

  const handleAddItem = (product?: Product) => {
    const newItem: InvoiceItem = {
      kode: product ? product.kode : 'CUSTOM',
      nama: product ? product.nama : 'Item Pesanan Baru',
      harga: product ? product.harga : 0,
      qty: 1,
      satuan: product ? product.satuan : 'pcs',
      tipeHarga: product ? product.tipeHarga : 'fix',
      panjang: 1,
      lebar: 1,
      bahan: '',
      catatan: '',
      diskonItem: 0,
    };
    setItems((prev) => [...prev, newItem]);
  };

  const handleDeleteItem = (index: number) => {
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Handle Pelunasan Step Changes
  const handlePelunasanChange = (index: number, field: keyof PelunasanRecord, val: any) => {
    setPelunasanHistory((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: val };
      return updated;
    });
  };

  const handleDeletePelunasan = (index: number) => {
    setPelunasanHistory((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Submit Save Changes
  const handleSaveCorrection = async () => {
    if (items.length === 0) {
      onShowToast('Transaksi harus memiliki minimal 1 item pesanan!', 'error');
      return;
    }

    const finalReason = editReasonCustom.trim() 
      ? `${editReasonCategory}: ${editReasonCustom.trim()}` 
      : editReasonCategory;

    setIsSaving(true);

    const parseNum = (v: any, fallback = 0): number => {
      if (v === undefined || v === null || v === '') return fallback;
      if (typeof v === 'number') return isNaN(v) ? fallback : v;
      const num = parseFloat(String(v).trim().replace(',', '.'));
      return isNaN(num) ? fallback : num;
    };

    const cleanItems = items.map((it) => {
      const q = Math.max(0.01, parseNum(it.qty, 1));
      const p = parseNum(it.panjang, 0);
      const l = parseNum(it.lebar, 0);
      const h = parseNum(it.harga, 0);
      const d = parseNum(it.diskonItem, 0);
      return {
        ...it,
        qty: q,
        panjang: p,
        lebar: l,
        harga: h,
        diskonItem: d,
        totalItem: computeItemTotal({
          ...it,
          qty: q,
          panjang: p,
          lebar: l,
          harga: h,
          diskonItem: d,
        }),
      };
    });

    const updatedInvoice: Invoice = {
      ...invoice,
      customer: customerName.trim() || 'Umum',
      pelanggan: customerName.trim() || 'Umum',
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      date: transactionDate,
      time: transactionTime,
      deadline: deadlineDate,
      cashier: cashierName,
      subtotal: calculatedSubtotal,
      discPct: discPct,
      discAmt: calculatedDiscAmt,
      taxPct: taxPct,
      taxAmt: calculatedTaxAmt,
      negoAmt: negoAmt,
      total: calculatedTotal,
      payMethod: dpAmount > 0 ? (payMethod || 'Tunai') : '-',
      metodePembayaran: dpAmount > 0 ? (payMethod || 'Tunai') : '-',
      dp: dpAmount,
      sisa: calculatedSisa,
      status: calculatedStatus,
      items: cleanItems,
      pelunasanHistory: pelunasanHistory,
      historiPelunasan: pelunasanHistory,
      lastEditedBy: authorizedBy || currentUser || 'SPV/Owner',
      editReason: finalReason,
    };

    try {
      // Stock Reconciliation (Rekonsiliasi Stok Otomatis)
      // Memetakan kuantitas item nota lama (invoice.items) vs baru (cleanItems), hitung Delta = Qty Lama - Qty Baru
      // Positif: kembalikan ke stok produk; Negatif: kurangi stok produk di Firebase Firestore secara real-time via writeBatch
      await reconcileInvoiceStockFirebase(invoice.items || [], cleanItems).catch((reconErr) => {
        console.warn('Stock reconciliation notice on invoice correction:', reconErr);
      });

      // 1. Immediately update local cache & broadcast update
      updateInvoiceInLocalCache(updatedInvoice);

      // 2. Update in Firebase Firestore (with safe timeout)
      await updateInvoiceFirebase(updatedInvoice, {
        editedBy: authorizedBy || currentUser || 'SPV/Owner',
        editReason: finalReason,
      });

      // 3. Update in Google Sheets asynchronously in background (non-blocking so slow network never hangs UI)
      updateInvoiceRemote(updatedInvoice, {
        editedBy: authorizedBy || currentUser || 'SPV/Owner',
        editReason: finalReason,
      }).catch((gasErr) => {
        console.warn('Google Sheets background sync warning:', gasErr);
      });

      setSavedInvoice(updatedInvoice);
      if (onSaveSuccess) {
        onSaveSuccess(updatedInvoice);
      }
      onShowToast(`✓ Transaksi #${updatedInvoice.invoiceNo} berhasil dikoreksi & disimpan!`, 'success');
    } catch (err: any) {
      console.error('Notice updating invoice in cloud:', err);
      // Fallback: local storage is already updated, proceed with success UI
      setSavedInvoice(updatedInvoice);
      if (onSaveSuccess) {
        onSaveSuccess(updatedInvoice);
      }
      onShowToast(`✓ Transaksi #${updatedInvoice.invoiceNo} disimpan di pembukuan kasir!`, 'success');
    } finally {
      setIsSaving(false);
    }
  };

  // Print Handlers for updated invoice
  const handlePrintThermal = () => {
    if (!savedInvoice) return;
    const html = generateThermalHTML(savedInvoice, settings);
    openPrintWindow(html, 'Struk Koreksi ' + savedInvoice.invoiceNo);
  };

  const handlePrintA5 = () => {
    if (!savedInvoice) return;
    const html = generateA5HTML(savedInvoice, settings);
    openPrintWindow(html, 'Nota A5 Koreksi ' + savedInvoice.invoiceNo);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col">
        
        {/* Header */}
        <div className="p-4 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-600 text-white flex items-center justify-center font-bold shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-stone-900 text-base">
                  Koreksi & Edit Transaksi
                </h3>
                <span className="px-2 py-0.5 rounded-md bg-stone-200 text-stone-800 font-mono text-xs font-bold">
                  {invoice.invoiceNo}
                </span>
              </div>
              <p className="text-xs text-stone-500 font-medium">
                Perbaiki kesalahan input kasir atau metode pembayaran dengan otorisasi SPV / Owner.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {!isAuthorized ? (
          /* STEP 1: SPV / OWNER AUTHORIZATION GATE */
          <div className="p-6 overflow-y-auto space-y-5">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
              <div className="p-2 bg-amber-100 text-amber-800 rounded-xl mt-0.5">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="font-extrabold text-amber-900 text-sm">
                  Otorisasi SPV / Owner Diperlukan
                </h4>
                <p className="text-xs text-amber-800 leading-relaxed">
                  Sesuai kebijakan keamanan dan pembukuan toko, kasir tidak diizinkan mengubah data transaksi secara sepihak. Masukkan PIN / Password akun <strong>Supervisor (SPV)</strong> atau <strong>Owner</strong> untuk membuka akses koreksi.
                </p>
              </div>
            </div>

            <form onSubmit={handleVerifyAuth} className="space-y-4 max-w-md mx-auto pt-2">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span>Pilih Akun Otorisator (SPV / Owner)</span>
                </label>
                <select
                  value={authSpvUser}
                  onChange={(e) => setAuthSpvUser(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                >
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, uIdx) => (
                    <option key={`${u.nama}-${uIdx}`} value={u.nama}>
                      {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(SPV / Owner)'}
                    </option>
                  ))}
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0 && (
                    <>
                      <option key="etm-spv-owner" value="Owner">Owner / Pemilik Toko</option>
                      <option key="etm-spv-spv" value="SPV">Supervisor (SPV)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                  <span>Password / PIN SPV / Owner</span>
                </label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Masukkan password / PIN otorisasi..."
                  required
                  autoFocus
                  className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                />
              </div>

              {authError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 px-4 rounded-xl border border-stone-200 text-stone-700 font-bold text-xs hover:bg-stone-50 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-1.5 transition"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Buka Akses Koreksi</span>
                </button>
              </div>
            </form>
          </div>
        ) : savedInvoice ? (
          /* SUCCESS / POST-SAVE PRINT DIALOG */
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-base font-extrabold text-stone-900">
                Koreksi Transaksi Berhasil Disimpan!
              </h4>
              <p className="text-xs text-stone-500 mt-1 max-w-md mx-auto">
                Data nota <strong>#{savedInvoice.invoiceNo}</strong> telah diperbarui di pembukuan kas, buku piutang, dan Google Sheets.
              </p>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-left max-w-md mx-auto text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-stone-500">Pelanggan:</span>
                <strong className="text-stone-900">{savedInvoice.customer}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Metode Pembayaran:</span>
                <span className="font-extrabold text-blue-700">{savedInvoice.payMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Total Transaksi:</span>
                <strong className="text-stone-900">{fRp(savedInvoice.total)}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Dibayar (DP):</span>
                <strong className="text-emerald-700">{fRp(savedInvoice.dp)}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Sisa Piutang:</span>
                <strong className={savedInvoice.sisa > 0 ? 'text-amber-700' : 'text-emerald-700'}>
                  {fRp(savedInvoice.sisa)} ({savedInvoice.status})
                </strong>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handlePrintThermal}
                className="px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Ulang Struk Thermal</span>
              </button>
              <button
                onClick={handlePrintA5}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition"
              >
                <FileText className="w-4 h-4" />
                <span>Cetak Nota A5</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition"
              >
                Selesai / Tutup
              </button>
            </div>
          </div>
        ) : (
          /* STEP 2: FULL CORRECTION FORM */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Sub-Navigation Tabs & SPV Badge */}
            <div className="px-4 py-2 bg-stone-100/80 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('pembayaran')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition ${
                    activeSubTab === 'pembayaran'
                      ? 'bg-white text-orange-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>1. Metode & Pembayaran</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('items')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition ${
                    activeSubTab === 'items'
                      ? 'bg-white text-orange-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>2. Item Pesanan ({items.length})</span>
                </button>
                {pelunasanHistory.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveSubTab('pelunasan')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition ${
                      activeSubTab === 'pelunasan'
                        ? 'bg-white text-orange-700 shadow-2xs border border-stone-200'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                    }`}
                  >
                    <History className="w-3.5 h-3.5" />
                    <span>3. Angsuran ({pelunasanHistory.length})</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setActiveSubTab('audit')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition ${
                    activeSubTab === 'audit'
                      ? 'bg-white text-orange-700 shadow-2xs border border-stone-200'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Alasan & Riwayat Audit</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg text-[11px] font-extrabold shrink-0 border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Otorisasi: {authorizedBy || 'SPV/Owner'}</span>
              </div>
            </div>

            {/* Tab Panes */}
            <div className="p-4 overflow-y-auto flex-1 space-y-4">
              
              {/* TAB 1: METODE PEMBAYARAN & NOMINAL DP */}
              {activeSubTab === 'pembayaran' && (
                <div className="space-y-4">
                  {/* Pilihan Metode Pembayaran Utama */}
                  <div className={`p-3.5 rounded-2xl border transition-all ${
                    dpAmount <= 0
                      ? 'bg-stone-100/70 border-stone-200'
                      : 'bg-stone-50 border-stone-200'
                  }`}>
                    <div className="flex items-center justify-between mb-2.5">
                      <label className="block text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                        Metode Pembayaran (Cash-In) <span className="text-red-500">*</span>
                      </label>
                      {dpAmount <= 0 && (
                        <span className="text-[10px] font-extrabold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md border border-amber-200">
                          Nonaktif (DP Belum Diisi / Rp 0)
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'Tunai', label: 'Tunai / Cash', icon: Banknote, color: 'emerald' },
                        { id: 'Transfer', label: 'Transfer Bank', icon: Building2, color: 'blue' },
                        { id: 'QRIS', label: 'QRIS Scan', icon: QrCode, color: 'amber' },
                        { id: 'Debet', label: 'Kartu Debet', icon: CreditCard, color: 'purple' },
                      ].map((m) => {
                        const Icon = m.icon;
                        const isSelected = payMethod.toLowerCase().includes(m.id.toLowerCase());
                        const isMethodDisabled = dpAmount <= 0;
                        return (
                          <button
                            key={m.id}
                            type="button"
                            disabled={isMethodDisabled}
                            onClick={() => !isMethodDisabled && setPayMethod(m.id)}
                            className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-xs font-extrabold transition-all ${
                              isMethodDisabled
                                ? 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed opacity-60'
                                : isSelected
                                ? 'bg-orange-600 text-white border-orange-600 shadow-sm cursor-pointer'
                                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-300 hover:bg-stone-50 cursor-pointer'
                            }`}
                          >
                            <Icon className="w-5 h-5" />
                            <span>{m.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Nominal Pembayaran DP / Bayar Muka */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                        Uang Muka / Nominal Bayar Awal (DP) <span className="text-red-500">*</span>
                      </label>
                      <span className="text-xs font-extrabold text-stone-900">
                        Total Order: {fRp(calculatedTotal)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2.5 text-xs font-bold text-stone-400">Rp</span>
                        <input
                          type="text"
                          inputMode="decimal"
                          value={dpAmount === 0 ? '' : dpAmount}
                          onChange={(e) => {
                            const clean = e.target.value.replace(/[^0-9.,]/g, '');
                            const num = parseFloat(clean.replace(',', '.'));
                            const validNum = isNaN(num) ? 0 : Math.max(0, num);
                            setDpAmount(validNum);
                            if (validNum > 0 && (!payMethod || payMethod === '-')) {
                              setPayMethod('Tunai');
                            }
                          }}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          placeholder="0 (Belum Bayar)"
                          className="w-full pl-9 pr-3 py-2.5 bg-white border border-stone-200 rounded-xl text-sm font-mono font-extrabold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                        />
                      </div>
                    </div>

                    {/* Quick Shortcuts */}
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDpAmount(calculatedTotal)}
                        className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] rounded-lg border border-emerald-200 transition"
                      >
                        Bayar Lunas (100%)
                      </button>
                      <button
                        type="button"
                        onClick={() => setDpAmount(Math.round(calculatedTotal / 2))}
                        className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-[11px] rounded-lg border border-blue-200 transition"
                      >
                        DP 50% ({fRp(Math.round(calculatedTotal / 2))})
                      </button>
                      <button
                        type="button"
                        onClick={() => setDpAmount(0)}
                        className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-[11px] rounded-lg border border-amber-200 transition"
                      >
                        Belum Bayar / Piutang Penuh (Rp 0)
                      </button>
                    </div>

                    {/* Live Recalculated Summary Card */}
                    <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-stone-500 text-[11px] block">Status Otomatis:</span>
                        <span className={`inline-block font-extrabold uppercase px-2 py-0.5 rounded text-[10px] ${
                          calculatedStatus === 'LUNAS' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {calculatedStatus}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-stone-500 text-[11px] block">Sisa Tagihan / Piutang:</span>
                        <span className="text-sm font-mono font-extrabold text-amber-600">
                          {fRp(calculatedSisa)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Data Pelanggan & Info Transaksi */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Informasi Pelanggan & Tanggal Nota
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Nama Pelanggan
                        </label>
                        <input
                          type="text"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Nama Pelanggan (misal: Umum)"
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          No. Telepon / WhatsApp
                        </label>
                        <input
                          type="text"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="08..."
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-mono font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Tanggal Transaksi
                        </label>
                        <input
                          type="text"
                          value={transactionDate}
                          onChange={(e) => setTransactionDate(e.target.value)}
                          placeholder="DD/MM/YYYY atau YYYY-MM-DD"
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-700 mb-1">
                          Kasir yang Menangani
                        </label>
                        <select
                          value={cashierName}
                          onChange={(e) => setCashierName(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                        >
                          {kasirUsers.map((u, uIdx) => (
                            <option key={`${u.nama}-${uIdx}`} value={u.nama}>{u.nama}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ITEM PESANAN & PERHITUNGAN */}
              {activeSubTab === 'items' && (
                <div className="space-y-4">
                  {/* Item List Header & Action Buttons */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-stone-200">
                    <div>
                      <h4 className="text-xs font-extrabold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                        <Package className="w-4 h-4 text-orange-600" />
                        <span>Rincian Item Nota ({items.length} Item)</span>
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Pilih barang dari katalog untuk tambah baru atau tukar barang yang salah.
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleOpenCatalogForNew}
                        className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
                      >
                        <Search className="w-3.5 h-3.5" />
                        <span>Cari di Katalog</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleAddItem()}
                        className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1 border border-stone-300 transition cursor-pointer active:scale-95"
                        title="Tambah baris kosong untuk diisi manual"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Item Manual</span>
                      </button>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="space-y-3">
                    {items.map((item, idx) => {
                      const itemTotal = computeItemTotal(item);
                      const isMeteran = item.tipeHarga === 'ukuran';

                      // Matching suggestions when typing in name input
                      const itemNameQuery = (item.nama || '').trim().toLowerCase();
                      const suggestions = itemNameQuery.length >= 2
                        ? products.filter(
                            (p) =>
                              (p.nama || '').toLowerCase().includes(itemNameQuery) ||
                              (p.kode || '').toLowerCase().includes(itemNameQuery)
                          ).slice(0, 5)
                        : [];

                      return (
                        <div key={idx} className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3 relative">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1 relative">
                              <span className="w-6 h-6 rounded-lg bg-stone-200 text-stone-800 font-extrabold text-xs flex items-center justify-center shrink-0">
                                {idx + 1}
                              </span>

                              <div className="flex-1 relative">
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="text"
                                    value={item.nama}
                                    onChange={(e) => {
                                      handleItemChange(idx, 'nama', e.target.value);
                                      setActiveSuggestIndex(idx);
                                    }}
                                    onFocus={() => setActiveSuggestIndex(idx)}
                                    placeholder="Ketik nama barang atau klik 'Tukar'..."
                                    className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                                  />
                                </div>

                                {/* Floating Suggestions Dropdown */}
                                {activeSuggestIndex === idx && suggestions.length > 0 && (
                                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-stone-200 rounded-xl shadow-xl z-30 max-h-48 overflow-y-auto divide-y divide-stone-100">
                                    <div className="p-1.5 bg-stone-100/70 text-[10px] font-bold text-stone-500 flex items-center justify-between">
                                      <span>Saran dari Katalog:</span>
                                      <button
                                        type="button"
                                        onClick={() => setActiveSuggestIndex(null)}
                                        className="text-stone-400 hover:text-stone-700"
                                      >
                                        ✕
                                      </button>
                                    </div>
                                    {suggestions.map((sug, sIdx) => (
                                      <button
                                        key={`${sug.kode}-${sIdx}`}
                                        type="button"
                                        onClick={() => {
                                          handleItemChange(idx, 'nama', sug.nama);
                                          handleItemChange(idx, 'kode', sug.kode || 'CUSTOM');
                                          handleItemChange(idx, 'harga', sug.harga || 0);
                                          handleItemChange(idx, 'satuan', sug.satuan || 'pcs');
                                          handleItemChange(idx, 'tipeHarga', sug.tipeHarga || 'fix');
                                          setActiveSuggestIndex(null);
                                          onShowToast(`✓ Memilih ${sug.nama}`, 'info');
                                        }}
                                        className="w-full p-2 text-left hover:bg-orange-50/70 flex items-center justify-between text-xs transition cursor-pointer"
                                      >
                                        <div>
                                          <div className="font-bold text-stone-900">{sug.nama}</div>
                                          <div className="text-[10px] text-stone-400">
                                            {sug.kode ? `[${sug.kode}]` : ''} {sug.kategori ? `• ${sug.kategori}` : ''}
                                          </div>
                                        </div>
                                        <div className="text-right shrink-0">
                                          <div className="font-bold font-mono text-orange-600">{fRp(sug.harga)}</div>
                                          <div className="text-[10px] text-stone-400">/{sug.satuan || 'pcs'}</div>
                                        </div>
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Action Buttons for this item */}
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleOpenCatalogForSwap(idx)}
                                className="px-2.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs rounded-xl flex items-center gap-1 border border-amber-300/80 transition cursor-pointer shadow-2xs active:scale-95"
                                title="Tukar item ini dengan produk lain dari katalog"
                              >
                                <ArrowLeftRight className="w-3.5 h-3.5 text-amber-700" />
                                <span className="hidden sm:inline">Tukar Barang</span>
                                <span className="sm:hidden">Tukar</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleDeleteItem(idx)}
                                className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer"
                                title="Hapus Item"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Dimensions & Qty */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
                            {isMeteran && (
                              <>
                                <div>
                                  <label className="block text-[10px] font-bold text-stone-500">Panjang (m)</label>
                                  <input
                                    type="text"
                                    inputMode="decimal"
                                    value={item.panjang ?? ''}
                                    onChange={(e) => {
                                      const clean = e.target.value.replace(/[^0-9.,]/g, '');
                                      handleItemChange(idx, 'panjang', clean);
                                    }}
                                    onFocus={(e) => (e.target as HTMLInputElement).select()}
                                    placeholder="1"
                                    className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono text-stone-900"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-stone-500">Lebar (m)</label>
                                  <input
                                    type="text"
                                    inputMode="decimal"
                                    value={item.lebar ?? ''}
                                    onChange={(e) => {
                                      const clean = e.target.value.replace(/[^0-9.,]/g, '');
                                      handleItemChange(idx, 'lebar', clean);
                                    }}
                                    onFocus={(e) => (e.target as HTMLInputElement).select()}
                                    placeholder="1"
                                    className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono text-stone-900"
                                  />
                                </div>
                              </>
                            )}

                            <div>
                              <label className="block text-[10px] font-bold text-stone-500">Qty ({item.satuan || 'pcs'})</label>
                              <input
                                type="text"
                                inputMode="decimal"
                                value={item.qty ?? ''}
                                onChange={(e) => {
                                  const clean = e.target.value.replace(/[^0-9.,]/g, '');
                                  handleItemChange(idx, 'qty', clean);
                                }}
                                onFocus={(e) => (e.target as HTMLInputElement).select()}
                                placeholder="1"
                                className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono font-bold text-stone-900"
                              />
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-stone-500">Harga Satuan (Rp)</label>
                              <input
                                type="text"
                                inputMode="numeric"
                                value={item.harga ?? ''}
                                onChange={(e) => {
                                  const clean = e.target.value.replace(/[^0-9]/g, '');
                                  handleItemChange(idx, 'harga', clean ? parseInt(clean, 10) : 0);
                                }}
                                onFocus={(e) => (e.target as HTMLInputElement).select()}
                                placeholder="0"
                                className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono font-bold text-stone-900"
                              />
                            </div>
                          </div>

                          <div className="pt-1">
                            <label className="block text-[10px] font-bold text-stone-600 mb-1 flex items-center gap-1">
                              <span>📁 Catatan/ Nama File Cetak:</span>
                            </label>
                            <input
                              type="text"
                              value={item.catatan || ''}
                              onChange={(e) => handleItemChange(idx, 'catatan', e.target.value)}
                              placeholder="Nama file / instruksi cetak..."
                              className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                            />
                          </div>

                          <div className="flex items-center justify-between text-xs pt-1.5 border-t border-stone-200/60">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] text-stone-400 font-medium">Subtotal Item:</span>
                              {item.kode && item.kode !== 'CUSTOM' && (
                                <span className="px-1.5 py-0.5 bg-stone-200/80 text-stone-700 font-mono text-[10px] rounded">
                                  {item.kode}
                                </span>
                              )}
                            </div>
                            <span className="font-mono font-extrabold text-stone-900">{fRp(itemTotal)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Summary Totals Calculation */}
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2 text-xs">
                    <div className="flex justify-between text-stone-600">
                      <span>Subtotal Order:</span>
                      <span className="font-mono font-bold">{fRp(calculatedSubtotal)}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1 border-t border-stone-200/60">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Diskon Nota (%)</label>
                        <input
                          type="text"
                          inputMode="decimal"
                          value={discPct === 0 ? '' : discPct}
                          onChange={(e) => {
                            const clean = e.target.value.replace(/[^0-9.,]/g, '');
                            const num = parseFloat(clean.replace(',', '.'));
                            setDiscPct(isNaN(num) ? 0 : Math.min(100, Math.max(0, num)));
                          }}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          placeholder="0"
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Pajak PPN (%)</label>
                        <input
                          type="text"
                          inputMode="decimal"
                          value={taxPct === 0 ? '' : taxPct}
                          onChange={(e) => {
                            const clean = e.target.value.replace(/[^0-9.,]/g, '');
                            const num = parseFloat(clean.replace(',', '.'));
                            setTaxPct(isNaN(num) ? 0 : Math.min(100, Math.max(0, num)));
                          }}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          placeholder="0"
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500">Potongan Nego (Rp)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={negoAmt === 0 ? '' : negoAmt}
                          onChange={(e) => {
                            const clean = e.target.value.replace(/[^0-9]/g, '');
                            setNegoAmt(clean ? parseInt(clean, 10) : 0);
                          }}
                          onFocus={(e) => (e.target as HTMLInputElement).select()}
                          placeholder="0"
                          className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-stone-200 font-extrabold text-sm text-stone-900">
                      <span>Total Akhir Nota:</span>
                      <span className="text-base font-mono text-orange-600">{fRp(calculatedTotal)}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ANGSURAN PELUNASAN (JIKA ADA) */}
              {activeSubTab === 'pelunasan' && (
                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                    Koreksi Riwayat Angsuran / Pelunasan Lanjutan
                  </h4>

                  {pelunasanHistory.map((p, pIdx) => (
                    <div key={pIdx} className="p-3 bg-stone-50 border border-stone-200 rounded-2xl space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-stone-800">Angsuran #{pIdx + 1}</span>
                        <button
                          type="button"
                          onClick={() => handleDeletePelunasan(pIdx)}
                          className="text-red-500 hover:text-red-700 text-xs font-bold"
                        >
                          Hapus Angsuran
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500">Nominal Angsuran (Rp)</label>
                          <input
                            type="text"
                            inputMode="numeric"
                            value={p.jumlahBayar === 0 ? '' : p.jumlahBayar}
                            onChange={(e) => {
                              const clean = e.target.value.replace(/[^0-9]/g, '');
                              handlePelunasanChange(pIdx, 'jumlahBayar', clean ? parseInt(clean, 10) : 0);
                            }}
                            onFocus={(e) => (e.target as HTMLInputElement).select()}
                            placeholder="0"
                            className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg font-mono font-bold"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500">Metode Angsuran</label>
                          <select
                            value={p.payMethod || 'Tunai'}
                            onChange={(e) => handlePelunasanChange(pIdx, 'payMethod', e.target.value)}
                            className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg font-bold"
                          >
                            <option value="Tunai">Tunai</option>
                            <option value="Transfer">Transfer</option>
                            <option value="QRIS">QRIS</option>
                            <option value="Debet">Debet</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* TAB 4: AUDIT LOG & ALASAN KOREKSI */}
              {activeSubTab === 'audit' && (
                <div className="space-y-4">
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-3">
                    <label className="block text-xs font-extrabold text-stone-800 uppercase tracking-wider">
                      Alasan Koreksi Transaksi <span className="text-red-500">*</span>
                    </label>

                    <div className="space-y-2">
                      {[
                        'Salah input metode pembayaran (misal: Kasir pilih Tunai padahal Transfer/QRIS)',
                        'Salah input nominal uang muka / DP',
                        'Salah pilih data pelanggan',
                        'Koreksi ukuran panjang x lebar atau kuantitas order',
                        'Lainnya (Tulis catatan khusus di bawah)',
                      ].map((reason, rIdx) => (
                        <label key={`reason-${rIdx}`} className="flex items-center gap-2 text-xs font-medium text-stone-700 cursor-pointer">
                          <input
                            type="radio"
                            name="editReasonCat"
                            checked={editReasonCategory === reason}
                            onChange={() => setEditReasonCategory(reason)}
                            className="accent-orange-600"
                          />
                          <span>{reason}</span>
                        </label>
                      ))}
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-stone-700 mb-1">
                        Catatan Tambahan Koreksi (Opsional):
                      </label>
                      <textarea
                        rows={2}
                        value={editReasonCustom}
                        onChange={(e) => setEditReasonCustom(e.target.value)}
                        placeholder="Contoh: Pelanggan meminta revisi metode bayar dari QRIS ke Tunai di tempat..."
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                      />
                    </div>
                  </div>

                  {/* History of Previous Audits */}
                  {Array.isArray(invoice.auditLogs) && invoice.auditLogs.length > 0 && (
                    <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2">
                      <h4 className="text-xs font-extrabold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
                        <History className="w-3.5 h-3.5 text-stone-500" />
                        <span>Riwayat Koreksi Sebelumnya</span>
                      </h4>
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {invoice.auditLogs.map((log, lIdx) => (
                          <div key={lIdx} className="p-2.5 bg-white border border-stone-200/70 rounded-xl text-[11px] space-y-1">
                            <div className="flex justify-between font-bold text-stone-800">
                              <span>Oleh: {log.editedBy}</span>
                              <span className="text-stone-400">{log.editedAt}</span>
                            </div>
                            <p className="text-stone-600 italic">"{log.reason}"</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Modal Bottom Footer Actions */}
            <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isSaving}
                className="py-2.5 px-4 rounded-xl border border-stone-200 text-stone-700 font-bold text-xs hover:bg-stone-100 transition"
              >
                Batal
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveCorrection}
                  disabled={isSaving}
                  className="py-2.5 px-5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-xs shadow-md flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Menyimpan Koreksi...' : 'Simpan & Sinkronkan Koreksi'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* MODAL / OVERLAY: KATALOG PRODUK & PENCARIAN BARANG */}
        {/* ---------------------------------------------------- */}
        {isCatalogModalOpen && (
          <div className="fixed inset-0 z-60 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-150">
            <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
              
              {/* Header */}
              <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold">
                    {targetSwapIndex !== null ? <ArrowLeftRight className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-stone-900">
                      {targetSwapIndex !== null 
                        ? `Tukar Barang (Item #${targetSwapIndex + 1})`
                        : 'Pilih Produk / Jasa dari Katalog'}
                    </h3>
                    <p className="text-xs text-stone-500">
                      {targetSwapIndex !== null
                        ? 'Pilih produk baru untuk menggantikan item yang ingin ditukar.'
                        : 'Klik produk yang diinginkan untuk otomatis memasukkan ke nota.'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setIsCatalogModalOpen(false);
                    setTargetSwapIndex(null);
                  }}
                  className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-xl transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Bar & Categories */}
              <div className="p-4 border-b border-stone-200 bg-white space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={catalogSearchQuery}
                    onChange={(e) => setCatalogSearchQuery(e.target.value)}
                    placeholder="Cari nama produk, kode barang, spanduk, merchandise..."
                    autoFocus
                    className="w-full pl-10 pr-10 py-2.5 bg-stone-50 border border-stone-200 rounded-2xl text-xs sm:text-sm font-bold text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:bg-white transition"
                  />
                  {catalogSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setCatalogSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600 rounded-lg"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Category Pills Filter */}
                {catalogCategories.length > 0 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
                    <button
                      type="button"
                      onClick={() => setCatalogSelectedCategory('ALL')}
                      className={`px-3 py-1 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
                        catalogSelectedCategory === 'ALL'
                          ? 'bg-orange-600 text-white shadow-2xs'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                      }`}
                    >
                      Semua ({products.length})
                    </button>

                    {catalogCategories.map((cat, cIdx) => {
                      const count = products.filter((p) => p.kategori && p.kategori.includes(cat)).length;
                      return (
                        <button
                          key={cIdx}
                          type="button"
                          onClick={() => setCatalogSelectedCategory(cat)}
                          className={`px-3 py-1 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
                            catalogSelectedCategory === cat
                              ? 'bg-orange-600 text-white shadow-2xs'
                              : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                          }`}
                        >
                          {cat} ({count})
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Product Catalog Grid / List */}
              <div className="p-4 overflow-y-auto flex-1 max-h-[55vh] space-y-2.5 bg-stone-50/50">
                {filteredCatalogProducts.length === 0 ? (
                  <div className="py-12 text-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
                      <Package className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-stone-700">Tidak ada produk yang cocok</p>
                      <p className="text-[11px] text-stone-400">
                        Coba kata kunci lain atau tambahkan sebagai item manual.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        handleAddItem();
                        setIsCatalogModalOpen(false);
                        setTargetSwapIndex(null);
                      }}
                      className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition cursor-pointer"
                    >
                      + Tambah Item Manual Saja
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {filteredCatalogProducts.map((prod, pIdx) => {
                      const isMeteran = prod.tipeHarga === 'ukuran';

                      return (
                        <div
                          key={`${prod.kode || 'prod'}-${pIdx}`}
                          onClick={() => handleSelectProduct(prod)}
                          className="p-3.5 bg-white border border-stone-200 hover:border-orange-500/60 hover:shadow-md rounded-2xl flex flex-col justify-between gap-3 transition cursor-pointer group active:scale-[0.99]"
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <span className="font-extrabold text-xs sm:text-sm text-stone-900 group-hover:text-orange-600 transition leading-snug line-clamp-2">
                                {prod.nama}
                              </span>
                              {isMeteran ? (
                                <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 font-bold text-[10px] rounded-lg shrink-0 border border-blue-100">
                                  Meteran
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 bg-stone-100 text-stone-600 font-bold text-[10px] rounded-lg shrink-0">
                                  Satuan
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-stone-400">
                              {prod.kode && (
                                <span className="px-1.5 py-0.5 bg-stone-100 font-mono text-stone-600 rounded">
                                  {prod.kode}
                                </span>
                              )}
                              {prod.kategori && (
                                <span className="text-stone-500 font-medium">
                                  • {prod.kategori}
                                </span>
                              )}
                              {prod.stok !== undefined && prod.stok !== '' && (
                                <span className="text-stone-400">
                                  • Stok: {prod.stok}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-stone-100">
                            <div>
                              <div className="text-[10px] text-stone-400">Harga Jual:</div>
                              <div className="font-mono font-extrabold text-xs sm:text-sm text-orange-600">
                                {fRp(prod.harga)}
                                <span className="text-[10px] font-normal text-stone-400">/{prod.satuan || (isMeteran ? 'm²' : 'pcs')}</span>
                              </div>
                            </div>

                            <button
                              type="button"
                              className="px-2.5 py-1.5 bg-orange-50 group-hover:bg-orange-600 text-orange-600 group-hover:text-white font-bold text-xs rounded-xl transition flex items-center gap-1"
                            >
                              {targetSwapIndex !== null ? (
                                <>
                                  <ArrowLeftRight className="w-3 h-3" />
                                  <span>Tukar</span>
                                </>
                              ) : (
                                <>
                                  <Check className="w-3 h-3" />
                                  <span>Pilih</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-3.5 bg-stone-50 border-t border-stone-200 flex items-center justify-between text-xs">
                <span className="text-stone-500 text-[11px]">
                  Menampilkan <strong>{filteredCatalogProducts.length}</strong> produk
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsCatalogModalOpen(false);
                    setTargetSwapIndex(null);
                  }}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-700 font-bold rounded-xl transition cursor-pointer"
                >
                  Tutup
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
