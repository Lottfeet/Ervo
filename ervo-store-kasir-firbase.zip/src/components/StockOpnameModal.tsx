import React, { useState, useMemo } from 'react';
import { Product, KasirUser, StockOpnameRecord, StockOpnameItem, StoreSettings } from '../types';
import { fRp, checkIsSpvOrOwner } from '../utils/formatters';
import { saveStockOpnameFirebase } from '../services/firebaseService';
import { addStockOpnameRecord } from '../services/gasService';
import { generateStockOpnamePdf, generateStockOpnameWorksheetPdf } from '../utils/pdfGenerator';
import { 
  X, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Lock, 
  RotateCcw, 
  FileSpreadsheet, 
  Check, 
  HelpCircle,
  ClipboardCheck,
  Building2,
  Tag,
  Calendar,
  Clock,
  Save,
  Sparkles,
  ArrowRight,
  History,
  TrendingDown,
  Layers,
  Info,
  Printer,
  FileDown,
  FileText,
  ChevronDown
} from 'lucide-react';

export interface StockOpnameModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  currentCashier?: string;
  currentUser?: string;
  kasirUsers: KasirUser[];
  settings?: StoreSettings;
  initialDraft?: StockOpnameRecord | null;
  onSuccess?: (record: StockOpnameRecord) => void;
  onOpnameSaved?: (record: StockOpnameRecord) => void;
  onShowToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const ALASAN_OPTIONS = [
  'Rusak / Cacat Cetak (Waste)',
  'Hilang / Tidak Ditemukan',
  'Salah Input Transaksi Kasir',
  'Sampel Toko / Display',
  'Bonus / Pembulatan Supplier',
  'Kadaluarsa / Rusak Lembab',
  'Lain-lain',
];

// Stable, collision-free unique key generator for products and audit items
const getItemKey = (item: { kode?: string; nama?: string; itemKey?: string }, fallbackIdx?: number): string => {
  if (item.itemKey) return item.itemKey;
  const k = (item.kode || '').trim();
  if (k && k !== 'NO-KODE') return `K_${k}`;
  const n = (item.nama || '').trim().toLowerCase();
  if (n) return `N_${n}`;
  return `IDX_${fallbackIdx ?? 0}`;
};

export const StockOpnameModal: React.FC<StockOpnameModalProps> = ({
  isOpen,
  onClose,
  products,
  currentCashier,
  currentUser,
  kasirUsers,
  settings,
  initialDraft,
  onSuccess,
  onOpnameSaved,
  onShowToast,
}) => {
  if (!isOpen) return null;

  const activeCashier = currentCashier || currentUser || 'Admin';

  const showToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    if (typeof onShowToast === 'function') {
      onShowToast(msg, type);
    } else {
      console.log(`[Toast ${type}] ${msg}`);
    }
  };

  const now = new Date();
  const todayDateStr = now.toISOString().split('T')[0];
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  // Sesi metadata
  const isContinuingDraft = Boolean(initialDraft && initialDraft.status === 'DRAFT');
  const [sessionId] = useState<string>(() => {
    if (initialDraft?.id) return initialDraft.id;
    const datePart = todayDateStr.replace(/-/g, '');
    const randomSeq = Math.floor(100 + Math.random() * 900);
    return `OPN-${datePart}-${randomSeq}`;
  });

  const [sessionStartDate, setSessionStartDate] = useState<string>(initialDraft?.tanggal || todayDateStr);
  const [sessionStartTime, setSessionStartTime] = useState<string>(initialDraft?.jam || timeStr);
  const [catatanUmum, setCatatanUmum] = useState<string>(initialDraft?.catatanUmum || '');

  // Mode Penyesuaian: DELTA (default) vs REPLACE
  const [metodePenyesuaian, setMetodePenyesuaian] = useState<'DELTA' | 'REPLACE'>(
    initialDraft?.metodePenyesuaian || 'DELTA'
  );

  // Baseline System Stock map: unique itemKey -> system stock at time item was counted
  const [baselineSystemStocks, setBaselineSystemStocks] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        const key = getItemKey(it, idx);
        const wasCounted = Boolean(it.isEditedInDraft || it.countedAt);
        if (wasCounted) {
          init[key] = it.stokSistem;
        } else {
          // Uncounted item: dynamically sync with current live system stock
          const currentProd = products.find((p, pIdx) => getItemKey(p, pIdx) === key);
          const sysVal = currentProd ? parseFloat(String(currentProd.stok || '0')) : it.stokSistem;
          init[key] = isNaN(sysVal) ? 0 : sysVal;
        }
      });
    } else {
      products.forEach((p, idx) => {
        const sysVal = parseFloat(String(p.stok || '0'));
        const key = getItemKey(p, idx);
        init[key] = isNaN(sysVal) ? 0 : sysVal;
      });
    }
    return init;
  });

  // Physical count state map: unique itemKey -> physical count
  const [physicalCounts, setPhysicalCounts] = useState<Record<string, number | string>>(() => {
    const init: Record<string, number | string> = {};
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        const key = getItemKey(it, idx);
        const wasCounted = Boolean(it.isEditedInDraft || it.countedAt);
        init[key] = wasCounted ? it.stokFisik : 0;
      });
    } else {
      products.forEach((p, idx) => {
        const key = getItemKey(p, idx);
        init[key] = 0;
      });
    }
    return init;
  });

  // Timestamp when item was counted
  const [countedTimestamps, setCountedTimestamps] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        if (it.countedAt) {
          const key = getItemKey(it, idx);
          init[key] = it.countedAt;
        }
      });
    }
    return init;
  });

  // Items explicitly touched / counted by user
  const [touchedCodes, setTouchedCodes] = useState<Set<string>>(() => {
    const s = new Set<string>();
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        if (it.countedAt || (it.isEditedInDraft && it.stokFisik > 0)) {
          s.add(getItemKey(it, idx));
        }
      });
    }
    return s;
  });

  // Discrepancy reasons & custom notes map
  const [reasons, setReasons] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        if (it.alasan) init[getItemKey(it, idx)] = it.alasan;
      });
    }
    return init;
  });

  const [notes, setNotes] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    if (initialDraft?.items) {
      initialDraft.items.forEach((it, idx) => {
        if (it.catatan) init[getItemKey(it, idx)] = it.catatan;
      });
    }
    return init;
  });

  // SPV Authorization state (Only needed for finalization, NOT for draft)
  const isCurrentKasirSpv = checkIsSpvOrOwner(activeCashier, kasirUsers);
  const [authorizedSpvUser, setAuthorizedSpvUser] = useState<string>(() => {
    if (initialDraft?.authorizedBy) return initialDraft.authorizedBy;
    if (isCurrentKasirSpv) return activeCashier;
    const spv = kasirUsers.find((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
    return spv ? spv.nama : 'Owner';
  });
  const [spvPin, setSpvPin] = useState<string>('');
  const [spvError, setSpvError] = useState<string | null>(null);

  // Filters state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [showOnlyDiff, setShowOnlyDiff] = useState<boolean>(false);
  const [showOnlyInterimSales, setShowOnlyInterimSales] = useState<boolean>(false);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSavingDraft, setIsSavingDraft] = useState<boolean>(false);
  const [isPdfMenuOpen, setIsPdfMenuOpen] = useState<boolean>(false);
  const [isFooterPdfMenuOpen, setIsFooterPdfMenuOpen] = useState<boolean>(false);

  // Unique categories list for filter pills
  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.kategori && p.kategori.trim()) set.add(p.kategori.trim());
    });
    return ['ALL', ...Array.from(set).sort()];
  }, [products]);

  // Compute items list with delta adjustments and interim sales
  const evaluatedItems = useMemo(() => {
    return products.map((p, pIdx) => {
      const itemKey = getItemKey(p, pIdx);
      const currentSysStock = parseFloat(String(p.stok || '0'));
      const safeSysStock = isNaN(currentSysStock) ? 0 : currentSysStock;
      
      const isCounted = touchedCodes.has(itemKey) || Boolean(countedTimestamps[itemKey]);

      // If item was never counted yet, baseline is ALWAYS the live system stock!
      const baselineStock = isCounted && baselineSystemStocks[itemKey] !== undefined
        ? baselineSystemStocks[itemKey]
        : safeSysStock;

      const rawFisik = physicalCounts[itemKey];
      const parsedFisik = typeof rawFisik === 'number' ? rawFisik : parseFloat(String(rawFisik || '0').replace(',', '.'));
      const fisik = isNaN(parsedFisik) ? 0 : parsedFisik;

      // Delta: Fisik - Baseline saat dihitung
      const selisihDelta = Math.round((fisik - baselineStock) * 100) / 100;

      // Interim sales: only relevant if item was counted and subsequent system stock decreased
      const interimSales = isCounted
        ? Math.max(0, Math.round((baselineStock - safeSysStock) * 100) / 100)
        : 0;

      // Final stock that will be saved to products if approved
      const stokPenyesuaianAkhir = metodePenyesuaian === 'DELTA'
        ? Math.max(0, Math.round((safeSysStock + selisihDelta) * 100) / 100)
        : fisik;

      const harga = Number(p.harga || 0);
      const selisihNilaiRp = selisihDelta * harga;
      const alasan = reasons[itemKey] || (selisihDelta !== 0 ? ALASAN_OPTIONS[0] : 'Sesuai');
      const catatan = notes[itemKey] || '';
      const countedAt = countedTimestamps[itemKey] || (isCounted ? `${sessionStartDate} ${sessionStartTime}` : undefined);

      return {
        itemKey,
        kode: p.kode,
        nama: p.nama,
        kategori: p.kategori || 'Lainnya',
        satuan: p.satuan || 'pcs',
        stokSistem: baselineStock, // Baseline saat dihitung
        stokFisik: fisik,
        selisih: selisihDelta,
        hargaSatuan: harga,
        selisihNilaiRp,
        alasan,
        catatan,
        countedAt,
        stokSistemTerkini: safeSysStock,
        penjualanInterim: interimSales,
        stokPenyesuaianAkhir,
        isEditedInDraft: isCounted,
      };
    });
  }, [products, baselineSystemStocks, physicalCounts, countedTimestamps, touchedCodes, reasons, notes, metodePenyesuaian, sessionStartDate, sessionStartTime]);

  // Filtered items based on search, category, and toggles
  const displayedItems = useMemo(() => {
    return evaluatedItems.filter((item) => {
      if (selectedCategory !== 'ALL' && item.kategori !== selectedCategory) return false;
      if (showOnlyDiff && item.selisih === 0) return false;
      if (showOnlyInterimSales && (item.penjualanInterim || 0) <= 0) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchNama = item.nama.toLowerCase().includes(q);
        const matchKode = item.kode.toLowerCase().includes(q);
        const matchKat = item.kategori.toLowerCase().includes(q);
        if (!matchNama && !matchKode && !matchKat) return false;
      }
      return true;
    });
  }, [evaluatedItems, selectedCategory, showOnlyDiff, showOnlyInterimSales, searchQuery]);

  // Summary statistics
  const summaryStats = useMemo(() => {
    const totalItems = evaluatedItems.length;
    const diffItems = evaluatedItems.filter((it) => it.selisih !== 0);
    const matchItems = evaluatedItems.filter((it) => it.selisih === 0);
    const interimItems = evaluatedItems.filter((it) => (it.penjualanInterim || 0) > 0);
    const countedCount = evaluatedItems.filter((it) => it.isEditedInDraft).length;

    let kurangQty = 0;
    let lebihQty = 0;
    let totalNominalRp = 0;
    let totalInterimQty = 0;

    diffItems.forEach((it) => {
      if (it.selisih < 0) kurangQty += Math.abs(it.selisih);
      else if (it.selisih > 0) lebihQty += it.selisih;
      totalNominalRp += it.selisihNilaiRp;
    });

    interimItems.forEach((it) => {
      totalInterimQty += (it.penjualanInterim || 0);
    });

    return {
      totalItems,
      countedCount,
      diffCount: diffItems.length,
      matchCount: matchItems.length,
      interimCount: interimItems.length,
      totalInterimQty: Math.round(totalInterimQty * 100) / 100,
      kurangQty: Math.round(kurangQty * 100) / 100,
      lebihQty: Math.round(lebihQty * 100) / 100,
      totalNominalRp: Math.round(totalNominalRp),
    };
  }, [evaluatedItems]);

  // Update physical count for single product
  const handleCountChange = (itemKey: string, valStr: string) => {
    const nowTs = new Date();
    const tsFormatted = `${String(nowTs.getDate()).padStart(2, '0')}/${String(nowTs.getMonth() + 1).padStart(2, '0')} ${String(nowTs.getHours()).padStart(2, '0')}:${String(nowTs.getMinutes()).padStart(2, '0')}`;

    setPhysicalCounts((prev) => ({ ...prev, [itemKey]: valStr }));
    setCountedTimestamps((prev) => ({ ...prev, [itemKey]: tsFormatted }));
    setTouchedCodes((prev) => new Set(prev).add(itemKey));

    // Fix baseline to current system stock if not set yet
    setBaselineSystemStocks((prev) => {
      if (prev[itemKey] !== undefined) return prev;
      const currentProd = products.find((pr, prIdx) => getItemKey(pr, prIdx) === itemKey);
      const curStock = parseFloat(String(currentProd?.stok || '0').replace(',', '.'));
      return { ...prev, [itemKey]: isNaN(curStock) ? 0 : curStock };
    });
  };

  // Reset item physical count to 0 (kembali belum dihitung)
  const handleResetSingleItem = (itemKey: string) => {
    setPhysicalCounts((prev) => ({ ...prev, [itemKey]: 0 }));
    setTouchedCodes((prev) => {
      const next = new Set(prev);
      next.delete(itemKey);
      return next;
    });
    setCountedTimestamps((prev) => {
      const next = { ...prev };
      delete next[itemKey];
      return next;
    });
    setReasons((prev) => {
      const next = { ...prev };
      delete next[itemKey];
      return next;
    });
    setNotes((prev) => {
      const next = { ...prev };
      delete next[itemKey];
      return next;
    });
  };

  // Quick reset all physical counts to 0 (default untuk penghitungan lapangan awal)
  const handleResetAllToZero = () => {
    if (!window.confirm('Reset semua kuantiti fisik lapangan ke 0 untuk memulai proses penghitungan?')) return;
    const resetCounts: Record<string, number> = {};
    products.forEach((p, idx) => {
      resetCounts[getItemKey(p, idx)] = 0;
    });
    setPhysicalCounts(resetCounts);
    setTouchedCodes(new Set());
    setCountedTimestamps({});
    setReasons({});
    setNotes({});
    showToast('Semua nilai fisik lapangan disetel ke 0', 'info');
  };

  // Quick reset all to system stock (opsional)
  const handleResetAllToSystem = () => {
    if (!window.confirm('Set semua kuantiti fisik sesuai nilai stok sistem saat ini?')) return;
    const resetCounts: Record<string, number> = {};
    const resetBaselines: Record<string, number> = {};
    products.forEach((p, idx) => {
      const key = getItemKey(p, idx);
      const sysVal = parseFloat(String(p.stok || '0'));
      const safeVal = isNaN(sysVal) ? 0 : sysVal;
      resetCounts[key] = safeVal;
      resetBaselines[key] = safeVal;
    });
    setPhysicalCounts(resetCounts);
    setBaselineSystemStocks(resetBaselines);
    setTouchedCodes(new Set());
    setCountedTimestamps({});
    setReasons({});
    setNotes({});
    showToast('Semua nilai fisik disesuaikan dengan stok sistem terkini', 'info');
  };

  // Cetak Dokumen PDF Laporan / Berita Acara Sesi Saat Ini
  const handlePrintSessionReportPdf = () => {
    try {
      const currentRecord: StockOpnameRecord = {
        id: sessionId,
        tanggal: sessionStartDate,
        jam: sessionStartTime,
        tanggalSelesai: todayDateStr,
        jamSelesai: timeStr,
        pjKasir: activeCashier,
        authorizedBy: isContinuingDraft ? 'Belum Disahkan (Draf)' : (authorizedSpvUser || 'Supervisor / SPV'),
        catatanUmum: catatanUmum.trim(),
        totalItemDiperiksa: summaryStats.totalItems,
        totalItemSelisih: summaryStats.diffCount,
        totalSelisihKurangQty: summaryStats.kurangQty,
        totalSelisihLebihQty: summaryStats.lebihQty,
        totalSelisihNominalRp: summaryStats.totalNominalRp,
        totalPenjualanInterimQty: summaryStats.totalInterimQty,
        metodePenyesuaian,
        items: evaluatedItems,
        status: 'DRAFT',
      };

      generateStockOpnamePdf(currentRecord, settings);
      setIsPdfMenuOpen(false);
      showToast(`Dokumen PDF Sesi #${sessionId} berhasil diunduh!`, 'success');
    } catch (err: any) {
      console.error('PDF error:', err);
      showToast('Gagal mencetak PDF: ' + (err?.message || 'Error'), 'error');
    }
  };

  // Cetak Lembar Kerja Blangko Fisik Lapangan (Worksheet PDF)
  const handlePrintWorksheetPdf = () => {
    try {
      // Gunakan item terfilter bila sedang memfilter kategori, atau seluruh item
      const targetItems = displayedItems.length > 0 ? displayedItems : evaluatedItems;
      const itemsForWorksheet = targetItems.map((it) => ({
        kode: it.kode,
        nama: it.nama,
        kategori: it.kategori,
        satuan: it.satuan,
        stokSistem: it.stokSistem,
        stokFisik: it.stokFisik,
      }));

      generateStockOpnameWorksheetPdf(
        itemsForWorksheet,
        {
          sessionId,
          tanggal: sessionStartDate,
          jam: sessionStartTime,
          pjKasir: activeCashier,
          catatan: catatanUmum,
          kategoriFilter: selectedCategory,
        },
        settings
      );
      setIsPdfMenuOpen(false);
      showToast(`Lembar Kerja Fisik Lapangan #${sessionId} berhasil diunduh (PDF)!`, 'success');
    } catch (err: any) {
      console.error('Worksheet PDF error:', err);
      showToast('Gagal mencetak Lembar Kerja: ' + (err?.message || 'Error'), 'error');
    }
  };

  // 1. Simpan Draf Sesi (Bisa dicicil berhari-hari tanpa perlu otorisasi SPV)
  const handleSaveDraft = async () => {
    setIsSavingDraft(true);
    try {
      const opnameRecord: StockOpnameRecord = {
        id: sessionId,
        tanggal: sessionStartDate,
        jam: sessionStartTime,
        pjKasir: activeCashier,
        authorizedBy: 'Belum Disahkan (Draf)',
        catatanUmum: catatanUmum.trim(),
        totalItemDiperiksa: summaryStats.totalItems,
        totalItemSelisih: summaryStats.diffCount,
        totalSelisihKurangQty: summaryStats.kurangQty,
        totalSelisihLebihQty: summaryStats.lebihQty,
        totalSelisihNominalRp: summaryStats.totalNominalRp,
        totalPenjualanInterimQty: summaryStats.totalInterimQty,
        metodePenyesuaian,
        items: evaluatedItems,
        status: 'DRAFT',
      };

      // Save to Firebase & local storage WITHOUT altering products collection
      await saveStockOpnameFirebase(opnameRecord).catch((err) => {
        console.warn('Firebase save draft warning:', err);
      });
      await addStockOpnameRecord(opnameRecord).catch((err) => {
        console.warn('GAS save draft warning:', err);
      });

      if (onOpnameSaved) onOpnameSaved(opnameRecord);
      if (onSuccess) onSuccess(opnameRecord);

      showToast(`✓ Draf Sesi Opname #${sessionId} berhasil disimpan! Anda dapat melanjutkannya kapan saja.`, 'success');
      onClose();
    } catch (err: any) {
      console.error('Failed to save stock opname draft:', err);
      showToast('Gagal menyimpan draf: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsSavingDraft(false);
    }
  };

  // 2. Sahkan & Sesuaikan Stok (Otorisasi SPV/Owner setelah seluruh opname selesai)
  const handleFinalizeAndApprove = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate SPV Authorization
    if (!isCurrentKasirSpv) {
      if (!authorizedSpvUser) {
        setSpvError('Pilih akun Supervisor atau Owner untuk pengesahan');
        return;
      }

      if (!checkIsSpvOrOwner(authorizedSpvUser, kasirUsers) && authorizedSpvUser.toLowerCase() !== 'owner' && authorizedSpvUser.toLowerCase() !== 'spv') {
        setSpvError(`Akses Ditolak: Akun "${authorizedSpvUser}" bukan Supervisor atau Owner!`);
        return;
      }

      if (!spvPin.trim()) {
        setSpvError('Wajib memasukkan Password / PIN Supervisor atau Owner untuk pengesahan');
        return;
      }
      const targetUser = kasirUsers.find((u) => u.nama.trim().toLowerCase() === authorizedSpvUser.trim().toLowerCase());
      const expectedPass = targetUser?.password?.trim() || 'ervo123';
      if (expectedPass !== spvPin.trim()) {
        setSpvError('Password / PIN Supervisor tidak valid');
        return;
      }
    }

    if (evaluatedItems.length === 0) {
      showToast('Tidak ada produk untuk disahkan', 'error');
      return;
    }

    // Confirmation if interim sales were detected
    if (summaryStats.totalInterimQty > 0 && metodePenyesuaian === 'DELTA') {
      const confirmMsg = `Pemberitahuan Penyesuaian Delta:\n\nSelama sesi audit berlangsung, terdeteksi ${summaryStats.totalInterimQty} unit penjualan kasir pada ${summaryStats.interimCount} barang.\n\nSistem akan menerapkan Metode Delta (Stok Akhir = Stok Terkini + Selisih Relatif), sehingga transaksi kasir toko tidak akan hilang.\n\nLanjutkan pengesahan stok?`;
      if (!window.confirm(confirmMsg)) return;
    }

    setIsSubmitting(true);
    setSpvError(null);

    try {
      const finishDate = todayDateStr;
      const finishTime = timeStr;

      const finalRecord: StockOpnameRecord = {
        id: sessionId,
        tanggal: sessionStartDate,
        jam: sessionStartTime,
        tanggalSelesai: finishDate,
        jamSelesai: finishTime,
        pjKasir: activeCashier,
        authorizedBy: authorizedSpvUser || 'Supervisor',
        catatanUmum: catatanUmum.trim(),
        totalItemDiperiksa: summaryStats.totalItems,
        totalItemSelisih: summaryStats.diffCount,
        totalSelisihKurangQty: summaryStats.kurangQty,
        totalSelisihLebihQty: summaryStats.lebihQty,
        totalSelisihNominalRp: summaryStats.totalNominalRp,
        totalPenjualanInterimQty: summaryStats.totalInterimQty,
        metodePenyesuaian,
        items: evaluatedItems,
        status: 'APPROVED',
      };

      // 1. Save to Firebase Firestore & sync products collection
      await saveStockOpnameFirebase(finalRecord).catch((err) => {
        console.warn('Firebase saveStockOpname warning:', err);
      });

      // 2. Save to local storage & GAS Sheets
      await addStockOpnameRecord(finalRecord).catch((err) => {
        console.warn('GAS addStockOpnameRecord warning:', err);
      });

      if (onOpnameSaved) onOpnameSaved(finalRecord);
      if (onSuccess) onSuccess(finalRecord);

      showToast(`✓ Berita Acara #${sessionId} resmi disahkan! Stok master berhasil disinkronkan.`, 'success');
      onClose();
    } catch (err: any) {
      console.error('Failed to finalize stock opname:', err);
      showToast('Gagal mengesahkan Stok Opname: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white border border-stone-200 rounded-3xl w-full max-w-6xl h-[94vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="px-5 py-3.5 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-600 text-white rounded-xl shadow-xs">
              <ClipboardCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-extrabold text-base sm:text-lg tracking-tight">
                  {isContinuingDraft ? `Melanjutkan Sesi Draf #${sessionId}` : 'Sesi Baru Audit Stok Opname'}
                </h2>
                <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                  isContinuingDraft 
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' 
                    : 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                }`}>
                  {isContinuingDraft ? 'Sesi Multi-Hari (Draf)' : 'Audit Inventaris'}
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Pencocokan stok fisik dengan database. Didukung metode <b>Koreksi Delta</b> agar penjualan selama masa opname tetap akurat.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* PDF Dropdown Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsPdfMenuOpen(!isPdfMenuOpen)}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer"
                title="Pilihan Cetak PDF Sesi Stok Opname"
              >
                <Printer className="w-3.5 h-3.5 text-orange-400" />
                <span className="hidden sm:inline">Cetak PDF</span>
                <ChevronDown className="w-3 h-3 text-stone-400" />
              </button>

              {isPdfMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-stone-200 p-2 z-50 text-stone-800 animate-fadeIn"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-3 py-2 border-b border-stone-100">
                    <span className="text-xs font-black text-stone-900 block">Pilihan Cetak Dokumen PDF</span>
                    <span className="text-[10px] text-stone-500 block">Sesi #{sessionId}</span>
                  </div>

                  <div className="py-1 space-y-1">
                    <button
                      type="button"
                      onClick={handlePrintSessionReportPdf}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-orange-50 text-stone-800 hover:text-orange-950 transition flex items-start gap-2.5 group cursor-pointer"
                    >
                      <div className="p-1.5 bg-orange-100 text-orange-700 rounded-lg group-hover:bg-orange-600 group-hover:text-white transition shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-stone-900">Berita Acara / Laporan Sesi</div>
                        <div className="text-[10px] text-stone-500">Rincian stok sistem, hasil fisik terkini, delta selisih, & estimasi nominal Rp.</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={handlePrintWorksheetPdf}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-blue-50 text-stone-800 hover:text-blue-950 transition flex items-start gap-2.5 group cursor-pointer"
                    >
                      <div className="p-1.5 bg-blue-100 text-blue-700 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition shrink-0 mt-0.5">
                        <Printer className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-stone-900">Lembar Kerja Blangko Fisik</div>
                        <div className="text-[10px] text-stone-500">Formulir kertas berkolom kosong untuk dibawa tim ke rak/gudang & ditulis tangan.</div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-white hover:bg-stone-800 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Top Session Metadata Row */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-stone-50 border border-stone-200/80 p-3.5 rounded-2xl">
            <div>
              <label className="text-[11px] font-extrabold text-stone-600 block mb-1">
                No. Berita Acara / Sesi
              </label>
              <input
                type="text"
                disabled
                value={`#${sessionId}`}
                className="w-full px-3 py-1.5 text-xs font-mono font-bold bg-stone-100 border border-stone-200 text-stone-800 rounded-xl"
              />
            </div>

            <div>
              <label className="text-[11px] font-extrabold text-stone-600 block mb-1">
                Tanggal Mulai Sesi
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={sessionStartDate}
                  onChange={(e) => setSessionStartDate(e.target.value)}
                  className="w-2/3 px-3 py-1.5 text-xs font-bold bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <input
                  type="time"
                  value={sessionStartTime}
                  onChange={(e) => setSessionStartTime(e.target.value)}
                  className="w-1/3 px-2 py-1.5 text-xs font-bold bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-extrabold text-stone-600 block mb-1">
                Petugas Pemeriksa
              </label>
              <input
                type="text"
                disabled
                value={`${activeCashier} (Staff Lapangan)`}
                className="w-full px-3 py-1.5 text-xs font-bold bg-stone-100 border border-stone-200 text-stone-700 rounded-xl cursor-not-allowed"
              />
            </div>

            <div>
              <label className="text-[11px] font-extrabold text-stone-600 block mb-1">
                Catatan Sesi (Opsional)
              </label>
              <input
                type="text"
                value={catatanUmum}
                onChange={(e) => setCatatanUmum(e.target.value)}
                placeholder="Contoh: Audit cicil rak banner & kertas..."
                className="w-full px-3 py-1.5 text-xs font-medium bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          {/* Explanation Callout for Multi-Day Stock Opname & Delta Formula */}
          <div className="bg-gradient-to-r from-blue-50/80 via-indigo-50/70 to-purple-50/60 border border-blue-200 rounded-2xl p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-600 text-white rounded-xl shrink-0 mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-extrabold text-blue-950 flex items-center gap-1.5">
                    <span>Penyesuaian Otomatis Opname Multi-Hari (Delta Adjustment)</span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
                      SOP Inventaris
                    </span>
                  </h3>
                  <p className="text-xs text-blue-900/80 mt-1 leading-relaxed">
                    Opname yang berlangsung 2–3 hari <b>tidak akan menimpa/menghilangkan transaksi kasir</b>. Sistem menghitung selisih saat barang diperiksa, lalu menyesuaikannya dengan sisa stok terkini saat SPV mengesahkan:
                  </p>
                  <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 bg-white/90 border border-blue-200 rounded-xl text-[11px] font-mono text-blue-950 font-bold">
                    <span>Stok Disahkan = Stok Terkini (Hari ke-3) + Selisih Delta</span>
                  </div>
                </div>
              </div>

              {/* Mode Switch Toggle */}
              <div className="bg-white/80 border border-blue-200/80 rounded-xl p-2 shrink-0 flex flex-col gap-1.5">
                <span className="text-[10px] font-extrabold text-stone-600 uppercase tracking-wider">
                  Metode Penyesuaian:
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setMetodePenyesuaian('DELTA')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                      metodePenyesuaian === 'DELTA'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                    }`}
                  >
                    <Check className="w-3 h-3" />
                    <span>Metode Delta (Rekomendasi)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMetodePenyesuaian('REPLACE')}
                    title="Hanya jika toko tutup / tidak ada penjualan selama opname"
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                      metodePenyesuaian === 'REPLACE'
                        ? 'bg-stone-800 text-white shadow-xs'
                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                    }`}
                  >
                    <span>Timpa Fisik Statis</span>
                  </button>
                </div>
              </div>
            </div>

            {/* If interim sales are detected, show interactive warning */}
            {summaryStats.totalInterimQty > 0 && (
              <div className="mt-3.5 pt-3 border-t border-blue-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-bold text-amber-900 bg-amber-50/80 border-amber-200 p-2.5 rounded-xl">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    Terdeteksi <b>{summaryStats.totalInterimQty} unit</b> penjualan kasir pada <b>{summaryStats.interimCount} produk</b> sejak fisik dicatat.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowOnlyInterimSales(!showOnlyInterimSales)}
                  className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-[11px] font-extrabold transition shrink-0"
                >
                  {showOnlyInterimSales ? 'Tampilkan Semua Barang' : 'Filter Barang Terjual'}
                </button>
              </div>
            )}
          </div>

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-stone-100 border border-stone-200/90 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-stone-500 uppercase tracking-wider block">Total Produk Dicek</span>
              <span className="text-base sm:text-lg font-black text-stone-900 block">{summaryStats.totalItems} Produk</span>
              <span className="text-[10px] font-bold text-emerald-600">
                {summaryStats.countedCount} / {summaryStats.totalItems} Selesai Dihitung
              </span>
            </div>

            <div className="bg-red-50 border border-red-200/90 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-red-700 uppercase tracking-wider block">Produk Berselisih</span>
              <span className="text-base sm:text-lg font-black text-red-950 block">{summaryStats.diffCount} Produk</span>
              <span className="text-[10px] font-bold text-red-600">Perlu Penyesuaian</span>
            </div>

            <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-amber-800 uppercase tracking-wider block">Selisih Qty & Mutasi</span>
              <span className="text-base sm:text-lg font-black text-amber-950 block">
                {summaryStats.kurangQty > 0 ? `-${summaryStats.kurangQty}` : '0'} / {summaryStats.lebihQty > 0 ? `+${summaryStats.lebihQty}` : '0'}
              </span>
              <span className="text-[10px] font-bold text-amber-700">
                {summaryStats.totalInterimQty > 0 ? `⚡ ${summaryStats.totalInterimQty} unit terjual selama sesi` : 'Kurang / Lebih'}
              </span>
            </div>

            <div className={`border rounded-2xl p-3 ${summaryStats.totalNominalRp < 0 ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
              <span className={`text-[10px] font-extrabold uppercase tracking-wider block ${summaryStats.totalNominalRp < 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                Estimasi Selisih Nilai (Rp)
              </span>
              <span className={`text-base sm:text-lg font-black block ${summaryStats.totalNominalRp < 0 ? 'text-rose-950' : 'text-emerald-950'}`}>
                {summaryStats.totalNominalRp < 0 ? `-${fRp(Math.abs(summaryStats.totalNominalRp))}` : summaryStats.totalNominalRp > 0 ? `+${fRp(summaryStats.totalNominalRp)}` : 'Rp 0'}
              </span>
              <span className={`text-[10px] font-bold ${summaryStats.totalNominalRp < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {summaryStats.totalNominalRp < 0 ? 'Potensi Selisih / Kerugian' : 'Surplus / Aset Bertambah'}
              </span>
            </div>
          </div>

          {/* Search, Category Filter, and Controls Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-1">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari nama produk, spanduk, kertas, ATK, atau kode..."
                className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {/* Quick Filter Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setShowOnlyDiff(!showOnlyDiff)}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition flex items-center gap-1.5 ${
                  showOnlyDiff
                    ? 'bg-red-600 text-white border-red-600 shadow-2xs'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Hanya Berselisih ({summaryStats.diffCount})</span>
              </button>

              <button
                type="button"
                onClick={handleResetAllToZero}
                title="Setel semua kuantiti fisik lapangan ke 0 untuk mulai penghitungan"
                className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-extrabold text-xs rounded-xl border border-stone-200 flex items-center gap-1.5 transition"
              >
                <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
                <span>Reset Fisik ke 0</span>
              </button>

              <button
                type="button"
                onClick={handleResetAllToSystem}
                title="Samakan semua nilai fisik dengan stok sistem"
                className="px-2.5 py-1.5 bg-stone-50 hover:bg-stone-100 text-stone-600 font-bold text-xs rounded-xl border border-stone-200 flex items-center gap-1 transition cursor-pointer"
              >
                <span>Samakan ke Sistem</span>
              </button>

              <div className="h-4 w-px bg-stone-300 hidden sm:block mx-0.5" />

              <button
                type="button"
                onClick={handlePrintSessionReportPdf}
                title="Cetak Dokumen Berita Acara / Laporan Hasil Hitung Sesi Ini (PDF)"
                className="px-2.5 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 font-extrabold text-xs rounded-xl border border-orange-200 flex items-center gap-1.5 transition cursor-pointer"
              >
                <FileDown className="w-3.5 h-3.5 text-orange-600" />
                <span>Cetak PDF Sesi</span>
              </button>

              <button
                type="button"
                onClick={handlePrintWorksheetPdf}
                title="Cetak Lembar Kerja Blangko Kertas Hitung Lapangan (PDF)"
                className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-extrabold text-xs rounded-xl border border-blue-200 flex items-center gap-1.5 transition cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-blue-600" />
                <span>Blangko Fisik</span>
              </button>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <span className="text-stone-400 font-bold text-[11px] shrink-0 mr-1 flex items-center gap-1">
              <Tag className="w-3 h-3" />
              <span>Kategori:</span>
            </span>
            {categories.map((cat, cIdx) => (
              <button
                key={`cat-pill-${cat}-${cIdx}`}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-stone-900 text-white shadow-2xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {cat === 'ALL' ? 'Semua Kategori' : cat}
              </button>
            ))}
          </div>

          {/* Products Table with Real-Time Delta & Interim Sales Tracking */}
          <div className="border border-stone-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto max-h-[420px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-stone-900 text-white sticky top-0 z-10 text-[11px] font-bold uppercase tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3">Produk & Status</th>
                    <th className="py-2.5 px-3 text-center">Stok Awal Hitung</th>
                    <th className="py-2.5 px-3 text-center">Fisik Lapangan</th>
                    <th className="py-2.5 px-3 text-center">Selisih Delta</th>
                    <th className="py-2.5 px-3 text-center">Penjualan Selama Opname</th>
                    <th className="py-2.5 px-3 text-center bg-stone-800">Stok Akhir Disahkan</th>
                    <th className="py-2.5 px-3">Alasan Selisih</th>
                    <th className="py-2.5 px-3">Catatan Detail</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {displayedItems.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-stone-400 text-xs">
                        Tidak ada data produk yang cocok dengan filter / pencarian.
                      </td>
                    </tr>
                  ) : (
                    displayedItems.map((item, itIdx) => {
                      const hasDiff = item.selisih !== 0;
                      const hasInterimSale = (item.penjualanInterim || 0) > 0;
                      const itemKey = item.itemKey;

                      return (
                        <tr 
                          key={`opname-item-${itemKey}-${itIdx}`} 
                          className={`transition ${
                            hasDiff ? 'bg-red-50/40 hover:bg-red-50/70' : 'hover:bg-stone-50'
                          }`}
                        >
                          {/* Nama & Kode Produk */}
                          <td className="py-2 px-3 align-middle">
                            <div className="font-extrabold text-stone-900 text-xs">{item.nama}</div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono text-[10px] text-stone-500">
                                {item.kode ? item.kode : 'NO-KODE'}
                              </span>
                              <span className="text-[10px] px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded">
                                {item.kategori}
                              </span>
                              {item.countedAt ? (
                                <span className="text-[9px] px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded font-mono font-bold flex items-center gap-0.5">
                                  <Clock className="w-2.5 h-2.5" />
                                  <span>{item.countedAt}</span>
                                </span>
                              ) : (
                                <span className="text-[9px] px-1.5 py-0.2 bg-stone-100 text-stone-500 rounded font-medium">
                                  Belum dihitung
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Stok Baseline Saat Dihitung */}
                          <td className="py-2 px-3 align-middle text-center font-mono">
                            <span className="font-extrabold text-stone-700 block text-xs">
                              {item.stokSistem} {item.satuan}
                            </span>
                            {item.stokSistemTerkini !== item.stokSistem && (
                              <span className="text-[10px] text-stone-400 block" title="Stok database saat ini">
                                Sekarang: {item.stokSistemTerkini}
                              </span>
                            )}
                          </td>

                          {/* Input Fisik Lapangan */}
                          <td className="py-2 px-3 align-middle text-center">
                            <div className="inline-flex items-center gap-1">
                              <input
                                type="text"
                                inputMode="decimal"
                                value={item.stokFisik}
                                onChange={(e) => {
                                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                                  handleCountChange(itemKey, val);
                                }}
                                onFocus={(e) => e.target.select()}
                                className="w-20 px-2 py-1 text-center font-mono font-extrabold text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-2xs"
                              />
                              <span className="text-[11px] text-stone-500 font-bold">{item.satuan}</span>
                            </div>
                          </td>

                          {/* Selisih Delta */}
                          <td className="py-2 px-3 align-middle text-center font-mono">
                            {hasDiff ? (
                              <div className="inline-block">
                                <span className={`px-2 py-0.5 rounded-full text-xs font-black ${
                                  item.selisih < 0 
                                    ? 'bg-red-100 text-red-800' 
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}>
                                  {item.selisih > 0 ? `+${item.selisih}` : item.selisih} {item.satuan}
                                </span>
                                <span className="block text-[10px] font-bold text-stone-500 mt-0.5">
                                  {item.selisihNilaiRp < 0 
                                    ? `-${fRp(Math.abs(item.selisihNilaiRp))}` 
                                    : item.selisihNilaiRp > 0 
                                    ? `+${fRp(item.selisihNilaiRp)}` 
                                    : 'Rp 0'}
                                </span>
                              </div>
                            ) : (
                              <span className="text-emerald-600 font-extrabold text-xs inline-flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" />
                                <span>Klop</span>
                              </span>
                            )}
                          </td>

                          {/* Penjualan Selama Sesi Berjalan (Interim Sales) */}
                          <td className="py-2 px-3 align-middle text-center font-mono">
                            {hasInterimSale ? (
                              <div className="inline-block bg-amber-100/80 border border-amber-300 text-amber-900 px-2 py-0.5 rounded-lg text-xs font-extrabold">
                                <span>⚡ -{item.penjualanInterim} {item.satuan}</span>
                                <span className="block text-[9px] font-medium text-amber-700">Terjual di Kasir</span>
                              </div>
                            ) : (
                              <span className="text-[11px] text-stone-400">-</span>
                            )}
                          </td>

                          {/* Stok Akhir Disahkan */}
                          <td className="py-2 px-3 align-middle text-center font-mono bg-stone-50/60">
                            <span className="text-xs font-black text-stone-900 block">
                              {item.stokPenyesuaianAkhir} {item.satuan}
                            </span>
                            {hasInterimSale && metodePenyesuaian === 'DELTA' && (
                              <span className="text-[9px] text-blue-700 font-bold block" title="Mengakomodasi penjualan">
                                ✓ Disesuaikan Delta
                              </span>
                            )}
                          </td>

                          {/* Alasan Selisih */}
                          <td className="py-2 px-3 align-middle">
                            {hasDiff ? (
                              <select
                                value={item.alasan}
                                onChange={(e) => setReasons({ ...reasons, [itemKey]: e.target.value })}
                                className="w-full px-2 py-1 bg-white border border-red-300 rounded-lg text-[11px] font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-red-500"
                              >
                                {ALASAN_OPTIONS.map((opt, oIdx) => (
                                  <option key={`opt-reason-${opt}-${oIdx}`} value={opt}>
                                    {opt}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <span className="text-stone-400 text-[11px] italic">Stok Sesuai</span>
                            )}
                          </td>

                          {/* Catatan Detail & Tombol Reset Baris */}
                          <td className="py-2 px-3 align-middle">
                            <div className="flex items-center gap-1">
                              {hasDiff ? (
                                <input
                                  type="text"
                                  value={notes[itemKey] || ''}
                                  onChange={(e) => setNotes({ ...notes, [itemKey]: e.target.value })}
                                  placeholder="Detail (cth: sisa sobekan)..."
                                  className="w-full px-2 py-1 bg-white border border-stone-200 rounded-lg text-[11px] text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
                                />
                              ) : (
                                <span className="text-stone-300">-</span>
                              )}
                              {item.isEditedInDraft && (
                                <button
                                  type="button"
                                  onClick={() => handleResetSingleItem(itemKey)}
                                  title="Reset barang ini ke stok sistem"
                                  className="p-1 text-stone-400 hover:text-red-600 hover:bg-stone-100 rounded"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Otorisasi SPV / Owner Section */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-amber-900">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <h4 className="font-extrabold text-xs uppercase tracking-wider">
                  Pengesahan Akhir: Supervisor / Owner
                </h4>
              </div>
              <span className="text-[10px] text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full font-bold">
                Wajib untuk Finalisasi & Sinkronisasi Stok
              </span>
            </div>
            <p className="text-xs text-amber-850 mb-3">
              Catatan: Tombol <b>"Simpan Draf Sesi"</b> di bawah tidak memerlukan PIN SPV (petugas kasir bisa menyimpan progres kapan saja). Otorisasi SPV di bawah ini hanya digunakan saat seluruh proses opname selesai dan siap disahkan.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-amber-900 block mb-1">
                  Pilih Supervisor / Owner:
                </label>
                <select
                  value={authorizedSpvUser}
                  onChange={(e) => {
                    setAuthorizedSpvUser(e.target.value);
                    setSpvError(null);
                  }}
                  className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, uIdx) => (
                    <option key={`spv-opt-${u.nama || 'user'}-${uIdx}`} value={u.nama}>
                      {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(Supervisor/Owner)'}
                    </option>
                  ))}
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0 && (
                    <>
                      <option key="som-spv-owner" value="Owner">Owner / Pemilik Toko</option>
                      <option key="som-spv-spv" value="SPV">Supervisor (SPV)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-amber-900 block mb-1 flex items-center justify-between">
                  <span>Password / PIN Pengesahan:</span>
                  {isCurrentKasirSpv && (
                    <span className="text-[10px] text-emerald-700 font-extrabold bg-emerald-100 px-1.5 py-0.2 rounded">
                      ✓ Anda Login sbg SPV/Owner
                    </span>
                  )}
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    disabled={isCurrentKasirSpv}
                    value={isCurrentKasirSpv ? '••••••••' : spvPin}
                    onChange={(e) => {
                      setSpvPin(e.target.value);
                      setSpvError(null);
                    }}
                    placeholder={isCurrentKasirSpv ? 'Terverifikasi otomatis' : 'Masukkan PIN/Password SPV...'}
                    className={`w-full pl-9 pr-3 py-2 text-xs font-bold rounded-xl border focus:outline-none focus:ring-2 ${
                      isCurrentKasirSpv
                        ? 'bg-emerald-50/50 border-emerald-300 text-emerald-800 cursor-not-allowed'
                        : 'bg-white border-amber-300 text-stone-900 focus:ring-amber-500'
                    }`}
                  />
                </div>
                {spvError && (
                  <p className="text-[11px] text-red-600 font-bold mt-1">
                    {spvError}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-stone-100 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-stone-600 font-medium">
            <span className="font-extrabold text-stone-900">{summaryStats.totalItems}</span> item dicek |{' '}
            <span className="font-extrabold text-red-600">{summaryStats.diffCount}</span> berselisih |{' '}
            {summaryStats.totalInterimQty > 0 && (
              <span className="text-blue-700 font-bold mr-1">
                ⚡ {summaryStats.totalInterimQty} unit terjual selama opname |{' '}
              </span>
            )}
            Estimasi selisih:{' '}
            <span className={`font-extrabold ${summaryStats.totalNominalRp < 0 ? 'text-red-700' : 'text-emerald-700'}`}>
              {summaryStats.totalNominalRp < 0 ? `-${fRp(Math.abs(summaryStats.totalNominalRp))}` : fRp(summaryStats.totalNominalRp)}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap sm:flex-nowrap">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting || isSavingDraft}
              className="px-4 py-2 bg-white hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-300 transition cursor-pointer"
            >
              Tutup
            </button>

            {/* Tombol Cetak PDF di Footer */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsFooterPdfMenuOpen(!isFooterPdfMenuOpen)}
                title="Pilihan Cetak Dokumen PDF Sesi Ini"
                className="px-3.5 py-2 bg-stone-200 hover:bg-stone-300 active:scale-95 text-stone-800 font-extrabold text-xs rounded-xl border border-stone-300 transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-orange-600" />
                <span>Cetak PDF</span>
                <ChevronDown className="w-3.5 h-3.5 text-stone-600" />
              </button>

              {isFooterPdfMenuOpen && (
                <div 
                  className="absolute bottom-full mb-2 left-0 sm:left-auto sm:right-0 w-72 bg-white rounded-2xl shadow-2xl border border-stone-200 p-2 z-50 text-stone-800 animate-fadeIn"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-3 py-2 border-b border-stone-100">
                    <span className="text-xs font-black text-stone-900 block">Pilihan Cetak Dokumen PDF</span>
                    <span className="text-[10px] text-stone-500 block">Sesi #{sessionId}</span>
                  </div>

                  <div className="py-1 space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        setIsFooterPdfMenuOpen(false);
                        handlePrintSessionReportPdf();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-orange-50 text-stone-800 hover:text-orange-950 transition flex items-start gap-2.5 group cursor-pointer"
                    >
                      <div className="p-1.5 bg-orange-100 text-orange-700 rounded-lg group-hover:bg-orange-600 group-hover:text-white transition shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-stone-900">Berita Acara / Laporan Sesi</div>
                        <div className="text-[10px] text-stone-500">Rincian stok sistem, hasil fisik, selisih delta, & nominal Rp.</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsFooterPdfMenuOpen(false);
                        handlePrintWorksheetPdf();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-blue-50 text-stone-800 hover:text-blue-950 transition flex items-start gap-2.5 group cursor-pointer"
                    >
                      <div className="p-1.5 bg-blue-100 text-blue-700 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition shrink-0 mt-0.5">
                        <Printer className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-stone-900">Lembar Kerja Blangko Fisik</div>
                        <div className="text-[10px] text-stone-500">Formulir kertas berkolom kosong untuk dibawa tim ke rak/gudang.</div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Simpan Draf Sesi (Tanpa Otorisasi SPV) */}
            <button
              type="button"
              onClick={handleSaveDraft}
              disabled={isSubmitting || isSavingDraft}
              title="Simpan data hitungan sementara tanpa mengubah stok toko"
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSavingDraft ? 'Menyimpan Draf...' : 'Simpan Draf (Lanjut Nanti)'}</span>
            </button>

            {/* Sahkan & Sinkronkan Stok (Butuh SPV) */}
            <button
              type="button"
              onClick={handleFinalizeAndApprove}
              disabled={isSubmitting || isSavingDraft}
              className="px-5 py-2 bg-orange-600 hover:bg-orange-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Memproses Opname...' : 'Sahkan & Sesuaikan Stok (SPV)'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
