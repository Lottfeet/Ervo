import React from 'react';
import { Eye, Printer, Receipt, ZoomIn, ZoomOut, RotateCcw, AlertCircle } from 'lucide-react';
import { Invoice, StoreSettings } from '../types';
import { generateThermalHTML } from '../utils/printUtils';

interface ReceiptPreviewProps {
  invoice: Partial<Invoice>;
  settings: StoreSettings;
  onPrintThermal: () => void;
  onPrintA5: () => void;
}

export const ReceiptPreview: React.FC<ReceiptPreviewProps> = ({
  invoice,
  settings,
  onPrintThermal,
  onPrintA5,
}) => {
  const [zoom, setZoom] = React.useState<number>(1);

  const htmlContent = generateThermalHTML(invoice, settings);
  const isCustomerEmpty = !invoice.customer || !invoice.customer.trim();
  const isPrintDisabled = !invoice.items || invoice.items.length === 0 || isCustomerEmpty;

  return (
    <div className="bg-white border border-stone-200 rounded-xl flex flex-col h-full min-h-0 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
        <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-stone-900">
          <Eye className="w-4 h-4 text-orange-700" />
          <span>Preview Struk Thermal (80mm)</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setZoom((z) => Math.max(0.7, z - 0.1))}
            className="p-1 text-stone-500 hover:text-stone-800 rounded hover:bg-stone-200 cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[10px] font-mono font-bold text-stone-500 w-8 text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom((z) => Math.min(1.4, z + 0.1))}
            className="p-1 text-stone-500 hover:text-stone-800 rounded hover:bg-stone-200 cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoom(1)}
            className="p-1 text-stone-500 hover:text-stone-800 rounded hover:bg-stone-200 cursor-pointer"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Paper Canvas */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4 bg-stone-200/80 flex justify-center items-start">
        <div
          style={{ transform: `scale(${zoom})`, transformOrigin: 'top center' }}
          className="transition-transform duration-150"
        >
          <div
            className="w-[302px] min-h-[350px] bg-white p-3 shadow-xl rounded-xs text-stone-900 font-mono text-[10px] leading-relaxed border border-stone-300"
            dangerouslySetInnerHTML={{ __html: htmlContent }}
          />
        </div>
      </div>

      {/* Print Controls */}
      <div className="p-3 border-t border-stone-200 bg-white space-y-2 shrink-0">
        {isCustomerEmpty && (
          <div className="p-2 bg-red-50 border border-red-200 rounded-lg text-red-700 text-[11px] font-bold flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
            <span>Nama Pelanggan / Pemesan Wajib Diisi</span>
          </div>
        )}
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={onPrintThermal}
            disabled={isPrintDisabled}
            title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Cetak Struk Thermal'}
            className="flex-1 py-2 px-3 rounded-lg bg-stone-900 hover:bg-black text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
          >
            <Receipt className="w-4 h-4 text-orange-400" />
            <span>Cetak Struk</span>
          </button>

          <button
            onClick={onPrintA5}
            disabled={isPrintDisabled}
            title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Cetak Invoice A5'}
            className="flex-1 py-2 px-3 rounded-lg bg-orange-700 hover:bg-orange-800 text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Invoice A5</span>
          </button>
        </div>
      </div>
    </div>
  );
};
