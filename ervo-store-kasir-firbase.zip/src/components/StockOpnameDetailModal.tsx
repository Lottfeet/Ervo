import React, { useState } from 'react';
import { StockOpnameRecord, StoreSettings } from '../types';
import { fRp } from '../utils/formatters';
import { generateStockOpnamePdf } from '../utils/pdfGenerator';
import { 
  X, 
  Printer, 
  Download, 
  CheckCircle2, 
  AlertTriangle, 
  Check, 
  Calendar, 
  User, 
  ShieldCheck, 
  FileText,
  Building2,
  Clock,
  Sparkles,
  Info
} from 'lucide-react';

interface StockOpnameDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: StockOpnameRecord | null;
  settings?: StoreSettings;
  onShowToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StockOpnameDetailModal: React.FC<StockOpnameDetailModalProps> = ({
  isOpen,
  onClose,
  record,
  settings,
  onShowToast,
}) => {
  if (!isOpen || !record) return null;

  const [showOnlyDiff, setShowOnlyDiff] = useState<boolean>(false);
  const [searchItemQuery, setSearchItemQuery] = useState<string>('');

  const items = record.items || [];
  const filteredItems = items.filter((item) => {
    if (showOnlyDiff && item.selisih === 0) return false;
    if (searchItemQuery.trim()) {
      const q = searchItemQuery.toLowerCase();
      const matchNama = item.nama?.toLowerCase().includes(q);
      const matchKode = item.kode?.toLowerCase().includes(q);
      const matchKat = item.kategori?.toLowerCase().includes(q);
      if (!matchNama && !matchKode && !matchKat) return false;
    }
    return true;
  });

  const handlePrintPdf = () => {
    try {
      generateStockOpnamePdf(record, settings);
      onShowToast?.(`Dokumen Berita Acara #${record.id} berhasil diunduh (PDF)`, 'success');
    } catch (err: any) {
      console.error('PDF error:', err);
      onShowToast?.('Gagal mencetak PDF: ' + (err?.message || 'Error'), 'error');
    }
  };

  const handleExportCsv = () => {
    try {
      const headers = [
        'No', 
        'Kode', 
        'Nama Produk', 
        'Kategori', 
        'Satuan', 
        'Stok Baseline', 
        'Stok Fisik', 
        'Selisih Delta', 
        'Penjualan Interim', 
        'Stok Akhir Disahkan', 
        'Alasan Selisih', 
        'Catatan Khusus', 
        'Harga Satuan (Rp)', 
        'Selisih Nilai (Rp)'
      ];
      const rows = record.items.map((it, idx) => [
        idx + 1,
        `"${it.kode || ''}"`,
        `"${it.nama || ''}"`,
        `"${it.kategori || ''}"`,
        `"${it.satuan || ''}"`,
        it.stokSistem,
        it.stokFisik,
        it.selisih,
        it.penjualanInterim || 0,
        it.stokPenyesuaianAkhir !== undefined ? it.stokPenyesuaianAkhir : it.stokFisik,
        `"${it.alasan || ''}"`,
        `"${it.catatan || ''}"`,
        it.hargaSatuan,
        it.selisihNilaiRp,
      ]);

      const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Stok_Opname_${record.id}_${record.tanggal}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      onShowToast?.(`File CSV Stok Opname #${record.id} berhasil diekspor`, 'success');
    } catch (err: any) {
      onShowToast?.('Gagal ekspor CSV: ' + (err?.message || 'Error'), 'error');
    }
  };

  const isDraft = record.status === 'DRAFT';
  const hasInterim = (record.totalPenjualanInterimQty || 0) > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white border border-stone-200 rounded-3xl w-full max-w-5xl h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-3.5 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-600/90 text-white rounded-xl shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-extrabold text-base sm:text-lg tracking-tight">
                  Berita Acara Stok Opname #{record.id}
                </h2>
                <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                  isDraft 
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' 
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}>
                  {isDraft ? '🟡 DRAF BERJALAN (BELUM DISAHKAN)' : '🟢 DISETUJUI SPV / RESMI'}
                </span>
                {record.metodePenyesuaian === 'DELTA' && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    Metode Delta
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-400">
                Dimulai: {record.tanggal} {record.jam ? `pukul ${record.jam} WIB` : ''} 
                {record.tanggalSelesai ? ` • Disahkan: ${record.tanggalSelesai} ${record.jamSelesai ? `pukul ${record.jamSelesai} WIB` : ''}` : ''}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white hover:bg-stone-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Multi-Day Delta Info Banner */}
          {hasInterim && (
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3.5 flex items-start gap-3 text-xs text-blue-950">
              <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-extrabold block">
                  Penyesuaian Transaksi Multi-Hari (Akomodasi Penjualan Kasir)
                </span>
                <p className="text-blue-900/80 mt-0.5 leading-relaxed">
                  Sesi ini berlangsung selama beberapa hari dan mencatat total <b>{record.totalPenjualanInterimQty} unit</b> penjualan kasir selama masa audit. Sistem menerapkan rumus <b>Delta (Stok Terkini + Selisih Fisik)</b> sehingga riwayat penjualan kasir toko tetap utuh dan stok akhir akurat.
                </p>
              </div>
            </div>
          )}

          {/* Metadata Card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-stone-50 border border-stone-200 rounded-2xl p-3.5 text-xs">
            <div className="flex items-start gap-2.5">
              <User className="w-4 h-4 text-stone-500 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Petugas Lapangan</span>
                <span className="font-extrabold text-stone-800">{record.pjKasir || 'Admin'}</span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Otorisasi Supervisor</span>
                <span className="font-extrabold text-emerald-800">{record.authorizedBy || 'Supervisor'}</span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Calendar className="w-4 h-4 text-stone-500 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Catatan Sesi</span>
                <span className="font-medium text-stone-700">{record.catatanUmum || '-'}</span>
              </div>
            </div>
          </div>

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-stone-100 border border-stone-200 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-stone-500 uppercase tracking-wider block">Item Diperiksa</span>
              <span className="text-base sm:text-lg font-black text-stone-900 block">{record.totalItemDiperiksa} Item</span>
              <span className="text-[10px] font-bold text-stone-500">100% Tercatat</span>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-red-700 uppercase tracking-wider block">Item Berselisih</span>
              <span className="text-base sm:text-lg font-black text-red-950 block">{record.totalItemSelisih} Item</span>
              <span className="text-[10px] font-bold text-red-600">
                {record.totalItemSelisih === 0 ? 'Semua Cocok' : 'Ada Ketidakcocokan'}
              </span>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3">
              <span className="text-[10px] font-extrabold text-amber-800 uppercase tracking-wider block">Selisih Qty & Mutasi</span>
              <span className="text-base sm:text-lg font-black text-amber-950 block">
                -{record.totalSelisihKurangQty || 0} / +{record.totalSelisihLebihQty || 0}
              </span>
              <span className="text-[10px] font-bold text-amber-700">
                {hasInterim ? `⚡ ${record.totalPenjualanInterimQty} unit terjual` : 'Kurang / Lebih'}
              </span>
            </div>

            <div className={`border rounded-2xl p-3 ${record.totalSelisihNominalRp < 0 ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
              <span className={`text-[10px] font-extrabold uppercase tracking-wider block ${record.totalSelisihNominalRp < 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                Selisih Nilai (Rp)
              </span>
              <span className={`text-base sm:text-lg font-black block ${record.totalSelisihNominalRp < 0 ? 'text-rose-950' : 'text-emerald-950'}`}>
                {record.totalSelisihNominalRp < 0 ? `-${fRp(Math.abs(record.totalSelisihNominalRp))}` : record.totalSelisihNominalRp > 0 ? `+${fRp(record.totalSelisihNominalRp)}` : 'Rp 0'}
              </span>
              <span className={`text-[10px] font-bold ${record.totalSelisihNominalRp < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {record.totalSelisihNominalRp < 0 ? 'Koreksi Minus (Waste/Lost)' : 'Surplus Aset'}
              </span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex items-center justify-between gap-3 pt-1">
            <input
              type="text"
              value={searchItemQuery}
              onChange={(e) => setSearchItemQuery(e.target.value)}
              placeholder="Filter nama produk dalam berita acara ini..."
              className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-orange-500 w-72"
            />

            <button
              type="button"
              onClick={() => setShowOnlyDiff(!showOnlyDiff)}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition flex items-center gap-1.5 cursor-pointer ${
                showOnlyDiff
                  ? 'bg-red-600 text-white border-red-600 shadow-2xs'
                  : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Hanya Berselisih ({record.totalItemSelisih})</span>
            </button>
          </div>

          {/* Detail Table */}
          <div className="border border-stone-200 rounded-2xl overflow-hidden shadow-2xs">
            <div className="max-h-[380px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-stone-100 text-stone-700 uppercase font-extrabold text-[10px] sticky top-0 z-10 border-b border-stone-200">
                  <tr>
                    <th className="py-2.5 px-3">Produk / Barang</th>
                    <th className="py-2.5 px-2 text-center">Stok Baseline</th>
                    <th className="py-2.5 px-2 text-center">Fisik Dihitung</th>
                    <th className="py-2.5 px-2 text-center">Selisih Delta</th>
                    {hasInterim && <th className="py-2.5 px-2 text-center">Terjual Kasir</th>}
                    <th className="py-2.5 px-2 text-center bg-stone-200/60">Stok Akhir</th>
                    <th className="py-2.5 px-3">Alasan / Catatan</th>
                    <th className="py-2.5 px-3 text-right">Selisih Nilai</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={hasInterim ? 8 : 7} className="py-8 text-center text-stone-400 font-bold">
                        Tidak ada item yang sesuai filter
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((it, idx) => {
                      const hasDiff = it.selisih !== 0;
                      const interimSold = it.penjualanInterim || 0;
                      const finalStock = it.stokPenyesuaianAkhir !== undefined ? it.stokPenyesuaianAkhir : it.stokFisik;

                      return (
                        <tr 
                          key={`opname-detail-${it.kode || 'item'}-${idx}`} 
                          className={`transition ${hasDiff ? 'bg-red-50/40 hover:bg-red-50/70' : 'hover:bg-stone-50'}`}
                        >
                          <td className="py-2 px-3">
                            <div className="font-extrabold text-stone-900">{it.nama}</div>
                            <div className="text-[10px] text-stone-400 flex items-center gap-1.5 mt-0.5">
                              <span>#{it.kode}</span>
                              <span>•</span>
                              <span>{it.kategori}</span>
                              {it.countedAt && (
                                <>
                                  <span>•</span>
                                  <span className="text-stone-500 font-mono">Dihitung: {it.countedAt}</span>
                                </>
                              )}
                            </div>
                          </td>

                          <td className="py-2 px-2 text-center font-bold text-stone-700">
                            {it.stokSistem} {it.satuan}
                          </td>

                          <td className="py-2 px-2 text-center font-black text-stone-900">
                            {it.stokFisik} {it.satuan}
                          </td>

                          <td className="py-2 px-2 text-center">
                            {it.selisih === 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-[10px]">
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span>Sesuai</span>
                              </span>
                            ) : it.selisih < 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-black text-[10px] border border-red-200">
                                <span>{it.selisih} {it.satuan}</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-black text-[10px] border border-blue-200">
                                <span>+{it.selisih} {it.satuan}</span>
                              </span>
                            )}
                          </td>

                          {hasInterim && (
                            <td className="py-2 px-2 text-center font-mono">
                              {interimSold > 0 ? (
                                <span className="px-1.5 py-0.5 bg-amber-100 text-amber-900 rounded text-[11px] font-extrabold">
                                  -{interimSold}
                                </span>
                              ) : (
                                <span className="text-stone-300">-</span>
                              )}
                            </td>
                          )}

                          <td className="py-2 px-2 text-center font-mono font-black text-stone-900 bg-stone-100/50">
                            <span>{finalStock} {it.satuan}</span>
                          </td>

                          <td className="py-2 px-3">
                            <div className="text-[11px] font-bold text-stone-800">
                              {it.selisih === 0 ? 'Sesuai' : it.alasan}
                            </div>
                            {it.catatan && (
                              <div className="text-[10px] text-stone-500 italic mt-0.5">
                                "{it.catatan}"
                              </div>
                            )}
                          </td>

                          <td className="py-2 px-3 text-right font-black">
                            {it.selisihNilaiRp === 0 ? (
                              <span className="text-stone-400">-</span>
                            ) : it.selisihNilaiRp < 0 ? (
                              <span className="text-red-600">-{fRp(Math.abs(it.selisihNilaiRp))}</span>
                            ) : (
                              <span className="text-blue-600">+{fRp(it.selisihNilaiRp)}</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-stone-100 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-stone-600 font-medium">
            Dokumen resmi Berita Acara Stok Opname Ervo Print
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleExportCsv}
              className="px-3.5 py-2 bg-white hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-extrabold border border-stone-300 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Ekspor CSV</span>
            </button>

            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 active:scale-95 text-white rounded-xl text-xs font-extrabold shadow-xs transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Unduh Berita Acara PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
