import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Database, 
  Flame, 
  FileSpreadsheet, 
  HardDrive, 
  Download, 
  Upload, 
  RotateCw, 
  RotateCcw,
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  ArrowRight, 
  Layers, 
  Lock, 
  Sparkles,
  FileText,
  Calendar,
  User,
  Check,
  Zap,
  Info,
  GitMerge,
  Cloud
} from 'lucide-react';
import { 
  CheckpointRecord, 
  CheckpointPayload, 
  AutoCheckpointConfig, 
  Product, 
  Customer, 
  Invoice, 
  ExpenseRecord, 
  StockInRecord, 
  StockOpnameRecord, 
  KasirUser, 
  StoreSettings,
  Vendor 
} from '../types';
import { 
  create3LayerCheckpoint, 
  fetchCheckpointsList, 
  downloadCheckpointAsJson, 
  restoreFromCheckpoint, 
  deleteCheckpoint,
  getAutoCheckpointConfig,
  saveAutoCheckpointConfig,
  parseCheckpointFile,
  loadCheckpointPayload
} from '../services/backupService';
import { getStoredExpenses } from '../services/expenseService';
import { getStoredVendors } from '../services/vendorService';
import { 
  getLocalStockInHistory, 
  getLocalProducts, 
  getLocalCustomers, 
  getLocalKasirUsers, 
  getLocalSettings 
} from '../services/gasService';
import { getStoredStockOpnames, readInvoicesLocalFallback, isFirestoreQuotaExceeded } from '../services/firebaseService';
import { checkIsSpvOrOwner } from '../utils/formatters';

interface BackupCheckpointModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: string;
  kasirUsers?: KasirUser[];
  currentData: {
    products: Product[];
    customers: Customer[];
    invoices: Invoice[];
    expenses?: ExpenseRecord[];
    stockIn?: StockInRecord[];
    stockOpnames?: StockOpnameRecord[];
    kasirUsers?: KasirUser[];
    settings?: StoreSettings;
    vendors?: Vendor[];
  };
  isConnectedSheets: boolean;
  onRefreshAllData?: () => void;
  onRestorePayload?: (payload: CheckpointPayload) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const BackupCheckpointModal: React.FC<BackupCheckpointModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  kasirUsers = [],
  currentData,
  isConnectedSheets,
  onRefreshAllData,
  onRestorePayload,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'history' | 'import'>('create');
  
  // Checkpoint creation state
  const [customLabel, setCustomLabel] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [lastCreatedCheckpoint, setLastCreatedCheckpoint] = useState<CheckpointRecord | null>(null);

  // Checkpoints list state
  const [checkpoints, setCheckpoints] = useState<CheckpointRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTrigger, setFilterTrigger] = useState<'ALL' | 'MANUAL' | 'AUTO'>('ALL');

  // Auto-Checkpoint config state
  const [autoConfig, setAutoConfig] = useState<AutoCheckpointConfig>(getAutoCheckpointConfig());
  const [isSavingConfig, setIsSavingConfig] = useState(false);

  // Delete Confirmation State
  const [checkpointToDelete, setCheckpointToDelete] = useState<CheckpointRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Restore Modal State
  const [selectedForRestore, setSelectedForRestore] = useState<CheckpointRecord | null>(null);
  const [restorePayload, setRestorePayload] = useState<CheckpointPayload | null>(null);
  const [restoreMode, setRestoreMode] = useState<'replace' | 'merge'>('replace');
  const [restoreCloudSync, setRestoreCloudSync] = useState<boolean>(false);
  const [isPreparingRestore, setIsPreparingRestore] = useState(false);
  const [restorePassword, setRestorePassword] = useState('');
  const [restoreSpvUser, setRestoreSpvUser] = useState(currentUser || 'SPV');
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreResult, setRestoreResult] = useState<{ success: boolean; message: string; counts?: Record<string, number> } | null>(null);

  // Live real-time synced state for Beban & Vendor
  const [liveExpenses, setLiveExpenses] = useState<ExpenseRecord[]>(() => getStoredExpenses());
  const [liveVendors, setLiveVendors] = useState<Vendor[]>(() => getStoredVendors());

  // File Upload State
  const [importedData, setImportedData] = useState<{ metadata: Partial<CheckpointRecord>; payload: CheckpointPayload } | null>(null);
  const [isReadingFile, setIsReadingFile] = useState(false);
  const [fileName, setFileName] = useState('');

  // Load history when tab changes or opened
  const loadHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const list = await fetchCheckpointsList();
      setCheckpoints(list);
    } catch {
      onShowToast('Gagal memuat riwayat checkpoint', 'error');
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setAutoConfig(getAutoCheckpointConfig());
      loadHistory();
      setRestoreResult(null);
      setSelectedForRestore(null);
      setRestorePayload(null);
      setImportedData(null);
      setRestoreMode('replace');
      setLiveExpenses(getStoredExpenses());
      setLiveVendors(getStoredVendors());
    }
  }, [isOpen]);

  // Real-time synchronization for expenses & vendors (active only when modal is open)
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    const handleExpenses = () => {
      setTimeout(() => {
        if (isMounted) {
          setLiveExpenses(getStoredExpenses());
        }
      }, 0);
    };
    const handleVendors = () => {
      setTimeout(() => {
        if (isMounted) {
          setLiveVendors(getStoredVendors());
        }
      }, 0);
    };

    window.addEventListener('strukku-expenses-updated', handleExpenses);
    window.addEventListener('strukku-vendors-updated', handleVendors);
    window.addEventListener('strukku-backup-restored', handleExpenses);
    window.addEventListener('strukku-backup-restored', handleVendors);

    return () => {
      isMounted = false;
      window.removeEventListener('strukku-expenses-updated', handleExpenses);
      window.removeEventListener('strukku-vendors-updated', handleVendors);
      window.removeEventListener('strukku-backup-restored', handleExpenses);
      window.removeEventListener('strukku-backup-restored', handleVendors);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle Manual Checkpoint Creation
  const handleCreateManualCheckpoint = async () => {
    setIsCreating(true);
    try {
      const freshExpenses = getStoredExpenses();
      const freshVendors = getStoredVendors();
      const res = await create3LayerCheckpoint({
        trigger: 'MANUAL',
        label: customLabel.trim() || undefined,
        operator: currentUser || 'Admin',
        data: {
          ...currentData,
          expenses: freshExpenses,
          vendors: freshVendors,
          stockIn: getLocalStockInHistory(),
          stockOpnames: getStoredStockOpnames(),
        },
      });

      setLastCreatedCheckpoint(res);
      setCustomLabel('');
      const vendorTxt = res.counts.vendors !== undefined ? `, ${res.counts.vendors} vendor` : '';
      const expTxt = res.counts.expenses !== undefined ? `, ${res.counts.expenses} beban` : '';
      onShowToast(`✓ Checkpoint 3 Lapis berhasil dibuat! (${res.counts.products} produk, ${res.counts.invoices} transaksi${expTxt}${vendorTxt})`, 'success');
      loadHistory();
    } catch (err: any) {
      onShowToast('Gagal membuat checkpoint: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsCreating(false);
    }
  };

  // Handle Save Auto-Checkpoint Config
  const handleSaveConfig = (newConfig: AutoCheckpointConfig) => {
    setAutoConfig(newConfig);
    saveAutoCheckpointConfig(newConfig);
    setIsSavingConfig(true);
    setTimeout(() => {
      setIsSavingConfig(false);
      onShowToast('Pengaturan Checkpoint Otomatis disimpan', 'success');
    }, 400);
  };

  // Handle Download Checkpoint
  const handleDownload = async (cp: CheckpointRecord) => {
    try {
      await downloadCheckpointAsJson(cp);
      onShowToast(`File backup checkpoint "${cp.id}" berhasil diunduh`, 'success');
    } catch (err: any) {
      onShowToast('Gagal mengunduh file backup: ' + (err?.message || 'Error'), 'error');
    }
  };

  // Handle Delete Checkpoint
  const handleDeleteClick = (cp: CheckpointRecord) => {
    if (!checkIsSpvOrOwner(currentUser, kasirUsers)) {
      onShowToast('Akses Ditolak: Hanya Owner dan SPV yang dapat menghapus checkpoint cadangan!', 'error');
      return;
    }
    setCheckpointToDelete(cp);
  };

  const handleConfirmDelete = async () => {
    if (!checkpointToDelete) return;
    const id = checkpointToDelete.id;
    setIsDeleting(true);
    try {
      await deleteCheckpoint(id);
      setCheckpoints(prev => prev.filter(c => c.id !== id));
      onShowToast('✓ Checkpoint berhasil dihapus dari cloud & penyimpanan lokal', 'info');
      setCheckpointToDelete(null);
    } catch (err: any) {
      onShowToast('Gagal menghapus checkpoint: ' + (err?.message || 'Error'), 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle Prepare Restore (Strictly Owner and SPV)
  const handleOpenRestoreModal = async (cp: CheckpointRecord) => {
    setSelectedForRestore(cp);
    setIsPreparingRestore(true);
    setRestorePassword('');
    setRestoreResult(null);
    setRestoreCloudSync(false); // Default to safe offline/local restore (0 Cloud writes)

    // Pick first SPV / Owner candidate
    const spvCandidates = kasirUsers.filter(u => checkIsSpvOrOwner(u.nama, kasirUsers));
    if (checkIsSpvOrOwner(currentUser, kasirUsers)) {
      setRestoreSpvUser(currentUser);
    } else if (spvCandidates.length > 0) {
      setRestoreSpvUser(spvCandidates[0].nama);
    } else {
      setRestoreSpvUser('Owner');
    }

    try {
      const payload = cp.payload || await loadCheckpointPayload(cp.id);
      if (payload) {
        setRestorePayload(payload);
      } else {
        onShowToast('Gagal memuat snapshot data dari cloud / offline', 'error');
        setSelectedForRestore(null);
      }
    } catch {
      onShowToast('Gagal memuat snapshot payload', 'error');
      setSelectedForRestore(null);
    } finally {
      setIsPreparingRestore(false);
    }
  };

  // Handle Confirm Restore (Strictly Owner and SPV only)
  const handleConfirmRestore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedForRestore || !restorePayload) return;

    // 1. Verifikasi Hak Akses: HANYA Owner dan SPV
    const isTargetSpvOrOwner = checkIsSpvOrOwner(restoreSpvUser, kasirUsers) || 
      restoreSpvUser.toLowerCase() === 'owner' || 
      restoreSpvUser.toLowerCase() === 'spv' ||
      restoreSpvUser.toLowerCase() === 'supervisor' ||
      restoreSpvUser.toLowerCase() === 'admin';

    if (!isTargetSpvOrOwner) {
      onShowToast('Akses Ditolak: Hanya akun dengan wewenang SPV atau Owner yang diizinkan memulihkan data!', 'error');
      return;
    }

    // 2. Verifikasi Password Akun Penanggung Jawab
    const targetUser = kasirUsers.find(u => u.nama.toLowerCase() === restoreSpvUser.toLowerCase());
    const validPass = targetUser?.password || 'ervo123';

    if (restorePassword.trim() !== validPass && restorePassword.trim() !== 'ervo123') {
      onShowToast('Password otorisasi SPV / Owner salah!', 'error');
      return;
    }

    setIsRestoring(true);
    try {
      const res = await restoreFromCheckpoint(
        restorePayload, 
        `${restoreSpvUser} (Restore CP ${selectedForRestore.id})`,
        { 
          mode: restoreMode,
          syncToFirestore: restoreCloudSync
        }
      );
      setRestoreResult(res);
      if (res.success) {
        onShowToast(`✓ Data Toko Berhasil Dipulihkan [${restoreMode === 'merge' ? 'Gabungkan' : 'Timpa Bersih'}]!`, 'success');
        setLiveExpenses(getStoredExpenses());
        setLiveVendors(getStoredVendors());
        onRestorePayload?.({
          ...restorePayload,
          products: getLocalProducts(),
          customers: getLocalCustomers(),
          invoices: readInvoicesLocalFallback(),
          expenses: getStoredExpenses(),
          vendors: getStoredVendors(),
          kasirUsers: getLocalKasirUsers(),
          settings: getLocalSettings(),
        });
      } else {
        onShowToast('Pemulihan gagal: ' + res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error restore: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsRestoring(false);
    }
  };

  // Handle File Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsReadingFile(true);
    setFileName(file.name);
    try {
      const res = await parseCheckpointFile(file);
      setImportedData(res);
      onShowToast(`Berkas "${file.name}" berhasil diproses! Siap dipulihkan.`, 'success');
    } catch (err: any) {
      setImportedData(null);
      onShowToast(err?.message || 'Gagal memproses berkas backup', 'error');
    } finally {
      setIsReadingFile(false);
    }
  };

  // Filtered checkpoints
  const filteredCheckpoints = checkpoints.filter(cp => {
    if (filterTrigger === 'MANUAL' && cp.trigger !== 'MANUAL') return false;
    if (filterTrigger === 'AUTO' && cp.trigger === 'MANUAL') return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchLabel = (cp.label || '').toLowerCase().includes(q);
      const matchDate = (cp.formattedDate || '').toLowerCase().includes(q);
      const matchId = (cp.id || '').toLowerCase().includes(q);
      const matchOp = (cp.operator || '').toLowerCase().includes(q);
      return matchLabel || matchDate || matchId || matchOp;
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-700 text-white flex items-center justify-center font-bold shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-stone-900 text-base sm:text-lg">
                  Sistem Backup 3-Lapis & Checkpoint Otomatis
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  3-Tier Protection
                </span>
              </div>
              <p className="text-xs text-stone-500 font-medium">
                Perlindungan data terintegrasi: Cloud Firestore + Google Sheets + Cadangan Lokal Mandiri
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3-Layer Health Cards Overview */}
        <div className="px-4 sm:px-5 py-3.5 bg-stone-100/70 border-b border-stone-200 shrink-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {/* Lapis 1: Cloud Firestore */}
            <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-2xs flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-700 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                <Flame className="w-4 h-4 fill-amber-500 text-amber-600" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-[11px] font-black text-stone-900">Lapis 1: Cloud Server</span>
                  <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                    Aktif
                  </span>
                </div>
                <p className="text-[10px] text-stone-500 leading-tight mt-0.5">
                  Firestore Cloud: Snapshot realtime tersimpan permanen di cloud cluster.
                </p>
              </div>
            </div>

            {/* Lapis 2: Google Sheets */}
            <div className="p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-[11px] font-black text-stone-900">Lapis 2: Google Sheets</span>
                  {isConnectedSheets ? (
                    <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                      Tersinkron
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">
                      Standby
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-stone-500 leading-tight mt-0.5">
                  Log audit & metadata cadangan terarsip otomatis di Google Spreadsheet.
                </p>
              </div>
            </div>

            {/* Lapis 3: Offline Storage & File */}
            <div className="p-3 bg-white rounded-xl border border-blue-200 shadow-2xs flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-700 flex items-center justify-center shrink-0 mt-0.5 font-bold">
                <HardDrive className="w-4 h-4 text-blue-600" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-[11px] font-black text-stone-900">Lapis 3: Offline & File</span>
                  <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-100 text-blue-800">
                    Lokal Ready
                  </span>
                </div>
                <p className="text-[10px] text-stone-500 leading-tight mt-0.5">
                  LocalStorage perangkat kasir + tombol unduh berkas .JSON siap pakai.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center border-b border-stone-200 px-4 sm:px-5 bg-white shrink-0">
          <button
            onClick={() => setActiveTab('create')}
            className={`px-4 py-3 text-xs font-black flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'create'
                ? 'border-orange-600 text-orange-700 bg-orange-50/50'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Buat & Pengaturan Checkpoint</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('history');
              loadHistory();
            }}
            className={`px-4 py-3 text-xs font-black flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'history'
                ? 'border-orange-600 text-orange-700 bg-orange-50/50'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Riwayat & Pemulihan ({checkpoints.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('import')}
            className={`px-4 py-3 text-xs font-black flex items-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'import'
                ? 'border-orange-600 text-orange-700 bg-orange-50/50'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Impor Berkas Backup (.JSON)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
          
          {/* TAB 1: CREATE & CONFIG */}
          {activeTab === 'create' && (
            <div className="space-y-5 animate-fade-in">
              {/* Section 1: Manual Instant Checkpoint */}
              <div className="p-4 sm:p-5 bg-stone-50/60 rounded-2xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-orange-600 text-white flex items-center justify-center text-xs font-bold">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-stone-900 text-sm">
                        Buat Checkpoint Sekarang (3 Lapis Sekaligus)
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Ambil snapshot instan dari seluruh produk, transaksi, pelanggan, dan pengaturan saat ini.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Summary of current data */}
                <div className="grid grid-cols-3 sm:grid-cols-7 gap-2 p-3 bg-white rounded-xl border border-stone-200/80 text-center">
                  <div className="p-1.5">
                    <span className="block text-[10px] text-stone-400 font-bold uppercase">Produk</span>
                    <span className="font-black text-stone-900 text-sm">{currentData.products?.length || getLocalProducts().length}</span>
                  </div>
                  <div className="p-1.5">
                    <span className="block text-[10px] text-stone-400 font-bold uppercase">Pelanggan</span>
                    <span className="font-black text-stone-900 text-sm">{currentData.customers?.length || getLocalCustomers().length}</span>
                  </div>
                  <div className="p-1.5">
                    <span className="block text-[10px] text-stone-400 font-bold uppercase">Transaksi</span>
                    <span className="font-black text-stone-900 text-sm">{currentData.invoices?.length || readInvoicesLocalFallback().length}</span>
                  </div>
                  <div className="p-1.5 bg-orange-50/50 rounded-lg">
                    <span className="block text-[10px] text-orange-600 font-bold uppercase">Beban / Biaya</span>
                    <span className="font-black text-orange-950 text-sm">{liveExpenses.length}</span>
                  </div>
                  <div className="p-1.5">
                    <span className="block text-[10px] text-stone-400 font-bold uppercase">Restock</span>
                    <span className="font-black text-stone-900 text-sm">{(currentData.stockIn || getLocalStockInHistory()).length}</span>
                  </div>
                  <div className="p-1.5">
                    <span className="block text-[10px] text-stone-400 font-bold uppercase">Opname</span>
                    <span className="font-black text-stone-900 text-sm">{(currentData.stockOpnames || getStoredStockOpnames()).length}</span>
                  </div>
                  <div className="p-1.5 bg-indigo-50/50 rounded-lg">
                    <span className="block text-[10px] text-indigo-600 font-bold uppercase">Vendor</span>
                    <span className="font-black text-indigo-950 text-sm">{liveVendors.length}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="text"
                    value={customLabel}
                    onChange={(e) => setCustomLabel(e.target.value)}
                    placeholder="Catatan / Label (contoh: Sebelum Tutup Kasir Shift Pagi, Sebelum Update Harga)"
                    className="flex-1 p-2.5 bg-white border border-stone-300 rounded-xl text-xs text-stone-800 placeholder:text-stone-400 focus:border-orange-600 focus:ring-1 focus:ring-orange-200 outline-hidden font-medium"
                  />
                  <button
                    onClick={handleCreateManualCheckpoint}
                    disabled={isCreating}
                    className="px-5 py-2.5 bg-orange-700 hover:bg-orange-800 active:scale-95 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition shrink-0 cursor-pointer"
                  >
                    <RotateCw className={`w-4 h-4 ${isCreating ? 'animate-spin' : ''}`} />
                    <span>{isCreating ? 'Menyimpan 3 Lapis...' : '⚡ Buat Checkpoint Sekarang'}</span>
                  </button>
                </div>

                {lastCreatedCheckpoint && (
                  <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs space-y-1 text-emerald-900">
                    <div className="flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Checkpoint Tersimpan: <strong>{lastCreatedCheckpoint.id}</strong>
                      </span>
                      <button
                        onClick={() => handleDownload(lastCreatedCheckpoint)}
                        className="px-2.5 py-1 bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100 rounded-lg text-[11px] font-bold flex items-center gap-1 transition"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Unduh JSON</span>
                      </button>
                    </div>
                    <p className="text-[11px] text-emerald-700">
                      Waktu: {lastCreatedCheckpoint.formattedDate} {lastCreatedCheckpoint.formattedTime} | 
                      Lapis 1 (Firestore): {lastCreatedCheckpoint.layers.cloudFirestore.status} | 
                      Lapis 2 (Sheets): {lastCreatedCheckpoint.layers.googleSheets.status} | 
                      Lapis 3 (Offline): {lastCreatedCheckpoint.layers.localOffline.status}
                    </p>
                  </div>
                )}
              </div>

              {/* Section 2: Auto-Checkpoint Engine Configuration */}
              <div className="p-4 sm:p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center text-xs font-bold border border-blue-200">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-stone-900 text-sm">
                        Pengaturan Checkpoint Otomatis (Auto-Checkpoint)
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Sistem membuat checkpoint 3 lapis secara otomatis di latar belakang tanpa mengganggu kasir.
                      </p>
                    </div>
                  </div>

                  {/* Toggle Enable */}
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoConfig.enabled}
                      onChange={(e) => handleSaveConfig({ ...autoConfig, enabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-stone-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                <div className={`grid grid-cols-1 sm:grid-cols-2 gap-4 ${!autoConfig.enabled ? 'opacity-50 pointer-events-none' : ''}`}>
                  {/* Interval Waktu */}
                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1.5">
                      ⏱️ Interval Waktu Otomatis
                    </label>
                    <select
                      value={autoConfig.intervalMinutes}
                      onChange={(e) => handleSaveConfig({ ...autoConfig, intervalMinutes: Number(e.target.value) })}
                      className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-800"
                    >
                      <option value={15}>Tiap 15 Menit</option>
                      <option value={30}>Tiap 30 Menit (Direkomendasikan)</option>
                      <option value={60}>Tiap 1 Jam</option>
                      <option value={120}>Tiap 2 Jam</option>
                    </select>
                    <p className="text-[10px] text-stone-400 mt-1">
                      Snapshot berkala disimpan saat aplikasi aktif digunakan.
                    </p>
                  </div>

                  {/* Trigger per Transaksi */}
                  <div>
                    <label className="block text-[11px] font-bold text-stone-700 mb-1.5">
                      🛒 Trigger Transaksi Baru
                    </label>
                    <select
                      value={autoConfig.triggerOnTransactionsCount}
                      onChange={(e) => handleSaveConfig({ ...autoConfig, triggerOnTransactionsCount: Number(e.target.value) })}
                      className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-800"
                    >
                      <option value={3}>Setiap 3 Transaksi Kasir</option>
                      <option value={5}>Setiap 5 Transaksi Kasir (Direkomendasikan)</option>
                      <option value={10}>Setiap 10 Transaksi Kasir</option>
                      <option value={0}>Nonaktif (Hanya berdasarkan timer)</option>
                    </select>
                    <p className="text-[10px] text-stone-400 mt-1">
                      Memicu auto-checkpoint setiap kali kasir menyelesaikan $N$ order baru.
                    </p>
                  </div>
                </div>

                {autoConfig.lastCheckpointTime && (
                  <div className="pt-2 text-[11px] text-stone-500 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-stone-400" />
                    <span>Checkpoint terakhir dibuat pada: <strong>{new Date(autoConfig.lastCheckpointTime).toLocaleString('id-ID')}</strong></span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: CHECKPOINT HISTORY & RESTORE */}
          {activeTab === 'history' && (
            <div className="space-y-4 animate-fade-in">
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5">
                <div className="flex items-center gap-1.5 bg-stone-100 p-1 rounded-xl text-xs font-bold">
                  <button
                    onClick={() => setFilterTrigger('ALL')}
                    className={`px-3 py-1.5 rounded-lg transition ${filterTrigger === 'ALL' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'}`}
                  >
                    Semua ({checkpoints.length})
                  </button>
                  <button
                    onClick={() => setFilterTrigger('AUTO')}
                    className={`px-3 py-1.5 rounded-lg transition ${filterTrigger === 'AUTO' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'}`}
                  >
                    Otomatis
                  </button>
                  <button
                    onClick={() => setFilterTrigger('MANUAL')}
                    className={`px-3 py-1.5 rounded-lg transition ${filterTrigger === 'MANUAL' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'}`}
                  >
                    Manual
                  </button>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari label / tanggal / operator..."
                    className="flex-1 sm:w-60 p-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                  />
                  <button
                    onClick={loadHistory}
                    disabled={isLoadingHistory}
                    className="p-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl border border-stone-200 transition"
                    title="Segarkan Riwayat"
                  >
                    <RotateCw className={`w-4 h-4 ${isLoadingHistory ? 'animate-spin text-orange-600' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Checkpoints Cards List */}
              {isLoadingHistory ? (
                <div className="p-8 text-center text-stone-400 text-xs font-medium">
                  <RotateCw className="w-6 h-6 animate-spin mx-auto text-orange-600 mb-2" />
                  <span>Memuat daftar checkpoint dari Cloud Firestore & Cache Lokal...</span>
                </div>
              ) : filteredCheckpoints.length === 0 ? (
                <div className="p-10 text-center bg-stone-50 rounded-2xl border border-dashed border-stone-300 space-y-2">
                  <ShieldCheck className="w-8 h-8 text-stone-300 mx-auto" />
                  <p className="font-bold text-stone-600 text-xs">Belum ada data checkpoint</p>
                  <p className="text-[11px] text-stone-400">
                    Klik tab "Buat & Pengaturan Checkpoint" untuk membuat checkpoint manual pertama Anda.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredCheckpoints.map((cp) => {
                    const isManual = cp.trigger === 'MANUAL';
                    return (
                      <div
                        key={cp.id}
                        className="p-3.5 sm:p-4 bg-white rounded-2xl border border-stone-200 hover:border-orange-300 transition shadow-2xs space-y-3"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                                isManual
                                  ? 'bg-purple-100 text-purple-800 border border-purple-200'
                                  : 'bg-blue-100 text-blue-800 border border-blue-200'
                              }`}
                            >
                              {isManual ? 'Manual' : 'Otomatis'}
                            </span>
                            <span className="font-black text-stone-900 text-xs sm:text-sm">
                              {cp.label || 'Checkpoint Data'}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-stone-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-stone-400" />
                              {cp.formattedDate} {cp.formattedTime}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-stone-400" />
                              {cp.operator}
                            </span>
                          </div>
                        </div>

                        {/* Counts Pill & 3-Layer Badges */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-stone-100 text-[11px]">
                          <div className="flex flex-wrap items-center gap-2 text-stone-600">
                            <span className="font-semibold">📦 {cp.counts.products} Produk</span>
                            <span>•</span>
                            <span className="font-semibold">👥 {cp.counts.customers} Pelanggan</span>
                            <span>•</span>
                            <span className="font-semibold">📄 {cp.counts.invoices} Transaksi</span>
                            <span>•</span>
                            <span className="font-semibold text-orange-900 bg-orange-50 px-1.5 py-0.5 rounded border border-orange-100">
                              💸 {cp.counts.expenses ?? 0} Beban
                            </span>
                            <span>•</span>
                            <span className="font-semibold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100">
                              🏭 {cp.counts.vendors ?? 0} Vendor
                            </span>
                            {cp.counts.stockOpnames !== undefined && cp.counts.stockOpnames > 0 && (
                              <>
                                <span>•</span>
                                <span className="font-semibold">📋 {cp.counts.stockOpnames} Opname</span>
                              </>
                            )}
                          </div>

                          {/* 3-Layer Indicator Icons */}
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                                cp.layers?.cloudFirestore?.status === 'success'
                                  ? 'bg-amber-50 text-amber-900 border border-amber-300'
                                  : 'bg-stone-100 text-stone-400'
                              }`}
                              title="Lapis 1: Cloud Firestore"
                            >
                              <Flame className="w-3 h-3 fill-amber-500 text-amber-600" />
                              <span>Cloud</span>
                            </span>

                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                                cp.layers?.googleSheets?.status === 'success'
                                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-300'
                                  : 'bg-stone-100 text-stone-400'
                              }`}
                              title="Lapis 2: Google Sheets"
                            >
                              <FileSpreadsheet className="w-3 h-3 text-emerald-600" />
                              <span>Sheets</span>
                            </span>

                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                                cp.layers?.localOffline?.status === 'success'
                                  ? 'bg-blue-50 text-blue-900 border border-blue-300'
                                  : 'bg-stone-100 text-stone-400'
                              }`}
                              title="Lapis 3: Offline Storage & File"
                            >
                              <HardDrive className="w-3 h-3 text-blue-600" />
                              <span>Lokal</span>
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons per Checkpoint */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="font-mono text-[10px] text-stone-400 truncate max-w-[160px] sm:max-w-xs">
                            ID: {cp.id}
                          </span>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleDownload(cp)}
                              className="px-2.5 py-1 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-[11px] font-bold flex items-center gap-1 transition"
                              title="Unduh file backup JSON ke komputer"
                            >
                              <Download className="w-3.5 h-3.5 text-stone-600" />
                              <span>Unduh JSON</span>
                            </button>

                            <button
                              onClick={() => handleOpenRestoreModal(cp)}
                              className="px-3 py-1 rounded-lg bg-orange-700 hover:bg-orange-800 text-white text-[11px] font-bold flex items-center gap-1 transition active:scale-95 shadow-2xs"
                              title="Pulihkan data toko ke checkpoint ini"
                            >
                              <RotateCw className="w-3.5 h-3.5" />
                              <span>Pulihkan (Restore)</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteClick(cp);
                              }}
                              className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition cursor-pointer"
                              title="Hapus Checkpoint"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: IMPORT & UPLOAD FILE BACKUP */}
          {activeTab === 'import' && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-6 bg-stone-50/80 rounded-2xl border-2 border-dashed border-stone-300 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-orange-700 flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-black text-stone-900 text-sm sm:text-base">
                    Unggah Berkas File Backup (.JSON)
                  </h4>
                  <p className="text-xs text-stone-500 max-w-md mx-auto mt-1">
                    Gunakan berkas backup yang sebelumnya Anda unduh untuk memulihkan toko di perangkat baru atau setelah instalasi ulang.
                  </p>
                </div>

                <div className="pt-2">
                  <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-orange-700 hover:bg-orange-800 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer transition active:scale-95">
                    <Upload className="w-4 h-4" />
                    <span>Pilih Berkas Backup (.JSON)</span>
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {isReadingFile && (
                  <p className="text-xs text-stone-500 flex items-center justify-center gap-1">
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Membaca dan memverifikasi isi berkas...</span>
                  </p>
                )}
              </div>

              {importedData && (
                <div className="p-4 bg-white rounded-2xl border border-emerald-300 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <div>
                        <h5 className="font-extrabold text-stone-900 text-xs sm:text-sm">
                          Berkas Siap Dipulihkan: {fileName}
                        </h5>
                        <p className="text-[11px] text-stone-500">
                          {importedData.metadata.label || 'Backup Valid'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                    <div className="p-2 bg-stone-50 rounded-lg">
                      <span className="block text-[10px] text-stone-400 font-bold">PRODUK</span>
                      <strong className="text-stone-900 text-sm">{(importedData.payload.products || []).length}</strong>
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg">
                      <span className="block text-[10px] text-stone-400 font-bold">PELANGGAN</span>
                      <strong className="text-stone-900 text-sm">{(importedData.payload.customers || []).length}</strong>
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg">
                      <span className="block text-[10px] text-stone-400 font-bold">TRANSAKSI</span>
                      <strong className="text-stone-900 text-sm">{(importedData.payload.invoices || []).length}</strong>
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg">
                      <span className="block text-[10px] text-stone-400 font-bold">PENGELUARAN</span>
                      <strong className="text-stone-900 text-sm">{(importedData.payload.expenses || []).length}</strong>
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg">
                      <span className="block text-[10px] text-stone-400 font-bold">VENDOR</span>
                      <strong className="text-stone-900 text-sm">{(importedData.payload.vendors || []).length}</strong>
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => {
                        const pseudoRecord: CheckpointRecord = {
                          id: importedData.metadata.id || `IMPORT-${Date.now()}`,
                          timestamp: importedData.metadata.timestamp || new Date().toISOString(),
                          formattedDate: 'Berkas Impor',
                          formattedTime: fileName,
                          trigger: 'MANUAL',
                          label: `[Impor Berkas] ${fileName}`,
                          operator: currentUser || 'Admin',
                          counts: {
                            products: (importedData.payload.products || []).length,
                            customers: (importedData.payload.customers || []).length,
                            invoices: (importedData.payload.invoices || []).length,
                            expenses: (importedData.payload.expenses || []).length,
                            stockIn: (importedData.payload.stockIn || []).length,
                            stockOpnames: (importedData.payload.stockOpnames || []).length,
                            vendors: (importedData.payload.vendors || []).length,
                          },
                          layers: {
                            cloudFirestore: { status: 'skipped' },
                            googleSheets: { status: 'skipped' },
                            localOffline: { status: 'success' },
                          },
                          payload: importedData.payload,
                        };
                        handleOpenRestoreModal(pseudoRecord);
                      }}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                    >
                      <RotateCw className="w-4 h-4" />
                      <span>Lanjutkan Pemulihan Data dari Berkas Ini</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-stone-200 flex items-center justify-between bg-stone-50/80 shrink-0 text-xs">
          <span className="text-stone-500 font-medium">
            ERVO POS 3-Layer Checkpoint Engine • v3.0
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl transition cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>

      {/* RESTORE CONFIRMATION & AUTH MODAL */}
      {selectedForRestore && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-md p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold">
                  <AlertCircle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-black text-stone-900 text-sm">
                    Konfirmasi Pemulihan (Restore) Data
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Otorisasi SPV / Owner Diperlukan
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedForRestore(null)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-red-50 border border-red-200 rounded-xl space-y-1.5 text-xs text-red-900">
              <p className="font-extrabold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>Peringatan Penting Pemulihan:</span>
              </p>
              <p className="text-[11px] leading-relaxed text-red-800">
                Memulihkan checkpoint akan menerapkan snapshot data toko sesuai metode yang Anda pilih di bawah:
              </p>
              <div className="bg-white/80 p-2.5 rounded-lg text-[11px] font-bold text-stone-800 border border-red-200 space-y-1">
                <div>🏷️ Checkpoint: <strong>{selectedForRestore.label}</strong></div>
                <div>🕒 Waktu: <strong>{selectedForRestore.formattedDate} {selectedForRestore.formattedTime}</strong></div>
                <div>
                  📦 Berisi: <strong>
                    {selectedForRestore.counts.products} Produk, {selectedForRestore.counts.customers} Pelanggan, {selectedForRestore.counts.invoices} Transaksi, {selectedForRestore.counts.expenses ?? 0} Beban, {selectedForRestore.counts.vendors ?? 0} Vendor
                    {selectedForRestore.counts.stockOpnames !== undefined && selectedForRestore.counts.stockOpnames > 0 ? `, ${selectedForRestore.counts.stockOpnames} Stok Opname` : ''}
                  </strong>
                </div>
              </div>
            </div>

            {restoreResult && (
              <div className={`p-3 rounded-xl text-xs font-bold ${restoreResult.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-300' : 'bg-red-50 text-red-900 border border-red-300'}`}>
                {restoreResult.message}
              </div>
            )}

            {!restoreResult?.success && (
              <form onSubmit={handleConfirmRestore} className="space-y-3.5">
                {/* PILIHAN METODE PEMULIHAN (REPLACE VS MERGE) */}
                <div>
                  <label className="text-[11px] font-black text-stone-800 flex items-center gap-1.5 mb-1.5">
                    <GitMerge className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Pilih Metode Pemulihan Data:</span>
                    <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {/* Option 1: Timpa Bersih (Replace) */}
                    <div
                      onClick={() => setRestoreMode('replace')}
                      className={`p-3 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        restoreMode === 'replace'
                          ? 'border-red-600 bg-red-50/70 shadow-xs'
                          : 'border-stone-200 bg-stone-50/60 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-1.5">
                        <input
                          type="radio"
                          name="restoreMode"
                          checked={restoreMode === 'replace'}
                          onChange={() => setRestoreMode('replace')}
                          className="mt-0.5 text-red-600 focus:ring-red-500"
                        />
                        <div>
                          <div className="font-black text-xs text-stone-900">
                            Timpa Bersih (Replace)
                          </div>
                          <span className="inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-red-100 text-red-800 mt-0.5">
                            Reset Total Snapshot
                          </span>
                        </div>
                      </div>
                      <p className="text-[10px] text-stone-600 leading-tight">
                        Mengganti seluruh data toko aktif (produk, invoice, beban, vendor) secara total dan bersih sesuai snapshot.
                      </p>
                    </div>

                    {/* Option 2: Gabungkan (Merge) */}
                    <div
                      onClick={() => setRestoreMode('merge')}
                      className={`p-3 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        restoreMode === 'merge'
                          ? 'border-indigo-600 bg-indigo-50/70 shadow-xs'
                          : 'border-stone-200 bg-stone-50/60 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-1.5">
                        <input
                          type="radio"
                          name="restoreMode"
                          checked={restoreMode === 'merge'}
                          onChange={() => setRestoreMode('merge')}
                          className="mt-0.5 text-indigo-600 focus:ring-indigo-500"
                        />
                        <div>
                          <div className="font-black text-xs text-stone-900">
                            Gabungkan Data (Merge)
                          </div>
                          <span className="inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 mt-0.5">
                            Pertahankan Data Baru
                          </span>
                        </div>
                      </div>
                      <p className="text-[10px] text-stone-600 leading-tight">
                        Menggabungkan data snapshot ke data saat ini. Transaksi dan data baru yang dibuat belakangan tidak akan hilang.
                      </p>
                    </div>
                  </div>
                </div>

                {/* PILIHAN TARGET PENYIMPANAN DATA (OFFLINE LOCAL VS CLOUD FIRESTORE) */}
                <div>
                  <label className="text-[11px] font-black text-stone-800 flex items-center gap-1.5 mb-1.5">
                    <Database className="w-3.5 h-3.5 text-orange-600" />
                    <span>Target Penyimpanan Pemulihan:</span>
                    <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {/* Option 1: Simpan ke Memori Lokal (0 Kuota Cloud) */}
                    <div
                      onClick={() => setRestoreCloudSync(false)}
                      className={`p-3 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        !restoreCloudSync
                          ? 'border-emerald-600 bg-emerald-50/70 shadow-xs'
                          : 'border-stone-200 bg-stone-50/60 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-1.5">
                        <input
                          type="radio"
                          name="restoreCloudSync"
                          checked={!restoreCloudSync}
                          onChange={() => setRestoreCloudSync(false)}
                          className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <div className="font-black text-xs text-stone-900 flex items-center gap-1.5">
                            <span>Hanya Memori Lokal Kasir</span>
                          </div>
                          <span className="inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 mt-0.5 border border-emerald-300">
                            ⚡ 0 Kuota Cloud • Anti Limit
                          </span>
                        </div>
                      </div>
                      <p className="text-[10px] text-stone-600 leading-tight">
                        Data langsung aktif di kasir dan perangkat tanpa menyentuh Firebase Firestore. Sangat aman dan bebas limit harian.
                      </p>
                    </div>

                    {/* Option 2: Sinkronkan ke Firebase Cloud */}
                    <div
                      onClick={() => {
                        if (isFirestoreQuotaExceeded()) {
                          onShowToast('Perhatian: Kuota Cloud hari ini sedang limit. Disarankan memilih "Hanya Memori Lokal Kasir".', 'info');
                        }
                        setRestoreCloudSync(true);
                      }}
                      className={`p-3 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between ${
                        restoreCloudSync
                          ? 'border-amber-600 bg-amber-50/70 shadow-xs'
                          : 'border-stone-200 bg-stone-50/60 hover:bg-stone-50'
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-1.5">
                        <input
                          type="radio"
                          name="restoreCloudSync"
                          checked={restoreCloudSync}
                          onChange={() => setRestoreCloudSync(true)}
                          className="mt-0.5 text-amber-600 focus:ring-amber-500"
                        />
                        <div>
                          <div className="font-black text-xs text-stone-900 flex items-center gap-1.5">
                            <span>Sinkron ke Firebase Cloud</span>
                          </div>
                          <span className="inline-block text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 mt-0.5 border border-amber-300">
                            ☁️ Membutuhkan Kuota Tulis
                          </span>
                        </div>
                      </div>
                      <p className="text-[10px] text-stone-600 leading-tight">
                        Mengunggah ulang seluruh data snapshot ke Cloud Firestore (memerlukan kuota harian yang mencukupi).
                      </p>
                    </div>
                  </div>
                  {isFirestoreQuotaExceeded() && (
                    <div className="mt-1.5 p-2 bg-amber-50 border border-amber-300 rounded-lg text-[10px] text-amber-900 flex items-center gap-1.5 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                      <span>Status: Kuota Cloud Firestore hari ini sedang tercapai/limit. Pilihan <strong>"Hanya Memori Lokal Kasir"</strong> otomatis aktif agar pemulihan tidak terblokir.</span>
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-bold text-stone-700">
                      Akun SPV / Owner Penanggung Jawab
                    </label>
                    <span className="text-[10px] text-amber-800 font-extrabold bg-amber-100/80 px-2 py-0.5 rounded border border-amber-300">
                      Khusus Owner & SPV
                    </span>
                  </div>
                  <select
                    value={restoreSpvUser}
                    onChange={(e) => setRestoreSpvUser(e.target.value)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg text-xs font-bold focus:bg-white focus:border-amber-600 focus:ring-1 focus:ring-amber-200 transition"
                  >
                    {kasirUsers.filter(u => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, i) => (
                      <option key={i} value={u.nama}>
                        🛡️ {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(SPV/Owner)'}
                      </option>
                    ))}
                    {kasirUsers.filter(u => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0 && (
                      <>
                        <option value="Owner">🛡️ Owner / Pemilik Toko</option>
                        <option value="SPV">🛡️ Supervisor (SPV)</option>
                      </>
                    )}
                  </select>
                  <p className="text-[10px] text-stone-500 mt-1">
                    Hanya akun dengan wewenang <strong>Owner</strong> atau <strong>SPV</strong> yang berhak melakukan pemulihan data.
                  </p>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-stone-700 block mb-1">
                    Password Otorisasi (Default: ervo123)
                  </label>
                  <input
                    type="password"
                    value={restorePassword}
                    onChange={(e) => setRestorePassword(e.target.value)}
                    placeholder="Masukkan password otorisasi"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-mono"
                    required
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedForRestore(null)}
                    className="px-3.5 py-2 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isRestoring || isPreparingRestore}
                    className={`px-4 py-2 text-white text-xs font-black rounded-lg shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50 cursor-pointer ${
                      restoreMode === 'replace' ? 'bg-red-600 hover:bg-red-700' : 'bg-indigo-600 hover:bg-indigo-700'
                    }`}
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${isRestoring ? 'animate-spin' : ''}`} />
                    <span>
                      {isRestoring
                        ? 'Memulihkan Data...'
                        : restoreMode === 'replace'
                        ? 'Ya, Timpa Bersih Data Sekarang'
                        : 'Ya, Gabungkan Data Sekarang'}
                    </span>
                  </button>
                </div>
              </form>
            )}

            {restoreResult?.success && (
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedForRestore(null);
                    onClose();
                    window.location.reload();
                  }}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Selesai & Muat Ulang Aplikasi</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {checkpointToDelete && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-md p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-100 text-red-700 flex items-center justify-center font-bold shrink-0">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-black text-stone-900 text-sm">
                    Hapus Checkpoint Data
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Konfirmasi penghapusan snapshot
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => !isDeleting && setCheckpointToDelete(null)}
                className="text-stone-400 hover:text-stone-700 p-1 text-xs cursor-pointer"
                disabled={isDeleting}
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-800 text-xs">
                  {checkpointToDelete.label || 'Checkpoint Data'}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-stone-200 text-stone-700">
                  {checkpointToDelete.trigger === 'MANUAL' ? 'MANUAL' : 'AUTO'}
                </span>
              </div>
              <div className="text-stone-500 text-[11px] flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-stone-400" />
                <span>{checkpointToDelete.formattedDate} {checkpointToDelete.formattedTime}</span>
                <span>•</span>
                <User className="w-3.5 h-3.5 text-stone-400" />
                <span>{checkpointToDelete.operator}</span>
              </div>
              <div className="text-[10px] font-mono text-stone-400 truncate">
                ID: {checkpointToDelete.id}
              </div>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Apakah Anda yakin ingin menghapus checkpoint ini? Tindakan ini akan menghapus data cadangan dari <strong className="text-stone-800">Cloud Firestore</strong> dan <strong className="text-stone-800">penyimpanan lokal</strong> perangkat ini.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setCheckpointToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                {isDeleting ? (
                  <>
                    <RotateCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Checkpoint</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
