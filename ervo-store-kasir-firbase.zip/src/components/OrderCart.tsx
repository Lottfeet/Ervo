import React, { useState } from 'react';
import { 
  FileText, 
  User, 
  UserPlus,
  Trash2, 
  Plus, 
  Printer, 
  Receipt, 
  BadgeDollarSign, 
  Tag, 
  CheckCircle2, 
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Banknote,
  QrCode,
  ArrowRightLeft,
  CreditCard
} from 'lucide-react';
import { Customer, InvoiceItem } from '../types';
import { fRp, fDec, computeItemTotal } from '../utils/formatters';

interface OrderCartProps {
  invoiceNo: string;
  invoiceDate: string;
  items: InvoiceItem[];
  customers: Customer[];
  selectedCustomer: string;
  setSelectedCustomer: (name: string) => void;
  orderDate: string;
  setOrderDate: (date: string) => void;
  deadlineDate: string;
  setDeadlineDate: (date: string) => void;
  discountPct: number;
  setDiscountPct: (pct: number) => void;
  taxPct: number;
  setTaxPct: (pct: number) => void;
  negoAmt: number;
  setNegoAmt: (amt: number) => void;
  payMethod: string;
  setPayMethod: (method: string) => void;
  dpAmount: number | string;
  setDpAmount: (val: number | string) => void;
  onUpdateQty: (index: number, delta: number) => void;
  onSetQty?: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onNewInvoice: () => void;
  onPrintThermal: () => void;
  onPrintA5: () => void;
  onCompletePayment?: () => void;
  onOpenPelunasan: () => void;
  onOpenAddCustomer?: () => void;
  isSaving?: boolean;
}

export const OrderCart: React.FC<OrderCartProps> = ({
  invoiceNo,
  invoiceDate,
  items,
  customers,
  selectedCustomer,
  setSelectedCustomer,
  orderDate,
  setOrderDate,
  deadlineDate,
  setDeadlineDate,
  discountPct,
  setDiscountPct,
  taxPct,
  setTaxPct,
  negoAmt,
  setNegoAmt,
  payMethod,
  setPayMethod,
  dpAmount,
  setDpAmount,
  onUpdateQty,
  onSetQty,
  onRemoveItem,
  onNewInvoice,
  onPrintThermal,
  onPrintA5,
  onCompletePayment,
  onOpenPelunasan,
  onOpenAddCustomer,
  isSaving = false,
}) => {
  const [showDiscounts, setShowDiscounts] = useState(false);

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + computeItemTotal(item), 0);
  const discAmt = (subtotal * discountPct) / 100;
  const afterDisc = Math.max(0, subtotal - discAmt - negoAmt);
  const taxAmt = (afterDisc * taxPct) / 100;
  const total = Math.max(0, afterDisc) + taxAmt;

  const dp = typeof dpAmount === 'number' ? dpAmount : parseFloat(String(dpAmount).replace(',', '.')) || 0;
  const hasDp = Boolean(dpAmount !== '' && dpAmount !== null && dpAmount !== undefined && dp > 0);
  const sisa = Math.max(0, total - dp);
  const kembalian = dp > total ? dp - total : 0;

  const isCustomerEmpty = !selectedCustomer || !selectedCustomer.trim();
  const isTransactionDisabled = items.length === 0 || isSaving || isCustomerEmpty;

  const hasCustomAdjustments = discountPct > 0 || negoAmt > 0 || taxPct > 0;

  // Find customer match
  const matchedCustomer = customers.find(
    (c) => c.nama.toLowerCase() === selectedCustomer.trim().toLowerCase()
  );

  const handleCustomerChange = (val: string) => {
    setSelectedCustomer(val);
    const match = customers.find((c) => c.nama.toLowerCase() === val.trim().toLowerCase());
    if (match) {
      setDiscountPct(match.diskon || 0);
    } else if (val.trim() === '') {
      setDiscountPct(0);
    }
  };

  const handleSelectPaymentMethod = (method: string) => {
    if (!hasDp) return;
    setPayMethod(method);
  };

  const handleQuickUangPas = () => {
    if (total <= 0) return;
    setDpAmount(total);
    setPayMethod(payMethod && payMethod !== '-' && payMethod !== '' ? payMethod : 'Tunai');
  };

  return (
    <div className="bg-white border border-stone-200 rounded-xl flex flex-col h-full min-h-0 overflow-hidden shadow-xs">
      {/* 1. Compact Header */}
      <div className="px-3 py-2 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
        <div className="flex items-center gap-1.5 font-bold text-xs text-stone-900">
          <FileText className="w-3.5 h-3.5 text-orange-700" />
          <span>Pesanan Aktif</span>
        </div>
        <div className="text-right text-[11px] font-semibold text-stone-600 font-mono">
          <span className="text-orange-700 font-extrabold">{invoiceNo}</span>
          <span className="mx-1 text-stone-300">•</span>
          <span>{invoiceDate}</span>
        </div>
      </div>

      {/* 2. Customer & Dates Bar - Streamlined & Compact */}
      <div className="p-2 sm:p-2.5 bg-stone-50/70 border-b border-stone-200 space-y-1.5 shrink-0">
        {/* Customer Input Row */}
        <div>
          <div className="flex items-center justify-between mb-0.5">
            <label className="text-[10px] font-bold text-stone-600 flex items-center gap-1 flex-wrap">
              <span>Pelanggan / Pemesan <span className="text-red-500 font-extrabold">*</span></span>
              {matchedCustomer ? (
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 inline-flex items-center gap-0.5">
                  <CheckCircle2 className="w-2.5 h-2.5" /> {matchedCustomer.kelas} ({matchedCustomer.diskon}% Disc)
                </span>
              ) : selectedCustomer.trim() ? (
                <span className="text-[9px] font-medium px-1.5 py-0.2 rounded bg-stone-100 text-stone-700">
                  Pelanggan Baru
                </span>
              ) : (
                <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-red-100 text-red-700">
                  Wajib Diisi
                </span>
              )}
            </label>
            {onOpenAddCustomer && (
              <button
                type="button"
                onClick={onOpenAddCustomer}
                className="text-[9px] font-bold px-1.5 py-0.5 bg-orange-100 hover:bg-orange-200 text-orange-800 rounded transition flex items-center gap-0.5 active:scale-95 shadow-2xs"
                title="Tambah Pelanggan Baru"
              >
                <UserPlus className="w-2.5 h-2.5 text-orange-700" />
                <span>+ Pelanggan</span>
              </button>
            )}
          </div>
          <div className="relative">
            <User className={`w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 transition-colors ${
              isCustomerEmpty ? 'text-red-400' : 'text-stone-400'
            }`} />
            <input
              type="text"
              list="customerListOptions"
              value={selectedCustomer}
              onChange={(e) => handleCustomerChange(e.target.value)}
              placeholder="Ketik Nama Pelanggan / Pemesan (Wajib)..."
              required
              className={`w-full pl-8 pr-2.5 py-1 border rounded-lg text-xs font-semibold bg-white focus:outline-none transition ${
                isCustomerEmpty
                  ? 'border-red-300 focus:border-red-500 focus:ring-1 focus:ring-red-100 text-red-900 placeholder-red-300'
                  : 'border-stone-200 focus:border-orange-600 focus:ring-1 focus:ring-orange-100'
              }`}
            />
            <datalist id="customerListOptions">
              {customers.map((c, idx) => (
                <option key={`${c.nama}-${idx}`} value={c.nama}>
                  {c.kelas ? `${c.kelas} - Diskon ${c.diskon}%` : ''}
                </option>
              ))}
            </datalist>
          </div>
        </div>

        {/* Compact Dates Row */}
        <div className="grid grid-cols-2 gap-1.5">
          <div className="flex items-center gap-1 bg-white px-2 py-0.5 rounded-md border border-stone-200">
            <span className="text-[9px] font-bold text-stone-500 shrink-0">Tgl:</span>
            <input
              type="date"
              value={orderDate}
              onChange={(e) => setOrderDate(e.target.value)}
              className="w-full text-[11px] font-semibold text-stone-800 bg-transparent focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-1 bg-white px-2 py-0.5 rounded-md border border-stone-200">
            <span className="text-[9px] font-bold text-stone-500 shrink-0">Selesai:</span>
            <input
              type="date"
              value={deadlineDate}
              onChange={(e) => setDeadlineDate(e.target.value)}
              className="w-full text-[11px] font-semibold text-stone-800 bg-transparent focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* 3. Items List with Independent Scroll */}
      <div className="flex-1 min-h-0 overflow-y-auto p-2 sm:p-2.5 space-y-1.5 bg-stone-50/20">
        {items.length === 0 ? (
          <div className="text-center py-6 px-3 text-stone-400">
            <Receipt className="w-8 h-8 mx-auto mb-1 opacity-25" />
            <p className="font-bold text-xs text-stone-600">Keranjang Masih Kosong</p>
            <p className="text-[10px] text-stone-400 mt-0.5">
              Pilih produk / jasa dari katalog untuk menambahkan item ke pesanan.
            </p>
          </div>
        ) : (
          items.map((item, idx) => {
            const itemTotal = computeItemTotal(item);
            const isUkuran = item.tipeHarga === 'ukuran';
            const dimStr = isUkuran ? `${fDec(item.panjang, 2)}m × ${fDec(item.lebar, 2)}m` : '';

            return (
              <div
                key={idx}
                className="p-2 rounded-lg border border-stone-200 bg-white hover:border-stone-300 transition shadow-2xs"
              >
                <div className="flex items-center justify-between gap-1.5">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-stone-900 truncate">
                      {item.nama}
                    </div>
                    <div className="text-[10px] text-stone-500 flex flex-wrap items-center gap-1 mt-0.5">
                      <span>{fRp(item.harga)}/{item.satuan}</span>
                      {isUkuran && (
                        <span className="font-mono px-1 py-0.2 rounded bg-blue-50 text-blue-700 font-semibold">
                          {dimStr}
                        </span>
                      )}
                      {item.bahan && (
                        <span className="px-1 py-0.2 rounded bg-emerald-50 text-emerald-800 font-medium">
                          {item.bahan}
                        </span>
                      )}
                      {item.diskonItem > 0 && (
                        <span className="text-red-600 font-bold">
                          Disc -{fRp(item.diskonItem)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Stepper + Subtotal + Trash */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <div className="flex items-center border border-stone-200 rounded-md overflow-hidden bg-stone-50">
                      <button
                        type="button"
                        onClick={() => {
                          const curQty = typeof item.qty === 'number' ? item.qty : parseFloat(String(item.qty).replace(',', '.')) || 1;
                          const delta = curQty <= 1 ? -0.1 : -1;
                          onUpdateQty(idx, delta);
                        }}
                        className="w-5 h-5 flex items-center justify-center font-bold text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                      >
                        -
                      </button>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={fDec(item.qty, 2).replace(/\.?0+$/, '')}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9.,]/g, '');
                          const parsed = parseFloat(val.replace(',', '.'));
                          if (!isNaN(parsed) && parsed > 0) {
                            if (onSetQty) {
                              onSetQty(idx, parsed);
                            } else {
                              onUpdateQty(idx, parsed - item.qty);
                            }
                          }
                        }}
                        onFocus={(e) => (e.target as HTMLInputElement).select()}
                        className="w-9 text-center text-xs font-black text-stone-900 bg-transparent focus:outline-none focus:bg-white font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const curQty = typeof item.qty === 'number' ? item.qty : parseFloat(String(item.qty).replace(',', '.')) || 1;
                          const delta = curQty < 1 ? 0.1 : 1;
                          onUpdateQty(idx, delta);
                        }}
                        className="w-5 h-5 flex items-center justify-center font-bold text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right min-w-[65px]">
                      <div className="text-xs font-black text-orange-700 font-mono tabular-nums">
                        {fRp(itemTotal)}
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(idx)}
                      className="p-1 rounded text-stone-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                      title="Hapus Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* 4. Docked Quick-Checkout Bar - ALWAYS VISIBLE WITHOUT SCROLLING */}
      <div className="border-t border-stone-200 bg-white p-2 sm:p-2.5 shrink-0 shadow-xs space-y-1.5">
        {/* A. Subtotal & Quick Diskon/Pajak Trigger */}
        <div className="flex items-center justify-between text-xs px-0.5">
          <div className="text-stone-500 font-medium flex items-center gap-1.5">
            <span>Subtotal:</span>
            <span className="font-bold text-stone-800 font-mono tabular-nums">{fRp(subtotal)}</span>
          </div>

          <button
            type="button"
            onClick={() => setShowDiscounts(!showDiscounts)}
            className={`text-[10px] font-bold px-2 py-0.5 rounded-md transition flex items-center gap-1 ${
              hasCustomAdjustments
                ? 'bg-orange-100 text-orange-900 border border-orange-200'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Tag className="w-2.5 h-2.5 text-orange-700" />
            <span>
              {hasCustomAdjustments
                ? `Diskon/PPN (${[
                    discountPct > 0 ? `${discountPct}%` : null,
                    negoAmt > 0 ? `Nego ${fRp(negoAmt)}` : null,
                    taxPct > 0 ? `PPN ${taxPct}%` : null,
                  ].filter(Boolean).join(' • ')})`
                : '+ Diskon / Nego / PPN'}
            </span>
            {showDiscounts ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        {/* Collapsible Discounts & Taxes Row */}
        {showDiscounts && (
          <div className="p-1.5 bg-stone-50 rounded-lg border border-stone-200 grid grid-cols-3 gap-1.5 animate-in fade-in duration-150">
            <div>
              <label className="text-[9px] font-bold text-stone-500 block mb-0.5">Diskon (%)</label>
              <input
                type="text"
                inputMode="decimal"
                value={discountPct === 0 ? '' : discountPct}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                  const num = parseFloat(val.replace(',', '.'));
                  setDiscountPct(isNaN(num) ? 0 : Math.min(100, Math.max(0, num)));
                }}
                onFocus={(e) => (e.target as HTMLInputElement).select()}
                placeholder="0"
                className="w-full py-0.5 px-1 text-center border border-stone-200 rounded text-xs font-bold bg-white"
              />
            </div>
            <div>
              <label className="text-[9px] font-bold text-stone-500 block mb-0.5">Nego (Rp)</label>
              <input
                type="text"
                inputMode="numeric"
                value={negoAmt === 0 ? '' : negoAmt}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  setNegoAmt(val ? parseInt(val, 10) : 0);
                }}
                onFocus={(e) => (e.target as HTMLInputElement).select()}
                placeholder="0"
                className="w-full py-0.5 px-1 text-center border border-stone-200 rounded text-xs font-bold bg-white"
              />
            </div>
            <div>
              <label className="text-[9px] font-bold text-stone-500 block mb-0.5">PPN (%)</label>
              <input
                type="text"
                inputMode="decimal"
                value={taxPct === 0 ? '' : taxPct}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                  const num = parseFloat(val.replace(',', '.'));
                  setTaxPct(isNaN(num) ? 0 : Math.min(100, Math.max(0, num)));
                }}
                onFocus={(e) => (e.target as HTMLInputElement).select()}
                placeholder="0"
                className="w-full py-0.5 px-1 text-center border border-stone-200 rounded text-xs font-bold bg-white"
              />
            </div>
          </div>
        )}

        {/* B. Prominent TOTAL TAGIHAN Header */}
        <div className="bg-stone-900 text-white px-2.5 py-1.5 rounded-lg flex items-center justify-between shadow-xs">
          <div>
            <div className="text-[9px] font-extrabold text-stone-400 tracking-wider">TOTAL TAGIHAN</div>
            <div className="text-[10px] text-stone-400 font-medium">
              {items.length === 0 ? '0 item' : `${items.length} jenis item`}
            </div>
          </div>
          <div className="text-right">
            <div className="text-base sm:text-lg font-black text-orange-400 font-mono tracking-tight tabular-nums">
              {fRp(total)}
            </div>
          </div>
        </div>

        {/* C. Fast Payment Method Buttons + DP & Status */}
        <div className="space-y-1 bg-stone-50 p-1.5 rounded-lg border border-stone-200">
          {/* Quick Payment Method Selector */}
          <div className="flex items-center gap-1.5">
            <div className="flex items-center justify-between gap-1 w-12 shrink-0">
              <span className="text-[9px] font-bold text-stone-500">Metode:</span>
            </div>
            <div className="grid grid-cols-4 gap-1 flex-1">
              {[
                { id: 'Tunai', label: 'Tunai', icon: Banknote },
                { id: 'Transfer', label: 'Transfer', icon: ArrowRightLeft },
                { id: 'QRIS', label: 'QRIS', icon: QrCode },
                { id: 'Debet', label: 'Debet', icon: CreditCard },
              ].map(({ id, label, icon: Icon }) => {
                const isActive = hasDp && payMethod === id;
                return (
                  <button
                    key={id}
                    type="button"
                    disabled={!hasDp}
                    onClick={() => handleSelectPaymentMethod(id)}
                    title={
                      !hasDp
                        ? 'Metode pembayaran dinonaktifkan karena belum ada pembayaran (Piutang Penuh)'
                        : `Pilih metode ${label}`
                    }
                    className={`py-1 px-1 rounded-md text-[10px] font-bold transition flex items-center justify-center gap-1 ${
                      !hasDp
                        ? 'bg-stone-100/90 border border-stone-200 text-stone-400 opacity-60 cursor-not-allowed select-none'
                        : isActive
                        ? 'bg-stone-900 text-white shadow-2xs ring-1 ring-stone-900 active:scale-95 cursor-pointer'
                        : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 active:scale-95 cursor-pointer'
                    }`}
                  >
                    <Icon className="w-2.5 h-2.5 shrink-0" />
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
            {!hasDp && (
              <span className="text-[8px] font-extrabold px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 shrink-0 select-none">
                Nonaktif
              </span>
            )}
          </div>

          {/* Nominal Bayar / DP Input + Uang Pas Shortcut */}
          <div className="flex items-center gap-1.5">
            <div className="w-12 shrink-0 text-[9px] font-bold text-stone-500">
              Bayar:
            </div>
            <div className="relative flex-1">
              <input
                type="text"
                inputMode="decimal"
                value={dpAmount}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9.,]/g, '');
                  setDpAmount(val);
                  const parsed = parseFloat(val.replace(',', '.')) || 0;
                  if (parsed > 0) {
                    if (!payMethod || payMethod === '-' || payMethod === '') {
                      setPayMethod('Tunai');
                    }
                  } else {
                    setPayMethod('');
                  }
                }}
                onFocus={(e) => (e.target as HTMLInputElement).select()}
                placeholder="0 (Belum Bayar)"
                className="w-full py-0.5 pl-2 pr-14 border border-stone-300 rounded-md text-xs font-black text-stone-900 bg-white font-mono tabular-nums focus:outline-none focus:border-orange-600 focus:ring-1 focus:ring-orange-600"
              />
              <button
                type="button"
                onClick={handleQuickUangPas}
                disabled={total <= 0}
                className="absolute right-0.5 top-1/2 -translate-y-1/2 text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition active:scale-95 disabled:opacity-40 cursor-pointer"
                title="Isi otomatis lunas sesuai total tagihan"
              >
                Uang Pas
              </button>
            </div>

            {/* Status Lunas / Sisa / Kembalian */}
            <div className="shrink-0 text-right min-w-[85px]">
              {kembalian > 0 ? (
                <div className="text-[9px] font-extrabold text-emerald-700 leading-tight">
                  <div>Kembalian:</div>
                  <div className="font-mono text-[11px] tabular-nums">{fRp(kembalian)}</div>
                </div>
              ) : sisa > 0 ? (
                <div className="text-[9px] font-extrabold text-red-600 leading-tight">
                  <div>{hasDp ? 'Sisa Piutang:' : 'Piutang Penuh:'}</div>
                  <div className="font-mono text-[11px] tabular-nums">{fRp(sisa)}</div>
                </div>
              ) : total > 0 ? (
                <div className="text-[10px] font-black text-emerald-700 flex items-center justify-end gap-0.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>✓ LUNAS</span>
                </div>
              ) : (
                <div className="text-[9px] text-stone-400 font-medium">-</div>
              )}
            </div>
          </div>
        </div>

        {/* Warning If Customer Empty */}
        {isCustomerEmpty && items.length > 0 && (
          <div className="p-1 bg-red-50 border border-red-200 rounded-md text-red-800 text-[10px] font-bold flex items-center gap-1">
            <AlertCircle className="w-3 h-3 text-red-600 shrink-0" />
            <span>Nama Pelanggan wajib diisi untuk melakukan transaksi!</span>
          </div>
        )}

        {/* D. Primary Transaction Action Buttons (Selesaikan Pembayaran, Cetak Struk & Invoice A5) */}
        <div className="flex flex-col gap-1.5 pt-0.5">
          {onCompletePayment && (
            <button
              onClick={onCompletePayment}
              disabled={isTransactionDisabled}
              title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Selesaikan Pembayaran & Sinkron ke ERVO Payroll'}
              className="w-full py-2 px-2.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-200" />
              <span>Selesaikan Pembayaran</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={onPrintThermal}
              disabled={isTransactionDisabled}
              title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Cetak Struk Thermal'}
              className="py-2 px-2.5 rounded-lg bg-stone-900 hover:bg-black text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5 text-orange-400" />
              <span>Cetak Struk</span>
            </button>

            <button
              onClick={onPrintA5}
              disabled={isTransactionDisabled}
              title={isCustomerEmpty ? 'Nama pelanggan / pemesan wajib diisi!' : 'Cetak Invoice A5'}
              className="py-2 px-2.5 rounded-lg bg-orange-700 hover:bg-orange-800 text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Invoice A5</span>
            </button>
          </div>
        </div>

        {/* E. Utility Actions (Nota Baru & Pelunasan) */}
        <div className="grid grid-cols-2 gap-1.5 pt-0.5">
          <button
            onClick={onNewInvoice}
            className="py-1 px-2 rounded-md border border-stone-200 text-stone-700 hover:bg-stone-100 text-[10px] font-bold flex items-center justify-center gap-1 transition active:scale-95 cursor-pointer"
          >
            <Plus className="w-3 h-3 text-stone-500" />
            <span>+ Nota Baru</span>
          </button>

          <button
            onClick={onOpenPelunasan}
            className="py-1 px-2 rounded-md border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 text-[10px] font-bold flex items-center justify-center gap-1 transition active:scale-95 cursor-pointer"
          >
            <BadgeDollarSign className="w-3 h-3 text-amber-700" />
            <span>Pelunasan Piutang</span>
          </button>
        </div>
      </div>
    </div>
  );
};
