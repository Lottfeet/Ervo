import React, { useState, useEffect } from 'react';
import { X, UserPlus, Edit3, Phone, MapPin, Tag, Percent, FileText, CheckCircle2, User } from 'lucide-react';
import { Customer } from '../types';
import { addCustomer, deleteCustomer } from '../services/gasService';
import { saveCustomerFirebase, deleteCustomerFirebase } from '../services/firebaseService';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCustomerAdded: (customer: Customer) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  initialName?: string;
  customerToEdit?: Customer | null;
  onOpenGasGuide?: () => void;
}

const KELAS_PRESETS = [
  { kelas: 'Reguler', diskon: 0, label: 'Reguler (0%)' },
  { kelas: 'Reseller', diskon: 10, label: 'Reseller (10%)' },
  { kelas: 'VIP', diskon: 15, label: 'VIP (15%)' },
  { kelas: 'Grosir', diskon: 20, label: 'Grosir (20%)' },
  { kelas: 'seller', diskon: 25, label: 'Seller (25%)' },
];

export const AddCustomerModal: React.FC<AddCustomerModalProps> = ({
  isOpen,
  onClose,
  onCustomerAdded,
  onShowToast,
  initialName = '',
  customerToEdit,
  onOpenGasGuide,
}) => {
  const [nama, setNama] = useState('');
  const [kelas, setKelas] = useState('Reguler');
  const [diskon, setDiskon] = useState<number | string>(0);
  const [telepon, setTelepon] = useState('');
  const [catatan, setCatatan] = useState('');
  const [alamat, setAlamat] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (customerToEdit) {
        setNama(customerToEdit.nama || '');
        setKelas(customerToEdit.kelas || 'Reguler');
        setDiskon(customerToEdit.diskon || 0);
        setTelepon(customerToEdit.telepon || '');
        setCatatan(customerToEdit.catatan || '');
        setAlamat(customerToEdit.alamat || '');
      } else if (initialName) {
        setNama(initialName);
        setKelas('Reguler');
        setDiskon(0);
        setTelepon('');
        setCatatan('');
        setAlamat('');
      } else {
        setNama('');
        setKelas('Reguler');
        setDiskon(0);
        setTelepon('');
        setCatatan('');
        setAlamat('');
      }
    }
  }, [isOpen, customerToEdit, initialName]);

  if (!isOpen) return null;

  const isEdit = Boolean(customerToEdit);

  const handleSelectPreset = (preset: { kelas: string; diskon: number }) => {
    setKelas(preset.kelas);
    setDiskon(preset.diskon);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = nama.trim();
    if (!cleanName) {
      onShowToast('Nama pelanggan wajib diisi!', 'error');
      return;
    }

    const newCust: Customer = {
      nama: cleanName,
      kelas: kelas.trim() || 'Reguler',
      diskon: typeof diskon === 'number' ? diskon : parseFloat(String(diskon).replace(',', '.')) || 0,
      telepon: telepon.trim(),
      catatan: catatan.trim(),
      alamat: alamat.trim(),
    };

    setIsSaving(true);
    try {
      if (isEdit && customerToEdit && customerToEdit.nama.trim().toLowerCase() !== cleanName.toLowerCase()) {
        const oldName = customerToEdit.nama.trim();
        await deleteCustomerFirebase(oldName).catch(() => {});
        await deleteCustomer(oldName).catch(() => {});
      }

      await saveCustomerFirebase(newCust).catch(() => {});
      const res = await addCustomer(newCust);
      if (isEdit) {
        onShowToast(`Data pelanggan "${cleanName}" berhasil diperbarui!`, 'success');
      } else {
        if (res.isSheetSynced) {
          onShowToast(res.message, 'success');
        } else if (res.needsScriptUpdate) {
          onShowToast(`Pelanggan "${cleanName}" tersimpan lokal. Silakan update Kode Apps Script v4 di Google Sheets agar tersinkron otomatis.`, 'info');
          if (onOpenGasGuide) {
            setTimeout(() => onOpenGasGuide(), 800);
          }
        } else {
          onShowToast(res.message, 'info');
        }
      }

      onCustomerAdded(res.customer || newCust);
      // Reset form
      setNama('');
      setKelas('Reguler');
      setDiskon(0);
      setTelepon('');
      setCatatan('');
      setAlamat('');
      onClose();
    } catch {
      onShowToast('Terjadi kesalahan saat menyimpan pelanggan', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-200">
        {/* Modal Header */}
        <div className={`p-4 text-white flex items-center justify-between ${isEdit ? 'bg-blue-800' : 'bg-orange-700'}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center font-bold">
              {isEdit ? <Edit3 className="w-5 h-5 text-white" /> : <UserPlus className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h3 className="font-extrabold text-white text-sm sm:text-base leading-tight">
                {isEdit ? 'Edit Data Pelanggan' : 'Tambah Pelanggan Baru'}
              </h3>
              <p className="text-[11px] text-orange-100 font-medium">
                Data otomatis tersimpan ke Firebase & Google Sheets
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
          {/* Nama Pelanggan */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-orange-700" />
              <span>Nama Pelanggan / Usaha <span className="text-red-500">*</span></span>
            </label>
            <input
              type="text"
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              placeholder="Contoh: HUMBEL, Toko Cahaya, Bpk Andi"
              className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
              required
              autoFocus
            />
          </div>

          {/* Quick Preset Kelas & Diskon */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-orange-700" />
              <span>Pilih Kategori & Diskon Khusus</span>
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {KELAS_PRESETS.map((p, idx) => {
                const isSelected = kelas.toLowerCase() === p.kelas.toLowerCase();
                return (
                  <button
                    key={`${p.kelas}-${idx}`}
                    type="button"
                    onClick={() => handleSelectPreset(p)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border ${
                      isSelected
                        ? 'bg-orange-700 text-white border-orange-800 shadow-xs'
                        : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {isSelected && <CheckCircle2 className="w-3 h-3 text-white" />}
                    <span>{p.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-bold text-stone-500 mb-0.5 block">Nama Kelas</label>
                <input
                  type="text"
                  value={kelas}
                  onChange={(e) => setKelas(e.target.value)}
                  placeholder="Reguler / Reseller / VIP"
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs font-semibold bg-white focus:outline-none focus:border-orange-600"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-stone-500 mb-0.5 flex items-center gap-1">
                  <Percent className="w-3 h-3 text-stone-400" /> Diskon Default (%)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={diskon}
                  onChange={(e) => setDiskon(e.target.value.replace(/[^0-9.,]/g, ''))}
                  onFocus={(e) => (e.target as HTMLInputElement).select()}
                  placeholder="0"
                  className="w-full p-2 border border-stone-300 rounded-lg text-xs font-semibold bg-white focus:outline-none focus:border-orange-600"
                />
              </div>
            </div>
          </div>

          {/* Telepon / WA */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-stone-500" />
              <span>No. Telepon / WhatsApp</span>
            </label>
            <input
              type="text"
              value={telepon}
              onChange={(e) => setTelepon(e.target.value)}
              placeholder="Contoh: 0821 1963 7682"
              className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
            />
          </div>

          {/* Alamat */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-stone-500" />
              <span>Alamat Lengkap</span>
            </label>
            <textarea
              rows={2}
              value={alamat}
              onChange={(e) => setAlamat(e.target.value)}
              placeholder="Jl. HOS Cokroaminoto No.19, Ciamis - Jawa Barat"
              className="w-full p-2 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:border-orange-600"
            />
          </div>

          {/* Catatan */}
          <div>
            <label className="text-[11px] font-bold text-stone-700 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-stone-500" />
              <span>Catatan Khusus (Opsional)</span>
            </label>
            <input
              type="text"
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="Contoh: Pelanggan prioritas cetakbanner"
              className="w-full p-2 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:border-orange-600"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100 transition"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className={`px-5 py-2 rounded-xl text-white text-xs font-bold shadow-xs transition active:scale-95 disabled:opacity-50 flex items-center gap-1.5 ${
                isEdit ? 'bg-blue-800 hover:bg-blue-900' : 'bg-orange-700 hover:bg-orange-800'
              }`}
            >
              {isEdit ? <Edit3 className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
              <span>{isSaving ? 'Menyimpan...' : isEdit ? 'Simpan Perubahan' : 'Simpan Pelanggan'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
