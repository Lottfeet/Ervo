import React, { useState, useEffect } from 'react';
import { X, Plus, Calculator, FileText, Tag, CornerDownRight } from 'lucide-react';
import { Product, InvoiceItem } from '../types';
import { fRp, fDec } from '../utils/formatters';

interface SpecModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (item: InvoiceItem) => void;
}

// Helper to parse decimal numbers safely supporting both comma (0,1) and dot (0.1)
export const parseDecimal = (val: string | number | undefined | null): number => {
  if (val === undefined || val === null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const cleaned = String(val).trim().replace(',', '.');
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
};

export const SpecModal: React.FC<SpecModalProps> = ({
  product,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [panjang, setPanjang] = useState<string>('');
  const [lebar, setLebar] = useState<string>('');
  const [qtyInput, setQtyInput] = useState<string>('1');
  const [bahan, setBahan] = useState<string>('');
  const [catatan, setCatatan] = useState<string>('');
  const [diskonInput, setDiskonInput] = useState<string>('');
  const [catatanError, setCatatanError] = useState<string | null>(null);

  useEffect(() => {
    if (product) {
      setPanjang('');
      setLebar('');
      setQtyInput('1');
      setBahan('');
      setCatatan('');
      setDiskonInput('');
      setCatatanError(null);
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const isUkuran = product.tipeHarga === 'ukuran';
  const pVal = parseDecimal(panjang);
  const lVal = parseDecimal(lebar);
  const area = pVal * lVal;

  const diskonItem = parseDecimal(diskonInput);
  const hargaSatuanBase = product.harga || 0;
  const hargaSatuanJadi = Math.max(0, hargaSatuanBase - diskonItem);

  const qtyParsed = parseDecimal(qtyInput);
  const effectiveQty = qtyParsed > 0 ? qtyParsed : 0;

  let finalTotal = 0;
  let breakdown = '';
  let label = '';

  if (isUkuran) {
    finalTotal = effectiveQty * area * hargaSatuanJadi;
    breakdown =
      effectiveQty !== 1
        ? `${fDec(pVal, 2)}m × ${fDec(lVal, 2)}m × ${fRp(hargaSatuanJadi)}/m² × ${fDec(effectiveQty, 2)} pcs`
        : `${fDec(pVal, 2)}m × ${fDec(lVal, 2)}m × ${fRp(hargaSatuanJadi)}/m²`;
    label = 'Ukuran × Harga/m²';
  } else {
    finalTotal = effectiveQty * hargaSatuanJadi;
    breakdown = `${fDec(effectiveQty, 2)} ${product.satuan || 'pcs'} × ${fRp(hargaSatuanJadi)}`;
    label = 'Qty × Harga Satuan';
  }

  const handleAdjustQty = (delta: number) => {
    const cur = parseDecimal(qtyInput);
    const next = Math.max(0.01, parseFloat((cur + delta).toFixed(2)));
    setQtyInput(String(next));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalQty = parseDecimal(qtyInput);
    if (finalQty <= 0) {
      alert('Mohon masukkan Jumlah / Qty yang valid (lebih dari 0, contoh: 0.1 atau 1).');
      return;
    }

    if (isUkuran && (pVal <= 0 || lVal <= 0)) {
      alert('Mohon isi ukuran panjang dan lebar dalam meter.');
      return;
    }

    if (!catatan.trim()) {
      setCatatanError('Catatan/ Nama File Cetak wajib diisi.');
      return;
    }

    onConfirm({
      kode: product.kode,
      nama: product.nama,
      harga: product.harga,
      satuan: product.satuan || 'pcs',
      tipeHarga: product.tipeHarga || 'fix',
      qty: finalQty,
      panjang: pVal,
      lebar: lVal,
      bahan: bahan.trim(),
      catatan: catatan.trim(),
      diskonItem,
      totalItem: finalTotal,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div>
            <h3 className="font-extrabold text-stone-900 text-base">{product.nama}</h3>
            <p className="text-xs text-stone-500 font-medium">
              Harga Base: {fRp(product.harga)} / {product.satuan || 'pcs'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Ukuran (Panjang x Lebar) */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1.5 flex items-center justify-between">
              <span>Ukuran (Meter)</span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                  isUkuran ? 'bg-blue-50 text-blue-700' : 'bg-stone-100 text-stone-500'
                }`}
              >
                {isUkuran ? 'Otomatis hitung harga' : 'Catatan dimensi saja'}
              </span>
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                inputMode="decimal"
                value={panjang}
                onChange={(e) => {
                  const clean = e.target.value.replace(/[^0-9.,]/g, '');
                  setPanjang(clean);
                }}
                onFocus={(e) => e.target.select()}
                placeholder="Panjang (m)"
                className="w-full text-center py-2 px-3 border border-stone-200 rounded-lg text-sm font-semibold focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
              />
              <span className="font-bold text-stone-400">×</span>
              <input
                type="text"
                inputMode="decimal"
                value={lebar}
                onChange={(e) => {
                  const clean = e.target.value.replace(/[^0-9.,]/g, '');
                  setLebar(clean);
                }}
                onFocus={(e) => e.target.select()}
                placeholder="Lebar (m)"
                className="w-full text-center py-2 px-3 border border-stone-200 rounded-lg text-sm font-semibold focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
              />
              <div className="bg-orange-50 text-orange-700 px-3 py-2 rounded-lg text-xs font-extrabold whitespace-nowrap shrink-0 border border-orange-200">
                {area > 0 ? `${fDec(area, 2)} m²` : '0 m²'}
              </div>
            </div>
          </div>

          {/* Qty Stepper */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1.5 block">
              Jumlah / Qty ({product.satuan || 'pcs'})
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleAdjustQty(-1)}
                className="w-9 h-9 rounded-lg border border-stone-200 bg-stone-50 text-stone-700 hover:bg-orange-50 hover:border-orange-300 font-bold text-base flex items-center justify-center transition active:scale-95 cursor-pointer"
              >
                -
              </button>
              <input
                type="text"
                inputMode="decimal"
                value={qtyInput}
                onChange={(e) => {
                  // Allow numbers, dot, comma (misal 0.1 atau 0,1)
                  const clean = e.target.value.replace(/[^0-9.,]/g, '');
                  // Ensure at most one decimal separator
                  const parts = clean.split(/[.,]/);
                  let sanitized = clean;
                  if (parts.length > 2) {
                    const sep = clean.includes('.') ? '.' : ',';
                    sanitized = parts[0] + sep + parts.slice(1).join('');
                  }
                  setQtyInput(sanitized);
                }}
                onFocus={(e) => e.target.select()}
                onBlur={() => {
                  const val = parseDecimal(qtyInput);
                  if (val <= 0 || !qtyInput.trim()) {
                    setQtyInput('1');
                  }
                }}
                placeholder="1"
                className="w-24 text-center py-2 border border-stone-200 rounded-lg text-sm font-bold focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
              />
              <button
                type="button"
                onClick={() => handleAdjustQty(1)}
                className="w-9 h-9 rounded-lg border border-stone-200 bg-stone-50 text-stone-700 hover:bg-orange-50 hover:border-orange-300 font-bold text-base flex items-center justify-center transition active:scale-95 cursor-pointer"
              >
                +
              </button>
              <span className="text-xs font-semibold text-stone-500 ml-1">
                {product.satuan || 'pcs'}
              </span>
            </div>
          </div>

          {/* Bahan & Finishing */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1.5 block">
              Finishing / Bahan / Ring
            </label>
            <input
              type="text"
              list="bahanDatalist"
              value={bahan}
              onChange={(e) => setBahan(e.target.value)}
              placeholder="cth: Mata Itik 4 Sudut, Laminasi Doff, Lipat Saja..."
              className="w-full py-2 px-3 border border-stone-200 rounded-lg text-xs font-medium focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
            />
            <datalist id="bahanDatalist">
              <option value="Mata Itik 4 Sudut" />
              <option value="Lebih Bahan 5cm" />
              <option value="Solobong Atas Bawah" />
              <option value="Lipat Saja (Tanpa Ring)" />
              <option value="Laminasi Doff" />
              <option value="Laminasi Glossy" />
              <option value="DieCut Sesuai Pola" />
              <option value="KissCut Stiker Sheet" />
            </datalist>
          </div>

          {/* Catatan/ Nama File Cetak (Wajib Diisi) */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <span>Catatan/ Nama File Cetak</span>
                <span className="text-red-500 font-bold">*</span>
              </span>
              <span className="text-[10px] font-semibold text-red-600 bg-red-50 px-1.5 py-0.5 rounded border border-red-100">
                Wajib diisi
              </span>
            </label>
            <input
              type="text"
              required
              value={catatan}
              onChange={(e) => {
                setCatatan(e.target.value);
                if (catatanError) setCatatanError(null);
              }}
              placeholder="cth: File di WhatsApp 'Budi_Spanduk.pdf', siap cetak..."
              className={`w-full py-2 px-3 border rounded-lg text-xs font-medium focus:outline-none focus:ring-2 transition ${
                catatanError
                  ? 'border-red-500 bg-red-50/40 focus:border-red-600 focus:ring-red-100'
                  : 'border-stone-200 focus:border-orange-600 focus:ring-orange-100'
              }`}
            />
            {catatanError && (
              <p className="text-[11px] text-red-600 font-semibold mt-1">
                {catatanError}
              </p>
            )}
          </div>

          {/* Diskon Item Rp */}
          <div>
            <label className="text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
              <span>Diskon Satuan / Harga Nego (Rp)</span>
              {diskonItem > 0 && (
                <button
                  type="button"
                  onClick={() => setDiskonInput('')}
                  className="text-[10px] text-red-600 hover:underline font-semibold cursor-pointer"
                >
                  Reset Diskon
                </button>
              )}
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-stone-400">
                Rp
              </span>
              <input
                type="text"
                inputMode="numeric"
                value={diskonInput}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  setDiskonInput(val);
                }}
                onFocus={(e) => e.target.select()}
                className="w-full pl-8 py-2 pr-3 border border-stone-200 rounded-lg text-xs font-bold text-red-700 focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
                placeholder="0"
              />
            </div>
          </div>

          {/* Price Preview Box */}
          <div className="p-3.5 rounded-xl bg-orange-50 border border-orange-200 text-center space-y-1">
            <div className="text-[11px] font-bold text-orange-800 uppercase tracking-wider">
              {label}
            </div>
            <div className="text-xs text-stone-600 font-medium">{breakdown}</div>
            {diskonItem > 0 && (
              <div className="text-xs font-semibold text-red-700">
                Potongan Harga: -{fRp(diskonItem)} / {isUkuran ? 'm²' : product.satuan || 'pcs'}
              </div>
            )}
            <div className="text-xl font-extrabold text-orange-700 pt-1">
              {fRp(finalTotal)}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-stone-200 text-stone-600 text-xs font-semibold hover:bg-stone-50 transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-orange-700 hover:bg-orange-800 text-white text-xs font-bold shadow-xs transition active:scale-95 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah ke Order</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
