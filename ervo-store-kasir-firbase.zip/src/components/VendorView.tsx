import React, { useState, useEffect } from 'react';
import { Vendor } from '../types';
import { subscribeVendors } from '../services/firebaseService';
import { 
  getStoredVendors, 
  fetchVendorsFromFirebase, 
  saveVendorRecord, 
  deleteVendorRecord,
  resetDefaultVendors 
} from '../services/vendorService';
import { 
  Building2, 
  Search, 
  Plus, 
  Phone, 
  MapPin, 
  CreditCard, 
  FileText, 
  User, 
  Mail, 
  Edit3, 
  Trash2, 
  PackagePlus, 
  Copy, 
  Check, 
  ExternalLink,
  Tag,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  X
} from 'lucide-react';

interface VendorViewProps {
  onNavigateToBarangMasuk: (vendorName?: string) => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

const CATEGORY_OPTIONS = [
  'Tekstil & Garment',
  'Banner & Digital Printing',
  'Kertas & Offset',
  'Tinta & Sparepart',
  'Sticker & Display',
  'Akrilik & Display',
  'Umum',
];

export const VendorView: React.FC<VendorViewProps> = ({
  onNavigateToBarangMasuk,
  onShowToast,
}) => {
  const [vendors, setVendors] = useState<Vendor[]>(() => getStoredVendors());
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedRekeningId, setCopiedRekeningId] = useState<string | null>(null);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [vendorToDelete, setVendorToDelete] = useState<Vendor | null>(null);

  // Form State
  const [formNama, setFormNama] = useState<string>('');
  const [formKategori, setFormKategori] = useState<string>('Umum');
  const [formTelepon, setFormTelepon] = useState<string>('');
  const [formEmail, setFormEmail] = useState<string>('');
  const [formAlamat, setFormAlamat] = useState<string>('');
  const [formKontakPerson, setFormKontakPerson] = useState<string>('');
  const [formNomorRekening, setFormNomorRekening] = useState<string>('');
  const [formCatatan, setFormCatatan] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Background sync and restore event listeners
  useEffect(() => {
    fetchVendorsFromFirebase().then((data) => {
      if (data && data.length > 0) {
        setVendors(data);
      }
    });

    const unsub = subscribeVendors((list) => {
      if (list && list.length > 0) {
        setVendors(list);
      }
    });

    const handleSync = () => {
      setVendors(getStoredVendors());
    };
    window.addEventListener('strukku-backup-restored', handleSync);
    window.addEventListener('strukku-vendors-updated', handleSync);

    return () => {
      unsub();
      window.removeEventListener('strukku-backup-restored', handleSync);
      window.removeEventListener('strukku-vendors-updated', handleSync);
    };
  }, []);

  const handleOpenAddModal = () => {
    setEditingVendor(null);
    setFormNama('');
    setFormKategori('Umum');
    setFormTelepon('');
    setFormEmail('');
    setFormAlamat('');
    setFormKontakPerson('');
    setFormNomorRekening('');
    setFormCatatan('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (vendor: Vendor) => {
    setEditingVendor(vendor);
    setFormNama(vendor.nama);
    setFormKategori(vendor.kategori || 'Umum');
    setFormTelepon(vendor.telepon || '');
    setFormEmail(vendor.email || '');
    setFormAlamat(vendor.alamat || '');
    setFormKontakPerson(vendor.kontakPerson || '');
    setFormNomorRekening(vendor.nomorRekening || '');
    setFormCatatan(vendor.catatan || '');
    setIsModalOpen(true);
  };

  const handleSaveVendor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNama.trim()) {
      onShowToast('Nama vendor / supplier wajib diisi!', 'error');
      return;
    }

    setIsSaving(true);
    try {
      const saved = await saveVendorRecord({
        id: editingVendor ? editingVendor.id : undefined,
        nama: formNama,
        kategori: formKategori,
        telepon: formTelepon,
        email: formEmail,
        alamat: formAlamat,
        kontakPerson: formKontakPerson,
        nomorRekening: formNomorRekening,
        catatan: formCatatan,
      });

      setVendors((prev) => {
        const idx = prev.findIndex((v) => v.id === saved.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = saved;
          return updated;
        }
        return [saved, ...prev];
      });

      setIsModalOpen(false);
      onShowToast(
        editingVendor
          ? `Data vendor "${saved.nama}" berhasil diperbarui`
          : `Vendor "${saved.nama}" berhasil ditambahkan`,
        'success'
      );
    } catch (err) {
      console.error(err);
      onShowToast('Gagal menyimpan data vendor', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteVendor = async () => {
    if (!vendorToDelete) return;
    try {
      await deleteVendorRecord(vendorToDelete.id);
      setVendors((prev) => prev.filter((v) => v.id !== vendorToDelete.id));
      onShowToast(`Vendor "${vendorToDelete.nama}" berhasil dihapus`, 'info');
      setVendorToDelete(null);
    } catch (err) {
      console.error(err);
      onShowToast('Gagal menghapus vendor', 'error');
    }
  };

  const handleCopyRekening = (text: string, id: string) => {
    if (!text || text === '-') return;
    navigator.clipboard.writeText(text);
    setCopiedRekeningId(id);
    onShowToast('Nomor rekening disalin ke clipboard', 'success');
    setTimeout(() => {
      setCopiedRekeningId((cur) => (cur === id ? null : cur));
    }, 2000);
  };

  // Filter logic
  const filteredVendors = vendors.filter((v) => {
    const q = searchTerm.toLowerCase().trim();
    const matchesSearch =
      !q ||
      v.nama.toLowerCase().includes(q) ||
      (v.kontakPerson && v.kontakPerson.toLowerCase().includes(q)) ||
      (v.telepon && v.telepon.toLowerCase().includes(q)) ||
      (v.alamat && v.alamat.toLowerCase().includes(q)) ||
      (v.catatan && v.catatan.toLowerCase().includes(q));

    const matchesCategory =
      selectedCategory === 'all' ||
      (v.kategori && v.kategori.toLowerCase() === selectedCategory.toLowerCase());

    return matchesSearch && matchesCategory;
  });

  const allCategories = Array.from(
    new Set(vendors.map((v) => v.kategori).filter(Boolean) as string[])
  );

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Banner Header */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-indigo-600 rounded-xl text-white shrink-0 shadow-md">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight flex items-center gap-2.5 flex-wrap">
              <span>Database & Daftar Vendor Suplier</span>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-500/40 uppercase">
                {vendors.length} Vendor Terdaftar
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-1 max-w-2xl leading-relaxed">
              Pusat kelola master rekanan suplier bahan baku, kontak PIC, nomor rekening pembayaran transfer, dan shortcut pembuatan Faktur PO barang masuk.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 w-full md:w-auto">
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Muat ulang suplier bawaan? Rekanan yang sudah ada akan tetap digabungkan dengan suplier rekomendasi.')) {
                const defs = resetDefaultVendors();
                setVendors(defs);
                onShowToast('Daftar suplier bawaan berhasil dimuat!', 'success');
              }
            }}
            className="px-3 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 border border-stone-700 active:scale-95"
            title="Muat Ulang Suplier Bawaan"
          >
            <RotateCcw className="w-3.5 h-3.5 text-stone-400" />
            <span className="hidden sm:inline">Suplier Bawaan</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigateToBarangMasuk()}
            className="px-3.5 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 border border-stone-700 active:scale-95 flex-1 md:flex-initial"
          >
            <PackagePlus className="w-4 h-4 text-indigo-400" />
            <span>Ke Barang Masuk</span>
          </button>
          <button
            type="button"
            onClick={handleOpenAddModal}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition active:scale-95 shrink-0 flex-1 md:flex-initial"
          >
            <Plus className="w-4 h-4" />
            <span>+ Tambah Vendor</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        <div className="bg-white border border-stone-200 rounded-xl p-3 shadow-2xs">
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Total Rekanan</div>
          <div className="text-lg font-black text-stone-900 mt-0.5">{vendors.length} Suplier</div>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-3 shadow-2xs">
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Kategori Bahan</div>
          <div className="text-lg font-black text-indigo-700 mt-0.5">{allCategories.length || 1} Kategori</div>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-3 shadow-2xs">
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Rekening Terdata</div>
          <div className="text-lg font-black text-emerald-700 mt-0.5">
            {vendors.filter((v) => v.nomorRekening && v.nomorRekening !== '-').length} Bank
          </div>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-3 shadow-2xs">
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Kontak WhatsApp</div>
          <div className="text-lg font-black text-amber-700 mt-0.5">
            {vendors.filter((v) => v.telepon && v.telepon !== '-').length} PIC Aktif
          </div>
        </div>
      </div>

      {/* Controls Bar: Search & Category Filter */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-stone-200 shadow-2xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            placeholder="Cari nama vendor, kontak PIC, telepon, alamat, atau spesialisasi..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1 sm:pb-0">
          <span className="text-xs font-bold text-stone-400 whitespace-nowrap pl-1">Kategori:</span>
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-stone-900 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Semua ({vendors.length})
          </button>
          {allCategories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                selectedCategory.toLowerCase() === cat.toLowerCase()
                  ? 'bg-indigo-700 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Vendor Cards Grid */}
      {filteredVendors.length === 0 ? (
        <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center shadow-2xs">
          <div className="w-14 h-14 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-400 mx-auto mb-3">
            <Building2 className="w-7 h-7" />
          </div>
          <h3 className="font-black text-stone-800 text-base">Tidak Ada Vendor Ditemukan</h3>
          <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
            {searchTerm || selectedCategory !== 'all'
              ? 'Tidak ada vendor yang cocok dengan filter atau kata kunci pencarian Anda.'
              : 'Belum ada data vendor. Silakan tambahkan vendor pertama Anda.'}
          </p>
          <button
            type="button"
            onClick={handleOpenAddModal}
            className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>+ Tambah Vendor Baru</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
          {filteredVendors.map((vendor) => {
            const hasPhone = vendor.telepon && vendor.telepon !== '-';
            const cleanPhone = hasPhone ? vendor.telepon.replace(/[^0-9]/g, '') : '';
            const waLink = cleanPhone ? `https://wa.me/${cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone}` : null;

            return (
              <div
                key={vendor.id}
                className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between gap-3 relative group"
              >
                {/* Card Top: Name & Category Badge */}
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 inline-block mb-1">
                        {vendor.kategori || 'Umum'}
                      </span>
                      <h3 className="font-black text-stone-900 text-sm leading-snug break-words">
                        {vendor.nama}
                      </h3>
                    </div>

                    {/* Edit & Delete Quick Icons */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(vendor)}
                        className="p-1.5 text-stone-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                        title="Edit Vendor"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setVendorToDelete(vendor)}
                        className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                        title="Hapus Vendor"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Detail items */}
                  <div className="space-y-1.5 pt-2 border-t border-stone-100 text-xs">
                    {/* PIC & Phone */}
                    <div className="flex items-center justify-between gap-2 text-stone-700">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <User className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="font-semibold truncate">
                          {vendor.kontakPerson || 'PIC Tidak Tercatat'}
                        </span>
                      </div>

                      {hasPhone && (
                        <div className="flex items-center gap-1 shrink-0">
                          {waLink && (
                            <a
                              href={waLink}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded-md flex items-center gap-1 transition"
                              title="Chat WhatsApp"
                            >
                              <Phone className="w-3 h-3" />
                              <span>{vendor.telepon}</span>
                            </a>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Email if any */}
                    {vendor.email && vendor.email !== '-' && (
                      <div className="flex items-center gap-1.5 text-stone-600 text-[11px]">
                        <Mail className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="truncate">{vendor.email}</span>
                      </div>
                    )}

                    {/* Alamat */}
                    {vendor.alamat && vendor.alamat !== '-' && (
                      <div className="flex items-start gap-1.5 text-stone-600 text-[11px] leading-tight">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{vendor.alamat}</span>
                      </div>
                    )}

                    {/* Rekening Transfer */}
                    {vendor.nomorRekening && vendor.nomorRekening !== '-' && (
                      <div className="p-2 bg-stone-50 border border-stone-200/80 rounded-xl flex items-center justify-between gap-2 text-[11px] mt-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <CreditCard className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                          <span className="font-mono font-bold text-stone-800 truncate">
                            {vendor.nomorRekening}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyRekening(vendor.nomorRekening || '', vendor.id)}
                          className="p-1 text-stone-400 hover:text-indigo-600 rounded transition shrink-0"
                          title="Salin Nomor Rekening"
                        >
                          {copiedRekeningId === vendor.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    )}

                    {/* Catatan / Spesialisasi */}
                    {vendor.catatan && (
                      <div className="p-2 bg-amber-50/50 border border-amber-200/60 rounded-xl text-[11px] text-amber-900 leading-snug flex items-start gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{vendor.catatan}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Bottom: Primary Shortcut "Buat PO / Restock" */}
                <div className="pt-2 border-t border-stone-100 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onNavigateToBarangMasuk(vendor.nama)}
                    className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-xs font-black rounded-xl shadow-2xs flex items-center justify-center gap-1.5 transition"
                  >
                    <PackagePlus className="w-3.5 h-3.5" />
                    <span>Buat PO dari Vendor Ini</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Add / Edit Vendor */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
          <div className="bg-white border border-stone-200 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl space-y-0">
            {/* Modal Header */}
            <div className="px-5 py-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-600 text-white rounded-xl">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-white">
                    {editingVendor ? 'Edit Data Vendor' : 'Tambah Vendor Baru'}
                  </h3>
                  <p className="text-[11px] text-stone-300">
                    Isi detail master rekanan suplier untuk faktur barang masuk
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-stone-400 hover:text-white rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveVendor} className="p-5 space-y-3.5">
              {/* Nama Vendor */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nama Perusahaan / Vendor <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PT. KNITTO TEKSTIL INDONESIA"
                  value={formNama}
                  onChange={(e) => setFormNama(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              {/* Kategori & PIC */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Kategori / Spesialisasi
                  </label>
                  <select
                    value={formKategori}
                    onChange={(e) => setFormKategori(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-semibold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {CATEGORY_OPTIONS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nama PIC / Kontak Person
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Bpk. Hendra"
                    value={formKontakPerson}
                    onChange={(e) => setFormKontakPerson(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* No Telepon & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    No. Telepon / WhatsApp
                  </label>
                  <input
                    type="text"
                    placeholder="0812-3456-7890"
                    value={formTelepon}
                    onChange={(e) => setFormTelepon(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Email Vendor
                  </label>
                  <input
                    type="email"
                    placeholder="sales@vendor.com"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Nomor Rekening Bank */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nomor Rekening Pembayaran Transfer
                </label>
                <input
                  type="text"
                  placeholder="Contoh: BCA 0088-291-331 a.n PT Knitto Tekstil"
                  value={formNomorRekening}
                  onChange={(e) => setFormNomorRekening(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              {/* Alamat */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Alamat Kantor / Gudang Suplier
                </label>
                <input
                  type="text"
                  placeholder="Jl. Raya Industri No. 12..."
                  value={formAlamat}
                  onChange={(e) => setFormAlamat(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              {/* Catatan Khusus */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Catatan / Spesifikasi Bahan
                </label>
                <textarea
                  rows={2}
                  placeholder="Ketentuan minimal order, tempo pembayaran, bahan baku yang disuplai..."
                  value={formCatatan}
                  onChange={(e) => setFormCatatan(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              {/* Modal Actions */}
              <div className="pt-2 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50"
                >
                  {isSaving ? 'Menyimpan...' : editingVendor ? 'Simpan Perubahan' : 'Tambah Vendor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {vendorToDelete && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white border border-stone-200 rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-100 text-red-700 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-sm text-stone-900">Hapus Vendor?</h3>
                <p className="text-xs text-stone-500">
                  Data rekanan &quot;{vendorToDelete.nama}&quot; akan dihapus dari daftar master.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setVendorToDelete(null)}
                className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteVendor}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-xs transition active:scale-95"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
