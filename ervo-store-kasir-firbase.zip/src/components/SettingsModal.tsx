import React, { useState, useEffect } from 'react';
import { 
  X, 
  Settings, 
  Store, 
  Link, 
  CheckCircle2, 
  AlertCircle, 
  RotateCw, 
  Save, 
  PlugZap, 
  ChevronDown,
  Users,
  UserPlus,
  ShieldCheck,
  Lock,
  KeyRound,
  Clock,
  CreditCard,
  Trash2,
  Database,
  Flame,
  Zap,
  ArrowRight,
  Activity,
  BarChart3,
  TrendingDown,
  RotateCcw,
  Info,
  FileSpreadsheet
} from 'lucide-react';
import { StoreSettings, KasirUser, Customer, Product, ExpenseRecord } from '../types';
import { checkIsSpvOrOwner } from '../utils/formatters';
import { getSheetUrl, setSheetUrl, gasGet, updateKasirPassword, initSheetsRemote, saveSettingsRemote, clearLocalCache, getLocalProducts, getLocalStockInHistory } from '../services/gasService';
import { getStoredExpenses } from '../services/expenseService';
import { migrateAllDataToFirebase, saveSettingsFirebase } from '../services/firebaseService';
import { 
  getFirestoreQuotaMetrics, 
  subscribeQuotaMetrics, 
  resetFirestoreDailyMetrics, 
  QuotaMetrics, 
  FIRESTORE_SPARK_LIMITS 
} from '../services/firestoreQuotaService';
import { 
  ERVO_PAYROLL_DB_ID, 
  ERVO_PAYROLL_COLLECTION, 
  BUSINESS_UNIT_NAME, 
  flushPayrollOfflineQueue 
} from '../services/payrollSyncService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  kasirList: string[];
  kasirUsers?: KasirUser[];
  customers?: Customer[];
  currentUser?: string | null;
  onUpdateKasirUsers?: (users: KasirUser[]) => void;
  onSaveSettings: (newSettings: StoreSettings) => void;
  onSync: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onOpenAddCustomer?: () => void;
  onOpenGasGuide?: () => void;
  onOpenBackup?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  kasirList = [],
  kasirUsers = [],
  customers = [],
  currentUser,
  onUpdateKasirUsers,
  onSaveSettings,
  onSync,
  onShowToast,
  onOpenAddCustomer,
  onOpenGasGuide,
  onOpenBackup,
}) => {
  const [url, setUrl] = useState(getSheetUrl());
  const [testing, setTesting] = useState(false);
  const [initializing, setInitializing] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [autoLogoutMin, setAutoLogoutMin] = useState<number>(settings.autoLogoutMinutes ?? 15);
  const [rekeningText, setRekeningText] = useState<string>(settings.rekening || '');

  // Add Kasir State & Permission Controls
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAddKasirOpen, setIsAddKasirOpen] = useState(false);
  const [authSpvUser, setAuthSpvUser] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  const [newKasirName, setNewKasirName] = useState('');
  const [newKasirRole, setNewKasirRole] = useState<'Kasir' | 'SPV' | 'Owner'>('Kasir');
  const [newKasirPass, setNewKasirPass] = useState('');
  const [isSavingNewKasir, setIsSavingNewKasir] = useState(false);

  // Firebase Migration State
  const [isMigratingFirebase, setIsMigratingFirebase] = useState(false);
  const [migrationStats, setMigrationStats] = useState<Record<string, number> | null>(null);
  const [migrationProgress, setMigrationProgress] = useState<{
    current: number;
    total: number;
    stage: string;
    percent: number;
  } | null>(null);

  // Firestore Quota Monitoring State
  const [quotaMetrics, setQuotaMetrics] = useState<QuotaMetrics>(getFirestoreQuotaMetrics());
  const [showQuotaDetails, setShowQuotaDetails] = useState(false);
  const [isFlushingQueue, setIsFlushingQueue] = useState(false);
  const [flushMsg, setFlushMsg] = useState('');

  const handleFlushPayrollQueue = async () => {
    setIsFlushingQueue(true);
    setFlushMsg('');
    try {
      const count = await flushPayrollOfflineQueue();
      setFlushMsg(`Sinkronisasi selesai! ${count} transaksi terunggah ke ERVO Payroll.`);
    } catch {
      setFlushMsg('Sinkronisasi selesai diproses.');
    } finally {
      setIsFlushingQueue(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    setQuotaMetrics(getFirestoreQuotaMetrics());
    const unsub = subscribeQuotaMetrics((metrics) => {
      setQuotaMetrics(metrics);
    });
    return unsub;
  }, [isOpen]);

  const handleMigrateToFirebase = async () => {
    // Proteksi Hak Akses: Hanya Owner atau SPV yang boleh melakukan migrasi database cloud
    const activeUser = (currentUser || localStorage.getItem('strukku_logged_kasir') || settings.cashier || '').trim();
    if (!checkIsSpvOrOwner(activeUser, kasirUsers)) {
      onShowToast('Akses Ditolak: Hanya Owner atau SPV yang boleh melakukan migrasi database cloud!', 'error');
      return;
    }

    setIsMigratingFirebase(true);
    setMigrationStats(null);
    setMigrationProgress({ current: 0, total: 100, stage: 'Mempersiapkan data dan membuat batch...', percent: 0 });
    try {
      // Gather current local & sync data
      const localProds = getLocalProducts();
      const localStockIn = getLocalStockInHistory();
      const localExpenses = getStoredExpenses();

      // Gather recent invoices from local storage
      let recentInvoices: any[] = [];
      try {
        const rawInv = localStorage.getItem('strukku_recent_invoices');
        if (rawInv) recentInvoices = JSON.parse(rawInv);
      } catch {}

      const res = await migrateAllDataToFirebase(
        {
          products: localProds,
          customers: customers,
          kasirUsers: kasirUsers,
          settings: settings,
          expenses: localExpenses,
          stockIn: localStockIn,
          invoices: recentInvoices,
        },
        (info) => {
          setMigrationProgress(info);
        }
      );

      if (res.success) {
        setMigrationStats(res.migratedCounts);
        onShowToast('✓ Migrasi Data ke Firebase Firestore Berhasil! Performa kini ultra-fast.', 'success');
        onSync();
      } else {
        onShowToast('Gagal migrasi: ' + res.message, 'error');
      }
    } catch (err: any) {
      onShowToast('Error migrasi ke Firebase: ' + (err?.message || 'Gagal'), 'error');
    } finally {
      setIsMigratingFirebase(false);
    }
  };

  if (!isOpen) return null;

  const handleOpenAddKasirFlow = () => {
    const currentCashier = settings.cashier || localStorage.getItem('strukku_logged_kasir') || '';
    if (checkIsSpvOrOwner(currentCashier, kasirUsers)) {
      // Logged in as SPV/Owner -> Direct access
      setIsAddKasirOpen(true);
    } else {
      // Regular Kasir -> Require SPV/Owner Authorization
      const spvCandidates = kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers));
      if (spvCandidates.length > 0) {
        setAuthSpvUser(spvCandidates[0].nama);
      } else {
        setAuthSpvUser('Owner');
      }
      setAuthPassword('');
      setIsAuthModalOpen(true);
    }
  };

  const handleVerifyAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authSpvUser) {
      onShowToast('Pilih akun SPV / Owner terlebih dahulu', 'error');
      return;
    }

    if (!checkIsSpvOrOwner(authSpvUser, kasirUsers) && authSpvUser.toLowerCase() !== 'owner' && authSpvUser.toLowerCase() !== 'spv') {
      onShowToast(`Akses ditolak: Akun "${authSpvUser}" bukan Supervisor atau Owner!`, 'error');
      return;
    }

    const targetUser = kasirUsers.find((u) => u.nama.toLowerCase() === authSpvUser.toLowerCase());
    const validPassword = targetUser?.password?.trim() || 'ervo123';

    if (authPassword.trim() === validPassword) {
      onShowToast(`Otorisasi SPV/Owner (${authSpvUser}) berhasil!`, 'success');
      setIsAuthModalOpen(false);
      setAuthPassword('');
      setIsAddKasirOpen(true);
    } else {
      onShowToast(`Password otorisasi untuk ${authSpvUser} salah!`, 'error');
    }
  };

  const handleAddKasirSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newKasirName.trim();
    if (!cleanName) {
      onShowToast('Nama kasir/operator baru tidak boleh kosong!', 'error');
      return;
    }

    const pass = newKasirPass.trim() || 'ervo123';

    // Duplicate check
    if (kasirList.some((k) => k.toLowerCase() === cleanName.toLowerCase())) {
      onShowToast(`Kasir dengan nama "${cleanName}" sudah terdaftar!`, 'error');
      return;
    }

    setIsSavingNewKasir(true);
    try {
      await updateKasirPassword(cleanName, pass);

      const displayName = newKasirRole !== 'Kasir' ? `${cleanName} (${newKasirRole})` : cleanName;
      const updatedUsers = [...kasirUsers, { nama: displayName, password: pass }];

      if (onUpdateKasirUsers) {
        onUpdateKasirUsers(updatedUsers);
      }

      onShowToast(`Kasir/Operator "${displayName}" berhasil ditambahkan!`, 'success');
      setIsAddKasirOpen(false);
      setNewKasirName('');
      setNewKasirPass('');
      setNewKasirRole('Kasir');
    } catch {
      onShowToast('Gagal menambahkan kasir baru', 'error');
    } finally {
      setIsSavingNewKasir(false);
    }
  };

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    if (!url.trim()) {
      setTestResult({ ok: false, msg: 'Masukkan URL Google Apps Script terlebih dahulu' });
      return;
    }

    setTesting(true);
    setTestResult(null);

    setSheetUrl(url.trim());
    const res = await gasGet('ping');
    setTesting(false);

    if (res.success) {
      setTestResult({ ok: true, msg: 'Terhubung! Google Apps Script Backend aktif.' });
      onShowToast('Koneksi Google Sheets Berhasil!', 'success');
    } else {
      setTestResult({ ok: false, msg: res.message || 'Gagal terhubung ke Google Apps Script' });
      onShowToast('Koneksi Gagal: Cek Akses Deployment Apps Script (Anyone)', 'error');
    }
  };

  const handleInitSheets = async () => {
    if (!url.trim()) {
      setTestResult({ ok: false, msg: 'Masukkan URL Google Apps Script terlebih dahulu' });
      return;
    }

    setInitializing(true);
    setTestResult(null);
    setSheetUrl(url.trim());

    try {
      const res = await initSheetsRemote();
      if (res.success) {
        setTestResult({ ok: true, msg: '✓ Inisialisasi sheet & header v5 berhasil!' });
        onShowToast('✓ Inisialisasi Google Sheets v5 Berhasil! Sheet & Header telah disesuaikan.', 'success');
        onSync();
      } else {
        setTestResult({ ok: false, msg: res.message || 'Gagal melakukan inisialisasi sheet.' });
        onShowToast('Gagal inisialisasi: ' + res.message, 'error');
      }
    } catch (err: any) {
      setTestResult({ ok: false, msg: 'Error: ' + err.message });
      onShowToast('Gagal menghubungi Google Sheets: ' + err.message, 'error');
    } finally {
      setInitializing(false);
    }
  };

  const handleSave = () => {
    const cleanUrl = url.trim();
    setSheetUrl(cleanUrl);
    const updatedSettings = {
      ...settings,
      rekening: rekeningText.trim(),
      autoLogoutMinutes: autoLogoutMin,
      sheetUrl: cleanUrl,
    };
    onSaveSettings(updatedSettings);

    // Save locally to localStorage so settings persist across reloads
    try {
      localStorage.setItem('strukku_settings', JSON.stringify(updatedSettings));
    } catch {}

    // Sync settings to Google Sheets in background
    saveSettingsRemote(updatedSettings).catch(() => {});

    // Sync settings to Firebase Firestore so all devices get the updated settings & sheetUrl
    saveSettingsFirebase(updatedSettings).catch(() => {});

    onShowToast('Pengaturan tersimpan', 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-stone-800 text-white flex items-center justify-center font-bold">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">Pengaturan Perangkat</h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Atur koneksi Google Sheets & Profil Toko
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 space-y-4">
          {/* Daftar Kasir / Operator Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2.5 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-orange-700" /> Daftar Operator / Kasir
              </span>

              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-extrabold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-amber-700" /> SPV & Owner
                </span>
                <button
                  type="button"
                  onClick={handleOpenAddKasirFlow}
                  className="px-2.5 py-1 bg-orange-700 hover:bg-orange-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Tambah Kasir</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {kasirList.length > 0 ? (
                kasirList.map((k, idx) => (
                  <span
                    key={`${k}-${idx}`}
                    className="px-2.5 py-1 bg-white border border-stone-200 text-stone-800 font-extrabold rounded-lg text-[11px] shadow-2xs flex items-center gap-1"
                  >
                    <span className="text-stone-400">👤</span> {k}
                  </span>
                ))
              ) : (
                <span className="text-stone-400 italic text-[11px]">Belum ada kasir tersimpan</span>
              )}
            </div>

            <p className="text-[10px] text-stone-500 pt-1 leading-normal border-t border-stone-200/60 mt-1">
              💡 <strong>Otorisasi Pengguna:</strong> Hanya akun berhak akses <strong>SPV / Owner</strong> yang berwenang menambahkan kasir/operator baru ke sistem.
            </p>
          </div>

          {/* Master Pelanggan Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2.5 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-orange-700" /> Data Pelanggan ({customers.length})
              </span>

              {onOpenAddCustomer && (
                <button
                  type="button"
                  onClick={onOpenAddCustomer}
                  className="px-2.5 py-1 bg-orange-700 hover:bg-orange-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs transition active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Tambah Pelanggan</span>
                </button>
              )}
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1 max-h-32 overflow-y-auto">
              {customers.length > 0 ? (
                customers.map((c, idx) => (
                  <span
                    key={`${c.nama}-${idx}`}
                    className="px-2.5 py-1 bg-white border border-stone-200 text-stone-800 font-bold rounded-lg text-[11px] shadow-2xs flex items-center gap-1"
                  >
                    <span>{c.nama}</span>
                    {c.kelas && (
                      <span className="text-[9px] px-1 py-0.2 bg-orange-100 text-orange-800 rounded font-semibold">
                        {c.kelas} ({c.diskon}%)
                      </span>
                    )}
                  </span>
                ))
              ) : (
                <span className="text-stone-400 italic text-[11px]">Belum ada data pelanggan tersimpan</span>
              )}
            </div>
          </div>

          {/* Rekening Pembayaran Bank Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-orange-700" /> No. Rekening Pembayaran (Invoice)
              </span>
            </div>
            <textarea
              rows={3}
              value={rekeningText}
              onChange={(e) => setRekeningText(e.target.value)}
              placeholder={`Dapat diisi lebih dari 1 nomor rekening (1 per baris):\nBCA: 123456789 a/n ERVO PRINT\nMandiri: 987654321 a/n ERVO PRINT`}
              className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold bg-white focus:ring-1 focus:ring-orange-600 outline-none resize-y"
            />
            <p className="text-[10px] text-stone-500 leading-relaxed">
              Bisa memasukkan lebih dari 1 nomor rekening (pisahkan dengan baris baru). Otomatis tersimpan ke Google Sheets (kolom <code>Rekening</code>) dan akan tercetak rapi di Invoice A5 & Struk Thermal.
            </p>
          </div>

          {/* Auto Logout Inaktivitas Section */}
          <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-stone-800">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-orange-700" /> Auto Logout Inaktivitas
              </span>
              <select
                value={autoLogoutMin}
                onChange={(e) => setAutoLogoutMin(Number(e.target.value))}
                className="px-2.5 py-1 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-800 focus:ring-1 focus:ring-orange-600 outline-none cursor-pointer"
              >
                <option value={5}>5 Menit</option>
                <option value={10}>10 Menit</option>
                <option value={15}>15 Menit (Default)</option>
                <option value={30}>30 Menit</option>
                <option value={60}>60 Menit (1 Jam)</option>
                <option value={0}>Nonaktif (Matikan Auto Logout)</option>
              </select>
            </div>
            <p className="text-[10px] text-stone-500 leading-relaxed">
              Kasir/operator akan otomatis di-logout jika tidak ada reaksi/transaksi selama durasi ini. <strong>Sinkronisasi data Google Sheets tetap berjalan otomatis di latar belakang setiap 10 menit sekali.</strong>
            </p>
          </div>

          {/* Backup 3-Lapis & Checkpoint Otomatis Card */}
          <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/80 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-emerald-950">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <ShieldCheck className="w-5 h-5 text-emerald-600" /> Sistem Backup 3-Lapis & Checkpoint
              </span>
              <span className="px-2.5 py-0.5 bg-emerald-200 text-emerald-900 rounded-full text-[10px] font-extrabold border border-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-700" /> 3-Tier Protected
              </span>
            </div>

            <p className="text-[11px] text-emerald-900/90 leading-relaxed font-medium">
              Data terlindungi otomatis di 3 lapisan: <strong>Cloud Firestore</strong> (Lapis 1), <strong>Google Sheets</strong> (Lapis 2), dan <strong>Offline Local + Berkas .JSON</strong> (Lapis 3) dengan pemicu checkpoint berkala dan pasca-transaksi.
            </p>

            <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-bold">
              <div className="p-2 bg-white rounded-lg border border-emerald-200 text-stone-800">
                <span className="block text-emerald-600">☁️ Lapis 1</span>
                Firestore Cloud
              </div>
              <div className="p-2 bg-white rounded-lg border border-emerald-200 text-stone-800">
                <span className="block text-emerald-600">📊 Lapis 2</span>
                Google Sheets
              </div>
              <div className="p-2 bg-white rounded-lg border border-emerald-200 text-stone-800">
                <span className="block text-emerald-600">💻 Lapis 3</span>
                Offline & File
              </div>
            </div>

            {onOpenBackup && (
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenBackup();
                  }}
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-98 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Buka Manajer Backup & Pemulihan Checkpoint</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Firebase Firestore Cloud Database Section */}
          <div className="p-4 rounded-xl border border-amber-300 bg-amber-50/80 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-amber-950">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <Flame className="w-5 h-5 text-amber-600 fill-amber-500" /> Firebase Firestore Backend
              </span>
              <span className="px-2.5 py-0.5 bg-amber-200 text-amber-900 rounded-full text-[10px] font-extrabold border border-amber-300 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-700 fill-amber-600" /> Ultra Fast Realtime
              </span>
            </div>

            <p className="text-[11px] text-amber-900/90 leading-relaxed font-medium">
              Firebase Firestore telah aktif dan siap memberikan performa database super cepat (&lt;50ms), dukungan offline, serta pembaruan otomatis antar-kasir tanpa perlu reload page!
            </p>

            <div className="pt-1 space-y-2.5">
              <button
                type="button"
                onClick={handleMigrateToFirebase}
                disabled={isMigratingFirebase}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 disabled:bg-amber-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-98 cursor-pointer"
              >
                {isMigratingFirebase ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin text-white" />
                    <span>Sedang Memproses Migrasi ({migrationProgress?.percent || 0}%)...</span>
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4" />
                    <span>Migrasi 1-Klik Data Ke Firebase Firestore</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {isMigratingFirebase && (
                <div className="p-3 bg-white/95 border border-amber-300 rounded-xl space-y-2 shadow-2xs">
                  <div className="flex items-center justify-between text-[11px] font-bold text-amber-950">
                    <span className="flex items-center gap-1.5 truncate">
                      <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-600 shrink-0" />
                      <span className="truncate">{migrationProgress?.stage || 'Mempersiapkan data...'}</span>
                    </span>
                    <span className="font-mono text-amber-900 font-black shrink-0 ml-2">
                      {migrationProgress?.current || 0} / {migrationProgress?.total || 0} ({migrationProgress?.percent || 0}%)
                    </span>
                  </div>
                  <div className="w-full bg-amber-100 rounded-full h-2.5 overflow-hidden border border-amber-200">
                    <div 
                      className="bg-amber-600 h-2.5 rounded-full transition-all duration-300"
                      style={{ width: `${Math.max(4, migrationProgress?.percent || 0)}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-amber-800 leading-relaxed font-medium">
                    ⚡ Sistem memecah data menjadi batch kecil (50 item/batch) agar migrasi jauh lebih cepat dan tidak membebani koneksi.
                  </p>
                </div>
              )}
            </div>

            {migrationStats && (
              <div className="p-2.5 bg-white/90 border border-amber-300 rounded-lg space-y-1 text-[11px]">
                <p className="font-extrabold text-amber-900 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Hasil Migrasi Firebase Firestore:
                </p>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-stone-700 font-semibold pt-1 text-[10px]">
                  <div>📦 Produk: <strong>{migrationStats.products || 0}</strong></div>
                  <div>👥 Pelanggan: <strong>{migrationStats.customers || 0}</strong></div>
                  <div>🔑 Kasir/User: <strong>{migrationStats.kasirUsers || 0}</strong></div>
                  <div>💸 Pengeluaran: <strong>{migrationStats.expenses || 0}</strong></div>
                  <div>📄 Transaksi/Invoice: <strong>{migrationStats.invoices || 0}</strong></div>
                  <div>⚙️ Pengaturan Toko: <strong>{migrationStats.settings || 0}</strong></div>
                </div>
              </div>
            )}

            {/* Daily Quota Monitoring Dashboard */}
            <div className="mt-2 pt-3 border-t border-amber-300/80 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-amber-800" />
                  <span className="font-extrabold text-amber-950 text-xs">
                    Monitoring Kuota Harian (Free Tier)
                  </span>
                </div>
                {quotaMetrics.quotaExceeded ? (
                  <span className="px-2 py-0.5 bg-red-100 text-red-700 border border-red-300 rounded-md text-[10px] font-black animate-pulse flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-red-600" /> LIMIT TERCAPAI
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-md text-[10px] font-extrabold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Status: Normal
                  </span>
                )}
              </div>

              {/* Progress bars for Reads, Writes, Deletes */}
              <div className="grid grid-cols-1 gap-2 bg-white/95 p-3 rounded-xl border border-amber-200 shadow-2xs">
                {/* Reads */}
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-bold text-stone-700 flex items-center gap-1">
                      📖 Baca (Reads)
                    </span>
                    <span className="font-extrabold text-stone-900">
                      {quotaMetrics.reads.toLocaleString()} <span className="text-stone-400 font-normal">/ {FIRESTORE_SPARK_LIMITS.DAILY_READS.toLocaleString()} ({Math.min(100, Math.round((quotaMetrics.reads / FIRESTORE_SPARK_LIMITS.DAILY_READS) * 100))}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        (quotaMetrics.reads / FIRESTORE_SPARK_LIMITS.DAILY_READS) > 0.85
                          ? 'bg-rose-500'
                          : (quotaMetrics.reads / FIRESTORE_SPARK_LIMITS.DAILY_READS) > 0.6
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(2, (quotaMetrics.reads / FIRESTORE_SPARK_LIMITS.DAILY_READS) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* Writes */}
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-bold text-stone-700 flex items-center gap-1">
                      ✍️ Tulis (Writes)
                    </span>
                    <span className="font-extrabold text-stone-900">
                      {quotaMetrics.writes.toLocaleString()} <span className="text-stone-400 font-normal">/ {FIRESTORE_SPARK_LIMITS.DAILY_WRITES.toLocaleString()} ({Math.min(100, Math.round((quotaMetrics.writes / FIRESTORE_SPARK_LIMITS.DAILY_WRITES) * 100))}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        (quotaMetrics.writes / FIRESTORE_SPARK_LIMITS.DAILY_WRITES) > 0.85
                          ? 'bg-rose-500'
                          : (quotaMetrics.writes / FIRESTORE_SPARK_LIMITS.DAILY_WRITES) > 0.6
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(2, (quotaMetrics.writes / FIRESTORE_SPARK_LIMITS.DAILY_WRITES) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* Deletes */}
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-bold text-stone-700 flex items-center gap-1">
                      🗑️ Hapus (Deletes)
                    </span>
                    <span className="font-extrabold text-stone-900">
                      {quotaMetrics.deletes.toLocaleString()} <span className="text-stone-400 font-normal">/ {FIRESTORE_SPARK_LIMITS.DAILY_DELETES.toLocaleString()}</span>
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className="h-full bg-stone-400 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.max(1, (quotaMetrics.deletes / FIRESTORE_SPARK_LIMITS.DAILY_DELETES) * 100))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Quota Savings Summary */}
              <div className="p-2.5 bg-amber-100/70 border border-amber-300/80 rounded-xl flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold shrink-0">
                    <TrendingDown className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-extrabold text-amber-950 block">
                      Operasi Dihemat: {((quotaMetrics.savedReads || 0) + (quotaMetrics.savedWrites || 0)).toLocaleString()} Operasi
                    </span>
                    <span className="text-[10px] text-amber-800">
                      ⚡ {quotaMetrics.savedReads || 0} Reads & 🛡️ {quotaMetrics.savedWrites || 0} Writes dihemat via cache & debouncing
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuotaDetails(!showQuotaDetails)}
                  className="px-2 py-1 bg-white hover:bg-amber-50 text-amber-900 font-bold rounded-lg border border-amber-300 text-[10px] shadow-2xs transition cursor-pointer"
                >
                  {showQuotaDetails ? 'Tutup Rincian' : 'Lihat Rincian'}
                </button>
              </div>

              {/* Collapsible Details */}
              {showQuotaDetails && (
                <div className="p-2.5 bg-white border border-amber-200 rounded-xl space-y-1 text-[10px] text-stone-700 animate-fade-in">
                  <div className="font-extrabold text-stone-900 border-b border-stone-100 pb-1 mb-1.5 flex items-center justify-between">
                    <span>Rincian Operasi per Koleksi:</span>
                    <span className="text-stone-400 font-normal">Tanggal: {quotaMetrics.date}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-1 font-medium">
                    <div>📦 Produk: <strong>{quotaMetrics.byCollection['products']?.reads || 0} R / {quotaMetrics.byCollection['products']?.writes || 0} W</strong></div>
                    <div>👥 Pelanggan: <strong>{quotaMetrics.byCollection['customers']?.reads || 0} R / {quotaMetrics.byCollection['customers']?.writes || 0} W</strong></div>
                    <div>📄 Invoices: <strong>{quotaMetrics.byCollection['invoices']?.reads || 0} R / {quotaMetrics.byCollection['invoices']?.writes || 0} W</strong></div>
                    <div>🛡️ Checkpoints: <strong>{quotaMetrics.byCollection['checkpoints']?.reads || 0} R / {quotaMetrics.byCollection['checkpoints']?.writes || 0} W</strong></div>
                    <div>⚙️ Settings: <strong>{quotaMetrics.byCollection['settings/store']?.reads || 0} R / {quotaMetrics.byCollection['settings/store']?.writes || 0} W</strong></div>
                    <div>💸 Biaya: <strong>{quotaMetrics.byCollection['expenses']?.reads || 0} R / {quotaMetrics.byCollection['expenses']?.writes || 0} W</strong></div>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-stone-500 italic text-[9px]">
                      Quota di-reset otomatis setiap tengah malam (00:00).
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        resetFirestoreDailyMetrics();
                        setQuotaMetrics(getFirestoreQuotaMetrics());
                        onShowToast('Metrik kuota lokal berhasil di-reset', 'info');
                      }}
                      className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded text-[9px] flex items-center gap-1 transition cursor-pointer"
                    >
                      <RotateCcw className="w-2.5 h-2.5" /> Reset Metrik
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Cloud Firestore ERVO Payroll Integration Card */}
          <div className="p-4 rounded-xl border border-indigo-300 bg-indigo-50/80 space-y-3 text-xs">
            <div className="flex items-center justify-between font-bold text-indigo-950">
              <span className="flex items-center gap-2 text-sm font-extrabold">
                <Database className="w-5 h-5 text-indigo-600" /> Integrasi Pusat ERVO Payroll
              </span>
              <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold border border-emerald-300 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Auto-Sync Aktif
              </span>
            </div>

            <p className="text-[11px] text-indigo-900/90 leading-relaxed font-medium">
              Setiap kali transaksi kasir (struk pembayaran) diselesaikan atau kas keluar dicatat, salinan data otomatis dikirim ke database pusat Cloud Firestore ERVO Payroll.
            </p>

            <div className="bg-white/95 border border-indigo-200 rounded-xl p-3 space-y-1.5 font-mono text-[10px] text-stone-700">
              <div className="flex items-center justify-between">
                <span className="text-stone-500 font-sans">Database ID:</span>
                <span className="font-bold text-indigo-900 truncate max-w-[240px] sm:max-w-none">{ERVO_PAYROLL_DB_ID}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-stone-500 font-sans">Collection:</span>
                <span className="font-bold text-indigo-900">{ERVO_PAYROLL_COLLECTION}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-stone-500 font-sans">Business Unit:</span>
                <span className="font-bold text-emerald-700">{BUSINESS_UNIT_NAME}</span>
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={handleFlushPayrollQueue}
                disabled={isFlushingQueue}
                className="py-1.5 px-3 bg-indigo-700 hover:bg-indigo-800 disabled:bg-indigo-400 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-2xs"
              >
                <RotateCw className={`w-3.5 h-3.5 ${isFlushingQueue ? 'animate-spin' : ''}`} />
                <span>{isFlushingQueue ? 'Sinkronisasi Antrean...' : 'Sinkronkan Antrean Offline'}</span>
              </button>

              {flushMsg && (
                <span className="text-[11px] font-bold text-indigo-900 animate-fade-in truncate">
                  {flushMsg}
                </span>
              )}
            </div>
          </div>

          {/* Connection URL Google Sheets Configuration */}
          <details open className="p-3.5 rounded-xl border border-stone-200 bg-white group">
            <summary className="text-xs font-bold text-stone-800 cursor-pointer flex items-center justify-between select-none">
              <span className="flex items-center gap-1.5">
                <Link className="w-4 h-4 text-stone-500" /> Connection URL Google Sheets (Apps Script)
              </span>
              <ChevronDown className="w-4 h-4 text-stone-400 group-open:rotate-180 transition" />
            </summary>
            <div className="mt-3 pt-3 border-t border-stone-100 space-y-3">
              {/* Panduan Integrasi Banner */}
              <div className="p-3 bg-orange-50/80 border border-orange-200 rounded-xl flex items-center justify-between gap-3 flex-wrap">
                <div className="text-xs">
                  <p className="font-extrabold text-orange-900">
                    Panduan Script & Download Code.gs (v5)
                  </p>
                  <p className="text-[11px] text-stone-600 font-medium">
                    Salin kode Apps Script v5, unduh file Code.gs, atau baca petunjuk integrasi real-time.
                  </p>
                </div>
                {onOpenGasGuide && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenGasGuide();
                    }}
                    className="px-3 py-1.5 bg-orange-700 hover:bg-orange-800 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition shrink-0 active:scale-95 shadow-xs"
                  >
                    <span>Panduan & Download Code.gs</span>
                  </button>
                )}
              </div>

              <div>
                <label className="text-[11px] text-stone-500 block font-medium mb-1">
                  URL Web App Google Apps Script (Deployment 'Anyone'):
                </label>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/.../exec"
                  className="w-full p-2 border border-stone-200 rounded-lg font-mono text-[11px] bg-stone-50 focus:bg-white focus:border-orange-600 focus:ring-1 focus:ring-orange-200 transition"
                />
              </div>

              {/* Panel Sinkronisasi Manual Spreadsheet */}
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-stone-900 text-xs">
                      Sinkronisasi Manual ke Spreadsheet (Khusus Pengaturan)
                    </h5>
                    <p className="text-[11px] text-stone-600 leading-relaxed mt-0.5">
                      Tombol sinkron manual dialihkan ke halaman ini untuk mencegah kesalahan klik kasir/pengguna pada modal transaksi. Transaksi kasir, pelunasan piutang, dan pencatatan operasional tetap berjalan otomatis di latar belakang.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-amber-200/80">
                  <button
                    type="button"
                    onClick={onSync}
                    disabled={testing || initializing}
                    className="px-3 py-1.5 rounded-lg border border-orange-300 bg-orange-600 hover:bg-orange-700 text-white text-[11px] font-bold flex items-center gap-1.5 transition shadow-2xs cursor-pointer active:scale-95"
                    title="Tarik & sinkronkan data master dari Google Sheets secara manual"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Sinkron Manual Sekarang</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleTestConnection}
                    disabled={testing || initializing}
                    className="px-2.5 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-50 text-stone-800 text-[11px] font-bold flex items-center gap-1 transition shadow-2xs"
                  >
                    <PlugZap className="w-3.5 h-3.5 text-stone-600" />
                    <span>{testing ? 'Menghubungi...' : 'Tes Koneksi'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleInitSheets}
                    disabled={testing || initializing}
                    className="px-2.5 py-1.5 rounded-lg border border-amber-300 bg-amber-100/70 hover:bg-amber-100 text-amber-900 text-[11px] font-bold flex items-center gap-1 transition shadow-2xs"
                  >
                    <RotateCw className={`w-3.5 h-3.5 text-amber-700 ${initializing ? 'animate-spin' : ''}`} />
                    <span>{initializing ? 'Menginisialisasi...' : 'Init Sheet v5'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      clearLocalCache();
                      onSync();
                      onShowToast('Cache transaksi lokal dibersihkan & disinkron ulang', 'info');
                    }}
                    className="px-2.5 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-[11px] font-bold flex items-center gap-1 transition shadow-2xs"
                    title="Hapus cache transaksi/pelunasan lokal jika spreadsheet kosong"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-stone-600" />
                    <span>Clear Cache</span>
                  </button>
                </div>
              </div>

              {testResult && (
                <div
                  className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                    testResult.ok ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-red-50 text-red-800'
                  }`}
                >
                  {testResult.ok ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  )}
                  <span>{testResult.msg}</span>
                </div>
              )}
            </div>
          </details>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-stone-200">
            <button
              onClick={onClose}
              className="px-4 py-2 text-stone-600 hover:bg-stone-100 text-xs font-semibold rounded-lg transition"
            >
              Batal
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 bg-orange-700 hover:bg-orange-800 text-white text-xs font-bold rounded-lg shadow-xs transition active:scale-95 flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Pengaturan</span>
            </button>
          </div>
        </div>
      </div>

      {/* SPV / Owner Authorization Verification Modal */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-600" />
                <span>Otorisasi SPV / Owner Diperlukan</span>
              </h3>
              <button
                onClick={() => setIsAuthModalOpen(false)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Penambahan kasir baru merupakan fitur terbatas. Silakan pilih akun <strong>SPV / Owner</strong> dan masukkan password otorisasi.
            </p>

            <form onSubmit={handleVerifyAuth} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Akun SPV / Owner Penanggung Jawab
                </label>
                <select
                  value={authSpvUser}
                  onChange={(e) => setAuthSpvUser(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-bold bg-stone-50"
                  required
                >
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).map((u, i) => (
                    <option key={i} value={u.nama}>
                      🛡️ {u.nama} {u.role ? `(${u.role.toUpperCase()})` : '(SPV/Owner)'}
                    </option>
                  ))}
                  {kasirUsers.filter((u) => checkIsSpvOrOwner(u.nama, kasirUsers)).length === 0 && (
                    <>
                      <option key="sm-spv-owner" value="Owner">🛡️ Owner / Pemilik Toko</option>
                      <option key="sm-spv-spv" value="SPV">🛡️ Supervisor (SPV)</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Otorisasi
                </label>
                <input
                  type="password"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="Masukkan password SPV / Owner"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verifikasi & Lanjutkan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Kasir Modal */}
      {isAddKasirOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-orange-700" />
                <span>Tambah Kasir / Operator Baru</span>
              </h3>
              <button
                onClick={() => setIsAddKasirOpen(false)}
                className="text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddKasirSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Nama Kasir / Operator Baru
                </label>
                <input
                  type="text"
                  value={newKasirName}
                  onChange={(e) => setNewKasirName(e.target.value)}
                  placeholder="Contoh: Ani, Budi, Maya"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Role / Jabatan
                </label>
                <select
                  value={newKasirRole}
                  onChange={(e) => setNewKasirRole(e.target.value as any)}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs font-semibold bg-stone-50"
                >
                  <option value="Kasir">Kasir / Operator Standard</option>
                  <option value="SPV">SPV (Supervisor)</option>
                  <option value="Owner">Owner / Pimpinan</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-700 block mb-1">
                  Password Akses (Opsional)
                </label>
                <input
                  type="password"
                  value={newKasirPass}
                  onChange={(e) => setNewKasirPass(e.target.value)}
                  placeholder="Default: ervo123 (jika dikosongkan)"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-xs"
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Password awal default jika kosong adalah <strong>ervo123</strong>
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddKasirOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 text-xs font-bold hover:bg-stone-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingNewKasir}
                  className="px-4 py-1.5 rounded-lg bg-orange-700 hover:bg-orange-800 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  {isSavingNewKasir ? 'Menyimpan...' : 'Tambah Kasir'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
