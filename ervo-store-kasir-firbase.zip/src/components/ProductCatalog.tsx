import React, { useState, useMemo } from 'react';
import { Search, Package, Plus, Sparkles, X, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { fRp, escHtml } from '../utils/formatters';

interface ProductCatalogProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onLoadSample: () => void;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  onSelectProduct,
  onLoadSample,
}) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('Semua');

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      const katRaw = String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '');
      if (katRaw && katRaw.toLowerCase() !== 'semua') {
        const parts = katRaw.split(/[,;/]/).map((s) => s.trim()).filter(Boolean);
        if (parts.length > 0) {
          parts.forEach((pt) => set.add(pt));
        } else {
          set.add('Lainnya');
        }
      } else if (!katRaw) {
        set.add('Lainnya');
      }
    });
    const sorted = Array.from(set).sort((a, b) => a.localeCompare(b, 'id'));
    return ['Semua', ...sorted];
  }, [products]);

  const filteredProducts = useMemo(() => {
    let list = products;
    if (activeCategory !== 'Semua') {
      const target = activeCategory.trim().toLowerCase();
      list = list.filter((p) => {
        const katRaw = String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '').toLowerCase();
        if (katRaw === 'semua') return true; // If product category is literally 'Semua', show in all
        const parts = katRaw.split(/[,;/]/).map((s) => s.trim());
        return katRaw === target || parts.includes(target);
      });
    }
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.nama.toLowerCase().includes(q) ||
          (p.kode || '').toLowerCase().includes(q) ||
          (p.kategori || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [products, activeCategory, search]);

  return (
    <div className="bg-white border border-stone-200 rounded-xl flex flex-col h-full min-h-0 overflow-hidden shadow-xs">
      {/* Header */}
      <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 border-b border-stone-200 flex items-center justify-between bg-stone-50 shrink-0">
        <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-stone-900">
          <Package className="w-4 h-4 text-orange-700" />
          <span>Daftar Jasa & Produk Cetak</span>
        </div>
        <span className="text-[11px] sm:text-xs font-semibold text-stone-500 bg-stone-200/60 px-2 py-0.5 rounded-full font-mono">
          {filteredProducts.length} item
        </span>
      </div>

      {/* Search Input */}
      <div className="p-2.5 sm:p-3 pb-2 shrink-0">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari banner, sublime, A3+, stiker, dsb..."
            className="w-full pl-9 pr-8 py-1.5 sm:py-2 border border-stone-200 rounded-lg text-xs bg-white focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100 transition font-medium"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex gap-1.5 px-2.5 sm:px-3 pb-2 overflow-x-auto shrink-0 scrollbar-none">
        {categories.map((cat, idx) => (
          <button
            key={`${cat}-${idx}`}
            onClick={() => setActiveCategory(cat)}
            className={`px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition border ${
              activeCategory === cat
                ? 'bg-orange-700 text-white border-orange-700 shadow-xs'
                : 'bg-white text-stone-600 border-stone-200 hover:border-orange-500 hover:text-orange-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Product Grid / List with Guaranteed Scroll Container */}
      <div className="flex-1 min-h-0 overflow-y-auto p-2.5 sm:p-3 space-y-1.5 sm:space-y-2">
        {products.length === 0 ? (
          <div className="text-center py-10 px-4 text-stone-500">
            <Package className="w-10 h-10 mx-auto mb-3 opacity-30 text-stone-400" />
            <p className="font-semibold text-sm text-stone-800">Belum Ada Data Produk</p>
            <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
              Sinkronkan dengan Google Sheets atau muat data contoh digital printing.
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                onClick={onLoadSample}
                className="px-3 py-1.5 rounded-lg bg-orange-50 border border-orange-200 text-orange-700 text-xs font-semibold hover:bg-orange-100 transition"
              >
                Muat Data Contoh
              </button>
            </div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-10 px-4 text-stone-500">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-30 text-stone-400" />
            <p className="font-semibold text-xs text-stone-700">Tidak ada produk ditemukan</p>
            <p className="text-[11px] text-stone-400 mt-0.5">Coba ubah kata kunci pencarian</p>
          </div>
        ) : (
          filteredProducts.map((p, idx) => {
            const stokStr = String(p.stok ?? '').trim();
            
            // Robust parsing for stock values (handles "1,5", "1.5", "1 liter", "194", etc.)
            let stokNum: number | null = null;
            if (stokStr !== '' && stokStr !== '-') {
              const normalized = stokStr.replace(',', '.');
              const match = normalized.match(/-?\d+(?:\.\d+)?/);
              if (match) {
                const parsed = parseFloat(match[0]);
                if (!isNaN(parsed)) stokNum = parsed;
              }
            }

            const isOutOfStock = stokNum !== null && stokNum <= 0;
            const hasStock = (stokNum !== null && stokNum > 0) || (stokStr !== '' && stokStr !== '-' && stokNum === null);

            return (
              <div
                key={`${p.kode || p.nama || 'prod'}-${idx}`}
                onClick={() => !isOutOfStock && onSelectProduct(p)}
                className={`p-3 rounded-lg border transition duration-150 flex items-center justify-between gap-2 ${
                  isOutOfStock
                    ? 'opacity-50 bg-stone-100 border-stone-200 cursor-not-allowed'
                    : 'bg-white border-stone-200 hover:border-orange-500 hover:bg-orange-50/50 cursor-pointer hover:shadow-xs active:scale-[0.99]'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="text-xs sm:text-sm font-bold text-stone-900 truncate">
                    {p.nama}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    {p.kode && (
                      <span className="font-mono text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">
                        {p.kode}
                      </span>
                    )}
                    {p.kategori && (
                      <span className="text-[10px] font-semibold text-orange-800 bg-orange-50 px-1.5 py-0.5 rounded border border-orange-200">
                        {p.kategori}
                      </span>
                    )}
                    {p.satuan && (
                      <span className="text-[10px] font-medium text-stone-600 bg-stone-100 px-1.5 py-0.5 rounded">
                        {p.satuan}
                      </span>
                    )}
                    {p.tipeHarga === 'ukuran' && (
                      <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                        per m²
                      </span>
                    )}
                    {isOutOfStock ? (
                      <span className="text-[10px] font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded">
                        Stok Habis
                      </span>
                    ) : hasStock ? (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                        Stok: {stokStr}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div
                    className={`text-xs sm:text-sm font-extrabold ${
                      isOutOfStock ? 'text-stone-400' : 'text-orange-700'
                    }`}
                  >
                    {fRp(p.harga)}
                  </div>
                  {!isOutOfStock && (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-orange-700 mt-0.5">
                      <Plus className="w-3 h-3" /> Tambah
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
