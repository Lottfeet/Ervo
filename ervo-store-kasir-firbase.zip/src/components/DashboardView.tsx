import React, { useState, useEffect, useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { fetchRecentInvoices, RecentInvoiceItem } from '../services/gasService';
import { subscribeInvoices } from '../services/firebaseService';
import { Product } from '../types';
import { fRp, calculateCashInflowByPaymentMethod, calculatePeriodCashFlow, PeriodCashInflowBreakdown, compareInvoicesDesc } from '../utils/formatters';
import { 
  LayoutDashboard, 
  TrendingUp, 
  ShoppingBag, 
  Wallet, 
  RotateCw, 
  Award, 
  PieChart as PieIcon,
  Calendar,
  Zap,
  ArrowUpRight,
  AlertTriangle,
  PackagePlus,
  ArrowRight,
  SlidersHorizontal,
  Filter,
  CheckCircle2,
  PackageX,
  ChevronDown,
  ChevronUp,
  CreditCard
} from 'lucide-react';

interface DashboardViewProps {
  products: Product[];
  onNavigateToTransaksi: () => void;
  onNavigateToBarangMasuk?: (productToRestock?: Product) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  products,
  onNavigateToTransaksi,
  onNavigateToBarangMasuk,
  onShowToast,
}) => {
  const [invoices, setInvoices] = useState<RecentInvoiceItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [stockThreshold, setStockThreshold] = useState<number>(10);
  const [categoryFilter, setCategoryFilter] = useState<string>('Bahan Baku');
  const [isStockPanelCollapsed, setIsStockPanelCollapsed] = useState<boolean>(false);
  const todayStrDate = new Date().toISOString().split('T')[0];
  const thirtyDaysAgoStrDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const [topProductsScope, setTopProductsScope] = useState<'today' | '7d' | '30d' | 'month' | 'custom' | 'all'>('30d');
  const [topProductsStartDate, setTopProductsStartDate] = useState<string>(thirtyDaysAgoStrDate);
  const [topProductsEndDate, setTopProductsEndDate] = useState<string>(todayStrDate);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const res = await fetchRecentInvoices();
      const sorted = (res.list || []).sort(compareInvoicesDesc);
      setInvoices(sorted);
    } catch {
      onShowToast('Gagal memuat data statistik dashboard', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
    const unsub = subscribeInvoices((list) => {
      if (list && list.length > 0) {
        const sorted = [...list].sort(compareInvoicesDesc);
        setInvoices(sorted as RecentInvoiceItem[]);
      }
    });
    return () => {
      unsub();
    };
  }, []);

  // Filter Low Stock & Out of Stock Products (Defaults to 'Bahan Baku' category)
  const lowStockProducts = useMemo(() => {
    return products
      .map((p) => {
        const numericStok = parseFloat(String(p.stok || '0').replace(',', '.'));
        return {
          ...p,
          numericStok: isNaN(numericStok) ? 0 : numericStok,
        };
      })
      .filter((p) => {
        // Must be at or below threshold
        if (p.numericStok > stockThreshold) return false;

        // Category Filter
        if (categoryFilter === 'Bahan Baku') {
          const kat = (p.kategori || '').toLowerCase().trim();
          return kat === 'bahan baku' || kat.includes('bahan baku') || kat.includes('bahan');
        } else if (categoryFilter !== 'Semua') {
          return (p.kategori || '').toLowerCase().trim() === categoryFilter.toLowerCase().trim();
        }

        return true;
      })
      .sort((a, b) => a.numericStok - b.numericStok);
  }, [products, stockThreshold, categoryFilter]);

  const outOfStockCount = useMemo(() => {
    return lowStockProducts.filter((p) => p.numericStok <= 0).length;
  }, [lowStockProducts]);

  const availableCategories = useMemo(() => {
    const cats = new Set<string>();
    products.forEach((p) => {
      if (p.kategori && p.kategori.trim()) {
        cats.add(p.kategori.trim());
      }
    });
    return Array.from(cats).sort((a, b) => a.localeCompare(b, 'id'));
  }, [products]);

  // Calculate Today's Metrics
  const todayStr = new Date().toISOString().split('T')[0];
  const dToday = new Date();
  const day = String(dToday.getDate()).padStart(2, '0');
  const month = String(dToday.getMonth() + 1).padStart(2, '0');
  const year = dToday.getFullYear();
  const todayFormattedSlash = `${day}/${month}/${year}`;
  const todayFormattedShort = `${day}/${month}`;

  // Filter Invoices for Today
  const todayInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      if (!inv.date) return false;
      return (
        inv.date.startsWith(todayStr) ||
        inv.date === todayFormattedSlash ||
        inv.date.startsWith(todayFormattedShort)
      );
    });
  }, [invoices, todayStr, todayFormattedSlash, todayFormattedShort]);

  // Calculate cash inflow breakdown by payment method for today across all invoices (new sales + cross-day debt payments)
  const todayCashInflow = useMemo<PeriodCashInflowBreakdown>(() => {
    return calculatePeriodCashFlow(invoices, 'today');
  }, [invoices]);

  // Today Summary Stats
  const todayStats = useMemo(() => {
    let totalOmzet = 0;
    let totalPiutang = 0;

    todayInvoices.forEach((inv) => {
      const tot = Number(inv.total || 0);
      const sisa = Number(inv.sisa || 0);
      totalOmzet += tot;
      totalPiutang += sisa;
    });

    const avgTransaction = todayInvoices.length > 0 ? Math.round(totalOmzet / todayInvoices.length) : 0;

    return {
      totalOmzet,
      totalCashReceived: todayCashInflow.Total,
      fromNewSales: todayCashInflow.fromNewSales,
      fromPelunasanPiutang: todayCashInflow.fromPelunasanPiutang,
      totalPiutang,
      count: todayInvoices.length,
      avgTransaction,
      pelunasanCount: todayCashInflow.pelunasanItems.length,
    };
  }, [todayInvoices, todayCashInflow]);

  // 7-Day Revenue & Transaction Trend Chart Data
  const trendData = useMemo(() => {
    const daysMap = new Map<string, { dateLabel: string; omzet: number; transaksi: number }>();
    
    // Generate last 7 days keys
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dDay = String(d.getDate()).padStart(2, '0');
      const dMonth = String(d.getMonth() + 1).padStart(2, '0');
      const keyShort = `${dDay}/${dMonth}`;
      const keyFull = `${d.getFullYear()}-${dMonth}-${dDay}`;
      
      const label = i === 0 ? 'Hari Ini' : keyShort;
      daysMap.set(keyShort, { dateLabel: label, omzet: 0, transaksi: 0 });
      daysMap.set(keyFull, { dateLabel: label, omzet: 0, transaksi: 0 });
    }

    invoices.forEach((inv) => {
      if (!inv.date) return;
      let matchingKey = '';
      if (inv.date.includes('/')) {
        const parts = inv.date.split('/');
        if (parts.length >= 2) matchingKey = `${parts[0].padStart(2, '0')}/${parts[1].padStart(2, '0')}`;
      } else if (inv.date.includes('-')) {
        matchingKey = inv.date.substring(0, 10);
      }

      if (daysMap.has(matchingKey)) {
        const obj = daysMap.get(matchingKey)!;
        obj.omzet += Number(inv.total || 0);
        obj.transaksi += 1;
      }
    });

    // Extract unique entries for the last 7 days
    const uniqueList: { dateLabel: string; omzet: number; transaksi: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dDay = String(d.getDate()).padStart(2, '0');
      const dMonth = String(d.getMonth() + 1).padStart(2, '0');
      const keyShort = `${dDay}/${dMonth}`;
      
      if (daysMap.has(keyShort)) {
        uniqueList.push(daysMap.get(keyShort)!);
      }
    }

    return uniqueList;
  }, [invoices]);

  // Parse date helper for filtering top products
  const parseInvDate = (dateStr?: string): Date | null => {
    if (!dateStr || typeof dateStr !== 'string' || !dateStr.trim()) return null;
    const cleaned = dateStr.trim();
    if (cleaned.includes('/')) {
      const spaceSplit = cleaned.split(' ')[0];
      const parts = spaceSplit.split('/');
      if (parts.length === 3) {
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const year = parseInt(parts[2], 10);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) return new Date(year, month, day);
      }
    }
    if (cleaned.includes('-')) {
      const spaceSplit = cleaned.split('T')[0].split(' ')[0];
      const parts = spaceSplit.split('-');
      if (parts.length === 3) {
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        if (!isNaN(day) && !isNaN(month) && !isNaN(year)) return new Date(year, month, day);
      }
    }
    const d = new Date(cleaned);
    if (!isNaN(d.getTime())) return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    return null;
  };

  // Top Products Data filtered by topProductsScope
  const topProductsData = useMemo(() => {
    const now = new Date();
    const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const filteredInv = invoices.filter((inv) => {
      if (topProductsScope === 'all') return true;
      const d = parseInvDate(inv.date);
      if (!d) return false;

      if (topProductsScope === 'today') {
        return d.getFullYear() === todayLocal.getFullYear() &&
               d.getMonth() === todayLocal.getMonth() &&
               d.getDate() === todayLocal.getDate();
      }
      if (topProductsScope === '7d') {
        const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
        return d >= sevenDaysAgo;
      }
      if (topProductsScope === '30d') {
        const thirtyDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 29);
        return d >= thirtyDaysAgo;
      }
      if (topProductsScope === 'month') {
        return d.getFullYear() === todayLocal.getFullYear() && d.getMonth() === todayLocal.getMonth();
      }
      if (topProductsScope === 'custom') {
        if (!topProductsStartDate && !topProductsEndDate) return true;
        const startD = topProductsStartDate ? new Date(topProductsStartDate + 'T00:00:00') : new Date(0);
        const endD = topProductsEndDate ? new Date(topProductsEndDate + 'T23:59:59.999') : new Date(8640000000000000);
        return d >= startD && d <= endD;
      }
      return true;
    });

    const itemMap: Record<string, { fullName: string; jumlahOrder: number; totalNilai: number }> = {};
    let totalItemsFound = 0;

    filteredInv.forEach((inv) => {
      if (inv.items && Array.isArray(inv.items) && inv.items.length > 0) {
        inv.items.forEach((it) => {
          if (!it.nama) return;
          const nameKey = it.nama.trim();
          if (!itemMap[nameKey]) {
            itemMap[nameKey] = { fullName: nameKey, jumlahOrder: 0, totalNilai: 0 };
          }
          const qty = Number(it.qty || 1);
          const price = Number(it.harga || 0);
          const tot = Number(it.totalItem || (qty * price));
          itemMap[nameKey].jumlahOrder += qty;
          itemMap[nameKey].totalNilai += tot;
          totalItemsFound++;
        });
      }
    });

    if (totalItemsFound > 0) {
      return Object.values(itemMap)
        .sort((a, b) => b.jumlahOrder - a.jumlahOrder)
        .slice(0, 5)
        .map((p) => ({
          name: p.fullName.length > 18 ? p.fullName.substring(0, 18) + '...' : p.fullName,
          fullName: p.fullName,
          jumlahOrder: p.jumlahOrder,
          totalNilai: p.totalNilai,
        }));
    }

    return [];
  }, [invoices, topProductsScope, topProductsStartDate, topProductsEndDate]);

  // Payment Method Breakdown Data for Chart
  const paymentMethodData = useMemo(() => {
    return [
      { name: 'Tunai', value: todayCashInflow.Tunai, color: '#10b981' },
      { name: 'Transfer', value: todayCashInflow.Transfer, color: '#3b82f6' },
      { name: 'Debet', value: todayCashInflow.Debet, color: '#8b5cf6' },
      { name: 'QRIS', value: todayCashInflow.QRIS, color: '#f59e0b' },
    ];
  }, [todayCashInflow]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899'];

  return (
    <div className="h-full flex flex-col gap-4 overflow-y-auto pr-1">
      {/* Top Header Banner */}
      <div className="bg-stone-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-orange-600 rounded-xl text-white shrink-0">
            <LayoutDashboard className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Dashboard Ringkasan Operasional Hari Ini</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-orange-500/30 text-orange-200 border border-orange-500/40 uppercase">
                Grafik Analytics
              </span>
            </h2>
            <p className="text-xs text-stone-300 mt-0.5">
              Pantau performa omset harian, jumlah transaksi, stok menipis, dan arus kas kasir secara real-time.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToBarangMasuk && (
            <button
              onClick={onNavigateToBarangMasuk}
              className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 font-extrabold text-xs rounded-xl border border-stone-700 flex items-center gap-1.5 transition active:scale-95 shrink-0"
            >
              <PackagePlus className="w-4 h-4 text-orange-400" />
              <span>Restock Barang</span>
            </button>
          )}

          <button
            onClick={onNavigateToTransaksi}
            className="px-3.5 py-2 bg-orange-700 hover:bg-orange-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-2 transition active:scale-95 shrink-0"
          >
            <Zap className="w-4 h-4" />
            <span>+ Buat Transaksi</span>
          </button>

          <button
            onClick={loadDashboardData}
            disabled={isLoading}
            className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 transition"
            title="Refresh Data Dashboard"
          >
            <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Metric Cards (4 Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: Omzet Hari Ini */}
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50/60 border border-emerald-200/90 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-extrabold text-emerald-900 uppercase tracking-wider">Total Omzet Hari Ini</span>
            <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-2xs">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-950">{fRp(todayStats.totalOmzet)}</div>
          <div className="text-[11px] text-emerald-800/90 font-bold mt-2 pt-2 border-t border-emerald-200/60 flex items-center justify-between flex-wrap gap-1">
            <span className="flex items-center gap-1">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Kas Masuk: <strong>{fRp(todayStats.totalCashReceived)}</strong></span>
            </span>
            {todayStats.fromPelunasanPiutang > 0 && (
              <span className="text-[10px] font-extrabold text-purple-700 bg-purple-100/90 px-1.5 py-0.5 rounded border border-purple-200">
                +{fRp(todayStats.fromPelunasanPiutang)} Pelunasan
              </span>
            )}
          </div>
        </div>

        {/* Card 2: Jumlah Transaksi */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 border border-blue-200/90 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-extrabold text-blue-900 uppercase tracking-wider">Transaksi Hari Ini</span>
            <div className="p-2 bg-blue-600 text-white rounded-xl shadow-2xs">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-blue-950">{todayStats.count} <span className="text-xs font-bold text-blue-800/80">Nota</span></div>
          <div className="text-[11px] text-blue-800/90 font-semibold mt-2 pt-2 border-t border-blue-200/60">
            Rata-rata: <strong className="text-blue-950 font-black">{fRp(todayStats.avgTransaction)}</strong> / order
          </div>
        </div>

        {/* Card 3: Piutang Hari Ini */}
        <div className="bg-gradient-to-br from-amber-50 to-orange-50/60 border border-amber-200/90 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-extrabold text-amber-900 uppercase tracking-wider">Piutang Hari Ini</span>
            <div className="p-2 bg-amber-600 text-white rounded-xl shadow-2xs">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-950">{fRp(todayStats.totalPiutang)}</div>
          <div className="text-[11px] text-amber-800/90 font-bold mt-2 pt-2 border-t border-amber-200/60">
            Perlu Pelunasan Cetak
          </div>
        </div>

        {/* Card 4: Low Stock Alert Summary Card */}
        <div className={`border rounded-2xl p-4 shadow-xs transition ${
          lowStockProducts.length > 0 
            ? 'bg-gradient-to-br from-red-50 to-rose-50/60 border-red-200/90' 
            : 'bg-gradient-to-br from-emerald-50 to-teal-50/60 border-emerald-200/90'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-xs font-extrabold uppercase tracking-wider ${
              lowStockProducts.length > 0 ? 'text-red-900' : 'text-emerald-900'
            }`}>
              {categoryFilter === 'Bahan Baku' ? 'Stok Bahan Baku Menipis' : 'Peringatan Stok Menipis'}
            </span>
            <div className={`p-2 rounded-xl text-white shadow-2xs ${
              lowStockProducts.length > 0 ? 'bg-red-600' : 'bg-emerald-600'
            }`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black flex items-center gap-2">
            <span className={lowStockProducts.length > 0 ? 'text-red-950' : 'text-emerald-950'}>
              {lowStockProducts.length}
            </span>
            <span className={`text-xs font-bold ${lowStockProducts.length > 0 ? 'text-red-800/80' : 'text-emerald-800/80'}`}>
              Item (≤ {stockThreshold})
            </span>
          </div>
          <div className={`text-[11px] mt-2 pt-2 border-t flex items-center justify-between font-bold ${
            lowStockProducts.length > 0 
              ? 'border-red-200/60 text-red-800/90' 
              : 'border-emerald-200/60 text-emerald-800/90'
          }`}>
            <span>
              {outOfStockCount > 0 ? `${outOfStockCount} item Habis` : (lowStockProducts.length > 0 ? 'Perlu Restock' : 'Semua stok aman')}
            </span>
            {onNavigateToBarangMasuk && lowStockProducts.length > 0 && (
              <button
                onClick={onNavigateToBarangMasuk}
                className="text-red-900 font-extrabold hover:underline flex items-center gap-0.5 bg-red-100/80 px-2 py-0.5 rounded-md border border-red-200/80"
              >
                <span>Restock</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* RINCIAN ARUS KAS MASUK (REAL) BERDASARKAN METODE PEMBAYARAN */}
      <div className="bg-white border border-stone-200/90 rounded-2xl p-3.5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 mb-3 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-orange-100 text-orange-700 shadow-2xs">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-black text-stone-900 uppercase tracking-wider">
                Rincian Arus Kas Masuk Hari Ini Menurut Metode Pembayaran
              </h4>
              <p className="text-[10px] text-stone-500 font-medium">
                Penerimaan uang nyata (DP & Pelunasan) yang masuk ke kasir hari ini
              </p>
            </div>
          </div>
          <div className="text-[11px] font-bold text-stone-700 bg-stone-100/90 border border-stone-200 px-3 py-1 rounded-xl self-start sm:self-auto">
            Total Kas Masuk Hari Ini: <span className="text-emerald-700 font-black">{fRp(todayCashInflow.Total)}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Tunai */}
          <div className="bg-gradient-to-br from-emerald-50/90 to-teal-50/60 border border-emerald-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
            <div>
              <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block mb-0.5">
                Kas Tunai
              </span>
              <span className="text-sm sm:text-base font-black text-emerald-950">
                {fRp(todayCashInflow.Tunai)}
              </span>
            </div>
            <div className="text-[10px] font-bold text-emerald-700 bg-emerald-100/90 px-2 py-0.5 rounded-md">
              {todayCashInflow.counts.Tunai} Trx
            </div>
          </div>

          {/* Transfer */}
          <div className="bg-gradient-to-br from-blue-50/90 to-indigo-50/60 border border-blue-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
            <div>
              <span className="text-[10px] font-extrabold text-blue-800 uppercase tracking-wider block mb-0.5">
                Transfer Bank
              </span>
              <span className="text-sm sm:text-base font-black text-blue-950">
                {fRp(todayCashInflow.Transfer)}
              </span>
            </div>
            <div className="text-[10px] font-bold text-blue-700 bg-blue-100/90 px-2 py-0.5 rounded-md">
              {todayCashInflow.counts.Transfer} Trx
            </div>
          </div>

          {/* Debet */}
          <div className="bg-gradient-to-br from-purple-50/90 to-fuchsia-50/60 border border-purple-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
            <div>
              <span className="text-[10px] font-extrabold text-purple-800 uppercase tracking-wider block mb-0.5">
                Kartu Debet
              </span>
              <span className="text-sm sm:text-base font-black text-purple-950">
                {fRp(todayCashInflow.Debet)}
              </span>
            </div>
            <div className="text-[10px] font-bold text-purple-700 bg-purple-100/90 px-2 py-0.5 rounded-md">
              {todayCashInflow.counts.Debet} Trx
            </div>
          </div>

          {/* QRIS */}
          <div className="bg-gradient-to-br from-amber-50/90 to-orange-50/60 border border-amber-200/80 rounded-xl p-3 flex items-center justify-between shadow-2xs">
            <div>
              <span className="text-[10px] font-extrabold text-amber-800 uppercase tracking-wider block mb-0.5">
                QRIS
              </span>
              <span className="text-sm sm:text-base font-black text-amber-950">
                {fRp(todayCashInflow.QRIS)}
              </span>
            </div>
            <div className="text-[10px] font-bold text-amber-700 bg-amber-100/90 px-2 py-0.5 rounded-md">
              {todayCashInflow.counts.QRIS} Trx
            </div>
          </div>
        </div>
      </div>

      {/* LOW STOCK ALERT FEATURE PANEL */}
      <div className="bg-white border border-stone-200 rounded-2xl p-3.5 sm:p-4 shadow-xs">
        {/* Panel Header */}
        <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-stone-100">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`p-2 rounded-xl shrink-0 ${
              lowStockProducts.length > 0 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'
            }`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="font-extrabold text-stone-900 text-xs sm:text-sm flex flex-wrap items-center gap-1.5">
                <span>Peringatan Stok Menipis & Habis</span>
                {lowStockProducts.length > 0 ? (
                  <span className="px-2 py-0.5 bg-red-100 text-red-800 font-black text-[10px] rounded-full border border-red-200 shrink-0">
                    {lowStockProducts.length} ITEM
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-black text-[10px] rounded-full border border-emerald-200 flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3 h-3" /> STOK AMAN
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-stone-500 truncate">
                {isStockPanelCollapsed ? 'Daftar stok disembunyikan. Klik "Buka" untuk melihat.' : 'Pemantauan sisa stok di bawah batas kritis.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsStockPanelCollapsed((prev) => !prev)}
            className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 active:scale-95 text-stone-800 text-xs font-extrabold rounded-xl transition border border-stone-300 flex items-center gap-1 shrink-0 shadow-2xs cursor-pointer"
          >
            {isStockPanelCollapsed ? (
              <>
                <ChevronDown className="w-4 h-4 text-orange-600" />
                <span className="hidden sm:inline">Buka Box</span>
                <span className="sm:hidden">Buka</span>
              </>
            ) : (
              <>
                <ChevronUp className="w-4 h-4 text-stone-600" />
                <span className="hidden sm:inline">Sembunyikan</span>
                <span className="sm:hidden">Lipat</span>
              </>
            )}
          </button>
        </div>

        {/* Panel Content */}
        {!isStockPanelCollapsed && (
          <div className="mt-3 space-y-3">
            {/* Filter controls */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-stone-50 p-1.5 rounded-xl border border-stone-200 text-xs font-bold text-stone-700">
                <Filter className="w-3.5 h-3.5 text-stone-500" />
                <span className="text-[11px]">Kategori:</span>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="bg-white border border-stone-300 rounded-lg px-2 py-1 text-xs font-black text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                >
                  <option value="Bahan Baku">Khusus Bahan Baku (Default)</option>
                  <option value="Semua">Semua Kategori</option>
                  {availableCategories
                    .filter((cat) => cat !== 'Bahan Baku' && cat !== 'Semua')
                    .map((cat, cIdx) => (
                      <option key={`dash-cat-${cat}-${cIdx}`} value={cat}>{cat}</option>
                    ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-stone-50 p-1.5 rounded-xl border border-stone-200 text-xs font-bold text-stone-700">
                <SlidersHorizontal className="w-3.5 h-3.5 text-stone-500" />
                <span className="text-[11px]">Batas Stok ≤</span>
                <select
                  value={stockThreshold}
                  onChange={(e) => setStockThreshold(Number(e.target.value))}
                  className="bg-white border border-stone-300 rounded-lg px-2 py-1 text-xs font-black text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                >
                  <option value={5}>5 pcs / m² / roll</option>
                  <option value={10}>10 pcs / m² / roll</option>
                  <option value={20}>20 pcs / m² / roll</option>
                  <option value={50}>50 pcs / m² / roll</option>
                </select>
              </div>
            </div>

            {/* Restricted Height Scrollable Container */}
            {lowStockProducts.length === 0 ? (
              <div className="py-5 text-center text-stone-500 bg-stone-50/50 rounded-xl border border-dashed border-stone-200">
                <CheckCircle2 className="w-7 h-7 mx-auto text-emerald-500 mb-1" />
                <p className="text-xs font-bold text-stone-800">
                  Tidak ada produk yang di bawah batas stok {stockThreshold}!
                </p>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Semua bahan cetak dan barang jualan terisi dalam kuantitas aman.
                </p>
              </div>
            ) : (
              <div className="max-h-[404px] overflow-y-auto pr-1 space-y-2 border border-stone-200/80 rounded-xl p-2 bg-stone-50/40">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {lowStockProducts.map((p, idx) => {
                    const isZero = p.numericStok <= 0;
                    return (
                      <div 
                        key={`${p.kode}-${p.nama}-${idx}`}
                        className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition ${
                          isZero 
                            ? 'bg-red-50/80 border-red-200' 
                            : 'bg-amber-50/80 border-amber-200'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-stone-200 text-stone-800 uppercase shrink-0">
                              {p.kode}
                            </span>
                            <span className="text-[11px] font-bold text-stone-500 truncate">
                              {p.kategori}
                            </span>
                          </div>
                          <div className="font-extrabold text-xs text-stone-900 mt-1 truncate" title={p.nama}>
                            {p.nama}
                          </div>
                          <div className="text-[11px] mt-1 flex items-center gap-2">
                            <span className={`font-black text-xs px-2 py-0.5 rounded-lg ${
                              isZero 
                                ? 'bg-red-600 text-white' 
                                : 'bg-amber-600 text-white'
                            }`}>
                              {isZero ? 'HABIS (0)' : `Sisa: ${p.stok || p.numericStok} ${p.satuan}`}
                            </span>
                            <span className="text-stone-500 text-[10px]">
                              Harga: {fRp(p.harga)}
                            </span>
                          </div>
                        </div>

                        {onNavigateToBarangMasuk && (
                          <button
                            onClick={() => onNavigateToBarangMasuk(p)}
                            className="px-2.5 py-1.5 bg-stone-900 hover:bg-orange-700 text-white text-[11px] font-extrabold rounded-lg shadow-xs flex items-center gap-1 transition shrink-0 active:scale-95 cursor-pointer"
                            title={`Isi Ulang Stok ${p.nama}`}
                          >
                            <PackagePlus className="w-3.5 h-3.5" />
                            <span>Restock</span>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (8 Cols): Tren Omzet 7 Hari Terakhir */}
        <div className="lg:col-span-8 bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-stone-100">
            <div>
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-600" />
                <span>Grafik Tren Omzet Penjualan (7 Hari Terakhir)</span>
              </h3>
              <p className="text-[11px] text-stone-500">Pergerakan total nominal transaksi penjualan harian.</p>
            </div>
            <span className="text-[10px] font-extrabold px-2 py-1 bg-stone-100 rounded-lg text-stone-700">
              Auto Sync Google Sheets
            </span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorOmzet" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#c2410c" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#c2410c" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="dateLabel" tick={{ fontSize: 11, fill: '#78716c' }} />
                <YAxis 
                  tick={{ fontSize: 10, fill: '#78716c' }}
                  tickFormatter={(val) => val >= 1000000 ? `${(val / 1000000).toFixed(1)}M` : `${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip 
                  formatter={(value: any) => [fRp(Number(value)), 'Total Omzet']}
                  contentStyle={{ borderRadius: '12px', borderColor: '#e7e5e4', fontSize: '12px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="omzet" 
                  stroke="#c2410c" 
                  strokeWidth={2.5}
                  fillOpacity={1} 
                  fill="url(#colorOmzet)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Column (4 Cols): Metode Pembayaran */}
        <div className="lg:col-span-4 bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-stone-100">
            <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-orange-600" />
              <span>Metode Pembayaran</span>
            </h3>
          </div>

          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={paymentMethodData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={65}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {paymentMethodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(val: any) => [fRp(Number(val) || 0), 'Kas Masuk']}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Breakdown Pills List */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-100 text-xs mt-1">
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-950">
              <span className="font-bold text-[11px] text-emerald-900">Tunai:</span>
              <span className="font-extrabold text-emerald-700">{fRp(todayCashInflow.Tunai)}</span>
            </div>
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-blue-50 border border-blue-100 text-blue-950">
              <span className="font-bold text-[11px] text-blue-900">Transfer:</span>
              <span className="font-extrabold text-blue-700">{fRp(todayCashInflow.Transfer)}</span>
            </div>
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-purple-50 border border-purple-100 text-purple-950">
              <span className="font-bold text-[11px] text-purple-900">Debet:</span>
              <span className="font-extrabold text-purple-700">{fRp(todayCashInflow.Debet)}</span>
            </div>
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-amber-50 border border-amber-100 text-amber-950">
              <span className="font-bold text-[11px] text-amber-900">QRIS:</span>
              <span className="font-extrabold text-amber-700">{fRp(todayCashInflow.QRIS)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Top Products Chart & Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 7 Cols: Top Selling Products BarChart */}
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-2 border-b border-stone-100 gap-2">
            <div>
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-600" />
                <span>Barang & Jasa Cetak Terlaris</span>
              </h3>
              <p className="text-[11px] text-stone-500">Peringkat 5 produk/jasa cetak dengan volume order tertinggi.</p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider hidden sm:inline">Periode:</span>
              <select
                value={topProductsScope}
                onChange={(e) => setTopProductsScope(e.target.value as any)}
                className="px-2.5 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-extrabold text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20 cursor-pointer shadow-2xs"
              >
                <option value="today">Hari Ini</option>
                <option value="7d">7 Hari Terakhir</option>
                <option value="30d">30 Hari Terakhir</option>
                <option value="month">Bulan Ini</option>
                <option value="custom">Custom Tanggal</option>
                <option value="all">Semua Periode</option>
              </select>
            </div>
          </div>

          {topProductsScope === 'custom' && (
            <div className="mb-2 p-2 bg-stone-50 border border-stone-200 rounded-xl flex flex-wrap items-center gap-2 text-xs font-bold text-stone-700 animate-in fade-in duration-150">
              <Calendar className="w-3.5 h-3.5 text-orange-600" />
              <span>Dari:</span>
              <input
                type="date"
                value={topProductsStartDate}
                onChange={(e) => setTopProductsStartDate(e.target.value)}
                className="bg-white border border-stone-300 rounded-lg px-2 py-0.5 text-xs font-extrabold text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
              />
              <span>Sampai:</span>
              <input
                type="date"
                value={topProductsEndDate}
                onChange={(e) => setTopProductsEndDate(e.target.value)}
                className="bg-white border border-stone-300 rounded-lg px-2 py-0.5 text-xs font-extrabold text-stone-800 focus:outline-none focus:ring-2 focus:ring-orange-500/20"
              />
            </div>
          )}

          {topProductsData.length === 0 ? (
            <div className="h-60 w-full flex flex-col items-center justify-center text-stone-400 text-xs font-medium border border-dashed border-stone-200 rounded-xl my-2 p-4 text-center">
              <span>Belum ada data rincian barang/jasa cetak terlaris pada periode ini.</span>
              <span className="text-[11px] text-stone-400 mt-1">Sistem hanya menampilkan transaksi riil yang memiliki rincian produk.</span>
            </div>
          ) : (
            <div className="h-60 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProductsData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#78716c' }} />
                  <YAxis dataKey="name" type="category" width={110} tick={{ fontSize: 11, fill: '#44403c', fontWeight: 600 }} />
                  <Tooltip 
                    formatter={(value: any, name: any) => [
                      name === 'jumlahOrder' ? `${value} x Order` : fRp(Number(value)),
                      name === 'jumlahOrder' ? 'Total Order' : 'Est. Nilai'
                    ]}
                    contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                  />
                  <Bar dataKey="jumlahOrder" fill="#c2410c" radius={[0, 8, 8, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Right 5 Cols: Today's Orders Quick List */}
        <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-4 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-stone-100">
            <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4 text-orange-600" />
              <span>Transaksi Terbaru Hari Ini</span>
            </h3>
            <span className="text-[11px] font-bold text-stone-500">
              {todayInvoices.length} Order
            </span>
          </div>

          <div className="flex-1 overflow-y-auto max-h-56 divide-y divide-stone-100 pr-1">
            {todayInvoices.length === 0 ? (
              <div className="py-10 text-center text-stone-400">
                <p className="text-xs font-semibold">Belum ada transaksi tercatat hari ini.</p>
                <button
                  onClick={onNavigateToTransaksi}
                  className="mt-2 text-xs text-orange-700 font-bold hover:underline"
                >
                  + Mulai Kasir Transaksi
                </button>
              </div>
            ) : (
              todayInvoices.slice(0, 10).map((inv, idx) => (
                <div key={`${inv.invoiceNo}-${idx}`} className="py-2 hover:bg-stone-50 px-2 rounded-xl transition flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-xs text-stone-900">{inv.invoiceNo}</div>
                    <div className="text-[10px] text-stone-500">
                      {inv.customer || 'Umum'} • Jam {inv.time || '-'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-xs text-stone-900">{fRp(inv.total || 0)}</div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md ${
                      (inv.sisa || 0) <= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {(inv.sisa || 0) <= 0 ? 'LUNAS' : `DP ${fRp(inv.sisa || 0)}`}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
