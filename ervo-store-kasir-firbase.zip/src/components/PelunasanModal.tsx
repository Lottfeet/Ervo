import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  BadgeDollarSign, 
  CheckCircle2, 
  AlertCircle, 
  Receipt, 
  Printer,
  Loader2,
  RefreshCw,
  History,
  Clock,
  CreditCard,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Invoice, StoreSettings, PiutangItem, PelunasanRecord } from '../types';
import { getInvoiceByNo, submitPelunasan, fetchPiutangList, getPelunasanHistory, savePelunasanHistoryToLocal, sortPelunasanHistoryAsc, mergePelunasanHistories } from '../services/gasService';
import { saveInvoiceFirebase, subscribeInvoices } from '../services/firebaseService';
import { syncPelunasanToPayroll } from '../services/payrollSyncService';
import { fRp, fDate, fTime, fDec } from '../utils/formatters';
import { generatePelunasanReceiptHTML, generateA5HTML, openPrintWindow } from '../utils/printUtils';

interface PelunasanModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const PelunasanModal: React.FC<PelunasanModalProps> = ({
  isOpen,
  onClose,
  settings,
  onShowToast,
}) => {
  const [searchInv, setSearchInv] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingList, setLoadingList] = useState(false);
  const [piutangList, setPiutangList] = useState<PiutangItem[]>([]);
  const [invData, setInvData] = useState<any | null>(null);
  const [historyList, setHistoryList] = useState<PelunasanRecord[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(true);
  const [jumlahBayar, setJumlahBayar] = useState<string>('');
  const [payMethod, setPayMethod] = useState('Tunai');
  const [catatan, setCatatan] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isDone, setIsDone] = useState(false);
  const [lastResult, setLastResult] = useState<any | null>(null);

  const formatInvoiceDate = (dateStr?: string) => {
    if (!dateStr) return '';
    if (dateStr.includes('T') || dateStr.includes('-')) {
      try {
        const d = new Date(dateStr);
        if (!isNaN(d.getTime())) {
          const day = String(d.getDate()).padStart(2, '0');
          const month = String(d.getMonth() + 1).padStart(2, '0');
          const year = d.getFullYear();
          return `${day}/${month}/${year}`;
        }
      } catch {}
    }
    return dateStr;
  };

  const loadUnpaidList = async (autoSelectFirst = false, forceRefresh = false) => {
    setLoadingList(true);
    const list = await fetchPiutangList(forceRefresh);
    setPiutangList(list);
    setLoadingList(false);

    if (autoSelectFirst && list.length > 0 && !searchInv) {
      const firstNo = list[0].invoiceNo;
      setSearchInv(firstNo);
      fetchInvoiceDetail(firstNo);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setInvData(null);
      setIsDone(false);
      setLastResult(null);
      loadUnpaidList(true);
      const unsub = subscribeInvoices(() => {
        loadUnpaidList(false, true);
      });
      return () => {
        unsub();
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const fetchInvoiceDetail = async (noToFetch: string) => {
    if (!noToFetch.trim()) return;

    setLoading(true);
    setInvData(null);
    setHistoryList([]);
    setIsDone(false);
    setLastResult(null);

    const res = await getInvoiceByNo(noToFetch.trim());
    setLoading(false);

    if (res.success && res.data) {
      const inv = res.data;

      // Fetch payment history
      const backendHist = Array.isArray((inv as any).historiPelunasan) && (inv as any).historiPelunasan.length > 0
        ? (inv as any).historiPelunasan
        : (Array.isArray((inv as any).pelunasanHistory) ? (inv as any).pelunasanHistory : null);
      const localHist = getPelunasanHistory(inv.invoiceNo);
      const rawList: PelunasanRecord[] = mergePelunasanHistories(backendHist, localHist);
      const totalInv = Number(inv.total || 0);
      const dpAmt = Number(inv.dp || 0);
      
      // Total paid in previous installments/angsuran
      const totalPaidHist = rawList.reduce((acc, h) => acc + Number(h.jumlahBayar || 0), 0);
      
      // Actual remaining balance right now (Total - DP - all previous angsuran)
      const currentSisa = String(inv.status || '').toUpperCase() === 'LUNAS' ? 0 : Math.max(0, totalInv - dpAmt - totalPaidHist);

      // Reconstruct running balance for history list (starting after DP)
      let runningBal = Math.max(0, totalInv - dpAmt);
      const formattedHist = rawList.map((hItem) => {
        const b = Number(hItem.jumlahBayar || 0);
        runningBal = Math.max(0, runningBal - b);
        return {
          ...hItem,
          newSisa: runningBal,
        };
      });

      setHistoryList(formattedHist);
      setInvData({ 
        ...inv, 
        dp: dpAmt,
        sisa: currentSisa, 
        sisaAwal: currentSisa,
        totalPaidHist
      });
      setJumlahBayar(String(currentSisa));
    } else {
      onShowToast(res.message || 'Invoice tidak ditemukan', 'error');
    }
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchInv.trim()) {
      onShowToast('Masukkan nomor invoice terlebih dahulu', 'error');
      return;
    }
    fetchInvoiceDetail(searchInv.trim());
  };

  const handleSelectDropdown = (no: string) => {
    if (!no) return;
    setSearchInv(no);
    fetchInvoiceDetail(no);
  };

  const handleConfirmPay = async () => {
    if (!invData) return;
    const bayar = parseFloat(String(jumlahBayar).replace(',', '.')) || 0;
    if (bayar <= 0) {
      onShowToast('Masukkan jumlah bayar yang valid', 'error');
      return;
    }

    setIsSaving(true);

    const sisaVal = invData.sisa !== undefined ? invData.sisa : (invData.sisaAwal || 0);
    const newSisa = Math.max(0, sisaVal - bayar);
    const kembalian = bayar > sisaVal ? bayar - sisaVal : 0;

    const newRecord: PelunasanRecord = {
      id: 'pel_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      invoiceNo: invData.invoiceNo,
      date: fDate(new Date()),
      time: fTime(new Date()),
      customer: invData.customer || 'Umum',
      cashier: settings.cashier || 'Admin',
      kasir: settings.cashier || 'Admin',
      payMethod,
      jumlahBayar: bayar,
      sisaAwal: sisaVal,
      newSisa,
      status: newSisa <= 0 ? 'LUNAS' : 'DP',
      catatan,
    };

    // Save locally instantly
    savePelunasanHistoryToLocal(newRecord);

    const existingHist = Array.isArray(invData.pelunasanHistory) && invData.pelunasanHistory.length > 0
      ? invData.pelunasanHistory
      : (Array.isArray(invData.historiPelunasan) ? invData.historiPelunasan : []);
    const localHist = getPelunasanHistory(invData.invoiceNo);
    const mergedList = mergePelunasanHistories(existingHist, [...localHist, newRecord]);

    const resultObj = {
      ...invData,
      payMethodBayar: payMethod,
      jumlahBayar: bayar,
      newSisa,
      kembalian,
      status: newSisa <= 0 ? 'LUNAS' : 'DP',
      date: fDate(new Date()),
      time: fTime(new Date()),
      historiPelunasan: mergedList,
      pelunasanHistory: mergedList,
    };

    setLastResult(resultObj);
    setIsSaving(false);
    setIsDone(true);
    onShowToast('Pelunasan berhasil disimpan', 'success');

    // Save updated invoice to Firebase Firestore & Google Sheets in background
    saveInvoiceFirebase({
      ...invData,
      sisa: newSisa,
      status: newSisa <= 0 ? 'LUNAS' : 'DP',
      pelunasanHistory: mergedList,
      historiPelunasan: mergedList,
    } as Invoice).catch((err) => {
      console.warn('Firebase save invoice failed:', err);
    });

    submitPelunasan(newRecord).catch((err) => {
      console.warn('Async pelunasan error:', err);
    });

    // Sync pelunasan payment to ERVO Payroll Cloud Firestore
    syncPelunasanToPayroll({
      invoiceNo: invData.invoiceNo || invData.noInvoice,
      jumlahBayar: bayar,
      payMethod,
      tanggal: new Date(),
    }).catch((err) => {
      console.warn('Async pelunasan payroll sync error:', err);
    });

    const totalInv = Number(invData.total || 0);
    const dpAmt = Number(invData.dp || 0);
    let runningBal = Math.max(0, totalInv - dpAmt);
    const formattedHist = mergedList.map((hItem) => {
      const b = Number(hItem.jumlahBayar || 0);
      runningBal = Math.max(0, runningBal - b);
      return {
        ...hItem,
        newSisa: runningBal,
      };
    });
    setHistoryList(formattedHist);
    loadUnpaidList(false);
  };

  const handlePrintNota = () => {
    if (!lastResult) return;
    const html = generatePelunasanReceiptHTML(lastResult, settings);
    openPrintWindow(html, 'PELUNASAN-' + lastResult.invoiceNo);
  };

  const handlePrintA5 = () => {
    if (!lastResult) return;
    const html = generateA5HTML(lastResult, settings);
    openPrintWindow(html, 'INVOICE-A5-PELUNASAN-' + lastResult.invoiceNo);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-stone-900/50 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold">
              <BadgeDollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base">Pelunasan Piutang</h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Bayar sisa transaksi DP / piutang pelanggan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-4 space-y-4">
          {/* Dropdown Auto-Select Invoice Belum Lunas */}
          <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/80 space-y-1.5">
            <div className="text-xs font-bold text-amber-900">
              <span>Daftar Invoice Belum Lunas ({piutangList.length}):</span>
            </div>

            {loadingList ? (
              <div className="flex items-center gap-2 py-2 text-xs text-amber-800/80 italic">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-600" />
                <span>Memuat data piutang...</span>
              </div>
            ) : piutangList.length > 0 ? (
              <select
                value={searchInv}
                onChange={(e) => handleSelectDropdown(e.target.value)}
                className="w-full py-2 px-2.5 border border-amber-300 rounded-lg text-xs font-mono font-bold bg-white text-stone-900 shadow-xs focus:ring-2 focus:ring-amber-200 focus:border-amber-600 transition truncate"
              >
                <option value="">-- Pilih No. Invoice Belum Lunas --</option>
                {piutangList.map((item, idx) => (
                  <option key={`${item.invoiceNo}-${idx}`} value={item.invoiceNo}>
                    {item.invoiceNo} • {item.customer || 'Umum'} {formatInvoiceDate(item.date) ? `(${formatInvoiceDate(item.date)})` : ''} • Sisa: Rp {Number(item.sisa || 0).toLocaleString('id-ID')}
                  </option>
                ))}
              </select>
            ) : (
              <p className="text-[11px] text-amber-800 italic">
                Tidak ada transaksi piutang/belum lunas saat ini.
              </p>
            )}
          </div>

          {/* Search Box */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchInv}
                onChange={(e) => setSearchInv(e.target.value)}
                placeholder="Atau ketik No. Invoice (misal: INV-20260729-001)..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs font-mono font-bold focus:outline-none focus:border-orange-600 focus:ring-2 focus:ring-orange-100"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-orange-700 hover:bg-orange-800 text-white text-xs font-bold rounded-lg transition active:scale-95 disabled:opacity-50 shrink-0 flex items-center gap-1.5"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Cari'}
            </button>
          </form>

          {loading && !invData && (
            <div className="p-8 text-center text-xs text-stone-500 space-y-2">
              <Loader2 className="w-6 h-6 animate-spin text-orange-600 mx-auto" />
              <p className="font-semibold">Mengambil rincian piutang...</p>
            </div>
          )}

          {/* Invoice Card Info */}
          {invData && (
            <div className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono font-extrabold text-sm text-stone-900">
                  {invData.invoiceNo}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    invData.sisaAwal <= 0
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-200 text-amber-900'
                  }`}
                >
                  {invData.sisaAwal <= 0 ? '✓ LUNAS' : 'DP / UNPAID'}
                </span>
              </div>
              <div className="text-xs text-stone-600">
                <span className="font-semibold">{invData.customer || 'Umum'}</span> • {invData.date}
              </div>

              {/* Items Summary Breakdown */}
              <div className="max-h-32 overflow-y-auto space-y-1 text-xs border-y border-amber-200/80 py-2 bg-amber-50/50 -mx-1 px-1.5 rounded-md">
                <div className="text-[10px] font-bold text-amber-900 uppercase tracking-wide mb-1">
                  Rincian Jasa / Item ({invData.items?.length || 0}):
                </div>
                {invData.items && invData.items.length > 0 ? (
                  invData.items.map((it: any, i: number) => {
                    const hasDim = parseFloat(it.panjang) > 0 && parseFloat(it.lebar) > 0;
                    const dimStr = hasDim ? ` (${fDec(it.panjang, 2)}x${fDec(it.lebar, 2)}m)` : '';
                    return (
                      <div key={i} className="text-stone-700 text-[11px] pb-1 border-b border-amber-200/40 last:border-b-0">
                        <div className="flex justify-between">
                          <span className="truncate pr-2 font-medium">
                            • {it.nama}{dimStr} <span className="text-stone-500 font-mono">({fDec(it.qty, 2).replace(/\.?0+$/, '')} {it.satuan || 'pcs'})</span>
                          </span>
                          <span className="font-semibold shrink-0">
                            {fRp(it.totalItem !== undefined ? it.totalItem : (it.harga || 0) * (it.qty || 1))}
                          </span>
                        </div>
                        {it.catatan && (
                          <div className="text-[10px] text-amber-900 font-bold ml-2.5 flex items-center gap-1">
                            <span className="text-amber-700">📁 File:</span>
                            <span>{it.catatan}</span>
                          </div>
                        )}
                      </div>
                    );
                  })
                ) : (
                  <p className="text-stone-400 italic text-[11px]">Rincian item tidak tersedia</p>
                )}
              </div>

              <div className="pt-1 space-y-1 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Total Invoice</span>
                  <span className="font-semibold">{fRp(Number(invData.total || 0))}</span>
                </div>
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>DP Sudah Dibayar</span>
                  <span>{fRp(Number(invData.dp || 0))}</span>
                </div>
                {Number(invData.totalPaidHist || 0) > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Angsuran Terbayar ({historyList.length}x)</span>
                    <span>{fRp(Number(invData.totalPaidHist))}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black border-t border-amber-200 pt-1">
                  <span className={invData.sisa <= 0 ? 'text-emerald-700' : 'text-red-700'}>
                    Sisa Tagihan
                  </span>
                  <span className={invData.sisa <= 0 ? 'text-emerald-700' : 'text-red-700'}>
                    {fRp(invData.sisa)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Histori Pembayaran & Angsuran Timeline */}
          {invData && (
            <div className="rounded-xl border border-stone-200 overflow-hidden bg-stone-50/50">
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="w-full px-3.5 py-2.5 bg-stone-100 hover:bg-stone-200/80 flex items-center justify-between text-xs font-extrabold text-stone-800 transition"
              >
                <div className="flex items-center gap-1.5">
                  <History className="w-4 h-4 text-orange-600" />
                  <span>Histori Pembayaran & Angsuran ({(Number(invData.dp || 0) > 0 ? 1 : 0) + historyList.length})</span>
                </div>
                {showHistory ? <ChevronUp className="w-4 h-4 text-stone-500" /> : <ChevronDown className="w-4 h-4 text-stone-500" />}
              </button>

              {showHistory && (
                <div className="p-3 space-y-2 text-xs border-t border-stone-200">
                  {/* Item #1: DP / Transaksi Awal (only if DP > 0) */}
                  {Number(invData.dp || 0) > 0 && (
                    <div className="p-2.5 rounded-lg bg-white border border-stone-200 space-y-1">
                      <div className="flex items-center justify-between font-bold">
                        <span className="text-orange-900 flex items-center gap-1.5">
                          <span className="w-4 h-4 rounded-full bg-orange-100 text-orange-700 text-[10px] flex items-center justify-center font-extrabold">1</span>
                          DP / Pembayaran Awal
                        </span>
                        <span className="font-extrabold text-emerald-700">{fRp(Number(invData.dp || 0))}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-stone-500 font-medium pl-5">
                        <span>{invData.date} {invData.time || ''}</span>
                        <span className="px-1.5 py-0.5 rounded bg-stone-100 text-stone-700 text-[10px] font-bold">{invData.payMethod || 'Tunai'}</span>
                      </div>
                    </div>
                  )}

                  {/* Items: Histori Pelunasan / Cicilan */}
                  {historyList.map((h, idx) => {
                    const itemNo = Number(invData.dp || 0) > 0 ? idx + 2 : idx + 1;
                    return (
                      <div key={idx} className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200/80 space-y-1">
                        <div className="flex items-center justify-between font-bold">
                          <span className="text-emerald-900 flex items-center gap-1.5">
                            <span className="w-4 h-4 rounded-full bg-emerald-200 text-emerald-800 text-[10px] flex items-center justify-center font-extrabold">{itemNo}</span>
                            Pelunasan / Angsuran #{idx + 1}
                          </span>
                          <span className="font-extrabold text-emerald-700">{fRp(h.jumlahBayar)}</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-stone-600 font-medium pl-5">
                          <span>{h.date} {h.time || ''} • Kasir: {h.cashier || 'Admin'}</span>
                          <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">{h.payMethod}</span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-stone-500 pt-1 border-t border-emerald-100/80 pl-5">
                          <span>Sisa Setelah Bayar: <strong className="text-stone-800">{fRp(h.newSisa !== undefined ? h.newSisa : 0)}</strong></span>
                          {h.catatan && <span className="italic truncate max-w-[140px] text-stone-600">"{h.catatan}"</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Payment Input Form */}
          {invData && invData.sisaAwal > 0 && !isDone && (
            <div className="space-y-3 pt-1 border-t border-stone-200">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-stone-700 mb-1 block">Metode</label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value)}
                    className="w-full py-2 px-2.5 border border-stone-200 rounded-lg text-xs font-semibold bg-white"
                  >
                    <option value="Tunai">Tunai</option>
                    <option value="Transfer">Transfer</option>
                    <option value="Debet">Debet</option>
                    <option value="QRIS">QRIS</option>
                    <option value="Kartu">Kartu</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-stone-700 mb-1 block">
                    Jumlah Bayar
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={jumlahBayar}
                    onChange={(e) => setJumlahBayar(e.target.value.replace(/[^0-9.,]/g, ''))}
                    onFocus={(e) => (e.target as HTMLInputElement).select()}
                    className="w-full py-2 px-2.5 border border-stone-200 rounded-lg text-xs font-extrabold text-orange-700 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 mb-1 block">
                  Catatan Pelunasan (Opsional)
                </label>
                <input
                  type="text"
                  value={catatan}
                  onChange={(e) => setCatatan(e.target.value)}
                  placeholder="cth: Pelunasan via Transfer BCA..."
                  className="w-full py-2 px-3 border border-stone-200 rounded-lg text-xs font-medium"
                />
              </div>

              <button
                onClick={handleConfirmPay}
                disabled={isSaving}
                className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition active:scale-98 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Menyimpan ke Google Sheets...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Simpan Pembayaran Pelunasan</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Success Result & Print */}
          {isDone && lastResult && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-extrabold text-stone-900 text-sm">
                  Pelunasan Berhasil Disimpan
                </h4>
                <p className="text-xs text-stone-600 mt-0.5">
                  Sisa Akhir: <strong className="text-emerald-800">{fRp(lastResult.newSisa)}</strong>
                  {lastResult.kembalian > 0 && ` • Kembalian: ${fRp(lastResult.kembalian)}`}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={handlePrintNota}
                  className="py-2.5 px-3 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs"
                >
                  <Receipt className="w-4 h-4 text-orange-400" />
                  <span>Struk Thermal (80mm)</span>
                </button>

                <button
                  onClick={handlePrintA5}
                  className="py-2.5 px-3 bg-orange-700 hover:bg-orange-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs"
                >
                  <Printer className="w-4 h-4" />
                  <span>Invoice A5</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
