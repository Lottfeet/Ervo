// Service for tracking, monitoring, and budgeting daily Firebase Firestore reads, writes, and deletes.
// Provides Spark Plan (Free Tier) limits, daily auto-rollover, and reactive metrics for Admin/Settings UI.

export interface CollectionQuotaBreakdown {
  reads: number;
  writes: number;
  deletes: number;
}

export interface DailyUsageHistoryItem {
  date: string;
  reads: number;
  writes: number;
  deletes: number;
  savedReads: number;
  savedWrites: number;
}

export interface QuotaMetrics {
  date: string; // YYYY-MM-DD
  reads: number;
  writes: number;
  deletes: number;
  savedReads: number;
  savedWrites: number;
  byCollection: Record<string, CollectionQuotaBreakdown>;
  byOperation: Record<string, number>;
  lastUpdated: string;
  quotaExceeded: boolean;
  history: DailyUsageHistoryItem[];
}

export const FIRESTORE_SPARK_LIMITS = {
  DAILY_READS: 50000,
  DAILY_WRITES: 20000,
  DAILY_DELETES: 20000,
};

const STORAGE_KEY = 'strukku_firestore_quota_metrics';
const EVENT_NAME = 'firestore-quota-metric-updated';

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getDefaultMetrics(): QuotaMetrics {
  return {
    date: getTodayString(),
    reads: 0,
    writes: 0,
    deletes: 0,
    savedReads: 0,
    savedWrites: 0,
    byCollection: {},
    byOperation: {},
    lastUpdated: new Date().toISOString(),
    quotaExceeded: false,
    history: [],
  };
}

let inMemoryMetrics: QuotaMetrics | null = null;
const listeners = new Set<(metrics: QuotaMetrics) => void>();

function notifyListeners(metrics: QuotaMetrics) {
  listeners.forEach((fn) => {
    try {
      fn(metrics);
    } catch (e) {
      console.warn('Quota listener error:', e);
    }
  });

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: metrics }));
  }
}

export function getFirestoreQuotaMetrics(): QuotaMetrics {
  if (inMemoryMetrics) {
    checkAndRolloverDate(inMemoryMetrics);
    return inMemoryMetrics;
  }

  if (typeof window === 'undefined') {
    return getDefaultMetrics();
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed: QuotaMetrics = JSON.parse(raw);
      checkAndRolloverDate(parsed);
      inMemoryMetrics = parsed;
      return parsed;
    }
  } catch (e) {
    console.warn('Error reading firestore quota metrics:', e);
  }

  const initial = getDefaultMetrics();
  inMemoryMetrics = initial;
  saveMetrics(initial);
  return initial;
}

function checkAndRolloverDate(metrics: QuotaMetrics): boolean {
  const today = getTodayString();
  if (metrics.date !== today) {
    // Archive previous day's metrics to history (keep 7 days)
    const historyItem: DailyUsageHistoryItem = {
      date: metrics.date,
      reads: metrics.reads,
      writes: metrics.writes,
      deletes: metrics.deletes,
      savedReads: metrics.savedReads || 0,
      savedWrites: metrics.savedWrites || 0,
    };

    const existingHistory = Array.isArray(metrics.history) ? metrics.history : [];
    const updatedHistory = [historyItem, ...existingHistory.filter((h) => h.date !== metrics.date)].slice(0, 7);

    metrics.date = today;
    metrics.reads = 0;
    metrics.writes = 0;
    metrics.deletes = 0;
    metrics.savedReads = 0;
    metrics.savedWrites = 0;
    metrics.byCollection = {};
    metrics.byOperation = {};
    metrics.quotaExceeded = false;
    metrics.history = updatedHistory;
    metrics.lastUpdated = new Date().toISOString();

    // Also clear session quota block on new day
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('firestore_quota_exceeded');
      localStorage.removeItem('firestore_quota_exceeded');
    }

    saveMetrics(metrics);
    return true;
  }
  return false;
}

function saveMetrics(metrics: QuotaMetrics) {
  inMemoryMetrics = metrics;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(metrics));
    } catch {}
  }
}

export function recordFirestoreRead(collectionName: string, count: number = 1, operation: string = 'read'): void {
  if (count <= 0) return;
  const metrics = getFirestoreQuotaMetrics();
  metrics.reads += count;

  if (!metrics.byCollection[collectionName]) {
    metrics.byCollection[collectionName] = { reads: 0, writes: 0, deletes: 0 };
  }
  metrics.byCollection[collectionName].reads += count;

  metrics.byOperation[operation] = (metrics.byOperation[operation] || 0) + count;
  metrics.lastUpdated = new Date().toISOString();

  saveMetrics(metrics);
  notifyListeners(metrics);
}

export function recordFirestoreWrite(collectionName: string, count: number = 1, operation: string = 'write'): void {
  if (count <= 0) return;
  const metrics = getFirestoreQuotaMetrics();
  metrics.writes += count;

  if (!metrics.byCollection[collectionName]) {
    metrics.byCollection[collectionName] = { reads: 0, writes: 0, deletes: 0 };
  }
  metrics.byCollection[collectionName].writes += count;

  metrics.byOperation[operation] = (metrics.byOperation[operation] || 0) + count;
  metrics.lastUpdated = new Date().toISOString();

  saveMetrics(metrics);
  notifyListeners(metrics);
}

export function recordFirestoreDelete(collectionName: string, count: number = 1, operation: string = 'delete'): void {
  if (count <= 0) return;
  const metrics = getFirestoreQuotaMetrics();
  metrics.deletes += count;

  if (!metrics.byCollection[collectionName]) {
    metrics.byCollection[collectionName] = { reads: 0, writes: 0, deletes: 0 };
  }
  metrics.byCollection[collectionName].deletes += count;

  metrics.byOperation[operation] = (metrics.byOperation[operation] || 0) + count;
  metrics.lastUpdated = new Date().toISOString();

  saveMetrics(metrics);
  notifyListeners(metrics);
}

export function recordQuotaSavings(type: 'read' | 'write', count: number = 1, _reason?: string): void {
  if (count <= 0) return;
  const metrics = getFirestoreQuotaMetrics();
  if (type === 'read') {
    metrics.savedReads = (metrics.savedReads || 0) + count;
  } else {
    metrics.savedWrites = (metrics.savedWrites || 0) + count;
  }
  metrics.lastUpdated = new Date().toISOString();
  saveMetrics(metrics);
  notifyListeners(metrics);
}

export function markFirestoreQuotaExceeded(reason?: string): void {
  const metrics = getFirestoreQuotaMetrics();
  metrics.quotaExceeded = true;
  metrics.lastUpdated = new Date().toISOString();
  saveMetrics(metrics);
  if (typeof window !== 'undefined') {
    sessionStorage.setItem('firestore_quota_exceeded', 'true');
    window.dispatchEvent(new CustomEvent('firestore-quota-exceeded', { detail: reason || 'Quota exceeded' }));
  }
  notifyListeners(metrics);
}

export function resetFirestoreDailyMetrics(): QuotaMetrics {
  const reset = getDefaultMetrics();
  // Preserve history
  if (inMemoryMetrics && inMemoryMetrics.history) {
    reset.history = inMemoryMetrics.history;
  }
  inMemoryMetrics = reset;
  saveMetrics(reset);
  if (typeof window !== 'undefined') {
    sessionStorage.removeItem('firestore_quota_exceeded');
    localStorage.removeItem('firestore_quota_exceeded');
  }
  notifyListeners(reset);
  return reset;
}

export function subscribeQuotaMetrics(listener: (metrics: QuotaMetrics) => void): () => void {
  listeners.add(listener);
  // Initial fire
  listener(getFirestoreQuotaMetrics());
  return () => {
    listeners.delete(listener);
  };
}

export function isFirestoreQuotaExceeded(): boolean {
  if (typeof window === 'undefined') return false;
  const inSession = sessionStorage.getItem('firestore_quota_exceeded') === 'true';
  if (inSession) return true;
  const m = getFirestoreQuotaMetrics();
  return m.quotaExceeded;
}

export function getFirebaseConsoleUsageUrl(): string {
  const projectId = 'responsive-crossing-b5jvd';
  const databaseId = 'ai-studio-ervostore-5d8b9daa-41d8-4ad1-a296-d9a995b48463';
  return `https://console.firebase.google.com/project/${projectId}/firestore/databases/${databaseId}/usage`;
}
