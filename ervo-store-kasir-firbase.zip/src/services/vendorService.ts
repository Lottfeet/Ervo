import { Vendor } from '../types';
import { db } from './firebase';
import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  query,
  limit,
  serverTimestamp 
} from 'firebase/firestore';
import { isFirestoreQuotaExceeded, handleFirestoreError, OperationType } from './firebaseService';
import { recordFirestoreRead, recordFirestoreWrite, recordFirestoreDelete } from './firestoreQuotaService';

const VENDORS_STORAGE_KEY = 'strukku_vendors_list';
const VENDORS_INITIALIZED_KEY = 'strukku_vendors_initialized';
const DELETED_VENDORS_KEY = 'strukku_deleted_vendor_ids';

export function getDeletedVendorIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DELETED_VENDORS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return new Set(parsed);
    }
  } catch {}
  return new Set();
}

export function recordDeletedVendorId(id: string, name?: string) {
  try {
    const deleted = getDeletedVendorIds();
    deleted.add(id);
    if (name) {
      deleted.add(name.trim().toLowerCase());
    }
    localStorage.setItem(DELETED_VENDORS_KEY, JSON.stringify(Array.from(deleted)));
  } catch {}
}

export function unrecordDeletedVendorId(id: string) {
  try {
    const deleted = getDeletedVendorIds();
    if (deleted.has(id)) {
      deleted.delete(id);
      localStorage.setItem(DELETED_VENDORS_KEY, JSON.stringify(Array.from(deleted)));
    }
  } catch {}
}

export function clearDeletedVendorIds() {
  try {
    localStorage.removeItem(DELETED_VENDORS_KEY);
  } catch {}
}

export const INITIAL_DEFAULT_VENDORS: Vendor[] = [
  {
    id: 'ven-1',
    nama: 'PT. KNITTO TEKSTIL INDONESIA (CBD)',
    kategori: 'Tekstil & Garment',
    telepon: '0812-3456-7890',
    email: 'order@knitto.co.id',
    alamat: 'Jl. Holis No. 35, Bandung, Jawa Barat',
    kontakPerson: 'Bpk. Hendra Wijaya',
    nomorRekening: 'BCA 0088-291-331 a.n PT Knitto Tekstil',
    catatan: 'Suplier bahan kaos combed, fleece, baby terry, dan rib katun.',
    createdAt: '2026-01-10',
  },
  {
    id: 'ven-2',
    nama: 'PT. INDO SURYA GRAFIKA',
    kategori: 'Banner & Digital Printing',
    telepon: '0813-8899-1122',
    email: 'sales@indosuryagrafika.com',
    alamat: 'Kawasan Industri Candi Blok C-5, Semarang',
    kontakPerson: 'Ibu Maya Santoso',
    nomorRekening: 'Mandiri 137-00-9876543 a.n Indo Surya Grafika',
    catatan: 'Suplier bahan flexy frontlite, backlite, banner korea, luster & kain TC.',
    createdAt: '2026-01-12',
  },
  {
    id: 'ven-3',
    nama: 'TOKO SUMBER BAHAN GRAFIKA',
    kategori: 'Tinta & Sparepart',
    telepon: '0811-2233-4455',
    email: 'sumber.grafika@gmail.com',
    alamat: 'Jl. Otista No. 110, Bandung',
    kontakPerson: 'Koh Andy Pratama',
    nomorRekening: 'BCA 145-223-9988 a.n Sumber Bahan Grafika',
    catatan: 'Tinta ecosolvent, UV ink, sublim, cleaner head, wiper & damper.',
    createdAt: '2026-01-15',
  },
  {
    id: 'ven-4',
    nama: 'SURYA PALAPA DISTRIBUTOR KERTAS',
    kategori: 'Kertas & Offset',
    telepon: '0852-1122-3344',
    email: 'order.suryapalapa@gmail.com',
    alamat: 'Jl. Soekarno Hatta No. 450, Bandung',
    kontakPerson: 'Bpk. Dedi Supriatna',
    nomorRekening: 'BRI 0123-01-002233-50-1 a.n Surya Palapa',
    catatan: 'Art Paper, Art Carton, Ivory, HVS plano, Samson kraft & Duplex.',
    createdAt: '2026-01-20',
  },
  {
    id: 'ven-5',
    nama: 'CV. PRIMA DIGITAL REKATAMA',
    kategori: 'Sticker & Display',
    telepon: '0878-9900-1122',
    email: 'primadigital@rekatama.id',
    alamat: 'Jl. Leuwi Panjang No. 88, Bandung',
    kontakPerson: 'Mas Bagus Nugraha',
    nomorRekening: 'BCA 282-019-2231 a.n CV Prima Digital',
    catatan: 'Sticker vinyl Ritrama, Orajet, cutting sticker Oracal, lamination cold.',
    createdAt: '2026-02-01',
  },
  {
    id: 'ven-6',
    nama: 'PABRIK AKRILIK & DISPLAY MANDIRI',
    kategori: 'Akrilik & Display',
    telepon: '0819-3344-5566',
    email: 'displaymandiri@yahoo.com',
    alamat: 'Jl. Kopo Jaya No. 12, Bandung',
    kontakPerson: 'Bpk. Ronald Setiawan',
    nomorRekening: 'BCA 777-123-4560 a.n Display Mandiri',
    catatan: 'Lembaran akrilik bening/warna 2mm-10mm, roll banner, tripod banner, neon box profile.',
    createdAt: '2026-02-10',
  },
  {
    id: 'ven-7',
    nama: 'VENDOR / SUPLIER UMUM',
    kategori: 'Umum',
    telepon: '-',
    email: '-',
    alamat: 'Wilayah Ciamis, Tasikmalaya & Sekitarnya',
    kontakPerson: 'Petugas Suplier Lokal',
    nomorRekening: '-',
    catatan: 'Vendor umum / pembelian retail mendesak bahan baku pendukung operasional.',
    createdAt: '2026-01-01',
  },
];

export function getStoredVendors(): Vendor[] {
  try {
    const raw = localStorage.getItem(VENDORS_STORAGE_KEY);

    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const deletedIds = getDeletedVendorIds();
        if (deletedIds.size > 0) {
          return parsed.filter((v) => {
            if (!v) return false;
            if (v.id && deletedIds.has(v.id)) return false;
            if (v.nama && deletedIds.has(v.nama.trim().toLowerCase())) return false;
            return true;
          });
        }
        return parsed;
      }
    }
    return [];
  } catch (e) {
    console.error('Error loading stored vendors:', e);
    return [];
  }
}

export function saveVendorsLocally(vendors: Vendor[]) {
  try {
    localStorage.setItem(VENDORS_INITIALIZED_KEY, 'true');
    localStorage.setItem(VENDORS_STORAGE_KEY, JSON.stringify(vendors));
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('strukku-vendors-updated', { detail: vendors }));
      }, 0);
    }
  } catch (e) {
    console.error('Failed to save vendors locally:', e);
  }
}

let lastVendorFetchTime = 0;
const VENDOR_FETCH_INTERVAL = 5 * 60 * 1000; // 5 minutes cache to prevent spamming reads on tab switches

export async function fetchVendorsFromFirebase(): Promise<Vendor[]> {
  const localVendors = getStoredVendors();
  const now = Date.now();
  const deletedIds = getDeletedVendorIds();

  // If fetched recently, return local vendors without burning Firestore reads
  if (now - lastVendorFetchTime < VENDOR_FETCH_INTERVAL) {
    return localVendors;
  }

  // If quota is exceeded, return local vendors immediately
  if (isFirestoreQuotaExceeded()) {
    return localVendors;
  }

  try {
    if (!db) return localVendors;
    const snap = await getDocs(query(collection(db, 'vendors'), limit(250)));
    recordFirestoreRead('vendors', snap.size, 'getDocs');
    lastVendorFetchTime = now;
    if (!snap.empty) {
      const remoteList: Vendor[] = [];
      snap.forEach((docSnap) => {
        const data = docSnap.data();
        // If this vendor was deleted by the user, ensure it is cleaned from Firestore and do not revive
        if (deletedIds.has(docSnap.id) || (data.nama && deletedIds.has(String(data.nama).trim().toLowerCase()))) {
          deleteDoc(doc(db, 'vendors', docSnap.id)).catch(() => {});
          return;
        }
        remoteList.push({
          id: docSnap.id,
          nama: data.nama || '',
          kategori: data.kategori || 'Umum',
          telepon: data.telepon || '',
          email: data.email || '',
          alamat: data.alamat || '',
          kontakPerson: data.kontakPerson || '',
          nomorRekening: data.nomorRekening || '',
          catatan: data.catatan || '',
          createdAt: data.createdAt || new Date().toISOString().split('T')[0],
        });
      });

      // Smart merge: keep local records and add new remote records that are not in deletedIds
      const vendorMap = new Map<string, Vendor>();
      remoteList.forEach((v) => {
        if (v && v.id && !deletedIds.has(v.id)) {
          vendorMap.set(v.id, v);
        }
      });
      localVendors.forEach((v) => {
        if (v && v.id && !deletedIds.has(v.id)) {
          vendorMap.set(v.id, v);
        }
      });
      const merged = Array.from(vendorMap.values());
      saveVendorsLocally(merged);
      return merged;
    }
  } catch (err) {
    console.warn('Could not fetch vendors from Firestore, using local fallback:', err);
    handleFirestoreError(err, OperationType.GET, 'vendors');
  }
  return localVendors;
}

export function resetDefaultVendors(): Vendor[] {
  clearDeletedVendorIds();
  saveVendorsLocally(INITIAL_DEFAULT_VENDORS);
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('strukku-vendors-updated'));
    }, 0);
  }
  return INITIAL_DEFAULT_VENDORS;
}

export async function saveVendorRecord(vendor: Omit<Vendor, 'id'> & { id?: string }): Promise<Vendor> {
  const id = vendor.id || `ven-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  unrecordDeletedVendorId(id);

  const currentList = getStoredVendors();
  const record: Vendor = {
    id,
    nama: vendor.nama.trim(),
    kategori: vendor.kategori?.trim() || 'Umum',
    telepon: vendor.telepon?.trim() || '',
    email: vendor.email?.trim() || '',
    alamat: vendor.alamat?.trim() || '',
    kontakPerson: vendor.kontakPerson?.trim() || '',
    nomorRekening: vendor.nomorRekening?.trim() || '',
    catatan: vendor.catatan?.trim() || '',
    createdAt: vendor.createdAt || new Date().toISOString().split('T')[0],
  };

  const existingIdx = currentList.findIndex((v) => v.id === id);
  let updatedList: Vendor[];
  if (existingIdx >= 0) {
    updatedList = [...currentList];
    updatedList[existingIdx] = record;
  } else {
    updatedList = [record, ...currentList];
  }

  saveVendorsLocally(updatedList);
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('strukku-vendors-updated'));
    }, 0);
  }

  // Sync to Firestore if available
  try {
    if (db) {
      await setDoc(doc(db, 'vendors', id), {
        ...record,
        updatedAt: serverTimestamp(),
      }, { merge: true });
      recordFirestoreWrite('vendors', 1, 'setDoc');
    }
  } catch (err) {
    console.warn('Firestore sync failed for vendor, saved in localStorage:', err);
  }

  return record;
}

export async function deleteVendorRecord(id: string): Promise<boolean> {
  const currentList = getStoredVendors();
  const target = currentList.find((v) => v.id === id);
  recordDeletedVendorId(id, target?.nama);
  const updatedList = currentList.filter((v) => v.id !== id);
  saveVendorsLocally(updatedList);
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('strukku-vendors-updated'));
    }, 0);
  }

  try {
    if (db) {
      await deleteDoc(doc(db, 'vendors', id));
      recordFirestoreDelete('vendors', 1, 'deleteDoc');
    }
    return true;
  } catch (err) {
    console.warn('Firestore delete failed for vendor, removed in localStorage:', err);
    return true;
  }
}
