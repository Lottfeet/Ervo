import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  deleteDoc, 
  query, 
  where,
  orderBy, 
  limit, 
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import { db } from './firebase';
import { 
  CheckpointRecord, 
  CheckpointPayload, 
  AutoCheckpointConfig, 
  CheckpointTrigger,
  Product,
  Customer,
  Invoice,
  ExpenseRecord,
  StockInRecord,
  StockOpnameRecord,
  KasirUser,
  StoreSettings,
  Vendor
} from '../types';
import { getStoredVendors, saveVendorsLocally, clearDeletedVendorIds } from './vendorService';
import { getStoredExpenses, deduplicateExpenses } from './expenseService';
import { 
  gasPost, 
  getSheetUrl,
  setSheetUrl,
  getDeletedInvoices,
  getDeletedProducts,
  getDeletedCustomers,
  getDeletedExpenses,
  removeDeletedInvoice, 
  removeDeletedProduct, 
  removeDeletedCustomer,
  removeDeletedExpense,
  recalculateInvoiceSisaAndStatus,
  getLocalProducts,
  getLocalCustomers,
  getLocalStockInHistory,
  getLocalKasirUsers,
  getLocalSettings
} from './gasService';
import {
  isFirestoreQuotaExceeded,
  handleFirestoreError,
  OperationType,
  getStoredStockOpnames,
  readInvoicesLocalFallback,
  readExpensesLocalFallback,
} from './firebaseService';
import {
  recordFirestoreRead,
  recordFirestoreWrite,
  recordFirestoreDelete,
  recordQuotaSavings,
} from './firestoreQuotaService';
import { compareInvoicesDesc } from '../utils/formatters';

const STORAGE_KEY_CONFIG = 'strukku_auto_checkpoint_config';
const STORAGE_KEY_HISTORY = 'strukku_checkpoints_history';
const STORAGE_KEY_PAYLOAD_PREFIX = 'strukku_checkpoint_payload_';
const STORAGE_KEY_FINGERPRINT = 'strukku_last_checkpoint_fingerprint';
const STORAGE_KEY_LAST_FS_TS = 'strukku_last_firestore_checkpoint_ts';
const MAX_LOCAL_PAYLOADS = 5; // Retain full payload for 5 newest checkpoints locally
const FIRESTORE_AUTO_CHECKPOINT_COOLDOWN_MS = 60 * 60 * 1000; // 60 minutes minimum between automatic Cloud Firestore checkpoint writes

export const DEFAULT_AUTO_CHECKPOINT_CONFIG: AutoCheckpointConfig = {
  enabled: true,
  intervalMinutes: 60,
  triggerOnTransactionsCount: 20,
  maxStoredCheckpoints: 20,
};

// 1. Get / Save Auto-Checkpoint Config
export function getAutoCheckpointConfig(): AutoCheckpointConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONFIG);
    if (raw) {
      return { ...DEFAULT_AUTO_CHECKPOINT_CONFIG, ...JSON.parse(raw) };
    }
  } catch {}
  return DEFAULT_AUTO_CHECKPOINT_CONFIG;
}

export function saveAutoCheckpointConfig(cfg: AutoCheckpointConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(cfg));
  } catch (err) {
    console.error('Failed to save auto checkpoint config:', err);
  }
}

// 2. Format Date/Time Helpers
function getFormattedDate(d: Date = new Date()): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

function getFormattedTime(d: Date = new Date()): string {
  const hours = String(d.getHours()).padStart(2, '0');
  const mins = String(d.getMinutes()).padStart(2, '0');
  const secs = String(d.getSeconds()).padStart(2, '0');
  return `${hours}:${mins}:${secs}`;
}

function sanitizeForFirestore(obj: any): any {
  return JSON.parse(JSON.stringify(obj, (_key, value) => {
    return value === undefined ? null : value;
  }));
}

// Calculate fingerprint of state to detect if anything changed
function calculateDataFingerprint(data: CheckpointPayload): string {
  const pCount = data.products.length;
  const cCount = data.customers.length;
  const iCount = data.invoices.length;
  const eCount = data.expenses?.length || 0;
  const sCount = data.stockIn?.length || 0;
  const oCount = data.stockOpnames?.length || 0;
  const vCount = data.vendors?.length || 0;
  const latestInv = data.invoices[0] ? `${data.invoices[0].invoiceNo || data.invoices[0].noInvoice}_${data.invoices[0].total}` : 'none';
  const latestExp = data.expenses && data.expenses[0] ? `${data.expenses[0].id}_${data.expenses[0].nominal}` : 'none';
  const latestStock = data.stockIn && data.stockIn[0] ? `${data.stockIn[0].id}_${data.stockIn[0].jumlahMasuk}` : 'none';
  const latestVen = data.vendors && data.vendors[0] ? `${data.vendors[0].id}_${data.vendors[0].nama}` : 'none';
  return `${pCount}:${cCount}:${iCount}:${eCount}:${sCount}:${oCount}:${vCount}|${latestInv}|${latestExp}|${latestStock}|${latestVen}`;
}

// 3. Create 3-Layer Checkpoint
export async function create3LayerCheckpoint(params: {
  trigger: CheckpointTrigger;
  label?: string;
  operator?: string;
  skipFirestoreCloud?: boolean;
  data: {
    products: Product[];
    customers: Customer[];
    invoices: Invoice[];
    expenses?: ExpenseRecord[];
    stockIn?: StockInRecord[];
    stockOpnames?: StockOpnameRecord[];
    kasirUsers?: KasirUser[];
    settings?: StoreSettings;
    vendors?: Vendor[];
  };
}): Promise<CheckpointRecord> {
  const now = new Date();
  const id = `CKP-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  
  let defaultLabel = 'Checkpoint Manual';
  if (params.trigger === 'AUTO_TIMER') defaultLabel = 'Checkpoint Otomatis (Waktu Rutin)';
  else if (params.trigger === 'AUTO_TRANSACTION') defaultLabel = 'Checkpoint Otomatis (Pasca Transaksi)';
  else if (params.trigger === 'AUTO_RESTOCK') defaultLabel = 'Checkpoint Otomatis (Pasca Restock)';
  else if (params.trigger === 'AUTO_OPNAME') defaultLabel = 'Checkpoint Otomatis (Pasca Opname)';

  const label = (params.label && params.label.trim()) ? params.label.trim() : defaultLabel;
  const operator = params.operator || 'Sistem / Kasir';

  const currentSheetUrl = getSheetUrl();

  // Resolve vendors: use provided vendors or fallback to stored vendors
  const resolvedVendors = (params.data.vendors && params.data.vendors.length > 0)
    ? params.data.vendors
    : getStoredVendors();

  // Resolve stockOpnames: use provided stockOpnames or fallback to stored stock opnames
  const resolvedStockOpnames = (params.data.stockOpnames && params.data.stockOpnames.length > 0)
    ? params.data.stockOpnames
    : getStoredStockOpnames();

  // Resolve invoices: always capture the most complete dataset available (prevents truncation in background timers)
  let resolvedInvoices = params.data.invoices || [];
  const localFallbackInvoices = readInvoicesLocalFallback();
  if (localFallbackInvoices.length > resolvedInvoices.length) {
    resolvedInvoices = localFallbackInvoices;
  }

  // Resolve expenses: always capture the most complete dataset available (prevents truncation in background timers)
  let resolvedExpenses = params.data.expenses || [];
  const localStoredExpenses = getStoredExpenses();
  if (localStoredExpenses.length > resolvedExpenses.length) {
    resolvedExpenses = localStoredExpenses;
  }
  const fallbackExpenses = readExpensesLocalFallback();
  if (fallbackExpenses.length > resolvedExpenses.length) {
    resolvedExpenses = fallbackExpenses;
  }

  // Auto-Checkpoint Safeguard (AUTO_TIMER / AUTO_TRANSACTION):
  // Never allow automatic background checkpoints to drop expenses to 0 if a previous checkpoint or snapshot had expenses!
  if (resolvedExpenses.length === 0 || params.trigger === 'AUTO_TIMER' || params.trigger === 'AUTO_TRANSACTION') {
    const localHistory = getLocalCheckpointsHistory();
    for (const prevCp of localHistory) {
      const prevExpenseCount = prevCp.counts?.expenses ?? 0;
      if (prevExpenseCount > resolvedExpenses.length) {
        try {
          const prevRaw = localStorage.getItem(`${STORAGE_KEY_PAYLOAD_PREFIX}${prevCp.id}`);
          if (prevRaw) {
            const parsedPrev = JSON.parse(prevRaw);
            if (Array.isArray(parsedPrev.expenses) && parsedPrev.expenses.length > resolvedExpenses.length) {
              resolvedExpenses = parsedPrev.expenses;
              // Resurrect to local storage so subsequent reads and views don't lose the dataset
              localStorage.setItem('strukku_company_expenses', JSON.stringify(resolvedExpenses));
              localStorage.setItem('strukku_expenses', JSON.stringify(resolvedExpenses));
              break;
            }
          }
        } catch {}
      }
    }
  }

  // Build Payload
  const payload: CheckpointPayload = {
    products: params.data.products || [],
    customers: params.data.customers || [],
    invoices: resolvedInvoices,
    expenses: resolvedExpenses,
    stockIn: params.data.stockIn || [],
    stockOpnames: resolvedStockOpnames,
    kasirUsers: params.data.kasirUsers || [],
    settings: {
      ...(params.data.settings || {
        name: 'ERVO PRINT',
        address: '',
        phone: '',
        footer: '',
        cashier: 'Admin',
      }),
      sheetUrl: currentSheetUrl || params.data.settings?.sheetUrl || '',
    },
    vendors: resolvedVendors,
    sheetUrl: currentSheetUrl || '',
  };

  const counts = {
    products: payload.products.length,
    customers: payload.customers.length,
    invoices: payload.invoices.length,
    expenses: payload.expenses.length,
    stockIn: payload.stockIn.length,
    stockOpnames: payload.stockOpnames.length,
    vendors: payload.vendors?.length || 0,
  };

  // --- DIRTY CHECK: If this is an automatic checkpoint and data has not changed, SKIP writing! ---
  const currentFingerprint = calculateDataFingerprint(payload);
  const lastFingerprint = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY_FINGERPRINT) : null;

  if (params.trigger !== 'MANUAL' && lastFingerprint && lastFingerprint === currentFingerprint) {
    recordQuotaSavings('write', 1, 'Auto-checkpoint skipped: Data unchanged since last checkpoint');
    // Update config timestamp so timer doesn't trigger repeatedly
    try {
      const cfg = getAutoCheckpointConfig();
      cfg.lastCheckpointTime = now.toISOString();
      saveAutoCheckpointConfig(cfg);
    } catch {}

    const localList = getLocalCheckpointsHistory();
    if (localList.length > 0) {
      return localList[0];
    }
  }

  const payloadJson = JSON.stringify(payload);
  const sizeBytes = new Blob([payloadJson]).size;

  const checkpoint: CheckpointRecord = {
    id,
    timestamp: now.toISOString(),
    formattedDate: getFormattedDate(now),
    formattedTime: getFormattedTime(now),
    trigger: params.trigger,
    label,
    operator,
    counts,
    layers: {
      cloudFirestore: { status: 'failed' },
      googleSheets: { status: 'skipped' },
      localOffline: { status: 'failed' },
    },
    sizeBytes,
    payload,
  };

  // --- LAPIS 1: CLOUD FIRESTORE ---
  const lastFsTime = typeof window !== 'undefined' ? parseInt(localStorage.getItem(STORAGE_KEY_LAST_FS_TS) || '0', 10) : 0;
  const isAuto = params.trigger !== 'MANUAL';
  const isWithinCooldown = isAuto && (now.getTime() - lastFsTime < FIRESTORE_AUTO_CHECKPOINT_COOLDOWN_MS);

  if (params.skipFirestoreCloud || isFirestoreQuotaExceeded()) {
    checkpoint.layers.cloudFirestore = {
      status: 'skipped',
      message: params.skipFirestoreCloud
        ? 'Dilewati: Mode Offline / Lokal Aktif (0 Kuota Cloud Digunakan)'
        : 'Dilewati: Quota Firestore hari ini habis (tersimpan aman di Lapis Offline/Sheets)',
    };
  } else if (isWithinCooldown) {
    // Throttled: Conserve daily quota, data is already persisted in invoices and local layers
    checkpoint.layers.cloudFirestore = {
      status: 'skipped',
      message: 'Dilewati: Cooldown hemat kuota 15 menit aktif (tersimpan di Lapis Offline & Sheets)',
    };
    recordQuotaSavings('write', 1, 'Auto-checkpoint Firestore write throttled (15-min cooldown)');
  } else {
    try {
      // Create lightweight cloud payload to strictly protect Firestore 1 MiB document limit & bandwidth
      // Full raw unabridged payload is preserved in LocalStorage, downloadable JSON file, and Google Sheets
      const cloudPayload: Partial<CheckpointPayload> = {
        products: checkpoint.payload.products || [],
        customers: checkpoint.payload.customers || [],
        settings: checkpoint.payload.settings,
        kasirUsers: checkpoint.payload.kasirUsers || [],
        vendors: checkpoint.payload.vendors || [],
        invoices: (checkpoint.payload.invoices || []).slice(0, 25),
        expenses: (checkpoint.payload.expenses || []).slice(0, 30),
        stockIn: (checkpoint.payload.stockIn || []).slice(0, 25),
        stockOpnames: (checkpoint.payload.stockOpnames || []).slice(0, 20),
      };

      const firestoreData = sanitizeForFirestore({
        id: checkpoint.id,
        timestamp: checkpoint.timestamp,
        formattedDate: checkpoint.formattedDate,
        formattedTime: checkpoint.formattedTime,
        trigger: checkpoint.trigger,
        label: checkpoint.label,
        operator: checkpoint.operator,
        counts: checkpoint.counts,
        sizeBytes: checkpoint.sizeBytes,
        payload: cloudPayload,
        createdAt: serverTimestamp(),
      });

      await setDoc(doc(db, 'backupCheckpoints', id), firestoreData);
      recordFirestoreWrite('backupCheckpoints', 1, 'setDoc');
      invalidateCheckpointsCache();

      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEY_LAST_FS_TS, String(now.getTime()));
      }

      checkpoint.layers.cloudFirestore = {
        status: 'success',
        docId: id,
        timestamp: checkpoint.timestamp,
        message: 'Tersimpan aman di Firebase Firestore Cloud',
      };
    } catch (err: any) {
      console.warn('Lapis 1 (Firestore) Backup failed:', err);
      handleFirestoreError(err, OperationType.WRITE, 'backupCheckpoints');
      checkpoint.layers.cloudFirestore = {
        status: 'failed',
        message: err?.message || 'Gagal menyimpan ke Cloud Firestore',
      };
    }
  }

  // Save current fingerprint for next dirty check
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY_FINGERPRINT, currentFingerprint);
    } catch {}
  }

  // --- LAPIS 2: GOOGLE SHEETS / EXTERNAL CLOUD ---
  try {
    const gasRes = await gasPost('logBackup', {
      id: checkpoint.id,
      timestamp: checkpoint.timestamp,
      formattedDate: checkpoint.formattedDate,
      formattedTime: checkpoint.formattedTime,
      trigger: checkpoint.trigger,
      label: checkpoint.label,
      operator: checkpoint.operator,
      counts: JSON.stringify(checkpoint.counts),
      sizeKb: Math.round(sizeBytes / 1024),
    });

    if (gasRes && gasRes.success) {
      checkpoint.layers.googleSheets = {
        status: 'success',
        syncedAt: checkpoint.timestamp,
        message: 'Log Checkpoint tercatat di Google Sheets',
      };
    } else {
      checkpoint.layers.googleSheets = {
        status: 'skipped',
        message: gasRes?.message || 'Google Sheets offline / webhook aktif',
      };
    }
  } catch (err: any) {
    checkpoint.layers.googleSheets = {
      status: 'skipped',
      message: 'Koneksi Sheets dilewati: ' + (err?.message || 'Offline'),
    };
  }

  // --- LAPIS 3: OFFLINE LOCAL STORAGE & FILE READY ---
  try {
    // 1. Save metadata to history list
    let history: CheckpointRecord[] = [];
    try {
      const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
      if (raw) history = JSON.parse(raw);
    } catch {}

    // Exclude payload from history array to keep history list lightweight
    const { payload: _p, ...metaOnly } = checkpoint;
    const cleanMeta = { ...metaOnly };

    history = [cleanMeta as CheckpointRecord, ...history.filter(c => c.id !== id)].slice(0, 30);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history));

    // 2. Save full payload locally for the newest checkpoint
    try {
      localStorage.setItem(`${STORAGE_KEY_PAYLOAD_PREFIX}${id}`, payloadJson);
      pruneOldLocalPayloads(history.map(h => h.id));
    } catch (storageErr) {
      console.warn('Could not cache full payload to localStorage (quota reached):', storageErr);
    }

    checkpoint.layers.localOffline = {
      status: 'success',
      storageKey: `${STORAGE_KEY_PAYLOAD_PREFIX}${id}`,
      sizeKb: Math.round(sizeBytes / 1024),
      message: 'Snapshot tersimpan di LocalStorage & siap diunduh file .JSON',
    };
  } catch (err: any) {
    console.warn('Lapis 3 (LocalStorage) Backup failed:', err);
    checkpoint.layers.localOffline = {
      status: 'failed',
      message: err?.message || 'Gagal menyimpan ke LocalStorage',
    };
  }

  // Update last checkpoint time in config
  try {
    const cfg = getAutoCheckpointConfig();
    cfg.lastCheckpointTime = checkpoint.timestamp;
    saveAutoCheckpointConfig(cfg);
  } catch {}

  return checkpoint;
}

// Prune old local payloads
function pruneOldLocalPayloads(currentIds: string[]): void {
  try {
    const keepIds = new Set(currentIds.slice(0, MAX_LOCAL_PAYLOADS));
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_KEY_PAYLOAD_PREFIX)) {
        const id = key.replace(STORAGE_KEY_PAYLOAD_PREFIX, '');
        if (!keepIds.has(id)) {
          localStorage.removeItem(key);
        }
      }
    }
  } catch {}
}

// Cache for fetchCheckpointsList to prevent repeated getDocs calls
let cachedCheckpointsList: CheckpointRecord[] | null = null;
let lastCheckpointsFetchTime = 0;
const CHECKPOINTS_CACHE_TTL = 10 * 60 * 1000; // 10 minutes

export function invalidateCheckpointsCache(): void {
  cachedCheckpointsList = null;
  lastCheckpointsFetchTime = 0;
}

// 4. Fetch Checkpoints List (from Firestore with Local Fallback & 10-min in-memory cache)
export async function fetchCheckpointsList(): Promise<CheckpointRecord[]> {
  const localList = getLocalCheckpointsHistory();

  // If in-memory cache is valid, return immediately (0 reads)
  if (Date.now() - lastCheckpointsFetchTime < CHECKPOINTS_CACHE_TTL && cachedCheckpointsList && cachedCheckpointsList.length > 0) {
    recordQuotaSavings('read', 8, 'Served checkpoints list from in-memory cache');
    return cachedCheckpointsList;
  }

  // If Firestore quota is already exceeded, return local list immediately with 0 reads
  if (isFirestoreQuotaExceeded()) {
    return localList;
  }

  try {
    const q = query(
      collection(db, 'backupCheckpoints'),
      orderBy('timestamp', 'desc'),
      limit(8)
    );
    const snap = await getDocs(q);
    recordFirestoreRead('backupCheckpoints', snap.size, 'getDocs');

    const firestoreList: CheckpointRecord[] = [];

    snap.forEach((d) => {
      const data = d.data();
      firestoreList.push({
        id: data.id || d.id,
        timestamp: data.timestamp || new Date().toISOString(),
        formattedDate: data.formattedDate || '',
        formattedTime: data.formattedTime || '',
        trigger: data.trigger || 'MANUAL',
        label: data.label || 'Checkpoint Cloud',
        operator: data.operator || 'Admin',
        counts: {
          products: data.counts?.products ?? 0,
          customers: data.counts?.customers ?? 0,
          invoices: data.counts?.invoices ?? 0,
          expenses: data.counts?.expenses ?? (Array.isArray(data.payload?.expenses) ? data.payload.expenses.length : 0),
          stockIn: data.counts?.stockIn ?? 0,
          stockOpnames: data.counts?.stockOpnames ?? 0,
          vendors: data.counts?.vendors ?? (Array.isArray(data.payload?.vendors) ? data.payload.vendors.length : 0),
        },
        layers: data.layers || {
          cloudFirestore: { status: 'success' },
          googleSheets: { status: 'skipped' },
          localOffline: { status: 'success' },
        },
        sizeBytes: data.sizeBytes || 0,
      });
    });

    if (firestoreList.length > 0) {
      // Merge with local list (prefer Firestore metadata, keep any local-only)
      const map = new Map<string, CheckpointRecord>();
      firestoreList.forEach(c => map.set(c.id, c));
      localList.forEach(c => {
        if (!map.has(c.id)) {
          map.set(c.id, c);
        } else {
          // If local has local storage payload, ensure local layer shows success
          const existing = map.get(c.id)!;
          if (c.layers?.localOffline?.status === 'success') {
            existing.layers.localOffline = c.layers.localOffline;
          }
        }
      });

      const merged = Array.from(map.values()).sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      cachedCheckpointsList = merged;
      lastCheckpointsFetchTime = Date.now();

      // Cache merged metadata to localStorage
      try {
        localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(merged.slice(0, 30)));
      } catch {}

      return merged;
    }
  } catch (err) {
    console.warn('Could not fetch checkpoints from Firestore, using local cache:', err);
    handleFirestoreError(err, OperationType.GET, 'backupCheckpoints');
  }

  return localList;
}

export function getLocalCheckpointsHistory(): CheckpointRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.map((c: any) => ({
          ...c,
          counts: {
            products: c.counts?.products ?? 0,
            customers: c.counts?.customers ?? 0,
            invoices: c.counts?.invoices ?? 0,
            expenses: c.counts?.expenses ?? (Array.isArray(c.payload?.expenses) ? c.payload.expenses.length : 0),
            stockIn: c.counts?.stockIn ?? 0,
            stockOpnames: c.counts?.stockOpnames ?? 0,
            vendors: c.counts?.vendors ?? (Array.isArray(c.payload?.vendors) ? c.payload.vendors.length : 0),
          },
        }));
      }
    }
  } catch {}
  return [];
}

// 5. Load Full Checkpoint Payload
export async function loadCheckpointPayload(checkpointId: string): Promise<CheckpointPayload | null> {
  // 1. Try local storage payload (0 reads!)
  try {
    const localRaw = localStorage.getItem(`${STORAGE_KEY_PAYLOAD_PREFIX}${checkpointId}`);
    if (localRaw) {
      const parsed = JSON.parse(localRaw);
      if (parsed.products || parsed.invoices) {
        recordQuotaSavings('read', 1, 'Loaded checkpoint payload from offline local cache');
        return parsed as CheckpointPayload;
      }
    }
  } catch {}

  // 2. Try Firestore document only if quota not exceeded and db is available
  if (db && !isFirestoreQuotaExceeded()) {
    try {
      const getDocPromise = getDoc(doc(db, 'backupCheckpoints', checkpointId));
      const timeoutPromise = new Promise<any>((_, reject) => 
        setTimeout(() => reject(new Error('Timeout memuat checkpoint dari cloud')), 6000)
      );
      const snap = await Promise.race([getDocPromise, timeoutPromise]);
      if (snap && snap.exists()) {
        recordFirestoreRead('backupCheckpoints', 1, 'getDoc');
        const data = snap.data();
        if (data.payload) {
          return data.payload as CheckpointPayload;
        }
      }
    } catch (err) {
      console.warn('Failed or timed out loading checkpoint payload from Firestore:', err);
      handleFirestoreError(err, OperationType.GET, 'backupCheckpoints');
    }
  }

  return null;
}

// Aggressive debouncing manager for automatic checkpoints
let debouncedCheckpointTimer: any = null;
let pendingCheckpointParams: Parameters<typeof create3LayerCheckpoint>[0] | null = null;
let pendingCheckpointResolvers: Array<(res: CheckpointRecord | null) => void> = [];

export function scheduleDebouncedAutoCheckpoint(
  params: Parameters<typeof create3LayerCheckpoint>[0],
  delayMs: number = 30000
): Promise<CheckpointRecord | null> {
  pendingCheckpointParams = params;
  if (debouncedCheckpointTimer) {
    clearTimeout(debouncedCheckpointTimer);
    recordQuotaSavings('write', 1, 'Coalesced multiple transaction checkpoints into single save');
  }

  return new Promise((resolve) => {
    pendingCheckpointResolvers.push(resolve);
    debouncedCheckpointTimer = setTimeout(async () => {
      debouncedCheckpointTimer = null;
      const currentResolvers = [...pendingCheckpointResolvers];
      pendingCheckpointResolvers = [];

      if (pendingCheckpointParams) {
        try {
          const cp = await create3LayerCheckpoint(pendingCheckpointParams);
          pendingCheckpointParams = null;
          currentResolvers.forEach((r) => r(cp));
        } catch (err) {
          console.warn('Debounced auto-checkpoint error:', err);
          currentResolvers.forEach((r) => r(null));
        }
      } else {
        resolversFallback(currentResolvers);
      }
    }, delayMs);
  });
}

function resolversFallback(resolvers: Array<(res: CheckpointRecord | null) => void>) {
  resolvers.forEach((r) => r(null));
}

// 6. Download Checkpoint as JSON File
export async function downloadCheckpointAsJson(checkpoint: CheckpointRecord): Promise<void> {
  let payload = checkpoint.payload;
  if (!payload) {
    payload = await loadCheckpointPayload(checkpoint.id);
  }

  if (!payload) {
    throw new Error('Data snapshot tidak dapat dimuat untuk diunduh');
  }

  const currentSheetUrl = payload.sheetUrl || getSheetUrl() || '';

  const exportObject = {
    app: 'ERVO PRINT POS',
    version: '3.0.0-3layer-backup',
    checkpointId: checkpoint.id,
    timestamp: checkpoint.timestamp,
    formattedDate: checkpoint.formattedDate,
    formattedTime: checkpoint.formattedTime,
    trigger: checkpoint.trigger,
    label: checkpoint.label,
    operator: checkpoint.operator,
    counts: checkpoint.counts,
    layers: checkpoint.layers,
    sheetUrl: currentSheetUrl,
    data: {
      ...payload,
      sheetUrl: currentSheetUrl,
      settings: {
        ...(payload.settings || {}),
        sheetUrl: payload.settings?.sheetUrl || currentSheetUrl,
      },
    },
  };

  const jsonStr = JSON.stringify(exportObject, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const cleanDate = (checkpoint.formattedDate || '').replace(/\//g, '-');
  const cleanTime = (checkpoint.formattedTime || '').replace(/:/g, '');
  const fileName = `Backup3Lapis_ERVO_${cleanDate}_${cleanTime}_${checkpoint.id.substring(0, 15)}.json`;

  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// 7. Parse Uploaded Checkpoint File
export async function parseCheckpointFile(file: File): Promise<{
  metadata: Partial<CheckpointRecord>;
  payload: CheckpointPayload;
}> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('File kosong atau tidak dapat dibaca');
        }
        const json = JSON.parse(text);

        // Support both direct CheckpointRecord format and nested { data: payload }
        let payload: CheckpointPayload | null = null;
        if (json.data && (json.data.products || json.data.invoices || json.data.transaksi || json.data.produk)) {
          payload = json.data as CheckpointPayload;
        } else if (json.payload && (json.payload.products || json.payload.invoices || json.payload.transaksi || json.payload.produk)) {
          payload = json.payload as CheckpointPayload;
        } else if (json.products || json.invoices || json.transaksi || json.produk) {
          payload = json as CheckpointPayload;
        }

        if (!payload) {
          throw new Error('Format berkas tidak valid: tidak ditemukan data produk atau transaksi');
        }

        // Normalize aliases in payload
        if (!payload.invoices && (payload as any).transaksi) payload.invoices = (payload as any).transaksi;
        if (!payload.invoices && (payload as any).transactions) payload.invoices = (payload as any).transactions;
        if (!payload.invoices && (payload as any).recentInvoices) payload.invoices = (payload as any).recentInvoices;
        if (!payload.products && (payload as any).produk) payload.products = (payload as any).produk;
        if (!payload.customers && (payload as any).pelanggan) payload.customers = (payload as any).pelanggan;
        if (!payload.expenses && (payload as any).pengeluaran) payload.expenses = (payload as any).pengeluaran;
        if (!payload.stockIn && (payload as any).stokMasuk) payload.stockIn = (payload as any).stokMasuk;
        if (!payload.stockOpnames && (payload as any).stockOpname) payload.stockOpnames = (payload as any).stockOpname;
        if (!payload.vendors && (payload as any).vendor) payload.vendors = (payload as any).vendor;
        if (!payload.vendors && (payload as any).suplier) payload.vendors = (payload as any).suplier;
        if (!payload.vendors && (payload as any).suppliers) payload.vendors = (payload as any).suppliers;

        // Extract Google Apps Script Web App URL if present in file
        const fileSheetUrl = (
          json.sheetUrl || 
          (json as any).webAppUrl || 
          json.data?.sheetUrl || 
          json.data?.settings?.sheetUrl || 
          (json as any).strukku_sheet_url || 
          payload.sheetUrl || 
          payload.settings?.sheetUrl || 
          ''
        ).trim();

        if (fileSheetUrl) {
          payload.sheetUrl = fileSheetUrl;
          if (payload.settings) {
            payload.settings.sheetUrl = fileSheetUrl;
          }
        }

        const metadata: Partial<CheckpointRecord> = {
          id: json.checkpointId || json.id || `IMPORT-${Date.now()}`,
          timestamp: json.timestamp || new Date().toISOString(),
          label: json.label ? `[Impor File] ${json.label}` : `[Impor Berkas] ${file.name}`,
          operator: json.operator || 'File Impor',
          counts: json.counts || {
            products: (payload.products || []).length,
            customers: (payload.customers || []).length,
            invoices: (payload.invoices || []).length,
            expenses: (payload.expenses || []).length,
            stockIn: (payload.stockIn || []).length,
            stockOpnames: (payload.stockOpnames || []).length,
            vendors: (payload.vendors || []).length,
          },
        };

        resolve({ metadata, payload });
      } catch (err: any) {
        reject(new Error('Gagal memproses file backup: ' + (err?.message || 'JSON tidak valid')));
      }
    };
    reader.onerror = () => reject(new Error('Gagal membaca file'));
    reader.readAsText(file);
  });
}

// 8. Restore from Checkpoint (Local-First Ultra-Fast with Smart Cloud Sync)
export async function restoreFromCheckpoint(
  payload: CheckpointPayload,
  operator: string = 'SPV',
  options?: {
    mode?: 'replace' | 'merge';
    skipEmergencyBackup?: boolean;
    syncToFirestore?: boolean;
  }
): Promise<{
  success: boolean;
  message: string;
  counts: Record<string, number>;
}> {
  const mode = options?.mode || 'replace';
  const shouldSyncCloud = (options?.syncToFirestore ?? true) && !isFirestoreQuotaExceeded();
  const counts = {
    products: 0,
    customers: 0,
    invoices: 0,
    expenses: 0,
    stockIn: 0,
    stockOpnames: 0,
    settings: 0,
    kasirUsers: 0,
    vendors: 0,
  };

  try {
    // --- JAMINAN PERLINDUNGAN: Titik Pemulihan Darurat Otomatis Pre-Restore ---
    if (!options?.skipEmergencyBackup) {
      try {
        const curP = getLocalProducts();
        const curC = getLocalCustomers();
        const curI = readInvoicesLocalFallback();
        const curE = getStoredExpenses();
        const curS = getLocalStockInHistory();
        const curO = getStoredStockOpnames();
        const curV = getStoredVendors();
        const curK = getLocalKasirUsers();
        const curCfg = getLocalSettings();

        if (curP.length > 0 || curI.length > 0) {
          await create3LayerCheckpoint({
            trigger: 'MANUAL',
            label: `[Darurat Pre-Restore] Sebelum ${mode === 'merge' ? 'Gabungkan' : 'Timpa Bersih'} (${(payload as any).label || 'Snapshot'})`,
            operator: `Sistem Otomatis (${operator})`,
            skipFirestoreCloud: !shouldSyncCloud,
            data: {
              products: curP,
              customers: curC,
              invoices: curI,
              expenses: curE,
              stockIn: curS,
              stockOpnames: curO,
              vendors: curV,
              kasirUsers: curK,
              settings: curCfg as any,
            },
          });
        }
      } catch (backupErr) {
        console.warn('Pre-restore emergency checkpoint notice:', backupErr);
      }
    }

    // PHASE 1: INSTANT LOCAL RESTORE (< 25ms)
    // Identify active tombstones BEFORE clearing them locally
    const activeDeletedInvoices = getDeletedInvoices();
    const activeDeletedProducts = getDeletedProducts();
    const activeDeletedCustomers = getDeletedCustomers();

    // 1. Products
    let finalProducts: Product[] = [];
    if (mode === 'replace') {
      finalProducts = payload.products || [];
    } else {
      const current = getLocalProducts();
      const map = new Map<string, Product>();
      current.forEach((p) => {
        const key = (p.kode || p.nama || '').trim().toLowerCase();
        if (key) map.set(key, p);
      });
      (payload.products || []).forEach((p) => {
        const key = (p.kode || p.nama || '').trim().toLowerCase();
        if (key && !map.has(key)) {
          map.set(key, p);
        }
      });
      finalProducts = Array.from(map.values());
    }

    finalProducts.forEach((p) => {
      if (p.kode) removeDeletedProduct(p.kode);
      if (p.nama) removeDeletedProduct(p.nama);
    });
    localStorage.setItem('strukku_products', JSON.stringify(finalProducts));
    try {
      const { productsManager } = await import('./firebaseService');
      productsManager.updateCacheAndNotify(finalProducts);
    } catch {}
    counts.products = finalProducts.length;

    // 2. Customers
    let finalCustomers: Customer[] = [];
    if (mode === 'replace') {
      finalCustomers = payload.customers || [];
    } else {
      const current = getLocalCustomers();
      const map = new Map<string, Customer>();
      current.forEach((c) => {
        const key = (c.nama || '').trim().toLowerCase();
        if (key) map.set(key, c);
      });
      (payload.customers || []).forEach((c) => {
        const key = (c.nama || '').trim().toLowerCase();
        if (key && !map.has(key)) {
          map.set(key, c);
        }
      });
      finalCustomers = Array.from(map.values());
    }

    finalCustomers.forEach((c) => {
      if (c.nama) removeDeletedCustomer(c.nama);
    });
    localStorage.setItem('strukku_customers', JSON.stringify(finalCustomers));
    try {
      const { customersManager } = await import('./firebaseService');
      customersManager.updateCacheAndNotify(finalCustomers);
    } catch {}
    counts.customers = finalCustomers.length;

    // 3. Invoices
    let formattedSnapshotInvoices: Invoice[] = [];
    if (payload.invoices && Array.isArray(payload.invoices) && payload.invoices.length > 0) {
      formattedSnapshotInvoices = payload.invoices.map((inv: any) => {
        const invNo = (inv.invoiceNo || inv.noInvoice || '').trim();
        const method = inv.payMethod || inv.metodePembayaran || 'Tunai';
        const raw = {
          invoiceNo: invNo,
          noInvoice: invNo,
          date: inv.date || inv.tanggal || '',
          time: inv.time || inv.jam || '',
          customer: inv.customer || inv.pelanggan || 'Umum',
          cashier: inv.cashier || inv.kasir || 'Admin',
          payMethod: method,
          metodePembayaran: method,
          subtotal: Number(inv.subtotal || inv.total || 0),
          discPct: Number(inv.discPct || inv.diskonPct || 0),
          discAmt: Number(inv.discAmt || inv.diskonNominal || 0),
          taxPct: Number(inv.taxPct || inv.pajakPct || 0),
          taxAmt: Number(inv.taxAmt || inv.pajakNominal || 0),
          negoAmt: Number(inv.negoAmt || inv.negoNominal || 0),
          total: Number(inv.total || 0),
          dp: Number(inv.dp || inv.bayarDp || 0),
          sisa: Number(inv.sisa || inv.sisaPiutang || 0),
          kembalian: Number(inv.kembalian || 0),
          deadline: inv.deadline || '',
          status: inv.status || (Number(inv.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
          items: Array.isArray(inv.items) ? inv.items : [],
          historiPelunasan: Array.isArray(inv.pelunasanHistory) ? inv.pelunasanHistory : (Array.isArray(inv.historiPelunasan) ? inv.historiPelunasan : []),
        };
        return recalculateInvoiceSisaAndStatus(raw as any);
      });
    }

    let finalInvoices: Invoice[] = [];
    if (mode === 'replace') {
      finalInvoices = formattedSnapshotInvoices;
    } else {
      const current = readInvoicesLocalFallback();
      const map = new Map<string, Invoice>();
      current.forEach((inv) => {
        const key = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
        if (key) map.set(key, inv);
      });
      formattedSnapshotInvoices.forEach((inv) => {
        const key = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
        if (key && !map.has(key)) {
          map.set(key, inv);
        }
      });
      finalInvoices = Array.from(map.values());
    }

    finalInvoices.forEach((inv) => {
      const no = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
      if (no) removeDeletedInvoice(no);
    });

    finalInvoices.sort(compareInvoicesDesc);
    localStorage.setItem('strukku_recent_invoices', JSON.stringify(finalInvoices));

    // Extract all pelunasan records
    const allPelunasan: any[] = [];
    finalInvoices.forEach((inv) => {
      if (Array.isArray(inv.historiPelunasan)) {
        allPelunasan.push(...inv.historiPelunasan);
      }
    });
    if (allPelunasan.length > 0) {
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(allPelunasan));
    }
    try {
      const { invoicesManager } = await import('./firebaseService');
      invoicesManager.updateCacheAndNotify(finalInvoices);
    } catch {}
    counts.invoices = finalInvoices.length;

    // 4. Settings & Google Sheets URL
    if (payload.settings && Object.keys(payload.settings).length > 0) {
      const currentSettings = getLocalSettings();
      const finalSettings = mode === 'merge' ? { ...payload.settings, ...currentSettings } : payload.settings;
      localStorage.setItem('strukku_sheet_settings', JSON.stringify(finalSettings));
      localStorage.setItem('strukku_settings', JSON.stringify(finalSettings));
      counts.settings = 1;
    }
    const restoredSheetUrl = (payload.sheetUrl || payload.settings?.sheetUrl || (payload as any).webAppUrl || '').trim();
    if (restoredSheetUrl) {
      setSheetUrl(restoredSheetUrl);
    }

    // 5. Kasir Users
    let finalKasir: KasirUser[] = [];
    if (mode === 'replace') {
      finalKasir = payload.kasirUsers || [];
    } else {
      const current = getLocalKasirUsers();
      const map = new Map<string, KasirUser>();
      current.forEach((u) => map.set(u.nama.trim().toLowerCase(), u));
      (payload.kasirUsers || []).forEach((u) => {
        const key = u.nama.trim().toLowerCase();
        if (key && !map.has(key)) map.set(key, u);
      });
      finalKasir = Array.from(map.values());
    }
    if (finalKasir.length > 0) {
      localStorage.setItem('strukku_kasir_users', JSON.stringify(finalKasir));
      localStorage.setItem('strukku_kasir_list', JSON.stringify(finalKasir.map((u) => u.nama)));
      counts.kasirUsers = finalKasir.length;
    }

    // 6. Expenses
    let finalExpenses: ExpenseRecord[] = [];
    if (mode === 'replace') {
      finalExpenses = payload.expenses || [];
      finalExpenses.forEach((exp) => {
        if (exp && exp.id) removeDeletedExpense(exp.id);
      });
    } else {
      const current = getStoredExpenses();
      finalExpenses = deduplicateExpenses([...current, ...(payload.expenses || [])]);
      finalExpenses.forEach((exp) => {
        if (exp && exp.id) removeDeletedExpense(exp.id);
      });
    }
    localStorage.setItem('strukku_company_expenses', JSON.stringify(finalExpenses));
    localStorage.setItem('strukku_expenses', JSON.stringify(finalExpenses));
    counts.expenses = finalExpenses.length;

    // 7. StockIn & StockOpnames
    let finalStockIn: StockInRecord[] = [];
    if (mode === 'replace') {
      finalStockIn = payload.stockIn || [];
    } else {
      const current = getLocalStockInHistory();
      const map = new Map<string, StockInRecord>();
      current.forEach((s) => map.set(s.id, s));
      (payload.stockIn || []).forEach((s) => {
        if (!map.has(s.id)) map.set(s.id, s);
      });
      finalStockIn = Array.from(map.values());
    }
    localStorage.setItem('strukku_stock_in_history', JSON.stringify(finalStockIn));
    counts.stockIn = finalStockIn.length;

    let finalStockOpnames: StockOpnameRecord[] = [];
    if (mode === 'replace') {
      finalStockOpnames = payload.stockOpnames || [];
    } else {
      const current = getStoredStockOpnames();
      const map = new Map<string, StockOpnameRecord>();
      current.forEach((o) => map.set(o.id, o));
      (payload.stockOpnames || []).forEach((o) => {
        if (!map.has(o.id)) map.set(o.id, o);
      });
      finalStockOpnames = Array.from(map.values());
    }
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify(finalStockOpnames));
    counts.stockOpnames = finalStockOpnames.length;

    // 8. Vendors
    let finalVendors: Vendor[] = [];
    if (mode === 'replace') {
      finalVendors = payload.vendors || [];
    } else {
      const current = getStoredVendors();
      const map = new Map<string, Vendor>();
      current.forEach((v) => map.set((v.id || v.nama || '').trim().toLowerCase(), v));
      (payload.vendors || []).forEach((v) => {
        const key = (v.id || v.nama || '').trim().toLowerCase();
        if (key && !map.has(key)) map.set(key, v);
      });
      finalVendors = Array.from(map.values());
    }
    clearDeletedVendorIds();
    saveVendorsLocally(finalVendors);
    counts.vendors = finalVendors.length;

    // Dispatch broadcast events so active views update immediately without waiting for Cloud writes!
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('strukku-backup-restored', { detail: { ...payload, products: finalProducts, invoices: finalInvoices, customers: finalCustomers, vendors: finalVendors, expenses: finalExpenses } }));
      window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: finalProducts }));
      window.dispatchEvent(new CustomEvent('strukku-invoices-updated'));
      window.dispatchEvent(new CustomEvent('strukku-vendors-updated', { detail: finalVendors }));
      window.dispatchEvent(new CustomEvent('strukku-expenses-updated', { detail: finalExpenses }));
      window.dispatchEvent(new CustomEvent('strukku-stock-opname-updated'));
    }

    // PHASE 2: OPTIMIZED SMART FIRESTORE SYNC
    // If user selected local-only restore, or Firestore is offline / quota exceeded: skip cloud writes safely
    if (!shouldSyncCloud || !db || isFirestoreQuotaExceeded()) {
      recordQuotaSavings('write', counts.products + counts.customers + Math.min(counts.invoices, 150) + counts.vendors, 'Skipped Firestore batch sync (Local Offline Mode active, 0 cloud writes)');
      const vendorSummary = counts.vendors ? `, ${counts.vendors} vendor` : '';
      const modeLabel = mode === 'merge' ? 'Gabungkan (Merge)' : 'Timpa Bersih (Replace)';
      return {
        success: true,
        message: `Pemulihan data offline lokal [${modeLabel}] berhasil 100%! Total: ${counts.products} produk, ${counts.customers} pelanggan, ${counts.invoices} transaksi${vendorSummary}. Sinkronisasi Cloud Firestore dilewati (0 kuota terpakai).`,
        counts,
      };
    }

    type BatchOp = { type?: 'set' | 'delete'; ref: any; data?: any };
    const writes: BatchOp[] = [];

    // Products
    if (finalProducts && finalProducts.length > 0) {
      for (const p of finalProducts) {
        if (p.kode) {
          writes.push({
            type: 'set',
            ref: doc(db, 'products', p.kode.trim()),
            data: sanitizeForFirestore({
              ...p,
              restoredAt: serverTimestamp(),
              restoredBy: `${operator} (${mode === 'merge' ? 'Merge' : 'Replace'})`,
            }),
          });

          const tombstoneId = (p.kode || p.nama || '').toLowerCase().replace(/[^a-z0-9_-]/g, '_');
          if (tombstoneId && (activeDeletedProducts.has(p.kode.toLowerCase()) || activeDeletedProducts.has(tombstoneId))) {
            writes.push({
              type: 'delete',
              ref: doc(db, 'deletedProducts', tombstoneId),
            });
          }
        }
      }
    }

    // Customers
    if (finalCustomers && finalCustomers.length > 0) {
      for (const c of finalCustomers) {
        if (c.nama) {
          writes.push({
            type: 'set',
            ref: doc(db, 'customers', c.nama.trim()),
            data: sanitizeForFirestore({
              ...c,
              restoredAt: serverTimestamp(),
              restoredBy: `${operator} (${mode === 'merge' ? 'Merge' : 'Replace'})`,
            }),
          });

          if (activeDeletedCustomers.has(c.nama.toLowerCase())) {
            writes.push({
              type: 'delete',
              ref: doc(db, 'deletedCustomers', c.nama.toLowerCase()),
            });
          }
        }
      }
    }

    // Invoices
    const invoicesToSync = finalInvoices;
    for (const inv of invoicesToSync) {
      const no = (inv.invoiceNo || (inv as any).noInvoice || '').trim();
      if (no) {
        writes.push({
          type: 'set',
          ref: doc(db, 'invoices', no),
          data: sanitizeForFirestore({
            ...inv,
            invoiceNo: no,
            noInvoice: no,
            restoredAt: serverTimestamp(),
            restoredBy: `${operator} (${mode === 'merge' ? 'Merge' : 'Replace'})`,
          }),
        });

        // ONLY delete tombstone if it was actually in deleted set
        if (activeDeletedInvoices.has(no.toLowerCase())) {
          writes.push({
            type: 'delete',
            ref: doc(db, 'deletedInvoices', no.toLowerCase()),
          });
        }
      }
    }

    // Kasir Users
    if (finalKasir && finalKasir.length > 0) {
      for (const u of finalKasir) {
        if (u.nama) {
          writes.push({
            type: 'set',
            ref: doc(db, 'kasirUsers', u.nama.trim()),
            data: sanitizeForFirestore({
              ...u,
              restoredAt: serverTimestamp(),
            }),
          });
        }
      }
    }

    // Store Settings
    if (payload.settings && Object.keys(payload.settings).length > 0) {
      writes.push({
        type: 'set',
        ref: doc(db, 'settings', 'store'),
        data: sanitizeForFirestore({
          ...payload.settings,
          restoredAt: serverTimestamp(),
        }),
      });
    }

    // Expenses
    if (finalExpenses && finalExpenses.length > 0) {
      for (const exp of finalExpenses) {
        if (exp.id) {
          writes.push({
            type: 'set',
            ref: doc(db, 'expenses', exp.id.trim()),
            data: sanitizeForFirestore({
              ...exp,
              restoredAt: serverTimestamp(),
            }),
          });
        }
      }
    }

    // Vendors
    if (finalVendors && finalVendors.length > 0) {
      for (const v of finalVendors) {
        if (v.id) {
          writes.push({
            type: 'set',
            ref: doc(db, 'vendors', v.id.trim()),
            data: sanitizeForFirestore({
              ...v,
              restoredAt: serverTimestamp(),
            }),
          });
        }
      }
    }

    // Stock Opnames
    if (finalStockOpnames && finalStockOpnames.length > 0) {
      for (const opn of finalStockOpnames) {
        if (opn.id) {
          writes.push({
            type: 'set',
            ref: doc(db, 'stockOpname', opn.id.trim()),
            data: sanitizeForFirestore({
              ...opn,
              restoredAt: serverTimestamp(),
            }),
          });
        }
      }
    }

    // Parallel Chunked Batches with 8-second timeout safeguard
    if (writes.length > 0) {
      const CHUNK_SIZE = 350;
      const batchPromises: Promise<void>[] = [];
      for (let i = 0; i < writes.length; i += CHUNK_SIZE) {
        const batch = writeBatch(db);
        const chunk = writes.slice(i, i + CHUNK_SIZE);
        for (const item of chunk) {
          if (item.type === 'delete') {
            batch.delete(item.ref);
          } else {
            batch.set(item.ref, item.data, { merge: true });
          }
        }
        batchPromises.push(batch.commit());
      }

      try {
        await Promise.race([
          Promise.all(batchPromises),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Cloud sync timeout (local data preserved)')), 8000))
        ]);
        recordFirestoreWrite('restore', writes.length, 'restoreFromCheckpoint');
      } catch (dbErr: any) {
        console.warn('Firestore checkpoint cloud sync note (local restore 100% active):', dbErr);
      }
    }

    const vendorMsg = counts.vendors ? `, ${counts.vendors} vendor` : '';
    const opnameMsg = counts.stockOpnames ? `, ${counts.stockOpnames} opname` : '';
    const modeLabel = mode === 'merge' ? 'Gabungkan (Merge)' : 'Timpa Bersih (Replace)';
    return {
      success: true,
      message: `Pemulihan data [${modeLabel}] berhasil! Total: ${counts.products} produk, ${counts.customers} pelanggan, ${counts.invoices} transaksi${counts.expenses ? `, ${counts.expenses} beban` : ''}${vendorMsg}${opnameMsg}.`,
      counts,
    };
  } catch (err: any) {
    console.error('Error during checkpoint restore:', err);
    return {
      success: false,
      message: 'Gagal memulihkan checkpoint: ' + (err?.message || 'Error tidak diketahui'),
      counts,
    };
  }
}

// 9. Delete Checkpoint
export async function deleteCheckpoint(checkpointId: string): Promise<void> {
  // 1. Delete from Firestore by document ID
  try {
    await deleteDoc(doc(db, 'backupCheckpoints', checkpointId));
    recordFirestoreDelete('backupCheckpoints', 1, 'deleteDoc');
    invalidateCheckpointsCache();
  } catch (err) {
    console.warn('Could not delete direct doc from Firestore:', err);
  }

  // 2. Delete from LocalStorage
  try {
    localStorage.removeItem(`${STORAGE_KEY_PAYLOAD_PREFIX}${checkpointId}`);
    const local = getLocalCheckpointsHistory();
    const updated = local.filter(c => c.id !== checkpointId);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Could not clean local storage checkpoint:', err);
  }
}
