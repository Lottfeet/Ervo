import { Product, Customer, StoreSettings, Invoice, InvoiceItem, GasResponse, PiutangItem, PelunasanRecord, KasirUser, StockInRecord, StockOpnameRecord, StockOpnameItem, ExpenseRecord } from '../types';
import { INITIAL_PRODUCTS, INITIAL_CUSTOMERS, INITIAL_KASIR, compareInvoicesDesc } from '../utils/formatters';

export const DEFAULT_GAS_URL = "";

export function getSheetUrl(): string {
  const saved = localStorage.getItem('strukku_sheet_url');
  return (saved || DEFAULT_GAS_URL).trim();
}

export function setSheetUrl(url: string) {
  localStorage.setItem('strukku_sheet_url', url.trim());
}

export async function gasGet<T = any>(action: string, extraQuery = ''): Promise<GasResponse<T>> {
  const gasUrl = getSheetUrl();
  if (!gasUrl) {
    return { success: false, message: 'URL Google Apps Script belum dikonfigurasi' };
  }

  const timestamp = Date.now();
  
  // Primary attempt via express server proxy
  try {
    const proxyUrl = `/api/sheets/proxy?action=${action}&gasUrl=${encodeURIComponent(gasUrl)}&_=${timestamp}${extraQuery ? '&' + extraQuery : ''}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35000); // 35s timeout
    const res = await fetch(proxyUrl, { 
      headers: { 'Cache-Control': 'no-cache' },
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    if (res.ok) {
      const json = await res.json();
      if (json) return json;
    }
  } catch (err: any) {
    if (err?.name !== 'AbortError') {
      console.warn(`[gasGet] Proxy GET (${action}) failed, trying direct fetch...`, err?.message || err);
    }
  }

  // Fallback to direct fetch
  try {
    const directUrl = `${gasUrl}?action=${action}&_=${timestamp}${extraQuery ? '&' + extraQuery : ''}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s fallback timeout
    const res = await fetch(directUrl, { 
      cache: 'no-store',
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, message: 'Gagal terhubung ke Google Sheets: ' + (err?.message || 'Waktu koneksi habis') };
  }
}

export async function gasPost<T = any>(action: string, body: any = {}): Promise<GasResponse<T>> {
  const gasUrl = getSheetUrl();
  if (!gasUrl) {
    return { success: false, message: 'URL Google Apps Script belum dikonfigurasi' };
  }

  // Primary attempt via express server proxy
  try {
    const proxyUrl = `/api/sheets/proxy?action=${action}&gasUrl=${encodeURIComponent(gasUrl)}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45000); // 45s timeout for writes
    const res = await fetch(proxyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    if (res.ok) {
      const json = await res.json();
      if (json) return json;
    }
  } catch (err: any) {
    if (err?.name !== 'AbortError') {
      console.warn(`[gasPost] Proxy POST (${action}) failed, trying direct fetch...`, err?.message || err);
    }
  }

  // Fallback to direct fetch
  try {
    const directUrl = `${gasUrl}?action=${action}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 40000); // 40s fallback timeout
    const res = await fetch(directUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(body),
      signal: controller.signal,
    }).finally(() => clearTimeout(timeoutId));

    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, message: 'Gagal mengirim data ke Google Sheets: ' + (err?.message || 'Waktu koneksi habis') };
  }
}

export function getDeletedProducts(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_products');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedProduct(identifier: string) {
  try {
    const clean = identifier.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedProducts();
    set.add(clean);
    localStorage.setItem('strukku_deleted_products', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedProduct(identifier: string) {
  try {
    const clean = identifier.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedProducts();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_products', JSON.stringify(Array.from(set)));
  } catch {}
}

export function isProductDeleted(kode?: string, nama?: string): boolean {
  const set = getDeletedProducts();
  if (set.size === 0) return false;
  if (kode && set.has(kode.trim().toLowerCase())) return true;
  if (nama && set.has(nama.trim().toLowerCase())) return true;
  return false;
}

// Instant Local Getters (0ms delay for Stale-While-Revalidate UI rendering)
export function getLocalProducts(): Product[] {
  const cached = localStorage.getItem('strukku_products');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed
          .filter((p) => !isProductDeleted(p.kode, p.nama))
          .map((p) => ({
            kode: String(p.kode || '').trim(),
            nama: String(p.nama || '').trim(),
            harga: Number(p.harga || 0),
            kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
            stok: (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : '',
            satuan: String(p.satuan || 'pcs').trim(),
            tipeHarga: String(p.tipeHarga || 'fix').trim(),
          }));
      }
    } catch {}
  }
  return [];
}

export function getDeletedCustomers(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_customers');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedCustomer(nama: string) {
  try {
    const clean = nama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedCustomers();
    set.add(clean);
    localStorage.setItem('strukku_deleted_customers', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedCustomer(nama: string) {
  try {
    const clean = nama.trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedCustomers();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_customers', JSON.stringify(Array.from(set)));
  } catch {}
}

export function getDeletedInvoices(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_invoices');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedInvoice(invoiceNo: string) {
  try {
    const clean = (invoiceNo || '').trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedInvoices();
    set.add(clean);
    localStorage.setItem('strukku_deleted_invoices', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedInvoice(invoiceNo: string) {
  try {
    const clean = (invoiceNo || '').trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedInvoices();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_invoices', JSON.stringify(Array.from(set)));
  } catch {}
}

export function isInvoiceDeleted(invoiceNo: string): boolean {
  if (!invoiceNo) return false;
  const set = getDeletedInvoices();
  return set.has(invoiceNo.trim().toLowerCase());
}

export function getDeletedExpenses(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_expenses');
    if (raw) {
      const list: string[] = JSON.parse(raw);
      return new Set(list.map((s) => s.trim().toLowerCase()));
    }
  } catch {}
  return new Set();
}

export function addDeletedExpense(id: string) {
  try {
    const clean = (id || '').trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedExpenses();
    set.add(clean);
    localStorage.setItem('strukku_deleted_expenses', JSON.stringify(Array.from(set)));
  } catch {}
}

export function removeDeletedExpense(id: string) {
  try {
    const clean = (id || '').trim().toLowerCase();
    if (!clean) return;
    const set = getDeletedExpenses();
    set.delete(clean);
    localStorage.setItem('strukku_deleted_expenses', JSON.stringify(Array.from(set)));
  } catch {}
}

export function isExpenseDeleted(id: string): boolean {
  if (!id) return false;
  const set = getDeletedExpenses();
  return set.has(id.trim().toLowerCase());
}

export function getLocalCustomers(): Customer[] {
  const deletedNames = getDeletedCustomers();
  const cached = localStorage.getItem('strukku_customers');
  if (cached !== null) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) {
        return parsed
          .filter((c) => c.nama && !deletedNames.has(c.nama.trim().toLowerCase()))
          .map((c) => ({ ...c, telepon: formatPhone(c.telepon) }));
      }
    } catch {}
  }
  return [];
}

export function getLocalKasirUsers(): KasirUser[] {
  const cached = localStorage.getItem('strukku_kasir_users');
  const customPasses = getLocalCustomPasswords();
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((u: KasirUser) => ({
          ...u,
          password: customPasses[u.nama.toLowerCase()] || u.password || 'ervo123',
        }));
      }
    } catch {}
  }
  return INITIAL_KASIR.map((k) => ({
    nama: k,
    password: customPasses[k.toLowerCase()] || 'ervo123',
  }));
}

export function getLocalSettings(): Partial<StoreSettings> {
  const cached = localStorage.getItem('strukku_sheet_settings');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return {};
}

export function getLocalStockInHistory(): StockInRecord[] {
  const cached = localStorage.getItem('strukku_stock_in_history');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return [];
}

export interface BatchSyncResult {
  products?: Product[];
  customers?: Customer[];
  kasirUsers?: KasirUser[];
  kasirList?: string[];
  settings?: Partial<StoreSettings>;
  stockIn?: StockInRecord[];
  nextInvoiceNo?: string;
  isBatchSupported: boolean;
}

/**
 * Ultra-fast single-request batch data sync from Google Sheets (v6)
 * Reduces 5+ HTTP roundtrips down to 1 request (~1.5s total time)
 */
export async function fetchAllDataBatch(): Promise<BatchSyncResult> {
  const gasUrl = getSheetUrl();
  if (!gasUrl) {
    try {
      const { fetchAllDataFromFirebase } = await import('./firebaseService');
      const cloud = await fetchAllDataFromFirebase();
      return {
        products: cloud.products,
        customers: cloud.customers,
        kasirUsers: cloud.kasirUsers,
        kasirList: cloud.kasirList,
        settings: cloud.settings,
        stockIn: cloud.stockIn,
        nextInvoiceNo: cloud.nextInvoiceNo,
        isBatchSupported: true,
      };
    } catch (e) {
      console.warn('Firestore batch sync fallback:', e);
      const kUsers = getLocalKasirUsers();
      return {
        products: getLocalProducts(),
        customers: getLocalCustomers(),
        kasirUsers: kUsers,
        kasirList: kUsers.map((u) => u.nama),
        settings: getLocalSettings(),
        stockIn: getLocalStockInHistory(),
        isBatchSupported: false,
      };
    }
  }

  try {
    const res = await gasGet<any>('getAllData');
    if (res.success && res.data) {
      const d = res.data;
      let products: Product[] | undefined;
      let customers: Customer[] | undefined;
      let kasirUsers: KasirUser[] | undefined;
      let settings: Partial<StoreSettings> | undefined;
      let stockIn: StockInRecord[] | undefined;
      let nextInvoiceNo: string | undefined;

      if (Array.isArray(d.products) && d.products.length > 0) {
        const localCachedProds = getLocalProducts();
        products = d.products
          .filter((p: any) => !isProductDeleted(p.kode, p.nama))
          .map((p: any) => {
            const cleanKode = String(p.kode || '').trim();
            const cleanNama = String(p.nama || '').trim();
            const localMatch = localCachedProds.find(
              (lp) => (cleanKode && lp.kode.toLowerCase() === cleanKode.toLowerCase()) ||
                      (cleanNama && lp.nama.toLowerCase() === cleanNama.toLowerCase())
            );
            let finalStok = (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : '';
            if ((!finalStok || finalStok === '0') && localMatch && localMatch.stok && String(localMatch.stok) !== '0') {
              finalStok = String(localMatch.stok);
            }
            return {
              kode: cleanKode,
              nama: cleanNama,
              harga: Number(p.harga || 0),
              kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
              stok: finalStok,
              satuan: String(p.satuan || 'pcs').trim(),
              tipeHarga: String(p.tipeHarga || 'fix').trim(),
            };
          });
        localStorage.setItem('strukku_products', JSON.stringify(products));
      }

      if (Array.isArray(d.customers)) {
        const deletedNames = getDeletedCustomers();
        customers = d.customers
          .filter((c: any) => c.nama && !deletedNames.has(c.nama.trim().toLowerCase()))
          .map((c: any) => ({
            ...c,
            telepon: formatPhone(c.telepon),
          }));
        localStorage.setItem('strukku_customers', JSON.stringify(customers));
      }

      if (Array.isArray(d.kasir) && d.kasir.length > 0) {
        const customPasses = getLocalCustomPasswords();
        kasirUsers = d.kasir.map((item: any) => {
          let nama = typeof item === 'string' ? item.trim() : String(item.nama || item.name || '').trim();
          let passFromGas = typeof item === 'object' ? String(item.password || '').trim() : '';
          const finalPass = customPasses[nama.toLowerCase()] || passFromGas || 'ervo123';
          return { nama, password: finalPass };
        }).filter((u: any) => u.nama.length > 0);

        if (kasirUsers.length > 0) {
          localStorage.setItem('strukku_kasir_users', JSON.stringify(kasirUsers));
          localStorage.setItem('strukku_kasir_list', JSON.stringify(kasirUsers.map((u) => u.nama)));
        }
      }

      if (d.settings && typeof d.settings === 'object') {
        const data = d.settings;
        const getVal = (possibleKeys: string[]): string | undefined => {
          const keys = Object.keys(data);
          for (const pKey of possibleKeys) {
            const cleanP = pKey.toLowerCase().replace(/[^a-z0-9]/g, '');
            const foundKey = keys.find((k) => k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanP);
            if (foundKey && data[foundKey] !== undefined && data[foundKey] !== null) {
              const val = String(data[foundKey]).trim();
              if (val) return val;
            }
          }
          return undefined;
        };

        const cfg: Partial<StoreSettings> = {};
        const name = getVal(['NamaToko', 'Nama Toko', 'StoreName', 'Toko']);
        if (name) cfg.name = name;
        const address = getVal(['Alamat', 'AlamatToko', 'Address']);
        if (address) cfg.address = address;
        const phone = getVal(['Telepon', 'NoTelepon', 'Phone', 'HP', 'NoHP', 'WA', 'WhatsApp']);
        if (phone) cfg.phone = phone;
        const footer = getVal(['Footer', 'CatatanFooter', 'Catatan', 'Note']);
        if (footer) cfg.footer = footer;
        const prefix = getVal(['PrefixInvoice', 'Prefix', 'KodeInvoice']);
        if (prefix) cfg.prefixInvoice = prefix;
        const rekening = getVal(['Rekening', 'NoRekening', 'No. Rekening', 'RekeningPembayaran', 'Bank', 'NoRek', 'Account']);
        if (rekening !== undefined) cfg.rekening = rekening;

        settings = cfg;
        localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
      }

      if (Array.isArray(d.stockIn)) {
        stockIn = d.stockIn;
        localStorage.setItem('strukku_stock_in_history', JSON.stringify(stockIn));
      }

      if (d.nextInvoiceNo) {
        nextInvoiceNo = String(d.nextInvoiceNo).trim();
      }

      return {
        products,
        customers,
        kasirUsers,
        kasirList: kasirUsers ? kasirUsers.map((u) => u.nama) : undefined,
        settings,
        stockIn,
        nextInvoiceNo,
        isBatchSupported: true,
      };
    }
  } catch (err) {
    console.warn('Batch getAllData failed, falling back to parallel fetch:', err);
  }

  // Fallback to individual fetches if getAllData is not supported on older script
  const [pData, cData, kUsers, sData, stData] = await Promise.all([
    fetchProducts(),
    fetchCustomers(),
    fetchKasirUsers(),
    fetchSheetSettings(),
    fetchStockInHistory(),
  ]);

  return {
    products: pData,
    customers: cData,
    kasirUsers: kUsers,
    kasirList: kUsers.map((u) => u.nama),
    settings: sData,
    stockIn: stData,
    isBatchSupported: false,
  };
}

export async function getNextInvoiceNumber(): Promise<string> {
  try {
    const res = await gasGet<{ invoiceNo: string }>('getNextInvoiceNo');
    if (res.success && res.invoiceNo) {
      return res.invoiceNo;
    }
  } catch {
    // offline fallback
  }

  const d = new Date();
  const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0');
  const key = 'strukku_inv_' + yearMonth;
  let count = parseInt(localStorage.getItem(key) || '0', 10) + 1;
  localStorage.setItem(key, count.toString());
  return 'ERV-' + yearMonth + '-' + String(count).padStart(3, '0');
}

export async function fetchProducts(): Promise<Product[]> {
  const sanitize = (list: any[]): Product[] => {
    return list
      .filter((p) => !isProductDeleted(p.kode, p.nama))
      .map((p) => ({
        kode: String(p.kode || '').trim(),
        nama: String(p.nama || '').trim(),
        harga: Number(p.harga || 0),
        kategori: String(p.kategori || 'Lainnya').trim().replace(/[\r\n]+/g, '') || 'Lainnya',
        stok: (p.stok !== null && p.stok !== undefined && String(p.stok).trim() !== '') ? String(p.stok).trim() : '',
        satuan: String(p.satuan || 'pcs').trim(),
        tipeHarga: String(p.tipeHarga || 'fix').trim(),
      }));
  };

  try {
    const res = await gasGet<Product[]>('getProducts');
    if (res.success && Array.isArray(res.data) && res.data.length > 0) {
      const sanitized = sanitize(res.data);
      localStorage.setItem('strukku_products', JSON.stringify(sanitized));
      return sanitized;
    }
  } catch {
    // fallback to cache
  }

  const cached = localStorage.getItem('strukku_products');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return sanitize(parsed);
      }
    } catch {}
  }
  return sanitize(INITIAL_PRODUCTS);
}

export function formatPhone(val: string | number | undefined | null): string {
  if (val === undefined || val === null) return '';
  let str = String(val).trim();
  if (str.startsWith("'")) {
    str = str.substring(1);
  }
  if (/^8\d{8,12}$/.test(str)) {
    str = '0' + str;
  }
  return str;
}

export async function fetchCustomers(): Promise<Customer[]> {
  const deletedNames = getDeletedCustomers();
  try {
    const res = await gasGet<Customer[]>('getCustomers');
    if (res.success && Array.isArray(res.data)) {
      const sanitized = res.data
        .filter((c) => c.nama && !deletedNames.has(c.nama.trim().toLowerCase()))
        .map((c) => ({
          ...c,
          telepon: formatPhone(c.telepon),
        }));
      localStorage.setItem('strukku_customers', JSON.stringify(sanitized));
      return sanitized;
    }
  } catch {
    // fallback
  }

  return getLocalCustomers();
}

export async function addCustomer(customerData: Customer): Promise<{ success: boolean; isSheetSynced: boolean; message: string; customer: Customer; needsScriptUpdate?: boolean }> {
  const cleanName = customerData.nama.trim();
  const cleanPhone = formatPhone(customerData.telepon);

  removeDeletedCustomer(cleanName);

  const formattedData: Customer = {
    ...customerData,
    nama: cleanName,
    kelas: customerData.kelas || 'Reguler',
    diskon: Number(customerData.diskon || 0),
    telepon: cleanPhone,
    catatan: customerData.catatan || '',
    alamat: customerData.alamat || '',
  };

  // Update local storage cache immediately
  const cached = localStorage.getItem('strukku_customers');
  let customers: Customer[] = [];
  if (cached) {
    try { customers = JSON.parse(cached); } catch {}
  } else {
    customers = getLocalCustomers();
  }

  const existsIndex = customers.findIndex(
    (c) => c.nama.trim().toLowerCase() === cleanName.toLowerCase()
  );
  if (existsIndex >= 0) {
    customers[existsIndex] = formattedData;
  } else {
    customers.push(formattedData);
  }

  localStorage.setItem('strukku_customers', JSON.stringify(customers));

  const telPayload = cleanPhone ? (cleanPhone.startsWith('0') ? ("'" + cleanPhone) : cleanPhone) : '';

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('addCustomer', {
      action: 'addCustomer',
      nama: cleanName,
      kelas: formattedData.kelas,
      diskon: formattedData.diskon,
      telepon: telPayload,
      catatan: formattedData.catatan,
      alamat: formattedData.alamat,
      pelanggan: cleanName,
      customer: formattedData,
    });

    if (res.success) {
      return {
        success: true,
        isSheetSynced: true,
        message: res.message || `Pelanggan "${cleanName}" berhasil disimpan ke Google Sheets!`,
        customer: formattedData,
      };
    } else {
      const isScriptOld = res.message?.includes('tidak dikenal') || res.message?.includes('Action');
      return {
        success: true,
        isSheetSynced: false,
        needsScriptUpdate: isScriptOld,
        message: isScriptOld
          ? `Pelanggan "${cleanName}" tersimpan di lokal HP/Aplikasi. PERHATIAN: Kode Apps Script di Google Sheets Anda perlu diperbarui ke versi v4 agar tercatat langsung di spreadsheet.`
          : `Pelanggan "${cleanName}" tersimpan di lokal. (${res.message || 'Gagal ke Google Sheets'})`,
        customer: formattedData,
      };
    }
  } catch (err: any) {
    return {
      success: true,
      isSheetSynced: false,
      message: `Pelanggan "${cleanName}" tersimpan secara lokal (offline mode).`,
      customer: formattedData,
    };
  }
}

export async function deleteCustomer(customerName: string): Promise<{ success: boolean; message: string }> {
  const cleanName = customerName.trim();

  addDeletedCustomer(cleanName);

  // Remove from localStorage cache
  const cached = localStorage.getItem('strukku_customers');
  if (cached) {
    try {
      let customers: Customer[] = JSON.parse(cached);
      customers = customers.filter((c) => c.nama.trim().toLowerCase() !== cleanName.toLowerCase());
      localStorage.setItem('strukku_customers', JSON.stringify(customers));
    } catch {}
  }

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('deleteCustomer', {
      action: 'deleteCustomer',
      nama: cleanName,
      pelanggan: cleanName,
    });

    if (res.success) {
      return {
        success: true,
        message: res.message || `Pelanggan "${cleanName}" berhasil dihapus.`,
      };
    } else {
      return {
        success: true,
        message: `Pelanggan "${cleanName}" dihapus dari data lokal.`,
      };
    }
  } catch (err: any) {
    return {
      success: true,
      message: `Pelanggan "${cleanName}" dihapus secara lokal (offline mode).`,
    };
  }
}

export function getLocalCustomPasswords(): Record<string, string> {
  try {
    const cached = localStorage.getItem('strukku_custom_passwords');
    return cached ? JSON.parse(cached) : {};
  } catch {
    return {};
  }
}

export function setLocalCustomPassword(kasirName: string, pass: string) {
  const current = getLocalCustomPasswords();
  current[kasirName.trim().toLowerCase()] = pass;
  localStorage.setItem('strukku_custom_passwords', JSON.stringify(current));
}

export async function fetchKasirUsers(): Promise<KasirUser[]> {
  const customPasses = getLocalCustomPasswords();

  try {
    const res = await gasGet<any[]>('getKasir');
    if (res.success && Array.isArray(res.data) && res.data.length > 0) {
      const users: KasirUser[] = res.data.map((item) => {
        let nama = '';
        let passFromGas = '';
        if (typeof item === 'string') {
          nama = item.trim();
        } else {
          nama = String(item.nama || item.name || '').trim();
          passFromGas = String(item.password || '').trim();
        }
        const lowerName = nama.toLowerCase();
        const finalPass = customPasses[lowerName] || passFromGas || 'ervo123';
        return { nama, password: finalPass };
      }).filter((u) => u.nama.length > 0);

      if (users.length > 0) {
        localStorage.setItem('strukku_kasir_users', JSON.stringify(users));
        const names = users.map((u) => u.nama);
        localStorage.setItem('strukku_kasir_list', JSON.stringify(names));
        return users;
      }
    }
  } catch {}

  const cached = localStorage.getItem('strukku_kasir_users');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((u: KasirUser) => ({
          ...u,
          password: customPasses[u.nama.toLowerCase()] || u.password || 'ervo123',
        }));
      }
    } catch {}
  }

  return INITIAL_KASIR.map((k) => ({
    nama: k,
    password: customPasses[k.toLowerCase()] || 'ervo123',
  }));
}

export async function fetchKasirList(): Promise<string[]> {
  const users = await fetchKasirUsers();
  return users.map((u) => u.nama);
}

export async function updateKasirPassword(kasirName: string, newPassword: string): Promise<{ success: boolean; message: string }> {
  // Save custom local password immediately
  setLocalCustomPassword(kasirName, newPassword);

  // Update local storage cache immediately
  const cached = localStorage.getItem('strukku_kasir_users');
  let users: KasirUser[] = [];
  if (cached) {
    try { users = JSON.parse(cached); } catch {}
  }
  let found = false;
  users = users.map((u) => {
    if (u.nama.toLowerCase() === kasirName.trim().toLowerCase()) {
      found = true;
      return { ...u, password: newPassword };
    }
    return u;
  });
  if (!found) {
    users.push({ nama: kasirName, password: newPassword });
  }
  localStorage.setItem('strukku_kasir_users', JSON.stringify(users));

  // Sync to Firestore for multi-device consistency
  try {
    const { saveKasirUserFirebase } = await import('./firebaseService');
    await saveKasirUserFirebase({ nama: kasirName, password: newPassword });
  } catch (err) {
    console.warn('Could not sync kasir password to Firestore:', err);
  }

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('updatePassword', {
      action: 'updatePassword',
      kasir: kasirName,
      newPassword: newPassword,
    });
    if (res.success) {
      return {
        success: true,
        message: 'Password berhasil diperbarui & disimpan!',
      };
    } else {
      return {
        success: true,
        message: 'Password berhasil diperbarui di aplikasi!',
      };
    }
  } catch (err: any) {
    return {
      success: true,
      message: 'Password berhasil diperbarui di aplikasi!',
    };
  }
}

export async function fetchSheetSettings(): Promise<Partial<StoreSettings>> {
  try {
    const res = await gasGet<Record<string, string>>('getSettings');
    if (res.success && res.data) {
      const data = res.data;
      const getVal = (possibleKeys: string[]): string | undefined => {
        const keys = Object.keys(data);
        for (const pKey of possibleKeys) {
          const cleanP = pKey.toLowerCase().replace(/[^a-z0-9]/g, '');
          const foundKey = keys.find((k) => k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanP);
          if (foundKey && data[foundKey] !== undefined && data[foundKey] !== null) {
            const val = String(data[foundKey]).trim();
            if (val) return val;
          }
        }
        return undefined;
      };

      const cfg: Partial<StoreSettings> = {};
      const name = getVal(['NamaToko', 'Nama Toko', 'StoreName', 'Toko']);
      if (name) cfg.name = name;

      const address = getVal(['Alamat', 'AlamatToko', 'Address']);
      if (address) cfg.address = address;

      const phone = getVal(['Telepon', 'NoTelepon', 'Phone', 'HP', 'NoHP', 'WA', 'WhatsApp']);
      if (phone) cfg.phone = phone;

      const footer = getVal(['Footer', 'CatatanFooter', 'Catatan', 'Note']);
      if (footer) cfg.footer = footer;

      const prefix = getVal(['PrefixInvoice', 'Prefix', 'KodeInvoice']);
      if (prefix) cfg.prefixInvoice = prefix;

      const rekening = getVal(['Rekening', 'NoRekening', 'No. Rekening', 'RekeningPembayaran', 'Bank', 'NoRek', 'Account', 'RekeningBank', 'NomorRekening', 'No.Rekening']);
      if (rekening !== undefined) cfg.rekening = rekening;

      const sheetUrl = getVal(['Url', 'AlamatUrl', 'GasUrl', 'WebUrl']);
      if (sheetUrl && sheetUrl.startsWith('http')) {
        setSheetUrl(sheetUrl);
      }

      localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
      return cfg;
    }
  } catch {}

  const cached = localStorage.getItem('strukku_sheet_settings');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }
  return {};
}

export async function saveSettingsRemote(settings: Partial<StoreSettings>): Promise<GasResponse> {
  return gasPost('saveSettings', {
    NamaToko: settings.name,
    Alamat: settings.address,
    Telepon: settings.phone,
    Footer: settings.footer,
    PrefixInvoice: settings.prefixInvoice,
    Rekening: settings.rekening,
  });
}

export interface RecentInvoiceItem {
  invoiceNo: string;
  date?: string;
  time?: string;
  customer?: string;
  cashier?: string;
  total?: number;
  dp?: number;
  sisa?: number;
  status?: string;
  items?: InvoiceItem[];
  historiPelunasan?: PelunasanRecord[];
  payMethod?: string;
  metodePembayaran?: string;
}

export function addRecentInvoiceToLocal(inv: Partial<Invoice>) {
  if (!inv.invoiceNo) return;
  try {
    const cached = localStorage.getItem('strukku_recent_invoices');
    let list: RecentInvoiceItem[] = cached ? JSON.parse(cached) : [];
    const invKey = inv.invoiceNo.trim().toLowerCase();
    list = list.filter((x) => (x.invoiceNo ? x.invoiceNo.trim().toLowerCase() : '') !== invKey);
    const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
    list.unshift({
      invoiceNo: inv.invoiceNo,
      date: inv.date,
      time: inv.time,
      customer: inv.customer,
      cashier: inv.cashier,
      total: inv.total,
      dp: inv.dp !== undefined ? inv.dp : 0,
      sisa: inv.sisa,
      status: inv.status || ((inv.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
      items: inv.items,
      payMethod: method,
      metodePembayaran: method,
    });
    if (list.length > 200) list = list.slice(0, 200);
    localStorage.setItem('strukku_recent_invoices', JSON.stringify(list));
  } catch {}
}

export async function fetchRecentInvoices(forceRefresh = false): Promise<{ list: RecentInvoiceItem[]; needsScriptUpdate: boolean }> {
  const deletedSet = getDeletedInvoices();
  const localHistoryRaw = localStorage.getItem('strukku_recent_invoices');
  let localList: RecentInvoiceItem[] = [];
  if (localHistoryRaw) {
    try {
      localList = JSON.parse(localHistoryRaw);
      localList = localList.filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()));
    } catch {}
  }

  // Always merge with live Firestore invoicesManager to guarantee multi-device real-time consistency
  try {
    const { invoicesManager } = await import('./firebaseService');
    const cached = invoicesManager.getCachedData();
    if (cached && cached.length > 0) {
      const mergedMap = new Map<string, RecentInvoiceItem>();
      localList.forEach((inv) => {
        const k = (inv.invoiceNo || '').trim().toLowerCase();
        if (k && !deletedSet.has(k)) mergedMap.set(k, inv);
      });
      cached.forEach((inv) => {
        const k = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
        if (k && !deletedSet.has(k)) {
          const processed = recalculateInvoiceSisaAndStatus(inv as RecentInvoiceItem);
          const existing = mergedMap.get(k);
          mergedMap.set(k, {
            ...existing,
            ...processed,
            items: (processed.items && processed.items.length > 0) ? processed.items : existing?.items || [],
          });
        }
      });
      localList = Array.from(mergedMap.values());
      localList.sort(compareInvoicesDesc);
    }
  } catch {}

  let needsScriptUpdate = false;

  const syncGas = async () => {
    try {
      const res = await gasGet<RecentInvoiceItem[]>('getRecentInvoices');
      if (res.success && Array.isArray(res.data)) {
        const localItemsMap = new Map<string, InvoiceItem[]>();
        const localDpMap = new Map<string, number>();
        const localPayMethodMap = new Map<string, string>();
        localList.forEach((item) => {
          if (item.invoiceNo) {
            const invKey = item.invoiceNo.trim();
            if (item.items && item.items.length > 0) {
              localItemsMap.set(invKey, item.items);
            }
            if (item.dp !== undefined) {
              localDpMap.set(invKey, Number(item.dp));
            }
            const pm = item.payMethod || (item as any).metodePembayaran;
            if (pm) {
              localPayMethodMap.set(invKey, pm);
              localPayMethodMap.set(invKey.toLowerCase(), pm);
            }
          }
        });

        const seenInvMap = new Map<string, RecentInvoiceItem>();

        // STEP 1: Pre-populate with local/Firestore list to ensure no invoices are lost (filter out deleted invoices)
        localList.forEach((inv) => {
          const invKey = inv.invoiceNo ? inv.invoiceNo.trim() : '';
          const invLowerKey = invKey.toLowerCase();
          if (invLowerKey && !deletedSet.has(invLowerKey)) {
            const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
            const processed = recalculateInvoiceSisaAndStatus({
              ...inv,
              payMethod: method,
              metodePembayaran: method,
            });
            seenInvMap.set(invLowerKey, processed);
          }
        });

        // STEP 2: Merge remote GAS data into seenInvMap (strictly ignoring any deleted invoices)
        res.data.forEach((inv) => {
          const invKey = inv.invoiceNo ? inv.invoiceNo.trim() : '';
          const invLowerKey = invKey.toLowerCase();
          if (!invKey || deletedSet.has(invLowerKey)) {
            // STRICTLY IGNORE deleted invoice from remote Google Sheets
            return;
          }

          let items = inv.items;
          const existing = seenInvMap.get(invLowerKey);

          if ((!items || items.length === 0) && invKey && localItemsMap.has(invKey)) {
            items = localItemsMap.get(invKey);
          } else if ((!items || items.length === 0) && existing?.items) {
            items = existing.items;
          }

          let dp = inv.dp !== undefined ? Number(inv.dp) : (localDpMap.has(invKey) ? localDpMap.get(invKey)! : (existing?.dp ?? 0));
          const payMethod = inv.payMethod || (inv as any).metodePembayaran || localPayMethodMap.get(invKey) || localPayMethodMap.get(invLowerKey) || existing?.payMethod || (existing as any)?.metodePembayaran || 'Tunai';

          const mergedInv: RecentInvoiceItem = {
            ...inv,
            ...existing,
            items: (existing?.items && existing.items.length > 0) ? existing.items : (items && items.length > 0 ? items : existing?.items),
            dp: existing?.dp !== undefined ? existing.dp : dp,
            sisa: existing?.sisa !== undefined ? existing.sisa : inv.sisa,
            status: existing?.status || inv.status,
            payMethod,
            metodePembayaran: payMethod,
            historiPelunasan: mergePelunasanHistories(
              existing?.historiPelunasan || (existing as any)?.pelunasanHistory,
              inv.historiPelunasan || (inv as any)?.pelunasanHistory
            ),
          };

          const processed = recalculateInvoiceSisaAndStatus(mergedInv);
          seenInvMap.set(invLowerKey, processed);
        });

        const mergedData: RecentInvoiceItem[] = Array.from(seenInvMap.values())
          .filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()));
        mergedData.sort(compareInvoicesDesc);

        try {
          localStorage.setItem('strukku_recent_invoices', JSON.stringify(mergedData));
          const allHistories: PelunasanRecord[] = [];
          mergedData.forEach((inv) => {
            if (Array.isArray(inv.historiPelunasan)) {
              allHistories.push(...inv.historiPelunasan);
            }
          });
          const existingLocalHist = getPelunasanHistory('');
          const mergedHistAll = mergePelunasanHistories(existingLocalHist, allHistories);
          localStorage.setItem('strukku_pelunasan_history', JSON.stringify(mergedHistAll));
        } catch {}
        return { list: mergedData, needsScriptUpdate: false };
      } else if (res.message && (res.message.toLowerCase().includes('tidak dikenal') || res.message.toLowerCase().includes('action'))) {
        needsScriptUpdate = true;
      }
    } catch {}
    const safeLocal = localList.filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()));
    return { list: safeLocal, needsScriptUpdate };
  };

  const safeLocalList = localList.filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()));
  if (!forceRefresh && safeLocalList.length > 0) {
    // Return instant local cache & sync in background
    syncGas().catch(() => {});
    return { list: safeLocalList, needsScriptUpdate: false };
  }

  const gasUrl = getSheetUrl();
  if (!gasUrl) {
    return { list: safeLocalList, needsScriptUpdate: false };
  }

  return await syncGas();
}

export async function fetchPiutangList(forceRefresh = false): Promise<PiutangItem[]> {
  const deletedSet = getDeletedInvoices();

  // 1. Cloud Firestore is shared across all users and devices - query it first!
  try {
    const { getPiutangInvoicesFirebase } = await import('./firebaseService');
    const firestoreInvoices = await getPiutangInvoicesFirebase();
    if (firestoreInvoices && firestoreInvoices.length > 0) {
      const result: PiutangItem[] = firestoreInvoices
        .filter((inv) => inv.invoiceNo && !deletedSet.has(inv.invoiceNo.trim().toLowerCase()))
        .map((inv) => {
          const processed = recalculateInvoiceSisaAndStatus(inv);
          return {
            invoiceNo: processed.invoiceNo || (processed as any).noInvoice,
            date: processed.date || '',
            customer: processed.customer || 'Umum',
            total: processed.total || 0,
            dp: processed.dp || 0,
            sisa: processed.sisa,
            deadline: processed.deadline || '',
            historiPelunasan: processed.historiPelunasan || processed.pelunasanHistory || [],
          };
        })
        .filter((p) => (p.sisa || 0) > 0);

      if (result.length > 0) {
        return result;
      }
    }
  } catch (err) {
    console.warn('fetchPiutangList: Firestore check skipped:', err);
  }

  // 2. Fallback to local storage cache
  const localHistoryRaw = localStorage.getItem('strukku_recent_invoices');
  let localList: RecentInvoiceItem[] = [];
  if (localHistoryRaw) {
    try {
      localList = JSON.parse(localHistoryRaw);
      localList = localList.filter((item) => item.invoiceNo && !deletedSet.has(item.invoiceNo.trim().toLowerCase()));
    } catch {}
  }

  const getLocalPiutangList = (): PiutangItem[] => {
    const piutangMap = new Map<string, PiutangItem>();
    localList.forEach((item) => {
      if (!item.invoiceNo) return;
      const invKey = item.invoiceNo.trim().toLowerCase();
      if (deletedSet.has(invKey)) return;
      const processed = recalculateInvoiceSisaAndStatus(item);

      if (processed.sisa > 0) {
        piutangMap.set(invKey, {
          invoiceNo: processed.invoiceNo!,
          date: processed.date || '',
          customer: processed.customer || 'Umum',
          total: processed.total || 0,
          dp: processed.dp || 0,
          sisa: processed.sisa,
          deadline: '',
          historiPelunasan: processed.historiPelunasan || [],
        });
      }
    });
    return Array.from(piutangMap.values());
  };

  const syncGasPiutang = async (): Promise<PiutangItem[]> => {
    try {
      const res = await gasGet<PiutangItem[]>('getPiutang');
      if (res.success && Array.isArray(res.data)) {
        return res.data
          .filter((p) => p.invoiceNo && !deletedSet.has(p.invoiceNo.trim().toLowerCase()))
          .map((p) => {
            const processed = recalculateInvoiceSisaAndStatus(p);
            return {
              invoiceNo: p.invoiceNo,
              date: p.date || '',
              customer: p.customer || 'Umum',
              total: p.total || 0,
              dp: processed.dp || 0,
              sisa: processed.sisa,
              deadline: p.deadline || '',
              historiPelunasan: processed.historiPelunasan || [],
            };
          })
          .filter((p) => (p.sisa || 0) > 0);
      }
    } catch {}
    return getLocalPiutangList();
  };

  const localPiutang = getLocalPiutangList();
  if (!forceRefresh && localPiutang.length > 0) {
    // Return instant local cache & sync in background
    syncGasPiutang().catch(() => {});
    return localPiutang;
  }

  return await syncGasPiutang();
}

export async function getInvoiceByNo(invoiceNo: string): Promise<GasResponse<Invoice>> {
  const cleanInv = invoiceNo.trim().toLowerCase();
  if (isInvoiceDeleted(cleanInv)) {
    return { success: false, message: 'Invoice #' + invoiceNo + ' telah dihapus oleh Supervisor/Owner' };
  }

  // 1. Check local cache first for instant response
  try {
    const cached = localStorage.getItem('strukku_recent_invoices');
    if (cached) {
      const list: RecentInvoiceItem[] = JSON.parse(cached);
      const target = list.find((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === cleanInv);
      if (target) {
        const historiPelunasan = target.historiPelunasan || getPelunasanHistory(target.invoiceNo);
        const method = target.payMethod || (target as any).metodePembayaran || 'Tunai';
        const inv: Invoice = {
          invoiceNo: target.invoiceNo,
          noInvoice: target.invoiceNo,
          date: target.date || '',
          time: target.time || '',
          customer: target.customer || '',
          cashier: target.cashier || '',
          subtotal: Number(target.total || 0),
          discPct: 0,
          discAmt: 0,
          taxPct: 0,
          taxAmt: 0,
          negoAmt: 0,
          total: Number(target.total || 0),
          payMethod: method,
          metodePembayaran: method,
          dp: Number(target.dp || 0),
          sisa: target.sisa !== undefined ? target.sisa : Math.max(0, Number(target.total || 0) - Number(target.dp || 0)),
          kembalian: 0,
          deadline: '',
          items: target.items || [],
          historiPelunasan,
          pelunasanHistory: historiPelunasan,
          status: target.status || 'LUNAS',
        };
        const processed = recalculateInvoiceSisaAndStatus(inv);
        return { success: true, data: processed };
      }
    }
  } catch {}

  // 2. Check Cloud Firestore (authoritative across devices and users)
  try {
    const { getInvoiceFirebase } = await import('./firebaseService');
    const firestoreInv = await getInvoiceFirebase(invoiceNo);
    if (firestoreInv) {
      return { success: true, data: firestoreInv };
    }
  } catch (err) {
    console.warn('getInvoiceByNo: Firestore check error:', err);
  }

  // 3. Query GAS if not found in local cache or Firestore
  const res = await gasPost<Invoice>('getInvoice', { invoiceNo });
  if (res.success && res.data) {
    const invNo = res.data.invoiceNo || invoiceNo;
    const method = res.data.payMethod || (res.data as any).metodePembayaran || 'Tunai';
    res.data.payMethod = method;
    (res.data as any).metodePembayaran = method;
    const backendHist = Array.isArray((res.data as any).historiPelunasan)
      ? (res.data as any).historiPelunasan
      : (Array.isArray((res.data as any).pelunasanHistory) ? (res.data as any).pelunasanHistory : null);
    const historiPelunasan: PelunasanRecord[] = backendHist !== null ? backendHist : getPelunasanHistory(invNo);
    (res.data as any).historiPelunasan = historiPelunasan;
    (res.data as any).pelunasanHistory = historiPelunasan;

    if (backendHist !== null) {
      try {
        const cached = localStorage.getItem('strukku_pelunasan_history');
        let list: PelunasanRecord[] = cached ? JSON.parse(cached) : [];
        list = list.filter((x) => x.invoiceNo?.trim().toLowerCase() !== invNo.trim().toLowerCase());
        list.push(...backendHist);
        localStorage.setItem('strukku_pelunasan_history', JSON.stringify(list));
      } catch {}
    }
    const processed = recalculateInvoiceSisaAndStatus(res.data);
    return { success: true, data: processed };
  }

  return res;
}

export async function saveTransaction(payload: any): Promise<GasResponse> {
  const res = await gasPost('saveTransaction', payload);
  if (res.success) {
    addRecentInvoiceToLocal(payload);
  }
  return res;
}

export function getPelunasanTimestamp(r: any): number {
  if (!r) return 0;
  if (r.createdAt) {
    if (typeof r.createdAt === 'number') return r.createdAt;
    if (typeof r.createdAt === 'string') {
      const parsed = new Date(r.createdAt).getTime();
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
    if (typeof r.createdAt === 'object' && typeof (r.createdAt as any).toDate === 'function') {
      return (r.createdAt as any).toDate().getTime();
    }
  }

  const dateStr = String(r.date || '').trim();
  const timeStr = String(r.time || '00:00').trim();

  if (!dateStr) return 0;

  let y = 1970, m = 1, d = 1;

  if (dateStr.includes('/')) {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        d = parseInt(parts[0], 10) || 1;
        m = parseInt(parts[1], 10) || 1;
        y = parseInt(parts[2], 10) || 1970;
      } else if (parts[0].length === 4) {
        y = parseInt(parts[0], 10) || 1970;
        m = parseInt(parts[1], 10) || 1;
        d = parseInt(parts[2], 10) || 1;
      }
    }
  } else if (dateStr.includes('-')) {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        y = parseInt(parts[0], 10) || 1970;
        m = parseInt(parts[1], 10) || 1;
        d = parseInt(parts[2], 10) || 1;
      } else if (parts[2].length === 4) {
        d = parseInt(parts[0], 10) || 1;
        m = parseInt(parts[1], 10) || 1;
        y = parseInt(parts[2], 10) || 1970;
      }
    }
  }

  let hh = 0, mm = 0, ss = 0;
  if (timeStr) {
    const tParts = timeStr.split(':');
    if (tParts.length >= 2) {
      hh = parseInt(tParts[0], 10) || 0;
      mm = parseInt(tParts[1], 10) || 0;
      if (tParts.length >= 3) {
        ss = parseInt(tParts[2], 10) || 0;
      }
    }
  }

  const dateObj = new Date(y, m - 1, d, hh, mm, ss);
  const t = dateObj.getTime();
  return isNaN(t) ? 0 : t;
}

export function sortPelunasanHistoryAsc(list: PelunasanRecord[]): PelunasanRecord[] {
  if (!Array.isArray(list)) return [];
  return [...list].sort((a, b) => getPelunasanTimestamp(a) - getPelunasanTimestamp(b));
}

export function mergePelunasanHistories(hist1?: PelunasanRecord[] | null, hist2?: PelunasanRecord[] | null): PelunasanRecord[] {
  const list1 = Array.isArray(hist1) ? hist1 : [];
  const list2 = Array.isArray(hist2) ? hist2 : [];
  const combined = [...list1, ...list2];
  
  const seen = new Set<string>();
  const unique: PelunasanRecord[] = [];

  for (const item of combined) {
    if (!item) continue;
    const invNo = (item.invoiceNo || '').trim().toLowerCase();
    const dt = (item.date || '').trim();
    const tm = (item.time || '').trim();
    const jm = Number(item.jumlahBayar || 0);
    const ks = (item.kasir || (item as any).cashier || '').trim().toLowerCase();
    const itemId = (item.id || '').trim();

    const key = itemId ? itemId : `${invNo}_${dt}_${tm}_${jm}_${ks}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(item);
    }
  }

  return sortPelunasanHistoryAsc(unique);
}

export function recalculateInvoiceSisaAndStatus<T extends Partial<RecentInvoiceItem>>(inv: T): T {
  if (!inv) return inv;

  const invoiceNo = inv.invoiceNo || '';
  const backendHist = Array.isArray((inv as any).historiPelunasan)
    ? (inv as any).historiPelunasan
    : Array.isArray((inv as any).pelunasanHistory)
    ? (inv as any).pelunasanHistory
    : null;

  const localHist = invoiceNo ? getPelunasanHistory(invoiceNo) : [];
  const historiPelunasan = mergePelunasanHistories(backendHist, localHist);

  const tot = Number(inv.total || 0);
  const dp = Number(inv.dp || 0);
  const totalPaidHist = historiPelunasan.reduce((acc, h) => acc + Number(h.jumlahBayar || 0), 0);

  const initialUnpaid = Math.max(0, tot - dp);
  let sisa = inv.sisa !== undefined && inv.sisa !== null ? Number(inv.sisa) : initialUnpaid;

  if (historiPelunasan.length > 0) {
    sisa = Math.max(0, initialUnpaid - totalPaidHist);
  } else if (inv.sisa !== undefined && inv.sisa !== null) {
    sisa = Number(inv.sisa);
  } else {
    sisa = initialUnpaid;
  }

  if (String(inv.status || '').toUpperCase() === 'LUNAS') {
    sisa = 0;
  }

  const status = sisa <= 0 ? 'LUNAS' : 'DP';
  const payMethod = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';

  return {
    ...inv,
    payMethod,
    metodePembayaran: payMethod,
    sisa,
    status,
    historiPelunasan,
    pelunasanHistory: historiPelunasan,
  };
}

export function savePelunasanHistoryToLocal(record: PelunasanRecord) {
  try {
    const cached = localStorage.getItem('strukku_pelunasan_history');
    let list: PelunasanRecord[] = cached ? JSON.parse(cached) : [];
    const invKey = record.invoiceNo ? record.invoiceNo.trim().toLowerCase() : '';
    const mergedList = mergePelunasanHistories(list, [record]);
    localStorage.setItem('strukku_pelunasan_history', JSON.stringify(mergedList));

    const recInvRaw = localStorage.getItem('strukku_recent_invoices');
    if (recInvRaw) {
      let recList: RecentInvoiceItem[] = JSON.parse(recInvRaw);
      const idx = recList.findIndex((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === invKey);
      if (idx >= 0) {
        const newSisa = record.newSisa !== undefined ? record.newSisa : Math.max(0, (recList[idx].sisa || 0) - (record.jumlahBayar || 0));
        recList[idx].sisa = newSisa;
        recList[idx].status = newSisa <= 0 ? 'LUNAS' : 'DP';
        const currentHist = Array.isArray(recList[idx].historiPelunasan)
          ? recList[idx].historiPelunasan
          : (Array.isArray((recList[idx] as any).pelunasanHistory) ? (recList[idx] as any).pelunasanHistory : []);
        const mergedItemHist = mergePelunasanHistories(currentHist, [record]);
        recList[idx].historiPelunasan = mergedItemHist;
        (recList[idx] as any).pelunasanHistory = mergedItemHist;
        localStorage.setItem('strukku_recent_invoices', JSON.stringify(recList));
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('strukku-invoices-updated', { detail: recList[idx] }));
        }
      }
    }
  } catch {}
}

export function getPelunasanHistory(invoiceNo?: string): PelunasanRecord[] {
  try {
    const cached = localStorage.getItem('strukku_pelunasan_history');
    if (!cached) return [];
    const list: PelunasanRecord[] = JSON.parse(cached);
    if (!Array.isArray(list)) return [];
    if (!invoiceNo || !invoiceNo.trim()) {
      return sortPelunasanHistoryAsc(list);
    }
    const cleanNo = invoiceNo.trim().toLowerCase();
    const filtered = list.filter((x) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === cleanNo);
    return sortPelunasanHistoryAsc(filtered);
  } catch {
    return [];
  }
}

export async function submitPelunasan(payload: PelunasanRecord): Promise<GasResponse> {
  const res = await gasPost('pelunasan', payload);
  // Calculate newSisa if response provided or infer it
  const bayar = payload.jumlahBayar || 0;
  const sisaAwal = payload.sisaAwal !== undefined ? payload.sisaAwal : 0;
  const newSisa = res.newSisa !== undefined ? res.newSisa : Math.max(0, sisaAwal - bayar);
  
  savePelunasanHistoryToLocal({
    ...payload,
    newSisa,
    status: newSisa <= 0 ? 'LUNAS' : 'DP',
  });
  return res;
}

export async function addNewProduct(newProd: Product): Promise<GasResponse> {
  if (newProd.kode) removeDeletedProduct(newProd.kode);
  if (newProd.nama) removeDeletedProduct(newProd.nama);

  // Update local product list
  try {
    const cachedProducts = localStorage.getItem('strukku_products');
    let products: Product[] = cachedProducts ? JSON.parse(cachedProducts) : INITIAL_PRODUCTS;
    const existingIdx = products.findIndex((p) => p.kode.toLowerCase() === newProd.kode.toLowerCase());
    if (existingIdx >= 0) {
      products[existingIdx] = newProd;
    } else {
      products.unshift(newProd);
    }
    localStorage.setItem('strukku_products', JSON.stringify(products));
  } catch {}

  return gasPost('addProduct', newProd);
}

export async function updateProductDetails(
  updatedProd: Product,
  oldKode?: string,
  oldNama?: string
): Promise<GasResponse> {
  if (updatedProd.kode) removeDeletedProduct(updatedProd.kode);
  if (updatedProd.nama) removeDeletedProduct(updatedProd.nama);

  const payload = {
    ...updatedProd,
    oldKode: oldKode || updatedProd.kode,
    oldNama: oldNama || updatedProd.nama,
  };

  // Update local product list
  try {
    const cachedProducts = localStorage.getItem('strukku_products');
    let products: Product[] = cachedProducts ? JSON.parse(cachedProducts) : INITIAL_PRODUCTS;
    const targetKode = (oldKode || updatedProd.kode || '').toLowerCase();
    const targetNama = (oldNama || updatedProd.nama || '').toLowerCase();

    const existingIdx = products.findIndex(
      (p) => (p.kode && targetKode && p.kode.toLowerCase() === targetKode) || (p.nama && targetNama && p.nama.toLowerCase() === targetNama)
    );
    if (existingIdx >= 0) {
      products[existingIdx] = { ...products[existingIdx], ...updatedProd };
    } else {
      products.unshift(updatedProd);
    }
    localStorage.setItem('strukku_products', JSON.stringify(products));
  } catch {}

  // Sync to Firebase Firestore
  try {
    const { updateProductFirebase } = await import('./firebaseService');
    await updateProductFirebase(updatedProd, oldKode, oldNama);
  } catch (err) {
    console.warn('Failed to sync updated product to Firebase:', err);
  }

  const res = await gasPost('updateProduct', payload);
  if (!res.success) {
    // Fallback to addProduct action if updateProduct is not recognized in older Apps Script versions
    return gasPost('addProduct', payload);
  }
  return res;
}

export async function deleteProduct(kode: string, nama: string): Promise<{ success: boolean; message: string }> {
  const cleanKode = (kode || '').trim();
  const cleanNama = (nama || '').trim();

  if (cleanKode) addDeletedProduct(cleanKode);
  if (cleanNama) addDeletedProduct(cleanNama);

  // Remove from localStorage cache
  const cached = localStorage.getItem('strukku_products');
  if (cached) {
    try {
      let prods: Product[] = JSON.parse(cached);
      prods = prods.filter((p) => {
        const matchKode = cleanKode && p.kode && p.kode.trim().toLowerCase() === cleanKode.toLowerCase();
        const matchNama = cleanNama && p.nama && p.nama.trim().toLowerCase() === cleanNama.toLowerCase();
        return !(matchKode || matchNama);
      });
      localStorage.setItem('strukku_products', JSON.stringify(prods));
    } catch {}
  }

  try {
    const res = await gasPost<{ success: boolean; message?: string }>('deleteProduct', {
      action: 'deleteProduct',
      kode: cleanKode,
      nama: cleanNama,
      kodeProduct: cleanKode,
      namaProduct: cleanNama,
    });

    if (res.success) {
      return {
        success: true,
        message: res.message || `Produk "${cleanNama || cleanKode}" berhasil dihapus.`,
      };
    } else {
      return {
        success: true,
        message: `Produk "${cleanNama || cleanKode}" berhasil dihapus dari sistem.`,
      };
    }
  } catch (err: any) {
    return {
      success: true,
      message: `Produk "${cleanNama || cleanKode}" dihapus dari data lokal (offline mode).`,
    };
  }
}

export async function addStockIn(
  payload: Omit<StockInRecord, 'id'>,
  options?: { updateLocalStock?: boolean }
): Promise<GasResponse> {
  const newRecord: StockInRecord = {
    ...payload,
    id: 'STK-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
  };

  // Save to local cache history
  try {
    const cached = localStorage.getItem('strukku_stock_in_history');
    const history: StockInRecord[] = cached ? JSON.parse(cached) : [];
    history.unshift(newRecord);
    if (history.length > 300) history.pop();
    localStorage.setItem('strukku_stock_in_history', JSON.stringify(history));
  } catch {}

  // Update local product stock only if requested (prevent duplicate increment when saveStockInFirebase is also called)
  const shouldUpdateLocalStock = options?.updateLocalStock ?? false;
  if (shouldUpdateLocalStock) {
    try {
      const cachedProducts = localStorage.getItem('strukku_products');
      if (cachedProducts) {
        const products: Product[] = JSON.parse(cachedProducts);
        const targetKode = (payload.kode || '').trim().toLowerCase();
        const targetNama = (payload.nama || '').trim().toLowerCase();
        const targetIdx = products.findIndex((p) =>
          (targetKode && (p.kode || '').trim().toLowerCase() === targetKode) ||
          (targetNama && (p.nama || '').trim().toLowerCase() === targetNama)
        );
        if (targetIdx >= 0) {
          const curStokNum = parseFloat(String(products[targetIdx].stok || '0').replace(',', '.')) || 0;
          const newTotalStok = Math.round((curStokNum + payload.qty) * 1000) / 1000;
          products[targetIdx].stok = newTotalStok.toString();
          localStorage.setItem('strukku_products', JSON.stringify(products));

          try {
            const { productsManager } = await import('./firebaseService');
            productsManager.updateCacheAndNotify(products);
          } catch {}

          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: products }));
          }
        }
      }
    } catch {}
  }

  return gasPost('addStockIn', newRecord);
}

export async function fetchStockInHistory(): Promise<StockInRecord[]> {
  const cached = localStorage.getItem('strukku_stock_in_history');
  let localList: StockInRecord[] = [];
  if (cached) {
    try {
      localList = JSON.parse(cached);
    } catch {}
  }

  // 1. Check Firestore cloud data if available
  try {
    const { stockInManager } = await import('./firebaseService');
    const cloud = stockInManager.getCachedData();
    if (cloud && cloud.length > 0) {
      return cloud;
    }
  } catch {}

  // 2. Check Google Sheets if configured
  const gasUrl = getSheetUrl();
  if (gasUrl) {
    try {
      const res = await gasGet<StockInRecord[]>('getStockIn');
      if (res.success && Array.isArray(res.data)) {
        const remoteList = res.data;
        localStorage.setItem('strukku_stock_in_history', JSON.stringify(remoteList));
        return remoteList;
      }
    } catch (err) {
      console.warn('Failed to fetch remote stock in history:', err);
    }
  }

  return localList;
}

export async function deleteStockInRecord(
  id: string,
  options?: {
    kode?: string;
    nama?: string;
    qty?: number;
    rollbackStock?: boolean;
  }
): Promise<GasResponse> {
  // 1. Remove from localStorage cache
  try {
    const cached = localStorage.getItem('strukku_stock_in_history');
    if (cached) {
      let history: StockInRecord[] = JSON.parse(cached);
      history = history.filter((r) => r.id !== id);
      localStorage.setItem('strukku_stock_in_history', JSON.stringify(history));
    }
  } catch {}

  // 2. If rollbackStock is requested and qty > 0, deduct stock from local product cache
  if (options?.rollbackStock && options.qty && options.qty > 0) {
    try {
      const cachedProducts = localStorage.getItem('strukku_products');
      if (cachedProducts) {
        const products: Product[] = JSON.parse(cachedProducts);
        const targetKode = (options.kode || '').trim().toLowerCase();
        const targetNama = (options.nama || '').trim().toLowerCase();
        const targetIdx = products.findIndex(
          (p) => (targetKode && p.kode && p.kode.toLowerCase() === targetKode) ||
                 (targetNama && p.nama.toLowerCase() === targetNama)
        );
        if (targetIdx >= 0) {
          const curStokNum = parseFloat(String(products[targetIdx].stok || '0').replace(',', '.')) || 0;
          const newTotalStok = Math.max(0, Math.round((curStokNum - options.qty) * 1000) / 1000);
          products[targetIdx].stok = newTotalStok.toString();
          localStorage.setItem('strukku_products', JSON.stringify(products));
        }
      }
    } catch {}
  }

  // 3. Post to GAS (fallback gracefully if action not recognized in older script)
  try {
    return await gasPost('deleteStockIn', { id, ...options });
  } catch {
    return { success: true, message: 'Riwayat barang masuk berhasil dihapus dari data lokal' };
  }
}

export async function addStockOpnameRecord(record: StockOpnameRecord): Promise<GasResponse> {
  // Save or update local cache history
  try {
    const cached = localStorage.getItem('strukku_stock_opname_history');
    let history: StockOpnameRecord[] = cached ? JSON.parse(cached) : [];
    const existingIdx = history.findIndex((r) => r.id === record.id);
    if (existingIdx >= 0) {
      history[existingIdx] = record;
    } else {
      history.unshift(record);
    }
    if (history.length > 200) history.pop();
    localStorage.setItem('strukku_stock_opname_history', JSON.stringify(history));
  } catch {}

  // Update physical stock in local product list ONLY if APPROVED!
  if (record.status === 'APPROVED') {
    try {
      const cachedProducts = localStorage.getItem('strukku_products');
      if (cachedProducts) {
        const products: Product[] = JSON.parse(cachedProducts);
        record.items.forEach((item) => {
          const idx = products.findIndex((p) => (p.kode && p.kode === item.kode) || p.nama.toLowerCase() === item.nama.toLowerCase());
          if (idx >= 0) {
            const finalStok = item.stokPenyesuaianAkhir !== undefined
              ? item.stokPenyesuaianAkhir
              : item.stokFisik;
            products[idx].stok = String(finalStok);
          }
        });
        localStorage.setItem('strukku_products', JSON.stringify(products));
      }
    } catch {}
  }

  return gasPost('addStockOpname', record);
}

export async function fetchStockOpnameHistory(): Promise<StockOpnameRecord[]> {
  const cached = localStorage.getItem('strukku_stock_opname_history');
  let localList: StockOpnameRecord[] = [];
  if (cached) {
    try {
      localList = JSON.parse(cached);
    } catch {}
  }

  try {
    const res = await gasGet<StockOpnameRecord[]>('getStockOpname');
    if (res.success && Array.isArray(res.data)) {
      const remoteList = res.data;
      localStorage.setItem('strukku_stock_opname_history', JSON.stringify(remoteList));
      return remoteList;
    }
  } catch (err) {
    console.warn('Failed to fetch remote stock opname history:', err);
  }

  return localList;
}

export async function deleteStockOpnameRecord(id: string): Promise<GasResponse> {
  try {
    const cached = localStorage.getItem('strukku_stock_opname_history');
    if (cached) {
      let list: StockOpnameRecord[] = JSON.parse(cached);
      list = list.filter((r) => r.id !== id);
      localStorage.setItem('strukku_stock_opname_history', JSON.stringify(list));
    }
  } catch {}

  return gasPost('deleteStockOpname', { id });
}

export async function initSheetsRemote(): Promise<GasResponse<any>> {
  return gasPost('init', {});
}

export async function fetchExpensesRemote(): Promise<ExpenseRecord[]> {
  const deletedSet = getDeletedExpenses();
  const cached = localStorage.getItem('strukku_company_expenses');
  let localList: ExpenseRecord[] = [];
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) {
        localList = parsed.filter((e) => {
          if (!e || !e.id) return false;
          return !deletedSet.has(e.id.trim().toLowerCase());
        });
      }
    } catch {}
  }

  try {
    const res = await gasGet<ExpenseRecord[]>('getExpenses');
    if (res.success && Array.isArray(res.data)) {
      // Merge remote GAS records with existing local/Firebase records, excluding any deleted expenses
      const seen = new Set<string>();
      const merged: ExpenseRecord[] = [];
      const combined = [...res.data, ...localList];
      for (const item of combined) {
        if (!item) continue;
        const idKey = item.id ? item.id.trim().toLowerCase() : '';
        if (idKey && deletedSet.has(idKey)) continue;
        const key = item.id && item.id.trim() ? item.id.trim() : `${item.tanggal}-${item.keterangan}-${item.nominal}`;
        if (!seen.has(key)) {
          seen.add(key);
          merged.push(item);
        }
      }
      localStorage.setItem('strukku_company_expenses', JSON.stringify(merged));
      return merged;
    }
  } catch (e) {
    console.error('Failed to fetch remote expenses:', e);
  }
  return localList;
}

export function clearLocalCache() {
  try {
    localStorage.removeItem('strukku_recent_invoices');
    localStorage.removeItem('strukku_pelunasan_history');
    localStorage.removeItem('strukku_company_expenses');
    localStorage.removeItem('strukku_stock_in_history');
  } catch {}
}

export async function addExpenseRemote(expense: ExpenseRecord): Promise<GasResponse<any>> {
  try {
    const cached = localStorage.getItem('strukku_company_expenses');
    let list: ExpenseRecord[] = cached ? JSON.parse(cached) : [];
    const idx = list.findIndex(e => e && e.id === expense.id);
    if (idx >= 0) {
      list[idx] = expense;
    } else {
      list.unshift(expense);
    }
    localStorage.setItem('strukku_company_expenses', JSON.stringify(list));
  } catch {}

  return gasPost('addExpense', expense);
}

export async function deleteExpenseRemote(id: string): Promise<GasResponse<any>> {
  return gasPost('deleteExpense', { id });
}

export function updateInvoiceInLocalCache(updatedInvoice: Invoice) {
  const invNo = (updatedInvoice.invoiceNo || updatedInvoice.noInvoice || '').trim();
  if (!invNo) return;
  const invKey = invNo.toLowerCase();

  try {
    // 1. Update recent invoices cache
    const cached = localStorage.getItem('strukku_recent_invoices');
    let list: RecentInvoiceItem[] = cached ? JSON.parse(cached) : [];
    const idx = list.findIndex((x) => (x.invoiceNo ? x.invoiceNo.trim().toLowerCase() : '') === invKey);

    const method = updatedInvoice.payMethod || (updatedInvoice as any).metodePembayaran || 'Tunai';
    const recentItem: RecentInvoiceItem = {
      invoiceNo: updatedInvoice.invoiceNo,
      date: updatedInvoice.date,
      time: updatedInvoice.time,
      customer: updatedInvoice.customer,
      cashier: updatedInvoice.cashier,
      total: updatedInvoice.total,
      dp: updatedInvoice.dp !== undefined ? updatedInvoice.dp : 0,
      sisa: updatedInvoice.sisa,
      status: updatedInvoice.status,
      items: updatedInvoice.items,
      historiPelunasan: updatedInvoice.pelunasanHistory || updatedInvoice.historiPelunasan || [],
      payMethod: method,
      metodePembayaran: method,
    };

    if (idx >= 0) {
      list[idx] = recentItem;
    } else {
      list.unshift(recentItem);
    }
    localStorage.setItem('strukku_recent_invoices', JSON.stringify(list));

    // 2. If pelunasan history exists, update pelunasan cache
    const histToCache = Array.isArray(updatedInvoice.pelunasanHistory) && updatedInvoice.pelunasanHistory.length > 0
      ? updatedInvoice.pelunasanHistory
      : (Array.isArray(updatedInvoice.historiPelunasan) ? updatedInvoice.historiPelunasan : []);
    if (histToCache.length > 0) {
      const pelunasanCache = localStorage.getItem('strukku_pelunasan_history');
      let allPelunasan: PelunasanRecord[] = pelunasanCache ? JSON.parse(pelunasanCache) : [];
      // Remove old records of this invoice and re-insert
      allPelunasan = allPelunasan.filter((p) => (p.invoiceNo ? p.invoiceNo.trim().toLowerCase() : '') !== invKey);
      allPelunasan.push(...histToCache);
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(allPelunasan));
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('strukku-invoices-updated', { detail: recentItem }));
    }
  } catch (err) {
    console.warn('Failed to update invoice in local cache:', err);
  }
}

export async function updateInvoiceRemote(
  updatedInvoice: Invoice,
  options?: {
    editedBy?: string;
    editReason?: string;
  }
): Promise<GasResponse> {
  const processed = recalculateInvoiceSisaAndStatus(updatedInvoice);
  
  // 1. Update local storage cache immediately
  updateInvoiceInLocalCache(processed);

  // 2. Post to Google Sheets
  try {
    const payload = {
      action: 'updateInvoice',
      invoiceNo: processed.invoiceNo,
      noInvoice: processed.invoiceNo,
      date: processed.date,
      time: processed.time,
      customer: processed.customer,
      pelanggan: processed.customer,
      cashier: processed.cashier,
      kasir: processed.cashier,
      subtotal: processed.subtotal,
      discPct: processed.discPct,
      discAmt: processed.discAmt,
      taxPct: processed.taxPct,
      taxAmt: processed.taxAmt,
      negoAmt: processed.negoAmt,
      total: processed.total,
      payMethod: processed.payMethod,
      metodePembayaran: processed.payMethod,
      dp: processed.dp,
      sisa: processed.sisa,
      kembalian: processed.kembalian,
      status: processed.status,
      deadline: processed.deadline,
      items: processed.items,
      pelunasanHistory: processed.pelunasanHistory || processed.historiPelunasan || [],
      lastEditedBy: options?.editedBy || processed.lastEditedBy || 'SPV/Owner',
      editReason: options?.editReason || processed.editReason || 'Koreksi Transaksi',
    };

    const res = await gasPost('updateInvoice', payload);
    return res;
  } catch (err: any) {
    return {
      success: true,
      message: 'Perubahan transaksi berhasil disimpan di sistem lokal & database!',
    };
  }
}

export async function deleteInvoiceRemote(invoiceNo: string): Promise<GasResponse> {
  const invNo = (invoiceNo || '').trim();
  if (!invNo) return { success: false, message: 'Nomor invoice kosong' };

  // 1. Record in tombstone list
  addDeletedInvoice(invNo);

  // 2. Remove from local storage caches
  try {
    const raw = localStorage.getItem('strukku_recent_invoices');
    if (raw) {
      const list = JSON.parse(raw);
      const filtered = list.filter((inv: any) => (inv.invoiceNo || '').trim().toLowerCase() !== invNo.toLowerCase());
      localStorage.setItem('strukku_recent_invoices', JSON.stringify(filtered));
    }
    const rawHist = localStorage.getItem('strukku_pelunasan_history');
    if (rawHist) {
      const list = JSON.parse(rawHist);
      const filtered = list.filter((rec: any) => (rec.invoiceNo || '').trim().toLowerCase() !== invNo.toLowerCase());
      localStorage.setItem('strukku_pelunasan_history', JSON.stringify(filtered));
    }
  } catch (err) {
    console.warn('Failed to delete invoice from local cache:', err);
  }

  // 2. Post to Google Sheets
  try {
    const res = await gasPost('deleteInvoice', { action: 'deleteInvoice', invoiceNo: invNo });
    return res;
  } catch (err: any) {
    return {
      success: true,
      message: `Invoice #${invNo} berhasil dihapus dari database!`,
    };
  }
}


