import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  documentId,
  writeBatch,
  serverTimestamp
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { 
  getDeletedCustomers, 
  getDeletedInvoices, 
  addDeletedInvoice, 
  getDeletedExpenses,
  addDeletedExpense,
  removeDeletedExpense,
  recalculateInvoiceSisaAndStatus, 
  isProductDeleted, 
  addDeletedProduct, 
  removeDeletedProduct,
  getDeletedProducts,
  mergePelunasanHistories,
  getPelunasanHistory,
  updateInvoiceInLocalCache,
  getSheetUrl
} from './gasService';
import {
  recordFirestoreRead,
  recordFirestoreWrite,
  recordFirestoreDelete,
  recordQuotaSavings,
  markFirestoreQuotaExceeded,
  isFirestoreQuotaExceeded as isQuotaExceededFromService,
  resetFirestoreDailyMetrics,
} from './firestoreQuotaService';
import { 
  Product, 
  Customer, 
  StoreSettings, 
  Invoice, 
  InvoiceItem, 
  KasirUser, 
  StockInRecord, 
  StockOpnameRecord, 
  ExpenseRecord, 
  PelunasanRecord, 
  Vendor 
} from '../types';
import { compareInvoicesDesc } from '../utils/formatters';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function isFirestoreQuotaExceeded(): boolean {
  return isQuotaExceededFromService();
}

export function resetFirestoreQuotaSession(): void {
  resetFirestoreDailyMetrics();
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  const isDocSizeError = errMsg.toLowerCase().includes('maximum size') || errMsg.toLowerCase().includes('too large') || errMsg.toLowerCase().includes('1048576');
  const isQuota = !isDocSizeError && (errMsg.toLowerCase().includes('quota exceeded') || errMsg.toLowerCase().includes('quota limit exceeded') || errMsg.toLowerCase().includes('resource-exhausted'));
  if (isQuota) {
    markFirestoreQuotaExceeded(errMsg);
  }

  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
      tenantId: auth?.currentUser?.tenantId,
      providerInfo: auth?.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  if (isQuota) {
    console.warn(`Firestore Free Tier Quota Limit Exceeded on '${path}'. Using offline cache fallback.`);
  } else {
    console.error('Firestore Error: ', JSON.stringify(errInfo));
  }
  return errInfo;
}

/**
 * Shared Subscription Coordinator (Singleton Multicast Pattern)
 * 
 * Prevents Quota Exhaustion by ensuring:
 * 1. Only ONE active Firestore onSnapshot listener exists per collection across the whole app.
 * 2. When components (App, DashboardView, LaporanView, Modals) mount/unmount, they share the same listener.
 * 3. Immediately serves in-memory and local cache (0 Firestore reads, zero latency).
 * 4. Navigating between views does not disconnect and re-fetch all documents repeatedly.
 */
export class SharedSubscriptionManager<T> {
  private subscribers = new Set<(data: T) => void>();
  public latestData: T | null = null;
  private unsubFirestore: (() => void) | null = null;
  private startListener: (onUpdate: (data: T) => void, onError: (err: any) => void) => () => void;
  private readLocalFallback: () => T | null;

  constructor(
    startListener: (onUpdate: (data: T) => void, onError: (err: any) => void) => () => void,
    readLocalFallback: () => T | null
  ) {
    this.startListener = startListener;
    this.readLocalFallback = readLocalFallback;
    const initial = this.readLocalFallback();
    if (initial !== null) {
      this.latestData = initial;
    }
  }

  public getCachedData(): T | null {
    return this.latestData !== null ? this.latestData : this.readLocalFallback();
  }

  public updateCacheAndNotify(data: T): void {
    this.latestData = data;
    this.subscribers.forEach((cb) => {
      try {
        cb(data);
      } catch (e) {
        console.error('Error invoking subscriber:', e);
      }
    });
  }

  public subscribe(callback: (data: T) => void): () => void {
    // 1. Immediately provide cached data (0 Firestore reads, zero latency)
    const current = this.getCachedData();
    if (current !== null) {
      try {
        callback(current);
      } catch (e) {
        console.error('Error in subscriber callback with cached data:', e);
      }
    }

    this.subscribers.add(callback);

    // 2. If quota is exceeded, do not start new Firestore listener
    if (isFirestoreQuotaExceeded()) {
      return () => {
        this.subscribers.delete(callback);
      };
    }

    // 3. Start Firestore onSnapshot listener ONCE across the whole application
    if (!this.unsubFirestore) {
      try {
        this.unsubFirestore = this.startListener(
          (data: T) => {
            this.latestData = data;
            this.subscribers.forEach((cb) => {
              try {
                cb(data);
              } catch (e) {
                console.error('Error invoking subscriber:', e);
              }
            });
          },
          (err: any) => {
            const fallback = this.readLocalFallback();
            if (fallback !== null) {
              this.latestData = fallback;
              this.subscribers.forEach((cb) => {
                try {
                  cb(fallback);
                } catch {}
              });
            }
          }
        );
      } catch (err) {
        console.warn('Failed to start Firestore subscription listener:', err);
      }
    }

    // 4. Return unsubscriber
    return () => {
      this.subscribers.delete(callback);
    };
  }
}

// 1. Products Manager
export const productsManager = new SharedSubscriptionManager<Product[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'products');
    return onSnapshot(colRef, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('products', changesCount, 'onSnapshot');
      }
      const list: Product[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const kode = data.kode || docSnap.id;
        const nama = data.nama || '';
        if (!isProductDeleted(kode, nama)) {
          list.push({
            kode,
            nama,
            harga: Number(data.harga || 0),
            kategori: data.kategori || 'Lainnya',
            stok: data.stok !== undefined && data.stok !== null ? String(data.stok) : '',
            satuan: data.satuan || 'pcs',
            tipeHarga: data.tipeHarga || 'fix',
          });
        }
      });
      if (list.length > 0) {
        localStorage.setItem('strukku_products', JSON.stringify(list));
      }
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'products');
      onError(err);
    });
  },
  () => {
    try {
      const cached = localStorage.getItem('strukku_products');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeProducts(callback: (products: Product[]) => void) {
  return productsManager.subscribe(callback);
}

// 2. Customers Manager
export const customersManager = new SharedSubscriptionManager<Customer[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'customers');
    return onSnapshot(colRef, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('customers', changesCount, 'onSnapshot');
      }
      const list: Customer[] = [];
      const deletedNames = getDeletedCustomers();
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const name = data.nama || docSnap.id;
        if (name && !deletedNames.has(name.trim().toLowerCase())) {
          list.push({
            nama: name,
            kelas: data.kelas || 'Reguler',
            diskon: Number(data.diskon || 0),
            telepon: data.telepon || '',
            catatan: data.catatan || '',
            alamat: data.alamat || '',
          });
        }
      });
      localStorage.setItem('strukku_customers', JSON.stringify(list));
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'customers');
      onError(err);
    });
  },
  () => {
    try {
      const cached = localStorage.getItem('strukku_customers');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeCustomers(callback: (customers: Customer[]) => void) {
  return customersManager.subscribe(callback);
}

// 3. Kasir Users Manager
export const kasirUsersManager = new SharedSubscriptionManager<KasirUser[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'kasirUsers');
    return onSnapshot(colRef, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('kasirUsers', changesCount, 'onSnapshot');
      }
      const list: KasirUser[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({
          nama: data.nama || docSnap.id,
          password: data.password || 'ervo123',
        });
      });
      if (list.length > 0) {
        localStorage.setItem('strukku_kasir_users', JSON.stringify(list));
        localStorage.setItem('strukku_kasir_list', JSON.stringify(list.map((u) => u.nama)));
      }
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'kasirUsers');
      onError(err);
    });
  },
  () => {
    try {
      const cached = localStorage.getItem('strukku_kasir_users');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeKasirUsers(callback: (users: KasirUser[]) => void) {
  return kasirUsersManager.subscribe(callback);
}

// 4. Store Settings Manager
export const settingsManager = new SharedSubscriptionManager<Partial<StoreSettings>>(
  (onUpdate, onError) => {
    const docRef = doc(db, 'settings', 'store');
    return onSnapshot(docRef, (docSnap) => {
      recordFirestoreRead('settings/store', 1, 'onSnapshot');
      if (docSnap.exists()) {
        const data = docSnap.data();
        const cfg: Partial<StoreSettings> = {
          name: data.name,
          address: data.address,
          phone: data.phone,
          footer: data.footer,
          prefixInvoice: data.prefixInvoice,
          rekening: data.rekening,
          autoLogoutMinutes: data.autoLogoutMinutes,
          sheetUrl: data.sheetUrl,
        };
        if (data.sheetUrl && typeof data.sheetUrl === 'string') {
          const trimmedUrl = data.sheetUrl.trim();
          if (trimmedUrl) {
            localStorage.setItem('strukku_sheet_url', trimmedUrl);
          }
        }
        localStorage.setItem('strukku_sheet_settings', JSON.stringify(cfg));
        onUpdate(cfg);
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'settings/store');
      onError(err);
    });
  },
  () => {
    try {
      const cached = localStorage.getItem('strukku_sheet_settings');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeSettings(callback: (settings: Partial<StoreSettings>) => void) {
  return settingsManager.subscribe(callback);
}

export function readInvoicesLocalFallback(): Invoice[] {
  try {
    const recRaw = localStorage.getItem('strukku_recent_invoices');
    if (recRaw) {
      const parsed = JSON.parse(recRaw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const deletedSet = getDeletedInvoices();
        const invList: Invoice[] = parsed
          .filter((it: any) => {
            const no = (it.invoiceNo || it.noInvoice || '').trim().toLowerCase();
            return no && !deletedSet.has(no);
          })
          .map((it: any) => ({
            invoiceNo: it.invoiceNo || it.noInvoice,
            noInvoice: it.invoiceNo || it.noInvoice,
            date: it.date || '',
            time: it.time || '',
            cashier: it.cashier || 'Admin',
            customer: it.customer || 'Umum',
            payMethod: it.payMethod || it.metodePembayaran || 'Tunai',
            subtotal: Number(it.subtotal || it.total || 0),
            discPct: Number(it.discPct || 0),
            discAmt: Number(it.discAmt || 0),
            taxPct: Number(it.taxPct || 0),
            taxAmt: Number(it.taxAmt || 0),
            negoAmt: Number(it.negoAmt || 0),
            total: Number(it.total || 0),
            dp: Number(it.dp || 0),
            sisa: Number(it.sisa || 0),
            kembalian: Number(it.kembalian || 0),
            deadline: it.deadline || '',
            status: it.status || 'LUNAS',
            items: Array.isArray(it.items) ? it.items : [],
            pelunasanHistory: Array.isArray(it.pelunasanHistory) ? it.pelunasanHistory : (Array.isArray(it.historiPelunasan) ? it.historiPelunasan : []),
          }));
        return invList;
      }
    }
  } catch {}
  return [];
}

// 5. Invoices Manager (Shared across App, Dashboard, Laporan, Pelunasan, Reprint)
export const invoicesManager = new SharedSubscriptionManager<Invoice[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'invoices');
    // Listen to collection in real-time across all devices without restrictive limits
    return onSnapshot(colRef, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('invoices', changesCount, 'onSnapshot');
      }
      const deletedSet = getDeletedInvoices();
      
      // Merge with previously cached local invoices so that earlier records and offline history remain visible
      const mergedMap = new Map<string, Invoice>();
      const localCached = readInvoicesLocalFallback();
      localCached.forEach((inv) => {
        const key = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
        if (key && !deletedSet.has(key)) {
          mergedMap.set(key, inv);
        }
      });

      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        const invNo = d.invoiceNo || d.noInvoice || docSnap.id;
        if (!invNo || deletedSet.has(String(invNo).trim().toLowerCase())) return;

        const historyArr = Array.isArray(d.pelunasanHistory) && d.pelunasanHistory.length > 0
          ? d.pelunasanHistory
          : (Array.isArray(d.historiPelunasan) ? d.historiPelunasan : []);

        const rawInv: Invoice = {
          invoiceNo: invNo,
          noInvoice: invNo,
          date: d.date || d.tanggal || '',
          time: d.time || d.jam || '',
          cashier: d.cashier || d.kasir || 'Admin',
          customer: d.customer || d.pelanggan || 'Umum',
          customerPhone: d.customerPhone || d.telepon || d.phone || '',
          customerAddress: d.customerAddress || d.alamat || '',
          payMethod: d.payMethod || d.metodePembayaran || 'Tunai',
          subtotal: Number(d.subtotal || 0),
          discPct: Number(d.discPct || d.diskonPct || 0),
          discAmt: Number(d.discAmt || d.diskonNominal || 0),
          taxPct: Number(d.taxPct || d.pajakPct || 0),
          taxAmt: Number(d.taxAmt || d.pajakNominal || 0),
          negoAmt: Number(d.negoAmt || d.negoNominal || 0),
          total: Number(d.total || 0),
          dp: Number(d.dp || d.bayarDp || 0),
          sisa: Number(d.sisa || d.sisaPiutang || 0),
          kembalian: Number(d.kembalian || 0),
          deadline: d.deadline || '',
          status: d.status || (Number(d.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
          items: Array.isArray(d.items) ? d.items : [],
          pelunasanHistory: historyArr,
          historiPelunasan: historyArr,
          lastEditedBy: d.lastEditedBy,
          lastEditedAt: d.lastEditedAt,
          editReason: d.editReason,
          auditLogs: Array.isArray(d.auditLogs) ? d.auditLogs : [],
        };
        const processed = recalculateInvoiceSisaAndStatus(rawInv);
        mergedMap.set(String(invNo).trim().toLowerCase(), processed);
      });

      const list = Array.from(mergedMap.values());
      // Sort descending by invoiceNo using numeric-aware natural collation (newest first)
      list.sort(compareInvoicesDesc);

      // Update local cache so all views get instant real-time data
      const recentFormat = list.map((inv) => {
        const method = inv.payMethod || (inv as any).metodePembayaran || 'Tunai';
        const historyArr = Array.isArray(inv.pelunasanHistory) && inv.pelunasanHistory.length > 0
          ? inv.pelunasanHistory
          : (Array.isArray((inv as any).historiPelunasan) ? (inv as any).historiPelunasan : []);
        return {
          invoiceNo: inv.invoiceNo,
          date: inv.date,
          time: inv.time,
          customer: inv.customer,
          cashier: inv.cashier,
          payMethod: method,
          metodePembayaran: method,
          total: inv.total,
          dp: inv.dp,
          sisa: inv.sisa,
          status: inv.status,
          items: inv.items,
          pelunasanHistory: historyArr,
          historiPelunasan: historyArr,
        };
      });
      localStorage.setItem('strukku_recent_invoices', JSON.stringify(recentFormat));

      const allPelunasan: PelunasanRecord[] = [];
      list.forEach((inv) => {
        const hist = Array.isArray(inv.pelunasanHistory) ? inv.pelunasanHistory : (Array.isArray((inv as any).historiPelunasan) ? (inv as any).historiPelunasan : []);
        if (hist.length > 0) {
          allPelunasan.push(...hist);
        }
      });
      if (allPelunasan.length > 0) {
        const existingLocal = getPelunasanHistory('');
        const mergedAll = mergePelunasanHistories(existingLocal, allPelunasan);
        localStorage.setItem('strukku_pelunasan_history', JSON.stringify(mergedAll));
      }

      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'invoices');
      onError(err);
    });
  },
  readInvoicesLocalFallback
);

export function subscribeInvoices(callback: (invoices: Invoice[]) => void) {
  const unsubManager = invoicesManager.subscribe(callback);

  const handleUpdateEvent = () => {
    const list = invoicesManager.getCachedData() || readInvoicesLocalFallback();
    if (list && list.length > 0) callback(list);
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('strukku-invoices-updated', handleUpdateEvent);
    window.addEventListener('strukku-backup-restored', handleUpdateEvent);
  }

  return () => {
    unsubManager();
    if (typeof window !== 'undefined') {
      window.removeEventListener('strukku-invoices-updated', handleUpdateEvent);
      window.removeEventListener('strukku-backup-restored', handleUpdateEvent);
    }
  };
}

// 6. Deleted Invoices Manager
export const deletedInvoicesManager = new SharedSubscriptionManager<string[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'deletedInvoices');
    const q = query(colRef);
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('deletedInvoices', changesCount, 'onSnapshot');
      }
      const list: string[] = [];
      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        const invNo = d.invoiceNo || docSnap.id;
        if (invNo) {
          list.push(String(invNo).trim().toLowerCase());
        }
      });
      const activeDelSet = new Set(list);
      localStorage.setItem('strukku_deleted_invoices', JSON.stringify(Array.from(activeDelSet)));

      // Purge local storage of deleted invoices
      try {
        const recRaw = localStorage.getItem('strukku_recent_invoices');
        if (recRaw) {
          const parsed = JSON.parse(recRaw);
          if (Array.isArray(parsed)) {
            const filtered = parsed.filter((it: any) => it.invoiceNo && !activeDelSet.has(String(it.invoiceNo).trim().toLowerCase()));
            localStorage.setItem('strukku_recent_invoices', JSON.stringify(filtered));
          }
        }
      } catch {}

      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'deletedInvoices');
      onError(err);
    });
  },
  () => {
    const deleted = getDeletedInvoices();
    return Array.from(deleted);
  }
);

export function subscribeDeletedInvoices(callback?: (deletedList: string[]) => void) {
  if (!callback) return () => {};
  return deletedInvoicesManager.subscribe(callback);
}

// Helper to read local expenses fallback safely
export function readExpensesLocalFallback(): ExpenseRecord[] {
  try {
    let expRaw = localStorage.getItem('strukku_company_expenses');
    if (!expRaw || expRaw === '[]') {
      const alt = localStorage.getItem('strukku_expenses');
      if (alt && alt !== '[]') {
        expRaw = alt;
      }
    }
    if (expRaw) {
      const parsed = JSON.parse(expRaw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const deletedSet = getDeletedExpenses();
        const nonDeleted = parsed.filter((it: ExpenseRecord) => {
          if (!it || !it.id) return false;
          return !deletedSet.has(it.id.trim().toLowerCase());
        });
        // If deletedSet accidentally filtered all records due to stale tombstones, preserve the dataset
        return nonDeleted.length > 0 ? nonDeleted : parsed;
      }
    }
  } catch {}
  return [];
}

// 7. Expenses Manager
export const expensesManager = new SharedSubscriptionManager<ExpenseRecord[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'expenses');
    // Limit to 200 items to protect Spark daily quota, merging with local storage for full history
    const q = query(colRef, limit(200));
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('expenses', changesCount, 'onSnapshot');
      }

      const deletedSet = getDeletedExpenses();
      const mergedMap = new Map<string, ExpenseRecord>();

      // Merge local cached expenses, strictly excluding any verified deleted tombstones
      const localCached = readExpensesLocalFallback();
      localCached.forEach((exp) => {
        if (!exp || !exp.id) return;
        const key = exp.id.trim().toLowerCase();
        if (!deletedSet.has(key)) {
          mergedMap.set(key, exp);
        }
      });

      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        const rawId = d.id || docSnap.id;
        const key = String(rawId || '').trim().toLowerCase();
        if (key && !deletedSet.has(key)) {
          const item: ExpenseRecord = {
            id: rawId,
            tanggal: d.tanggal || '',
            kategori: d.kategori || 'Operasional',
            keterangan: d.keterangan || '',
            nominal: Number(d.nominal || 0),
            pj: d.pj || 'Admin',
            buktiRef: d.buktiRef,
          };
          mergedMap.set(key, item);
        }
      });

      const unique = Array.from(mergedMap.values());
      unique.sort((a, b) => b.tanggal.localeCompare(a.tanggal));
      localStorage.setItem('strukku_company_expenses', JSON.stringify(unique));
      localStorage.setItem('strukku_expenses', JSON.stringify(unique));
      onUpdate(unique);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'expenses');
      onError(err);
    });
  },
  () => {
    const deletedSet = getDeletedExpenses();
    return readExpensesLocalFallback().filter(
      (e) => e && e.id && !deletedSet.has(e.id.trim().toLowerCase())
    );
  }
);

export function subscribeExpenses(callback: (expenses: ExpenseRecord[]) => void) {
  return expensesManager.subscribe(callback);
}

// 7b. Deleted Expenses Manager (Real-time synchronization across devices)
export const deletedExpensesManager = new SharedSubscriptionManager<string[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'deletedExpenses');
    const q = query(colRef);
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('deletedExpenses', changesCount, 'onSnapshot');
      }
      const list: string[] = [];
      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        const expId = d.id || docSnap.id;
        if (expId) {
          const clean = String(expId).trim().toLowerCase();
          list.push(clean);
        }
      });
      const activeDelSet = new Set(list);
      localStorage.setItem('strukku_deleted_expenses', JSON.stringify(Array.from(activeDelSet)));

      // Instantly purge local storage of genuine deleted expenses across all tabs & devices
      try {
        const expRaw = localStorage.getItem('strukku_company_expenses') || localStorage.getItem('strukku_expenses');
        if (expRaw) {
          const parsed = JSON.parse(expRaw);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const filtered = parsed.filter((it: ExpenseRecord) => {
              if (!it || !it.id) return false;
              return !activeDelSet.has(it.id.trim().toLowerCase());
            });
            if (filtered.length !== parsed.length) {
              localStorage.setItem('strukku_company_expenses', JSON.stringify(filtered));
              localStorage.setItem('strukku_expenses', JSON.stringify(filtered));
              expensesManager.updateCacheAndNotify(filtered);
            }
          }
        }
      } catch {}

      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'deletedExpenses');
      onError(err);
    });
  },
  () => {
    const deleted = getDeletedExpenses();
    return Array.from(deleted);
  }
);

export function subscribeDeletedExpenses(callback?: (deletedList: string[]) => void) {
  if (!callback) return () => {};
  return deletedExpensesManager.subscribe(callback);
}

// Single Action Helper Functions

export async function saveProductFirebase(product: Product): Promise<void> {
  const cleanKode = (product.kode || '').trim();
  const cleanNama = (product.nama || '').trim();
  if (cleanKode) removeDeletedProduct(cleanKode);
  if (cleanNama) removeDeletedProduct(cleanNama);

  const docId = cleanKode || `PROD-${Date.now()}`;
  const stokStr = product.stok !== undefined && product.stok !== null ? String(product.stok) : '0';

  const productPayload: Product = {
    ...product,
    kode: cleanKode || docId,
    nama: cleanNama,
    harga: Number(product.harga || 0),
    kategori: product.kategori || 'Lainnya',
    satuan: product.satuan || 'pcs',
    stok: stokStr,
    tipeHarga: product.tipeHarga || 'fix',
    pricingScheme: product.pricingScheme || 'meter_fix',
  };

  try {
    const cachedProducts = productsManager.getCachedData() || [];
    let prods: Product[] = [...cachedProducts];
    const idx = prods.findIndex(
      (p) =>
        (p.kode && cleanKode && p.kode.trim().toLowerCase() === cleanKode.toLowerCase()) ||
        (p.nama && cleanNama && p.nama.trim().toLowerCase() === cleanNama.toLowerCase())
    );
    if (idx >= 0) {
      prods[idx] = productPayload;
    } else {
      prods.unshift(productPayload);
    }
    localStorage.setItem('strukku_products', JSON.stringify(prods));
    productsManager.updateCacheAndNotify(prods);
  } catch {}

  await setDoc(doc(db, 'products', docId), {
    ...productPayload,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('products', 1, 'setDoc');
}

export async function updateProductFirebase(
  product: Product,
  oldKode?: string,
  oldNama?: string
): Promise<void> {
  const cleanKode = (product.kode || '').trim();
  const cleanOldKode = (oldKode || '').trim();
  const cleanOldNama = (oldNama || '').trim();
  const cleanNama = (product.nama || '').trim();

  if (cleanKode) removeDeletedProduct(cleanKode);
  if (cleanNama) removeDeletedProduct(cleanNama);

  const stokStr = product.stok !== undefined && product.stok !== null ? String(product.stok) : '0';

  const updatedItem: Product = {
    ...product,
    kode: cleanKode,
    nama: cleanNama,
    harga: Number(product.harga || 0),
    kategori: product.kategori || 'Lainnya',
    satuan: product.satuan || 'pcs',
    stok: stokStr,
    tipeHarga: product.tipeHarga || 'fix',
    pricingScheme: product.pricingScheme || 'meter_fix',
  };

  // 1. Instantly update in-memory cache and localStorage
  try {
    const cachedProducts = productsManager.getCachedData() || [];
    let prods: Product[] = [...cachedProducts];
    const idx = prods.findIndex(
      (p) =>
        (cleanOldKode && p.kode && p.kode.trim().toLowerCase() === cleanOldKode.toLowerCase()) ||
        (cleanOldNama && p.nama && p.nama.trim().toLowerCase() === cleanOldNama.toLowerCase()) ||
        (p.kode && cleanKode && p.kode.trim().toLowerCase() === cleanKode.toLowerCase())
    );
    if (idx >= 0) {
      prods[idx] = updatedItem;
    } else {
      prods.unshift(updatedItem);
    }
    localStorage.setItem('strukku_products', JSON.stringify(prods));
    productsManager.updateCacheAndNotify(prods);
  } catch (err) {
    console.warn('Local product cache update error:', err);
  }

  // 2. If product kode was modified, delete the old document in Firestore
  if (cleanOldKode && cleanOldKode !== cleanKode) {
    try {
      await deleteDoc(doc(db, 'products', cleanOldKode));
      recordFirestoreDelete('products', 1, 'deleteDoc');
    } catch (e) {
      console.warn('Error deleting old product document in Firestore:', e);
    }
  }

  // 3. Persist updated product with new stock to Firestore
  try {
    await setDoc(doc(db, 'products', cleanKode), {
      ...updatedItem,
      updatedAt: serverTimestamp(),
    }, { merge: true });
    recordFirestoreWrite('products', 1, 'setDoc');
  } catch (err) {
    console.error('Firestore setDoc error in updateProductFirebase:', err);
    throw err;
  }
}

export async function deleteProductFirebase(kode: string, nama?: string): Promise<void> {
  const cleanKode = (kode || '').trim();
  const cleanNama = (nama || '').trim();
  if (cleanKode) addDeletedProduct(cleanKode);
  if (cleanNama) addDeletedProduct(cleanNama);

  if (cleanKode) {
    try {
      await deleteDoc(doc(db, 'products', cleanKode));
      recordFirestoreDelete('products', 1, 'deleteDoc');
    } catch (err) {
      console.warn('Firestore deleteProduct error by kode:', err);
    }
  }

  // Also tombstone in deletedProducts collection for multi-device sync
  const tombstoneId = (cleanKode || cleanNama).toLowerCase().replace(/[^a-z0-9_-]/g, '_');
  if (tombstoneId) {
    try {
      await setDoc(doc(db, 'deletedProducts', tombstoneId), {
        kode: cleanKode,
        nama: cleanNama,
        deletedAt: serverTimestamp(),
      }, { merge: true });
      recordFirestoreWrite('deletedProducts', 1, 'setDoc');
    } catch (err) {
      console.warn('Firestore deletedProducts setDoc error:', err);
    }
  }
}

// 8. Deleted Products Manager
export const deletedProductsManager = new SharedSubscriptionManager<{ kode?: string; nama?: string }[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'deletedProducts');
    const q = query(colRef);
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('deletedProducts', changesCount, 'onSnapshot');
      }
      const list: { kode?: string; nama?: string }[] = [];
      const activeDel = new Set<string>();
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.kode) activeDel.add(String(data.kode).trim().toLowerCase());
        if (data.nama) activeDel.add(String(data.nama).trim().toLowerCase());
        list.push({ kode: data.kode, nama: data.nama });
      });
      localStorage.setItem('strukku_deleted_products', JSON.stringify(Array.from(activeDel)));
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'deletedProducts');
      onError(err);
    });
  },
  () => {
    const list: { kode?: string; nama?: string }[] = [];
    const delProds = getDeletedProducts();
    delProds.forEach((v) => list.push({ kode: v, nama: v }));
    return list;
  }
);

export function subscribeDeletedProducts(callback: (deletedList: { kode?: string; nama?: string }[]) => void) {
  return deletedProductsManager.subscribe(callback);
}

export async function saveCustomerFirebase(customer: Customer): Promise<void> {
  const docId = customer.nama.trim() || `CUST-${Date.now()}`;
  await setDoc(doc(db, 'customers', docId), {
    ...customer,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('customers', 1, 'setDoc');
}

export async function deleteCustomerFirebase(nama: string): Promise<void> {
  await deleteDoc(doc(db, 'customers', nama.trim()));
  recordFirestoreDelete('customers', 1, 'deleteDoc');
}

export async function saveKasirUserFirebase(user: KasirUser): Promise<void> {
  const docId = user.nama.trim();
  await setDoc(doc(db, 'kasirUsers', docId), {
    ...user,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('kasirUsers', 1, 'setDoc');
}

export async function saveSettingsFirebase(settings: Partial<StoreSettings>): Promise<void> {
  const currentSheetUrl = settings.sheetUrl !== undefined ? settings.sheetUrl : getSheetUrl();
  await setDoc(doc(db, 'settings', 'store'), {
    ...settings,
    sheetUrl: currentSheetUrl,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('settings/store', 1, 'setDoc');
}

// Debounced helper for settings modifications in UI to eliminate rapid write bursts
let settingsDebounceTimer: any = null;
let pendingSettingsData: Partial<StoreSettings> = {};

export function saveSettingsFirebaseDebounced(settings: Partial<StoreSettings>, delayMs = 1500): Promise<void> {
  pendingSettingsData = { ...pendingSettingsData, ...settings };
  if (settingsDebounceTimer) {
    clearTimeout(settingsDebounceTimer);
    recordQuotaSavings('write', 1, 'Debounced store settings burst');
  }

  return new Promise((resolve, reject) => {
    settingsDebounceTimer = setTimeout(async () => {
      settingsDebounceTimer = null;
      const dataToSave = { ...pendingSettingsData };
      pendingSettingsData = {};
      try {
        await saveSettingsFirebase(dataToSave);
        resolve();
      } catch (err) {
        reject(err);
      }
    }, delayMs);
  });
}

const PENDING_CLOUD_SYNC_KEY = 'strukku_pending_cloud_sync_invoices';

export function getPendingCloudSyncInvoices(): string[] {
  try {
    const raw = localStorage.getItem(PENDING_CLOUD_SYNC_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addPendingCloudSyncInvoice(invoiceNo: string): void {
  try {
    const clean = (invoiceNo || '').trim();
    if (!clean) return;
    const current = getPendingCloudSyncInvoices();
    if (!current.some((id) => id.toLowerCase() === clean.toLowerCase())) {
      current.push(clean);
      localStorage.setItem(PENDING_CLOUD_SYNC_KEY, JSON.stringify(current));
    }
  } catch {}
}

export function removePendingCloudSyncInvoice(invoiceNo: string): void {
  try {
    const clean = (invoiceNo || '').trim();
    if (!clean) return;
    const current = getPendingCloudSyncInvoices();
    const filtered = current.filter((id) => id.toLowerCase() !== clean.toLowerCase());
    localStorage.setItem(PENDING_CLOUD_SYNC_KEY, JSON.stringify(filtered));
  } catch {}
}

export async function saveInvoiceFirebase(invoice: Invoice): Promise<void> {
  const invNo = (invoice.invoiceNo || invoice.noInvoice || '').trim();
  if (!invNo) return;

  const historyArr = Array.isArray(invoice.pelunasanHistory) && invoice.pelunasanHistory.length > 0
    ? invoice.pelunasanHistory
    : (Array.isArray(invoice.historiPelunasan) ? invoice.historiPelunasan : []);

  const processed = recalculateInvoiceSisaAndStatus({
    ...invoice,
    invoiceNo: invNo,
    noInvoice: invNo,
    pelunasanHistory: historyArr,
    historiPelunasan: historyArr,
  });

  // Check quota state upfront; if exceeded, queue invoice for auto re-sync
  if (isFirestoreQuotaExceeded()) {
    addPendingCloudSyncInvoice(invNo);
  } else {
    try {
      await setDoc(doc(db, 'invoices', invNo), {
        ...processed,
        pelunasanHistory: processed.pelunasanHistory || historyArr,
        historiPelunasan: processed.historiPelunasan || historyArr,
        updatedAt: serverTimestamp(),
      }, { merge: true });
      recordFirestoreWrite('invoices', 1, 'setDoc');
      removePendingCloudSyncInvoice(invNo);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, 'invoices');
      addPendingCloudSyncInvoice(invNo);
    }
  }

  // Immediately update local storage and notify listeners
  updateInvoiceInLocalCache(processed as Invoice);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('strukku-invoices-updated', { detail: processed }));
  }

  // Update stock for products automatically using in-memory cache lookup (0 network reads!)
  // Batch commitment remains active and normal as primary stock management mechanism
  if (invoice.items && invoice.items.length > 0 && !isFirestoreQuotaExceeded()) {
    const batch = writeBatch(db);
    let batchUpdates = 0;
    const cachedProducts = productsManager.getCachedData() || [];
    const prodMap = new Map(cachedProducts.map((p) => [(p.kode || '').trim().toLowerCase(), p]));

    for (const item of invoice.items) {
      if (item.kode) {
        const cleanKode = item.kode.trim();
        const prodRef = doc(db, 'products', cleanKode);
        const cached = prodMap.get(cleanKode.toLowerCase());

        if (cached) {
          recordQuotaSavings('read', 1, 'Stock deduction using cached product data');
          const isManaged = (cached as any).kelolaStok !== false && (cached as any).kelolaStok !== 'false';
          if (isManaged && cached.stok !== '' && cached.stok !== null && cached.stok !== undefined) {
            const currentVal = parseFloat(String(cached.stok));
            if (!isNaN(currentVal)) {
              const qty = Number(item.qty || 1);
              const newVal = Math.max(0, currentVal - qty);
              batch.update(prodRef, { stok: String(newVal) });
              cached.stok = String(newVal);
              batchUpdates++;
            }
          }
        } else {
          // Fallback: only if item is not in local cache
          try {
            const prodSnap = await getDoc(prodRef);
            recordFirestoreRead('products', 1, 'getDoc_fallback');
            if (prodSnap.exists()) {
              const prodData = prodSnap.data() || {};
              const isManaged = (prodData as any).kelolaStok !== false && (prodData as any).kelolaStok !== 'false';
              const currentStokStr = prodData.stok;
              if (isManaged && currentStokStr !== '' && currentStokStr !== null && currentStokStr !== undefined) {
                const currentVal = parseFloat(currentStokStr);
                if (!isNaN(currentVal)) {
                  const qty = Number(item.qty || 1);
                  const newVal = Math.max(0, currentVal - qty);
                  batch.update(prodRef, { stok: String(newVal) });
                  batchUpdates++;
                }
              }
            }
          } catch (err) {
            console.warn('Fallback product fetch error:', err);
          }
        }
      }
    }
    if (batchUpdates > 0) {
      await batch.commit().catch((err) => console.warn('Stock update batch failed:', err));
      recordFirestoreWrite('products', batchUpdates, 'batch.update');

      // Instantly refresh local product cache and dispatch event for immediate catalog UI refresh
      if (cachedProducts.length > 0) {
        localStorage.setItem('strukku_products', JSON.stringify(cachedProducts));
        window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: cachedProducts }));
      }
    }
  }
}

export async function getInvoiceFirebase(invoiceNo: string): Promise<Invoice | null> {
  const cleanInv = (invoiceNo || '').trim();
  if (!cleanInv || !db) return null;

  // 1. Check in-memory cache
  const cached = invoicesManager.getCachedData() || [];
  const match = cached.find((it) => (it.invoiceNo || it.noInvoice || '').trim().toLowerCase() === cleanInv.toLowerCase());
  if (match) return match;

  // 2. Query Firestore directly
  try {
    const docSnap = await getDoc(doc(db, 'invoices', cleanInv));
    if (docSnap.exists()) {
      recordFirestoreRead('invoices', 1, 'getDoc_direct');
      const d = docSnap.data();
      const historyArr = Array.isArray(d.pelunasanHistory) && d.pelunasanHistory.length > 0
        ? d.pelunasanHistory
        : (Array.isArray(d.historiPelunasan) ? d.historiPelunasan : []);

      const inv: Invoice = {
        invoiceNo: cleanInv,
        noInvoice: cleanInv,
        date: d.date || d.tanggal || '',
        time: d.time || d.jam || '',
        cashier: d.cashier || d.kasir || 'Admin',
        customer: d.customer || d.pelanggan || 'Umum',
        customerPhone: d.customerPhone || d.telepon || d.phone || '',
        customerAddress: d.customerAddress || d.alamat || '',
        payMethod: d.payMethod || d.metodePembayaran || 'Tunai',
        subtotal: Number(d.subtotal || 0),
        discPct: Number(d.discPct || d.diskonPct || 0),
        discAmt: Number(d.discAmt || d.diskonNominal || 0),
        taxPct: Number(d.taxPct || d.pajakPct || 0),
        taxAmt: Number(d.taxAmt || d.pajakNominal || 0),
        negoAmt: Number(d.negoAmt || d.negoNominal || 0),
        total: Number(d.total || 0),
        dp: Number(d.dp || d.bayarDp || 0),
        sisa: Number(d.sisa || d.sisaPiutang || 0),
        kembalian: Number(d.kembalian || 0),
        deadline: d.deadline || '',
        status: d.status || (Number(d.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
        items: Array.isArray(d.items) ? d.items : [],
        pelunasanHistory: historyArr,
        historiPelunasan: historyArr,
        lastEditedBy: d.lastEditedBy,
        lastEditedAt: d.lastEditedAt,
        editReason: d.editReason,
        auditLogs: Array.isArray(d.auditLogs) ? d.auditLogs : [],
      };
      const processed = recalculateInvoiceSisaAndStatus(inv);
      updateInvoiceInLocalCache(processed);
      return processed;
    }
  } catch (err) {
    console.warn('Error fetching invoice from Firestore:', err);
  }
  return null;
}

export async function getPiutangInvoicesFirebase(): Promise<Invoice[]> {
  if (!db) return [];
  const deletedSet = getDeletedInvoices();
  const piutangMap = new Map<string, Invoice>();

  // 1. Check in-memory cache
  const cached = invoicesManager.getCachedData() || [];
  cached.forEach((inv) => {
    const key = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
    if (key && !deletedSet.has(key)) {
      const processed = recalculateInvoiceSisaAndStatus(inv);
      if (processed.sisa > 0 || String(processed.status).toUpperCase() === 'DP') {
        piutangMap.set(key, processed);
      }
    }
  });

  // 2. Check local storage fallback
  const localList = readInvoicesLocalFallback();
  localList.forEach((inv) => {
    const key = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
    if (key && !deletedSet.has(key) && !piutangMap.has(key)) {
      const processed = recalculateInvoiceSisaAndStatus(inv);
      if (processed.sisa > 0 || String(processed.status).toUpperCase() === 'DP') {
        piutangMap.set(key, processed);
      }
    }
  });

  // 3. Query Firestore if cache has no piutang
  if (piutangMap.size === 0) {
    try {
      const colRef = collection(db, 'invoices');
      const snap = await getDocs(colRef);
      recordFirestoreRead('invoices', snap.size, 'getDocs_piutang');
      snap.forEach((docSnap) => {
        const d = docSnap.data();
        const invNo = d.invoiceNo || d.noInvoice || docSnap.id;
        if (!invNo || deletedSet.has(String(invNo).trim().toLowerCase())) return;
        const historyArr = Array.isArray(d.pelunasanHistory) && d.pelunasanHistory.length > 0
          ? d.pelunasanHistory
          : (Array.isArray(d.historiPelunasan) ? d.historiPelunasan : []);
        const inv: Invoice = {
          invoiceNo: invNo,
          noInvoice: invNo,
          date: d.date || d.tanggal || '',
          time: d.time || d.jam || '',
          cashier: d.cashier || d.kasir || 'Admin',
          customer: d.customer || d.pelanggan || 'Umum',
          customerPhone: d.customerPhone || d.telepon || d.phone || '',
          customerAddress: d.customerAddress || d.alamat || '',
          payMethod: d.payMethod || d.metodePembayaran || 'Tunai',
          subtotal: Number(d.subtotal || 0),
          discPct: Number(d.discPct || d.diskonPct || 0),
          discAmt: Number(d.discAmt || d.diskonNominal || 0),
          taxPct: Number(d.taxPct || d.pajakPct || 0),
          taxAmt: Number(d.taxAmt || d.pajakNominal || 0),
          negoAmt: Number(d.negoAmt || d.negoNominal || 0),
          total: Number(d.total || 0),
          dp: Number(d.dp || d.bayarDp || 0),
          sisa: Number(d.sisa || d.sisaPiutang || 0),
          kembalian: Number(d.kembalian || 0),
          deadline: d.deadline || '',
          status: d.status || (Number(d.sisa || 0) > 0 ? 'DP' : 'LUNAS'),
          items: Array.isArray(d.items) ? d.items : [],
          pelunasanHistory: historyArr,
          historiPelunasan: historyArr,
        };
        const processed = recalculateInvoiceSisaAndStatus(inv);
        if (processed.sisa > 0 || String(processed.status).toUpperCase() === 'DP') {
          piutangMap.set(String(invNo).trim().toLowerCase(), processed);
        }
      });
    } catch (err) {
      console.warn('Error querying piutang from Firestore:', err);
    }
  }

  const result = Array.from(piutangMap.values());
  result.sort(compareInvoicesDesc);
  return result;
}

export async function updateInvoiceFirebase(
  invoice: Invoice,
  options?: {
    editedBy?: string;
    editReason?: string;
  }
): Promise<void> {
  const invNo = (invoice.invoiceNo || invoice.noInvoice || '').trim();
  if (!invNo) return;

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
  const formattedTimestamp = `${dateStr} ${timeStr}`;

  const editLog = options?.editReason || options?.editedBy ? {
    editedBy: options.editedBy || 'SPV/Owner',
    editedAt: formattedTimestamp,
    reason: options.editReason || 'Koreksi Data Transaksi Penjualan',
    previousTotal: invoice.total,
    previousPayMethod: invoice.payMethod,
    previousDp: invoice.dp,
    previousSisa: invoice.sisa,
    previousCustomer: invoice.customer,
  } : null;

  const existingLogs = Array.isArray(invoice.auditLogs) ? invoice.auditLogs : [];
  const updatedLogs = editLog ? [editLog, ...existingLogs] : existingLogs;

  const historyArr = Array.isArray(invoice.pelunasanHistory) && invoice.pelunasanHistory.length > 0
    ? invoice.pelunasanHistory
    : (Array.isArray(invoice.historiPelunasan) ? invoice.historiPelunasan : []);

  const updatedInvoice: Invoice = {
    ...invoice,
    pelunasanHistory: historyArr,
    historiPelunasan: historyArr,
    lastEditedBy: options?.editedBy || invoice.lastEditedBy || 'SPV/Owner',
    lastEditedAt: formattedTimestamp,
    editReason: options?.editReason || invoice.editReason || 'Koreksi Data Transaksi',
    auditLogs: updatedLogs,
  };

  const processed = recalculateInvoiceSisaAndStatus(updatedInvoice);

  // 1. Immediately update local storage cache & broadcast update event
  updateInvoiceInLocalCache(processed as Invoice);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('strukku-invoices-updated', { detail: processed }));
  }

  // 2. Persist to Firestore with safety timeout (max 4 seconds)
  try {
    const firestorePromise = setDoc(doc(db, 'invoices', invNo), {
      ...processed,
      pelunasanHistory: processed.pelunasanHistory || historyArr,
      historiPelunasan: processed.historiPelunasan || historyArr,
      updatedAt: serverTimestamp(),
    }, { merge: true });

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Firestore timeout')), 4000)
    );

    await Promise.race([firestorePromise, timeoutPromise]);
    recordFirestoreWrite('invoices', 1, 'setDoc');
  } catch (err: any) {
    console.warn('Firestore setDoc notice for updateInvoiceFirebase:', err?.message || err);
  }
}

export async function deleteInvoiceFirebase(invoiceNo: string, authorizer?: string, reason?: string): Promise<void> {
  const invNo = (invoiceNo || '').trim();
  if (!invNo) return;
  const invKey = invNo.toLowerCase();

  // 1. Stock Rollback: Read items from the invoice before deletion and return quantity to product catalog
  try {
    let targetInvoice: Invoice | null = null;
    const cachedInvoices = invoicesManager.getCachedData() || [];
    targetInvoice = cachedInvoices.find(
      (inv) => (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase() === invKey
    ) || null;

    if (!targetInvoice) {
      const localInvoices = readInvoicesLocalFallback();
      targetInvoice = localInvoices.find(
        (inv) => (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase() === invKey
      ) || null;
    }

    if (!targetInvoice && db && !isFirestoreQuotaExceeded()) {
      targetInvoice = await getInvoiceFirebase(invNo);
    }

    if (targetInvoice && targetInvoice.items && targetInvoice.items.length > 0 && db && !isFirestoreQuotaExceeded()) {
      const batch = writeBatch(db);
      let batchRollbacks = 0;
      const cachedProducts = productsManager.getCachedData() || [];
      const prodMap = new Map(cachedProducts.map((p) => [(p.kode || '').trim().toLowerCase(), p]));

      for (const item of targetInvoice.items) {
        if (item.kode) {
          const cleanKode = item.kode.trim();
          const prodRef = doc(db, 'products', cleanKode);
          const cached = prodMap.get(cleanKode.toLowerCase());

          if (cached) {
            recordQuotaSavings('read', 1, 'Stock rollback using cached product data');
            const isManaged = (cached as any).kelolaStok !== false && (cached as any).kelolaStok !== 'false';
            if (isManaged && cached.stok !== '' && cached.stok !== null && cached.stok !== undefined) {
              const currentVal = parseFloat(String(cached.stok));
              if (!isNaN(currentVal)) {
                const qty = Number(item.qty || 1);
                const newVal = currentVal + qty;
                batch.update(prodRef, { stok: String(newVal) });
                cached.stok = String(newVal);
                batchRollbacks++;
              }
            }
          } else {
            // Fallback: only if item is not in local cache
            try {
              const prodSnap = await getDoc(prodRef);
              recordFirestoreRead('products', 1, 'getDoc_rollback_fallback');
              if (prodSnap.exists()) {
                const prodData = prodSnap.data() || {};
                const isManaged = (prodData as any).kelolaStok !== false && (prodData as any).kelolaStok !== 'false';
                const currentStokStr = prodData.stok;
                if (isManaged && currentStokStr !== '' && currentStokStr !== null && currentStokStr !== undefined) {
                  const currentVal = parseFloat(currentStokStr);
                  if (!isNaN(currentVal)) {
                    const qty = Number(item.qty || 1);
                    const newVal = currentVal + qty;
                    batch.update(prodRef, { stok: String(newVal) });
                    batchRollbacks++;
                  }
                }
              }
            } catch (err) {
              console.warn('Fallback product fetch for rollback error:', err);
            }
          }
        }
      }

      if (batchRollbacks > 0) {
        await batch.commit().catch((err) => console.warn('Stock rollback batch failed:', err));
        recordFirestoreWrite('products', batchRollbacks, 'batch.update_rollback');

        // Immediately update local product cache and dispatch event for real-time UI catalog freshness
        if (cachedProducts.length > 0) {
          localStorage.setItem('strukku_products', JSON.stringify(cachedProducts));
          window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: cachedProducts }));
        }
      }
    }
  } catch (rollbackErr) {
    console.warn('Stock rollback before invoice deletion notice:', rollbackErr);
  }

  // 2. Record in local tombstone
  addDeletedInvoice(invNo);
  removePendingCloudSyncInvoice(invNo);

  // 3. Delete document from 'invoices'
  try {
    await deleteDoc(doc(db, 'invoices', invNo));
    recordFirestoreDelete('invoices', 1, 'deleteDoc');
  } catch (err) {
    console.warn('Firestore deleteDoc error:', err);
  }

  // 4. Write tombstone to 'deletedInvoices' collection for real-time synchronization across devices
  try {
    await setDoc(doc(db, 'deletedInvoices', invKey), {
      invoiceNo: invNo,
      deletedBy: authorizer || 'SPV/Owner',
      reason: reason || 'Dihapus oleh Supervisor/Owner',
      deletedAt: serverTimestamp(),
    }, { merge: true });
    recordFirestoreWrite('deletedInvoices', 1, 'setDoc');
  } catch (err) {
    console.warn('Firestore deletedInvoices setDoc error:', err);
  }
}

/**
 * Stock Reconciliation (Rekonsiliasi Stok Otomatis Saat Koreksi Nota)
 * Membandingkan item lama dan item baru:
 * Delta = Qty Lama - Qty Baru
 * Jika Delta > 0: Tambahkan balik selisih tersebut ke stok produk di Firestore (pelanggan mengurangi qty)
 * Jika Delta < 0: Kurangi lagi stok produk tersebut di Firestore (pelanggan menambah qty)
 * Menggunakan writeBatch dan data dari productsManager.getCachedData() untuk menghemat kuota Reads.
 */
export async function reconcileInvoiceStockFirebase(
  oldItems: InvoiceItem[] = [],
  newItems: InvoiceItem[] = []
): Promise<{ reconciledCount: number }> {
  if (!db || isFirestoreQuotaExceeded()) return { reconciledCount: 0 };

  const oldQtyMap = new Map<string, number>();
  for (const item of oldItems) {
    if (item.kode) {
      const k = item.kode.trim().toLowerCase();
      oldQtyMap.set(k, (oldQtyMap.get(k) || 0) + Number(item.qty || 1));
    }
  }

  const newQtyMap = new Map<string, number>();
  for (const item of newItems) {
    if (item.kode) {
      const k = item.kode.trim().toLowerCase();
      newQtyMap.set(k, (newQtyMap.get(k) || 0) + Number(item.qty || 1));
    }
  }

  const allKodes = new Set<string>([...oldQtyMap.keys(), ...newQtyMap.keys()]);
  if (allKodes.size === 0) return { reconciledCount: 0 };

  const batch = writeBatch(db);
  let batchUpdates = 0;
  const cachedProducts = productsManager.getCachedData() || [];
  const prodMap = new Map(cachedProducts.map((p) => [(p.kode || '').trim().toLowerCase(), p]));

  for (const k of allKodes) {
    const oldQty = oldQtyMap.get(k) || 0;
    const newQty = newQtyMap.get(k) || 0;
    const delta = oldQty - newQty; // Delta = Qty Lama - Qty Baru

    if (delta === 0) continue; // Tidak ada perubahan kuantitas

    const cached = prodMap.get(k);
    if (cached) {
      recordQuotaSavings('read', 1, 'Stock reconciliation using cached product data');
      const isManaged = (cached as any).kelolaStok !== false && (cached as any).kelolaStok !== 'false';
      if (isManaged && cached.stok !== '' && cached.stok !== null && cached.stok !== undefined) {
        const currentVal = parseFloat(String(cached.stok));
        if (!isNaN(currentVal)) {
          // Delta positif: kembalikan ke stok (+delta). Delta negatif: kurangi stok (+ (-|delta|)).
          const newVal = Math.max(0, currentVal + delta);
          const prodRef = doc(db, 'products', (cached.kode || k).trim());
          batch.update(prodRef, { stok: String(newVal) });
          cached.stok = String(newVal);
          batchUpdates++;
        }
      }
    } else {
      // Fallback jika tidak ada di in-memory cache
      try {
        const prodRef = doc(db, 'products', k);
        const prodSnap = await getDoc(prodRef);
        recordFirestoreRead('products', 1, 'getDoc_reconcile_fallback');
        if (prodSnap.exists()) {
          const prodData = prodSnap.data() || {};
          const isManaged = (prodData as any).kelolaStok !== false && (prodData as any).kelolaStok !== 'false';
          const currentStokStr = prodData.stok;
          if (isManaged && currentStokStr !== '' && currentStokStr !== null && currentStokStr !== undefined) {
            const currentVal = parseFloat(currentStokStr);
            if (!isNaN(currentVal)) {
              const newVal = Math.max(0, currentVal + delta);
              batch.update(prodRef, { stok: String(newVal) });
              batchUpdates++;
            }
          }
        }
      } catch (err) {
        console.warn('Fallback product fetch for stock reconciliation error:', err);
      }
    }
  }

  if (batchUpdates > 0) {
    await batch.commit().catch((err) => console.warn('Stock reconciliation batch commit failed:', err));
    recordFirestoreWrite('products', batchUpdates, 'batch.update_reconciliation');

    // Perbarui cache lokal produk secara instan agar katalog UI langsung segar
    if (cachedProducts.length > 0) {
      localStorage.setItem('strukku_products', JSON.stringify(cachedProducts));
      window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: cachedProducts }));
    }
  }

  return { reconciledCount: batchUpdates };
}

// State guard for auto re-sync engine
let isAutoSyncRunning = false;

/**
 * Fitur Otomatis Upload Data dari Cache Lokal ke Firebase (Auto Re-Sync Pasca Limit)
 * Mengecek apakah ada transaksi lokal di readInvoicesLocalFallback() yang tertahan
 * saat kuota limit/offline, lalu memanggil migrateAllDataToFirebase dengan metode merge di background.
 */
export async function autoSyncLocalDataToFirebase(
  onToast?: (msg: string, type?: 'success' | 'info' | 'error') => void
): Promise<{ synced: boolean; count: number }> {
  if (isAutoSyncRunning) return { synced: false, count: 0 };
  if (isFirestoreQuotaExceeded()) return { synced: false, count: 0 };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { synced: false, count: 0 };
  if (!db) return { synced: false, count: 0 };

  const pendingIds = new Set(getPendingCloudSyncInvoices().map((s) => s.trim().toLowerCase()));
  const localInvoices = readInvoicesLocalFallback();
  if (localInvoices.length === 0) return { synced: false, count: 0 };

  // 1. Identifikasi transaksi yang benar-benar tertahan di offline / pending list
  let unsyncedInvoices = localInvoices.filter((inv) => {
    const invNo = (inv.invoiceNo || inv.noInvoice || '').trim().toLowerCase();
    const isPending = (inv as any).syncStatus === 'pending' || (inv as any).isPendingSync === true;
    return invNo && (pendingIds.has(invNo) || isPending);
  });

  if (unsyncedInvoices.length === 0) {
    if (pendingIds.size > 0) {
      localStorage.removeItem(PENDING_CLOUD_SYNC_KEY);
    }
    return { synced: false, count: 0 };
  }

  isAutoSyncRunning = true;
  try {
    console.log(`[Auto Re-Sync] Mengunggah ${unsyncedInvoices.length} transaksi lokal tertahan ke Firebase Cloud di latar belakang...`);
    const res = await migrateAllDataToFirebase({
      invoices: unsyncedInvoices,
    });

    if (res.success) {
      // Hapus ID yang sukses disinkronkan dari antrean pending
      unsyncedInvoices.forEach((inv) => {
        removePendingCloudSyncInvoice(inv.invoiceNo || inv.noInvoice || '');
      });

      const count = unsyncedInvoices.length;
      const msg = `✓ ${count} transaksi lokal berhasil disinkronkan otomatis ke Firebase Cloud!`;
      if (onToast) {
        onToast(msg, 'info');
      } else if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('strukku-auto-resync-success', {
            detail: { count, message: msg },
          })
        );
      }
      return { synced: true, count };
    }
  } catch (syncErr) {
    console.warn('[Auto Re-Sync Pasca Limit] Gagal sinkronisasi data ke cloud:', syncErr);
  } finally {
    isAutoSyncRunning = false;
  }

  return { synced: false, count: 0 };
}

/**
 * Menjalankan engine Auto Re-Sync berkala (setiap 10 menit) dan pemicu online / reset kuota harian
 */
export function startAutoSyncEngine(
  onToast?: (msg: string, type?: 'success' | 'info' | 'error') => void
): () => void {
  // Pemicu 1: Cek awal 15 detik setelah aplikasi terbuka
  const initialTimer = setTimeout(() => {
    autoSyncLocalDataToFirebase(onToast).catch(() => {});
  }, 15000);

  // Pemicu 2: Berkala setiap 10 menit (600.000 ms)
  const intervalTimer = setInterval(() => {
    autoSyncLocalDataToFirebase(onToast).catch(() => {});
  }, 10 * 60 * 1000);

  // Pemicu 3: Saat koneksi internet kembali online
  const handleOnline = () => {
    setTimeout(() => {
      autoSyncLocalDataToFirebase(onToast).catch(() => {});
    }, 4000);
  };

  // Pemicu 4: Saat metrik kuota Firestore ter-reset (quotaExceeded kembali false)
  const handleQuotaMetricUpdate = (e: any) => {
    const metrics = e?.detail;
    if (metrics && metrics.quotaExceeded === false) {
      setTimeout(() => {
        autoSyncLocalDataToFirebase(onToast).catch(() => {});
      }, 5000);
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('online', handleOnline);
    window.addEventListener('firestore-quota-metric-updated', handleQuotaMetricUpdate);
  }

  return () => {
    clearTimeout(initialTimer);
    clearInterval(intervalTimer);
    if (typeof window !== 'undefined') {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('firestore-quota-metric-updated', handleQuotaMetricUpdate);
    }
  };
}

export async function saveExpenseFirebase(expense: ExpenseRecord): Promise<void> {
  const docId = expense.id.trim();
  removeDeletedExpense(docId);
  await setDoc(doc(db, 'expenses', docId), {
    ...expense,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('expenses', 1, 'setDoc');
}

export async function deleteExpenseFirebase(id: string, authorizer?: string, reason?: string): Promise<void> {
  const cleanId = (id || '').trim();
  if (!cleanId) return;

  // 1. Record in local tombstone
  addDeletedExpense(cleanId);

  // 2. Delete document from 'expenses'
  try {
    await deleteDoc(doc(db, 'expenses', cleanId));
    recordFirestoreDelete('expenses', 1, 'deleteDoc');
  } catch (err) {
    console.warn('Firestore deleteExpense error:', err);
  }

  // 3. Write tombstone to 'deletedExpenses' collection for real-time synchronization across devices
  const tombstoneKey = cleanId.toLowerCase().replace(/[^a-z0-9_-]/g, '_');
  try {
    await setDoc(doc(db, 'deletedExpenses', tombstoneKey), {
      id: cleanId,
      deletedBy: authorizer || 'Kasir',
      reason: reason || 'Dihapus oleh pengguna',
      deletedAt: serverTimestamp(),
    }, { merge: true });
    recordFirestoreWrite('deletedExpenses', 1, 'setDoc');
  } catch (err) {
    console.warn('Firestore deletedExpenses setDoc error:', err);
  }
}

export async function saveStockInFirebase(record: StockInRecord): Promise<void> {
  const docId = record.id || `STOCKIN-${Date.now()}`;
  await setDoc(doc(db, 'stockIn', docId), {
    ...record,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('stockIn', 1, 'setDoc');

  // Update product stock in product doc using cached data if possible
  const cleanKode = (record.kode || record.kodeProduct || '').trim();
  const cleanNama = (record.nama || '').trim();
  const addedQty = Number(record.qty || record.jumlahMasuk || 0);

  if ((cleanKode || cleanNama) && addedQty > 0) {
    // 1. Instantly update in-memory cache and localStorage
    const cachedProducts = productsManager.getCachedData() || [];
    let prods: Product[] = [...cachedProducts];
    if (prods.length === 0) {
      try {
        const local = localStorage.getItem('strukku_products');
        if (local) prods = JSON.parse(local);
      } catch {}
    }

    const targetIdx = prods.findIndex(
      (p) =>
        (cleanKode && p.kode && p.kode.trim().toLowerCase() === cleanKode.toLowerCase()) ||
        (cleanNama && p.nama && p.nama.trim().toLowerCase() === cleanNama.toLowerCase())
    );

    let newVal = addedQty;
    let actualDocKode = cleanKode;

    if (targetIdx >= 0) {
      const curStok = parseFloat(String(prods[targetIdx].stok || '0').replace(',', '.')) || 0;
      newVal = Math.round((curStok + addedQty) * 1000) / 1000;
      prods[targetIdx] = {
        ...prods[targetIdx],
        stok: String(newVal),
      };
      if (prods[targetIdx].kode) {
        actualDocKode = prods[targetIdx].kode.trim();
      }
    }

    // Persist to local storage and notify all subscribers immediately
    try {
      localStorage.setItem('strukku_products', JSON.stringify(prods));
      productsManager.updateCacheAndNotify(prods);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('strukku-products-updated', { detail: prods }));
      }
    } catch (err) {
      console.warn('Failed to update local products on stock-in:', err);
    }

    // 2. Persist updated stock to Cloud Firestore
    const targetDocId = actualDocKode || cleanKode || cleanNama;
    if (targetDocId) {
      try {
        const prodRef = doc(db, 'products', targetDocId);
        await setDoc(prodRef, {
          stok: String(newVal),
          updatedAt: serverTimestamp(),
        }, { merge: true });
        recordFirestoreWrite('products', 1, 'setDoc');
      } catch (err) {
        console.warn('Firestore update stock-in product stock notice:', err);
      }
    }
  }
}

export async function deleteStockInFirebase(id: string, rollbackProduct?: { kode: string; qty: number }): Promise<void> {
  const cleanId = (id || '').trim();
  if (!cleanId) return;

  try {
    await deleteDoc(doc(db, 'stockIn', cleanId));
    recordFirestoreDelete('stockIn', 1, 'deleteDoc');
  } catch (err) {
    console.warn('Firestore deleteStockIn error:', err);
  }

  // Rollback stock in Firestore product document if specified
  if (rollbackProduct && rollbackProduct.kode && rollbackProduct.qty > 0) {
    try {
      const cleanKode = rollbackProduct.kode.trim();
      const prodRef = doc(db, 'products', cleanKode);
      const prodSnap = await getDoc(prodRef);
      if (prodSnap.exists()) {
        const curStok = parseFloat(String(prodSnap.data().stok || '0')) || 0;
        const newStok = Math.max(0, Math.round((curStok - rollbackProduct.qty) * 1000) / 1000);
        await updateDoc(prodRef, {
          stok: String(newStok),
          updatedAt: serverTimestamp(),
        });
        recordFirestoreWrite('products', 1, 'updateDoc_rollback');
        const cached = productsManager.getCachedData()?.find((p) => (p.kode || '').trim().toLowerCase() === cleanKode.toLowerCase());
        if (cached) cached.stok = String(newStok);
      }
    } catch (err) {
      console.warn('Firestore rollback product stock error:', err);
    }
  }
}

// 9. Stock Opname Manager
export const stockOpnameManager = new SharedSubscriptionManager<StockOpnameRecord[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'stockOpname');
    const q = query(colRef);
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('stockOpname', changesCount, 'onSnapshot');
      }
      const list: StockOpnameRecord[] = [];
      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        list.push({
          id: d.id || docSnap.id,
          tanggal: d.tanggal || '',
          jam: d.jam || '',
          pjKasir: d.pjKasir || 'Admin',
          authorizedBy: d.authorizedBy || 'Supervisor',
          catatanUmum: d.catatanUmum || '',
          totalItemDiperiksa: Number(d.totalItemDiperiksa || 0),
          totalItemSelisih: Number(d.totalItemSelisih || 0),
          totalSelisihKurangQty: Number(d.totalSelisihKurangQty || 0),
          totalSelisihLebihQty: Number(d.totalSelisihLebihQty || 0),
          totalSelisihNominalRp: Number(d.totalSelisihNominalRp || 0),
          items: Array.isArray(d.items) ? d.items : [],
          status: d.status || 'APPROVED',
          tanggalSelesai: d.tanggalSelesai || undefined,
          jamSelesai: d.jamSelesai || undefined,
          metodePenyesuaian: d.metodePenyesuaian || 'DELTA',
          totalPenjualanInterimQty: Number(d.totalPenjualanInterimQty || 0),
        });
      });

      // Deduplicate and sort descending by tanggal & jam
      list.sort((a, b) => (b.tanggal + ' ' + b.jam).localeCompare(a.tanggal + ' ' + a.jam));
      localStorage.setItem('strukku_stock_opname_history', JSON.stringify(list));
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'stockOpname');
      onError(err);
    });
  },
  () => {
    try {
      const opnRaw = localStorage.getItem('strukku_stock_opname_history');
      if (opnRaw) {
        const parsed = JSON.parse(opnRaw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function getStoredStockOpnames(): StockOpnameRecord[] {
  try {
    const opnRaw = localStorage.getItem('strukku_stock_opname_history');
    if (opnRaw) {
      const parsed = JSON.parse(opnRaw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [];
}

export function subscribeStockOpname(callback: (records: StockOpnameRecord[]) => void) {
  return stockOpnameManager.subscribe(callback);
}

export async function saveStockOpnameFirebase(record: StockOpnameRecord): Promise<void> {
  const docId = record.id || `OPN-${Date.now()}`;
  // Sanitize undefined fields to prevent Firestore unsupported field value error
  const sanitizedRecord = JSON.parse(JSON.stringify(record, (_key, value) => {
    return value === undefined ? null : value;
  }));

  await setDoc(doc(db, 'stockOpname', docId), {
    ...sanitizedRecord,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('stockOpname', 1, 'setDoc');

  // Only update physical stock for audited items into Firestore products collection when APPROVED!
  // If record is still a DRAFT, products stock must NOT be altered yet.
  if (record.status === 'APPROVED' && record.items && record.items.length > 0) {
    const batch = writeBatch(db);
    let opnameStockWrites = 0;
    for (const item of record.items) {
      if (item.kode) {
        const prodRef = doc(db, 'products', item.kode.trim());
        // Use delta-adjusted stock if available, otherwise physical stock
        const targetStock = item.stokPenyesuaianAkhir !== undefined
          ? item.stokPenyesuaianAkhir
          : item.stokFisik;
        batch.set(prodRef, {
          stok: String(targetStock),
          updatedAt: serverTimestamp(),
        }, { merge: true });
        opnameStockWrites++;
      }
    }
    await batch.commit().catch((err) => console.warn('Opname product stock sync batch error:', err));
    if (opnameStockWrites > 0) {
      recordFirestoreWrite('products', opnameStockWrites, 'batch.set_opname');
    }
  }
}

export async function deleteStockOpnameFirebase(id: string): Promise<void> {
  await deleteDoc(doc(db, 'stockOpname', id.trim()));
  recordFirestoreDelete('stockOpname', 1, 'deleteDoc');
}

// Helper to safely read deleted vendor IDs without circular dependency
function getDeletedVendorIdsSafe(): Set<string> {
  try {
    const raw = localStorage.getItem('strukku_deleted_vendor_ids');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return new Set(parsed);
    }
  } catch {}
  return new Set();
}

// 10. Vendors Manager (Real-time syncing across all devices)
export const vendorsManager = new SharedSubscriptionManager<Vendor[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'vendors');
    const q = query(colRef, limit(300));
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('vendors', changesCount, 'onSnapshot');
      }
      const list: Vendor[] = [];
      const deletedIds = getDeletedVendorIdsSafe();
      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        const id = d.id || docSnap.id;
        if (id && !deletedIds.has(id)) {
          list.push({
            id,
            nama: d.nama || '',
            kategori: d.kategori || 'Umum',
            telepon: d.telepon || '',
            email: d.email || '',
            alamat: d.alamat || '',
            kontakPerson: d.kontakPerson || '',
            nomorRekening: d.nomorRekening || '',
            catatan: d.catatan || '',
            createdAt: d.createdAt || '',
          });
        }
      });
      list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      localStorage.setItem('strukku_vendors_list', JSON.stringify(list));
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'vendors');
      onError(err);
    });
  },
  () => {
    try {
      const raw = localStorage.getItem('strukku_vendors_list');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeVendors(callback: (vendors: Vendor[]) => void) {
  return vendorsManager.subscribe(callback);
}

export async function saveVendorFirebase(vendor: Vendor): Promise<void> {
  const docId = vendor.id || `VEN-${Date.now()}`;
  await setDoc(doc(db, 'vendors', docId), {
    ...vendor,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  recordFirestoreWrite('vendors', 1, 'setDoc');
}

export async function deleteVendorFirebase(id: string): Promise<void> {
  await deleteDoc(doc(db, 'vendors', id.trim()));
  recordFirestoreDelete('vendors', 1, 'deleteDoc');
}

// 11. Stock In Manager (Real-time syncing for barang masuk across devices)
export const stockInManager = new SharedSubscriptionManager<StockInRecord[]>(
  (onUpdate, onError) => {
    const colRef = collection(db, 'stockIn');
    const q = query(colRef, limit(500));
    return onSnapshot(q, (snapshot) => {
      const changesCount = snapshot.docChanges().length;
      if (changesCount > 0) {
        recordFirestoreRead('stockIn', changesCount, 'onSnapshot');
      }
      const list: StockInRecord[] = [];
      snapshot.forEach((docSnap) => {
        const d = docSnap.data();
        list.push({
          id: d.id || docSnap.id,
          kode: d.kode || d.kodeProduct || '',
          nama: d.nama || d.namaProduct || '',
          qty: Number(d.qty || d.jumlahMasuk || 0),
          satuan: d.satuan || 'pcs',
          supplier: d.supplier || d.vendor || '',
          cashier: d.cashier || d.pj || 'Admin',
          date: d.date || d.tanggal || '',
          time: d.time || d.jam || '',
          tanggal: d.tanggal || d.date || '',
          jam: d.jam || d.time || '',
          catatan: d.catatan || '',
          noPo: d.noPo || d.noFaktur || '',
          hargaBeli: Number(d.hargaBeli || 0),
          totalBiaya: Number(d.totalBiaya || d.totalBeli || 0),
          gudang: d.gudang || '',
        });
      });
      list.sort((a, b) => ((b.date || b.tanggal || '') + ' ' + (b.time || b.jam || '')).localeCompare((a.date || a.tanggal || '') + ' ' + (a.time || a.jam || '')));
      localStorage.setItem('strukku_stock_in_history', JSON.stringify(list));
      onUpdate(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'stockIn');
      onError(err);
    });
  },
  () => {
    try {
      const raw = localStorage.getItem('strukku_stock_in_history');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return null;
  }
);

export function subscribeStockIn(callback: (records: StockInRecord[]) => void) {
  return stockInManager.subscribe(callback);
}

export interface CloudDataBatchResult {
  products: Product[];
  customers: Customer[];
  kasirUsers: KasirUser[];
  kasirList: string[];
  settings: Partial<StoreSettings>;
  invoices: Invoice[];
  stockIn: StockInRecord[];
  expenses: ExpenseRecord[];
  vendors: Vendor[];
  stockOpnames: StockOpnameRecord[];
  nextInvoiceNo?: string;
}

/**
 * Direct complete sync from Firebase Firestore.
 * Used whenever Google Sheets is not configured or as the primary cloud data source.
 * Guarantees that opening the app on any device receives the true Firestore database state!
 */
export async function fetchAllDataFromFirebase(): Promise<CloudDataBatchResult> {
  const productsCached = productsManager.getCachedData() || [];
  const customersCached = customersManager.getCachedData() || [];
  const kasirCached = kasirUsersManager.getCachedData() || [];
  const settingsCached = settingsManager.getCachedData() || {};
  const invoicesCached = invoicesManager.getCachedData() || [];
  const expensesCached = expensesManager.getCachedData() || [];
  const stockInCached = stockInManager.getCachedData() || [];
  const vendorsCached = vendorsManager.getCachedData() || [];
  const stockOpnamesCached = stockOpnameManager.getCachedData() || [];

  let finalProducts = productsCached;
  let finalCustomers = customersCached;
  let finalKasir = kasirCached;
  let finalSettings = settingsCached;
  let finalInvoices = invoicesCached;

  try {
    if (finalProducts.length === 0) {
      const pSnap = await getDocs(collection(db, 'products'));
      recordFirestoreRead('products', pSnap.size, 'getDocs_batch');
      const list: Product[] = [];
      pSnap.forEach((docSnap) => {
        const d = docSnap.data();
        const kode = d.kode || docSnap.id;
        const nama = d.nama || '';
        if (!isProductDeleted(kode, nama)) {
          list.push({
            kode,
            nama,
            harga: Number(d.harga || 0),
            kategori: d.kategori || 'Lainnya',
            stok: d.stok !== undefined && d.stok !== null ? String(d.stok) : '',
            satuan: d.satuan || 'pcs',
            tipeHarga: d.tipeHarga || 'fix',
          });
        }
      });
      if (list.length > 0) {
        finalProducts = list;
        localStorage.setItem('strukku_products', JSON.stringify(list));
      }
    }
  } catch (e) {
    console.warn('Error fetching products from Firestore:', e);
  }

  try {
    if (finalCustomers.length === 0) {
      const cSnap = await getDocs(collection(db, 'customers'));
      recordFirestoreRead('customers', cSnap.size, 'getDocs_batch');
      const list: Customer[] = [];
      const deletedNames = getDeletedCustomers();
      cSnap.forEach((docSnap) => {
        const d = docSnap.data();
        const name = d.nama || docSnap.id;
        if (name && !deletedNames.has(name.trim().toLowerCase())) {
          list.push({
            nama: name,
            kelas: d.kelas || 'Reguler',
            diskon: Number(d.diskon || 0),
            telepon: d.telepon || '',
            catatan: d.catatan || '',
            alamat: d.alamat || '',
          });
        }
      });
      if (list.length > 0) {
        finalCustomers = list;
        localStorage.setItem('strukku_customers', JSON.stringify(list));
      }
    }
  } catch (e) {
    console.warn('Error fetching customers from Firestore:', e);
  }

  try {
    if (finalKasir.length === 0) {
      const kSnap = await getDocs(collection(db, 'kasirUsers'));
      recordFirestoreRead('kasirUsers', kSnap.size, 'getDocs_batch');
      const list: KasirUser[] = [];
      kSnap.forEach((docSnap) => {
        const d = docSnap.data();
        list.push({
          nama: d.nama || docSnap.id,
          password: d.password || 'ervo123',
        });
      });
      if (list.length > 0) {
        finalKasir = list;
        localStorage.setItem('strukku_kasir_users', JSON.stringify(list));
        localStorage.setItem('strukku_kasir_list', JSON.stringify(list.map((u) => u.nama)));
      }
    }
  } catch (e) {
    console.warn('Error fetching kasir users from Firestore:', e);
  }

  try {
    if (Object.keys(finalSettings).length === 0) {
      const sSnap = await getDoc(doc(db, 'settings', 'store'));
      recordFirestoreRead('settings', 1, 'getDoc_batch');
      if (sSnap.exists()) {
        finalSettings = sSnap.data() as Partial<StoreSettings>;
        localStorage.setItem('strukku_settings', JSON.stringify(finalSettings));
      }
    }
  } catch (e) {
    console.warn('Error fetching settings from Firestore:', e);
  }

  let nextInvoiceNo: string | undefined;
  try {
    nextInvoiceNo = await getNextInvoiceNumberFirebase(finalSettings.prefixInvoice || 'INV');
  } catch {}

  return {
    products: finalProducts,
    customers: finalCustomers,
    kasirUsers: finalKasir,
    kasirList: finalKasir.map((u) => u.nama),
    settings: finalSettings,
    invoices: finalInvoices,
    stockIn: stockInCached,
    expenses: expensesCached,
    vendors: vendorsCached,
    stockOpnames: stockOpnamesCached,
    nextInvoiceNo,
  };
}

// Generate Next Invoice Number from local cache / memory (Monthly sequence: PREFIX-YYYYMM-001)
// Uses cached real-time invoices without triggering full O(N) getDocs scans, saving thousands of Firestore reads
export async function getNextInvoiceNumberFirebase(prefix: string = 'INV'): Promise<string> {
  try {
    const d = new Date();
    const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0'); // e.g. 202609
    let maxSeq = 0;

    // 1. Check in-memory & cached invoices from invoicesManager (0 extra Firestore reads)
    const cached = invoicesManager.getCachedData();
    const listToCheck: any[] = cached && cached.length > 0 ? [...cached] : [];

    if (listToCheck.length === 0) {
      try {
        const raw = localStorage.getItem('strukku_recent_invoices');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0) listToCheck.push(...parsed);
        }
      } catch {}
    }

    // 2. Cold-boot safeguard for new devices: query all invoices directly from Firestore
    // This prevents new devices from resetting sequence to 001 when in-memory cache is empty
    if (listToCheck.length === 0) {
      try {
        const colRef = collection(db, 'invoices');
        const snap = await getDocs(colRef);
        recordFirestoreRead('invoices', snap.size, 'getNextInvoiceNumber_coldBoot');
        snap.forEach((docSnap) => {
          listToCheck.push(docSnap.data());
        });
      } catch (err) {
        console.warn('Could not query latest invoices from Firestore for sequence numbering:', err);
      }
    }

    for (const item of listToCheck) {
      const invNo = String(item.invoiceNo || item.noInvoice || '').trim();
      if (invNo.includes(yearMonth)) {
        const parts = invNo.split('-');
        if (parts.length >= 2) {
          const last = parts[parts.length - 1];
          const seq = parseInt(last, 10);
          if (!isNaN(seq) && seq > maxSeq) {
            maxSeq = seq;
          }
        }
      }
    }

    // 2. Check local counter storage for any optimistic reservation
    const localSeqKey = `strukku_inv_seq_${yearMonth}`;
    try {
      const storedSeq = parseInt(localStorage.getItem(localSeqKey) || '0', 10);
      if (!isNaN(storedSeq) && storedSeq > maxSeq) {
        maxSeq = storedSeq;
      }
    } catch {}

    const nextSeqNum = maxSeq + 1;
    const nextSeqStr = String(nextSeqNum).padStart(3, '0');

    // Save optimistic counter locally
    try {
      localStorage.setItem(localSeqKey, String(nextSeqNum));
    } catch {}

    return `${prefix}-${yearMonth}-${nextSeqStr}`;
  } catch (err) {
    const d = new Date();
    const yearMonth = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0');
    return `${prefix}-${yearMonth}-001`;
  }
}

// Helper to sanitize payload and strip unsupported undefined values before sending to Firestore
function sanitizeForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  return JSON.parse(JSON.stringify(obj, (_key, value) => {
    return value === undefined ? null : value;
  }));
}

// Full One-Click Batch Migration Utility to Firebase with Batch Chunking & Progress Tracking
export async function migrateAllDataToFirebase(
  data: {
    products?: Product[];
    customers?: Customer[];
    kasirUsers?: KasirUser[];
    settings?: Partial<StoreSettings>;
    expenses?: ExpenseRecord[];
    stockIn?: StockInRecord[];
    invoices?: Invoice[];
  },
  onProgress?: (info: { current: number; total: number; stage: string; percent: number }) => void
): Promise<{ success: boolean; migratedCounts: Record<string, number>; message: string }> {
  try {
    const counts: Record<string, number> = {
      products: 0,
      customers: 0,
      kasirUsers: 0,
      settings: 0,
      expenses: 0,
      stockIn: 0,
      invoices: 0,
    };

    interface MigrationOp {
      collection: string;
      docId: string;
      data: any;
      category: string;
      label: string;
    }

    const allOps: MigrationOp[] = [];

    // 1. Products
    if (data.products && data.products.length > 0) {
      for (const p of data.products) {
        const cleanKode = (p.kode || '').trim();
        if (cleanKode) {
          allOps.push({
            collection: 'products',
            docId: cleanKode,
            data: sanitizeForFirestore({ ...p }),
            category: 'products',
            label: `Produk "${p.nama || cleanKode}"`,
          });
        }
      }
    }

    // 2. Customers
    if (data.customers && data.customers.length > 0) {
      for (const c of data.customers) {
        const cleanName = (c.nama || '').trim();
        if (cleanName) {
          allOps.push({
            collection: 'customers',
            docId: cleanName,
            data: sanitizeForFirestore({ ...c }),
            category: 'customers',
            label: `Pelanggan "${cleanName}"`,
          });
        }
      }
    }

    // 3. Kasir Users
    if (data.kasirUsers && data.kasirUsers.length > 0) {
      for (const u of data.kasirUsers) {
        const cleanName = (u.nama || '').trim();
        if (cleanName) {
          allOps.push({
            collection: 'kasirUsers',
            docId: cleanName,
            data: sanitizeForFirestore({ ...u }),
            category: 'kasirUsers',
            label: `Kasir "${cleanName}"`,
          });
        }
      }
    }

    // 4. Settings
    if (data.settings && Object.keys(data.settings).length > 0) {
      allOps.push({
        collection: 'settings',
        docId: 'store',
        data: sanitizeForFirestore({ ...data.settings }),
        category: 'settings',
        label: 'Pengaturan Toko',
      });
    }

    // 5. Expenses
    if (data.expenses && data.expenses.length > 0) {
      for (const e of data.expenses) {
        const cleanId = (e.id || '').trim() || `EXP-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        allOps.push({
          collection: 'expenses',
          docId: cleanId,
          data: sanitizeForFirestore({ ...e }),
          category: 'expenses',
          label: `Pengeluaran "${e.keterangan || cleanId}"`,
        });
      }
    }

    // 6. Stock In
    if (data.stockIn && data.stockIn.length > 0) {
      for (const s of data.stockIn) {
        const cleanId = (s.id || '').trim() || `STOCKIN-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        allOps.push({
          collection: 'stockIn',
          docId: cleanId,
          data: sanitizeForFirestore({ ...s }),
          category: 'stockIn',
          label: `Barang Masuk "${s.nama || cleanId}"`,
        });
      }
    }

    // 7. Invoices
    if (data.invoices && data.invoices.length > 0) {
      for (const inv of data.invoices) {
        const invNo = (inv.invoiceNo || inv.noInvoice || '').trim();
        if (invNo) {
          allOps.push({
            collection: 'invoices',
            docId: invNo,
            data: sanitizeForFirestore({ ...inv }),
            category: 'invoices',
            label: `Faktur #${invNo}`,
          });
        }
      }
    }

    const totalOps = allOps.length;
    if (totalOps === 0) {
      return {
        success: true,
        migratedCounts: counts,
        message: 'Tidak ada data untuk dimigrasikan.',
      };
    }

    // Chunk into batches of 50 operations max (well below Firestore 500 limit for speed & reliability)
    const CHUNK_SIZE = 50;
    let processedOps = 0;

    for (let i = 0; i < allOps.length; i += CHUNK_SIZE) {
      const chunk = allOps.slice(i, i + CHUNK_SIZE);
      const batch = writeBatch(db);

      for (const op of chunk) {
        const ref = doc(db, op.collection, op.docId);
        batch.set(ref, {
          ...op.data,
          updatedAt: serverTimestamp(),
        }, { merge: true });
        counts[op.category] = (counts[op.category] || 0) + 1;
      }

      const stageName = chunk[0]?.label || `Batch ${Math.floor(i / CHUNK_SIZE) + 1}`;
      if (onProgress) {
        const pct = Math.round((processedOps / totalOps) * 100);
        onProgress({
          current: processedOps,
          total: totalOps,
          stage: `Memindahkan ${stageName}...`,
          percent: pct,
        });
      }

      // Commit batch with timeout safety
      const commitPromise = batch.commit();
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Timeout batch commit Firestore')), 15000)
      );

      try {
        await Promise.race([commitPromise, timeoutPromise]);
      } catch (commitErr: any) {
        console.warn('Batch commit warning (attempting individual fallback for chunk):', commitErr);
        // Fallback: write individually in background without blocking
        await Promise.allSettled(
          chunk.map((op) =>
            setDoc(doc(db, op.collection, op.docId), {
              ...op.data,
              updatedAt: serverTimestamp(),
            }, { merge: true })
          )
        );
      }

      processedOps += chunk.length;
      if (onProgress) {
        const pct = Math.min(100, Math.round((processedOps / totalOps) * 100));
        onProgress({
          current: processedOps,
          total: totalOps,
          stage: `Selesai memindahkan ${processedOps} dari ${totalOps} data`,
          percent: pct,
        });
      }
    }

    recordFirestoreWrite('migration', totalOps, 'batch.chunked');

    // Store flag in localStorage that Firebase migration is active
    localStorage.setItem('strukku_firebase_active', 'true');

    return {
      success: true,
      migratedCounts: counts,
      message: `Migrasi ${totalOps} data ke Firebase Firestore berhasil dilakukan secara bertahap!`,
    };
  } catch (err: any) {
    console.error('Firebase migration error:', err);
    return {
      success: false,
      migratedCounts: {},
      message: 'Gagal migrasi ke Firebase: ' + (err?.message || 'Error tidak diketahui'),
    };
  }
}
