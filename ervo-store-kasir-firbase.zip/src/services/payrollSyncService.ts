import app from './firebase';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import { ExpenseRecord } from '../types';

/**
 * Cloud Firestore ERVO Payroll Integration Service
 * Target Database ID: ai-studio-ervoprintpayroll-c2575e0d-0e0c-4bf0-9a48-fb8db6893509
 * Collection: businessTransactions
 */

export const ERVO_PAYROLL_DB_ID = 'ai-studio-ervoprintpayroll-c2575e0d-0e0c-4bf0-9a48-fb8db6893509';
export const ERVO_PAYROLL_COLLECTION = 'businessTransactions';
export const BUSINESS_UNIT_NAME = 'ERVO STORE';
const QUEUE_STORAGE_KEY = 'strukku_payroll_sync_queue';

export interface BusinessTransactionPayload {
  id: string;
  date: string; // YYYY-MM-DD
  businessUnit: string; // "ERVO STORE"
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  paymentMethod: string;
  referenceNo: string;
  status: 'completed';
  source: 'api_sync';
  sourceApp: string;
  createdAt: string; // ISO 8601
}

// Singleton Firestore instance for the ERVO Payroll database
let payrollDbInstance: ReturnType<typeof getFirestore> | null = null;

export function getPayrollFirestore() {
  if (!payrollDbInstance) {
    payrollDbInstance = getFirestore(app, ERVO_PAYROLL_DB_ID);
  }
  return payrollDbInstance;
}

/**
 * Normalize any date input into YYYY-MM-DD
 */
export function formatToISODate(dateVal?: any): string {
  if (!dateVal) {
    return new Date().toISOString().split('T')[0];
  }
  if (dateVal instanceof Date) {
    return isNaN(dateVal.getTime()) ? new Date().toISOString().split('T')[0] : dateVal.toISOString().split('T')[0];
  }
  const str = String(dateVal).trim();
  // Check if already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }
  // Check if DD/MM/YYYY
  const slashParts = str.split('/');
  if (slashParts.length === 3) {
    const [d, m, y] = slashParts;
    const year = y.length === 2 ? `20${y}` : y;
    return `${year.padStart(4, '20')}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }
  // Try Date parse
  try {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
  } catch {}

  return new Date().toISOString().split('T')[0];
}

/**
 * Get current application origin safely
 */
export function getSourceAppOrigin(): string {
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    return window.location.origin;
  }
  return '';
}

/**
 * Write a transaction document to ERVO Payroll Firestore
 */
export async function sendPayloadToPayroll(payload: BusinessTransactionPayload): Promise<boolean> {
  try {
    const db = getPayrollFirestore();
    const docRef = doc(db, ERVO_PAYROLL_COLLECTION, payload.id);
    await setDoc(docRef, payload, { merge: true });
    console.log(`[ERVO Payroll Sync] Berhasil sinkronisasi data (${payload.id}) ke ERVO Payroll.`);
    return true;
  } catch (err) {
    console.warn(`[ERVO Payroll Sync] Gagal mengirim data (${payload.id}), disimpan di antrean offline:`, err);
    saveToOfflineQueue(payload);
    return false;
  }
}

/**
 * Sync Cashier Transaction (Struk Pembayaran / Penjualan Kasir)
 */
export async function syncCashierTransactionToPayroll(invoiceData: any): Promise<boolean> {
  if (!invoiceData) return false;

  const receiptNumber = String(
    invoiceData.invoiceNo || 
    invoiceData.noInvoice || 
    invoiceData.receiptNumber || 
    invoiceData.id || 
    ''
  ).trim();

  if (!receiptNumber) {
    console.warn('[ERVO Payroll Sync] Invoice number tidak ditemukan untuk sinkronisasi.');
    return false;
  }

  // Calculate actual payment amount
  const rawDp = typeof invoiceData.dp === 'number' ? invoiceData.dp : parseFloat(String(invoiceData.dp || 0).replace(',', '.')) || 0;
  const rawTotal = typeof invoiceData.total === 'number' ? invoiceData.total : parseFloat(String(invoiceData.total || 0).replace(',', '.')) || 0;
  const rawKembalian = typeof invoiceData.kembalian === 'number' ? invoiceData.kembalian : parseFloat(String(invoiceData.kembalian || 0).replace(',', '.')) || 0;

  // Determine amount:
  // If DP > 0: if overpaid (kembalian > 0), the actual paid is total. Otherwise, rawDp.
  // If DP == 0, amount is rawTotal
  let totalBayar = rawTotal;
  if (rawDp > 0) {
    totalBayar = rawKembalian > 0 ? rawTotal : rawDp;
  } else if (rawTotal > 0) {
    totalBayar = rawTotal;
  } else if (typeof invoiceData.amount === 'number') {
    totalBayar = invoiceData.amount;
  }

  // Determine payment method
  let metodeBayar = String(invoiceData.payMethod || invoiceData.metodePembayaran || invoiceData.paymentMethod || '').trim();
  if (!metodeBayar || (rawDp === 0 && rawTotal > 0 && invoiceData.status === 'BELUM BAYAR')) {
    metodeBayar = rawDp > 0 ? 'Tunai' : 'Belum Bayar';
  }

  const payload: BusinessTransactionPayload = {
    id: 'str-' + receiptNumber,
    date: formatToISODate(invoiceData.tanggal || invoiceData.date),
    businessUnit: BUSINESS_UNIT_NAME,
    type: 'income',
    category: 'Penjualan Kasir',
    amount: totalBayar,
    description: 'Penjualan Kasir No ' + receiptNumber,
    paymentMethod: metodeBayar,
    referenceNo: receiptNumber,
    status: 'completed',
    source: 'api_sync',
    sourceApp: getSourceAppOrigin(),
    createdAt: new Date().toISOString(),
  };

  return sendPayloadToPayroll(payload);
}

/**
 * Sync Kas Keluar (Expense) to ERVO Payroll
 */
export async function syncExpenseToPayroll(expense: ExpenseRecord | any): Promise<boolean> {
  if (!expense) return false;

  const rawId = String(expense.id || '').trim();
  const expenseId = rawId || ('EXP-' + Date.now().toString().slice(-6));
  const cleanDocId = rawId.startsWith('EXP-') ? 'exp-' + rawId : 'exp-' + expenseId;

  const nominal = typeof expense.nominal === 'number' 
    ? expense.nominal 
    : parseFloat(String(expense.nominal || expense.amount || 0).replace(',', '.')) || 0;

  const kategori = expense.kategori || expense.category || 'Beban Operasional';
  const keterangan = expense.keterangan || expense.deskripsi || expense.description || '';
  const descriptionText = keterangan ? `Kas Keluar: ${keterangan}` : `Kas Keluar No ${expenseId}`;
  const metodeBayar = expense.metodePembayaran || expense.metode || expense.paymentMethod || 'Tunai';

  const payload: BusinessTransactionPayload = {
    id: cleanDocId,
    date: formatToISODate(expense.tanggal || expense.date),
    businessUnit: BUSINESS_UNIT_NAME,
    type: 'expense',
    category: kategori,
    amount: nominal,
    description: descriptionText,
    paymentMethod: metodeBayar,
    referenceNo: expenseId,
    status: 'completed',
    source: 'api_sync',
    sourceApp: getSourceAppOrigin(),
    createdAt: new Date().toISOString(),
  };

  return sendPayloadToPayroll(payload);
}

/**
 * Sync Pelunasan Piutang (Debt Repayment) to ERVO Payroll
 */
export async function syncPelunasanToPayroll(pelunasanData: any): Promise<boolean> {
  if (!pelunasanData) return false;

  const receiptNumber = String(
    pelunasanData.invoiceNo || 
    pelunasanData.noInvoice || 
    ''
  ).trim();

  if (!receiptNumber) return false;

  const bayar = typeof pelunasanData.jumlahBayar === 'number'
    ? pelunasanData.jumlahBayar
    : parseFloat(String(pelunasanData.jumlahBayar || pelunasanData.bayar || 0).replace(',', '.')) || 0;

  const timestampSuffix = Date.now().toString().slice(-6);
  const docId = `str-${receiptNumber}-pel-${timestampSuffix}`;
  const metodeBayar = pelunasanData.payMethod || pelunasanData.metode || 'Tunai';

  const payload: BusinessTransactionPayload = {
    id: docId,
    date: formatToISODate(pelunasanData.tanggal || pelunasanData.date),
    businessUnit: BUSINESS_UNIT_NAME,
    type: 'income',
    category: 'Pelunasan Piutang',
    amount: bayar,
    description: `Pelunasan Piutang No ${receiptNumber}`,
    paymentMethod: metodeBayar,
    referenceNo: receiptNumber,
    status: 'completed',
    source: 'api_sync',
    sourceApp: getSourceAppOrigin(),
    createdAt: new Date().toISOString(),
  };

  return sendPayloadToPayroll(payload);
}

// Offline Queue Handling
function saveToOfflineQueue(payload: BusinessTransactionPayload) {
  try {
    const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
    const queue: BusinessTransactionPayload[] = raw ? JSON.parse(raw) : [];
    // Prevent duplicate entries with same id
    const filtered = queue.filter(item => item.id !== payload.id);
    filtered.push(payload);
    localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.error('[ERVO Payroll Sync] Gagal menyimpan antrean offline:', e);
  }
}

export async function flushPayrollOfflineQueue(): Promise<number> {
  try {
    const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
    if (!raw) return 0;
    const queue: BusinessTransactionPayload[] = JSON.parse(raw);
    if (!Array.isArray(queue) || queue.length === 0) return 0;

    const remaining: BusinessTransactionPayload[] = [];
    let syncedCount = 0;

    for (const item of queue) {
      try {
        const db = getPayrollFirestore();
        const docRef = doc(db, ERVO_PAYROLL_COLLECTION, item.id);
        await setDoc(docRef, item, { merge: true });
        syncedCount++;
      } catch (err) {
        remaining.push(item);
      }
    }

    if (remaining.length > 0) {
      localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(remaining));
    } else {
      localStorage.removeItem(QUEUE_STORAGE_KEY);
    }

    if (syncedCount > 0) {
      console.log(`[ERVO Payroll Sync] Berhasil mengunggah ${syncedCount} transaksi dari antrean offline.`);
    }

    return syncedCount;
  } catch (e) {
    console.error('[ERVO Payroll Sync] Error flush offline queue:', e);
    return 0;
  }
}

// Auto-flush queue when browser comes back online
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    flushPayrollOfflineQueue();
  });
  // Also attempt once at startup after a brief delay
  setTimeout(() => {
    flushPayrollOfflineQueue();
  }, 4000);
}
