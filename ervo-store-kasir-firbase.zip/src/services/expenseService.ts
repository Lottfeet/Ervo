import { ExpenseRecord } from '../types';
import { addExpenseRemote, deleteExpenseRemote, getDeletedExpenses, addDeletedExpense, removeDeletedExpense } from './gasService';
import { saveExpenseFirebase, deleteExpenseFirebase } from './firebaseService';
import { syncExpenseToPayroll } from './payrollSyncService';

const STORAGE_KEY = 'strukku_company_expenses';

export function deduplicateExpenses(list: ExpenseRecord[]): ExpenseRecord[] {
  if (!Array.isArray(list)) return [];
  const seen = new Set<string>();
  const result: ExpenseRecord[] = [];
  for (const item of list) {
    if (!item) continue;
    const key = item.id && item.id.trim() ? item.id.trim() : `${item.tanggal}-${item.keterangan}-${item.nominal}`;
    if (!seen.has(key)) {
      seen.add(key);
      result.push(item);
    }
  }
  return result;
}

// Sample initial expense data for immediate reporting demo
const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: 'EXP-101',
    tanggal: new Date().toISOString().split('T')[0],
    kategori: 'Bahan Baku',
    keterangan: 'Pembelian Kertas Art Paper 230g A3+ (5 Pack)',
    nominal: 450000,
    pj: 'Admin / Kasir',
  },
  {
    id: 'EXP-102',
    tanggal: new Date().toISOString().split('T')[0],
    kategori: 'Sewa & Utilitas',
    keterangan: 'Pembayaran Token Listrik Operasional Workshop',
    nominal: 250000,
    pj: 'Admin / Kasir',
  },
  {
    id: 'EXP-103',
    tanggal: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    kategori: 'Maintenance & Service',
    keterangan: 'Servis Head & Isi Ulang Tinta Plotter Roland',
    nominal: 350000,
    pj: 'Teknisi Studio',
  },
  {
    id: 'EXP-104',
    tanggal: new Date(Date.now() - 86400000 * 4).toISOString().split('T')[0],
    kategori: 'Operasional & Makanan',
    keterangan: 'Snack & Galon Air Minum Karyawan Cetak',
    nominal: 85000,
    pj: 'Kasir',
  },
];

export function getStoredExpenses(): ExpenseRecord[] {
  try {
    let raw = localStorage.getItem(STORAGE_KEY);
    if (!raw || raw === '[]') {
      const alt = localStorage.getItem('strukku_expenses');
      if (alt && alt !== '[]') {
        raw = alt;
      }
    }

    // Safety fallback: if local storage is empty, auto-recover from the latest checkpoint snapshot
    if (!raw || raw === '[]') {
      try {
        const histRaw = localStorage.getItem('strukku_backup_checkpoints_history');
        if (histRaw) {
          const list = JSON.parse(histRaw);
          if (Array.isArray(list)) {
            for (const cp of list) {
              if (cp && cp.id && cp.counts && cp.counts.expenses > 0) {
                const payloadRaw = localStorage.getItem(`strukku_checkpoint_payload_${cp.id}`);
                if (payloadRaw) {
                  const parsedPl = JSON.parse(payloadRaw);
                  if (Array.isArray(parsedPl.expenses) && parsedPl.expenses.length > 0) {
                    raw = JSON.stringify(parsedPl.expenses);
                    localStorage.setItem(STORAGE_KEY, raw);
                    localStorage.setItem('strukku_expenses', raw);
                    break;
                  }
                }
              }
            }
          }
        }
      } catch {}
    }

    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      const deletedSet = getDeletedExpenses();
      let nonDeleted = parsed.filter((it: ExpenseRecord) => {
        if (!it) return false;
        const key = it.id ? it.id.trim().toLowerCase() : '';
        return !key || !deletedSet.has(key);
      });

      // Self-healing guard: if parsed had items (e.g. 104 items) but deletedSet falsely wiped all of them out
      // (due to past docChanges 'removed' bug), do NOT destroy the records! Preserve the records and clear false tombstones.
      if (parsed.length > 0 && nonDeleted.length === 0) {
        nonDeleted = parsed;
        localStorage.removeItem('strukku_deleted_expenses');
      }

      const unique = deduplicateExpenses(nonDeleted);
      if (unique.length > 0 && unique.length !== parsed.length) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
        localStorage.setItem('strukku_expenses', JSON.stringify(unique));
      }
      return unique;
    }
    return [];
  } catch (e) {
    console.error('Failed to parse expenses from localStorage:', e);
    return [];
  }
}

export function saveExpenses(expenses: ExpenseRecord[]): void {
  try {
    const deletedSet = getDeletedExpenses();
    const safeExpenses = (expenses || []).filter((it: ExpenseRecord) => {
      if (!it) return false;
      const key = it.id ? it.id.trim().toLowerCase() : '';
      return !key || !deletedSet.has(key);
    });
    const unique = deduplicateExpenses(safeExpenses);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(unique));
    localStorage.setItem('strukku_expenses', JSON.stringify(unique));
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('strukku-expenses-updated', { detail: unique }));
      }, 0);
    }
  } catch (e) {
    console.error('Failed to save expenses to localStorage:', e);
  }
}

export function addExpenseRecord(expense: Omit<ExpenseRecord, 'id'>): ExpenseRecord {
  const newId = 'EXP-' + Date.now().toString().slice(-6);
  removeDeletedExpense(newId);
  const current = getStoredExpenses();
  const newRecord: ExpenseRecord = {
    ...expense,
    id: newId,
  };
  const updated = deduplicateExpenses([newRecord, ...current]);
  saveExpenses(updated);

  // Sync to Google Sheets in background
  addExpenseRemote(newRecord).catch((err) =>
    console.error('Failed to sync new expense to Google Sheets:', err)
  );

  // Sync to Firebase in background
  saveExpenseFirebase(newRecord).catch((err) =>
    console.error('Failed to sync new expense to Firebase:', err)
  );

  // Sync to ERVO Payroll Cloud Firestore in background
  syncExpenseToPayroll(newRecord).catch((err) =>
    console.error('Failed to sync new expense to ERVO Payroll:', err)
  );

  return newRecord;
}

export function updateExpenseRecord(id: string, expense: Partial<ExpenseRecord>): boolean {
  const current = getStoredExpenses();
  const idx = current.findIndex((e) => e.id === id);
  if (idx === -1) return false;
  current[idx] = { ...current[idx], ...expense };
  const updated = deduplicateExpenses(current);
  saveExpenses(updated);

  // Sync updated record to Google Sheets
  addExpenseRemote(updated[idx]).catch((err) =>
    console.error('Failed to sync updated expense to Google Sheets:', err)
  );

  // Sync updated record to Firebase
  saveExpenseFirebase(updated[idx]).catch((err) =>
    console.error('Failed to sync updated expense to Firebase:', err)
  );

  // Sync updated record to ERVO Payroll Cloud Firestore
  syncExpenseToPayroll(updated[idx]).catch((err) =>
    console.error('Failed to sync updated expense to ERVO Payroll:', err)
  );

  return true;
}

export function deleteExpenseRecord(id: string): boolean {
  const cleanId = (id || '').trim();
  if (!cleanId) return false;

  // 1. Immediately record tombstone
  addDeletedExpense(cleanId);

  // 2. Filter local storage immediately
  const current = getStoredExpenses();
  const filtered = current.filter((e) => e && e.id && e.id.trim().toLowerCase() !== cleanId.toLowerCase());
  saveExpenses(filtered);

  // 3. Sync deletion to Google Sheets in background
  deleteExpenseRemote(cleanId).catch((err) =>
    console.error('Failed to delete expense from Google Sheets:', err)
  );

  // 4. Sync deletion and tombstone to Firebase for cross-device sync
  deleteExpenseFirebase(cleanId).catch((err) =>
    console.error('Failed to delete expense from Firebase:', err)
  );

  return true;
}
