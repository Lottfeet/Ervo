import { Invoice, StoreSettings, PelunasanRecord } from '../types';
import { fRp, fNum, fDec, escHtml, computeItemTotal } from './formatters';
import { getPelunasanHistory, sortPelunasanHistoryAsc } from '../services/gasService';

function resolveHistoryList(data: Partial<Invoice>): PelunasanRecord[] {
  const invoiceNo = data.invoiceNo || '';
  const backendHist = Array.isArray((data as any).historiPelunasan)
    ? (data as any).historiPelunasan
    : Array.isArray((data as any).history)
    ? (data as any).history
    : null;

  const rawList: PelunasanRecord[] = backendHist !== null 
    ? backendHist 
    : (invoiceNo ? getPelunasanHistory(invoiceNo) : []);

  const sorted = sortPelunasanHistoryAsc(rawList);

  const totalInvoice = Number(data.total || 0);
  const totalPelunasan = sorted.reduce((acc, item) => acc + Number(item.jumlahBayar || 0), 0);
  const sisaVal = data.sisa !== undefined ? Number(data.sisa) : totalInvoice;
  const calculatedDp = Math.max(0, totalInvoice - sisaVal - totalPelunasan);
  const dpAmount = (data.dp !== undefined && Number(data.dp) > 0) ? Number(data.dp) : calculatedDp;

  let currentBalance = Math.max(0, totalInvoice - dpAmount);

  return sorted.map((hItem) => {
    const bayar = Number(hItem.jumlahBayar || 0);
    currentBalance = Math.max(0, currentBalance - bayar);
    return {
      ...hItem,
      newSisa: currentBalance,
    };
  });
}

export function calculateCurrentSisa(data: Partial<Invoice>): number {
  const historyItems = resolveHistoryList(data);
  if (historyItems.length > 0) {
    const last = historyItems[historyItems.length - 1];
    return last.newSisa !== undefined ? last.newSisa : 0;
  }
  const total = Number(data.total || 0);
  const dp = Number(data.dp || 0);
  if (data.sisa !== undefined && data.sisa !== null) {
    return Number(data.sisa);
  }
  return Math.max(0, total - dp);
}

export function openPrintWindow(htmlContent: string, title: string) {
  const win = window.open('', '_blank', 'width=800,height=750');
  if (!win) {
    alert('Pop-up terblokir oleh browser. Izinkan pop-up untuk mencetak struk/invoice.');
    return;
  }

  const fullContent = htmlContent.includes('<html')
    ? htmlContent
    : `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>${escHtml(title)}</title>
<style>
  @page { size: 80mm auto; margin: 2mm; }
  @media print { body { margin: 0; width: 80mm; } }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { width: 80mm; font-family: 'Courier New', Courier, monospace; font-size: 10px; color: #000; line-height: 1.4; padding: 2mm; }
  .center { text-align: center; }
  .r { text-align: right; }
  .bold { font-weight: bold; }
  table { width: 100%; border-collapse: collapse; }
</style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

  win.document.write(fullContent);
  win.document.close();
  win.focus();
  setTimeout(() => {
    try {
      win.print();
    } catch {
      // Ignored
    }
  }, 500);
}

export function generateThermalHTML(data: Partial<Invoice>, s: StoreSettings): string {
  if (!data || !data.items || data.items.length === 0) {
    return `<div style="text-align:center;padding:30px 10px;color:#78716C;">
      <div style="font-size:24px;margin-bottom:8px;">🧾</div>
      <p style="font-size:10px;">Tambahkan jasa/produk untuk melihat preview struk</p>
    </div>`;
  }

  let h = '';
  h += `<div style="text-align:center;font-weight:800;font-size:13px;letter-spacing:1px;text-transform:uppercase;">${escHtml(s.name)}</div>`;
  if (s.address) h += `<div style="text-align:center;font-size:9px;font-weight:600;margin-top:2px;">${escHtml(s.address)}</div>`;
  if (s.phone) h += `<div style="text-align:center;font-size:9px;font-weight:600;margin-top:1px;">Telp/WA: ${escHtml(s.phone)}</div>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td style="width:60px;">No</td><td>: ${escHtml(data.invoiceNo || '')}</td></tr>
      <tr><td>Tgl</td><td>: ${escHtml(data.date || '')} ${escHtml(data.time || '')}</td></tr>
      <tr><td>Kasir</td><td>: ${escHtml(data.cashier || s.cashier || 'Admin')}</td></tr>
      <tr><td>Pelanggan</td><td>: ${escHtml(data.customer || 'Umum')}</td></tr>
      ${data.deadline ? `<tr><td>Est Selesai</td><td>: ${escHtml(data.deadline)}</td></tr>` : ''}
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="width:60%;">Jasa/Item</td><td style="width:15%;text-align:right;">Qty</td><td style="width:25%;text-align:right;">Total</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">`;
  
  data.items.forEach((item) => {
    const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
    const nameShort = String(item.nama || '').substring(0, 100);
    const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
    const sizeStr = hasDim ? ` (${fDec(item.panjang, 2)}x${fDec(item.lebar, 2)}m)` : '';
    h += `<tr><td style="width:60%;padding:1px 0;vertical-align:top;">${escHtml(nameShort)}${escHtml(sizeStr)}</td><td style="width:15%;text-align:right;padding:1px 0;vertical-align:top;">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td><td style="width:25%;text-align:right;padding:1px 0;vertical-align:top;">${fNum(total)}</td></tr>`;

    const diskon = parseFloat(item.diskonItem as any) || 0;
    const hargaAsli = parseFloat(item.harga as any) || 0;
    const hargaJadi = Math.max(0, hargaAsli - diskon);
    const satuanLabel = hasDim ? '/m²' : `/${item.satuan || 'pcs'}`;

    const subParts: string[] = [];
    if (diskon > 0) {
      subParts.push(`@${fNum(hargaAsli)}<span style="color:#B91C1C;"> -${fNum(diskon)}</span> =${fNum(hargaJadi)}${satuanLabel}`);
    } else {
      subParts.push(`@${fNum(hargaJadi)}${satuanLabel}`);
    }
    if (item.bahan) subParts.push(escHtml(item.bahan));
    if (item.catatan) subParts.push(escHtml(item.catatan));
    h += `<tr><td colspan="3" style="font-size:9px;padding:0 0 3px 3px;color:#444;">${subParts.join(' · ')}</td></tr>`;
  });

  h += `</table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td>Subtotal</td><td style="text-align:right;">${fNum(data.subtotal || 0)}</td></tr>
      ${(data.discAmt || 0) > 0 ? `<tr><td>Diskon ${data.discPct || 0}%</td><td style="text-align:right;">-${fNum(data.discAmt!)}</td></tr>` : ''}
      ${(data.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td style="text-align:right;">-${fNum(data.negoAmt!)}</td></tr>` : ''}
      ${(data.taxAmt || 0) > 0 ? `<tr><td>PPN ${data.taxPct || 0}%</td><td style="text-align:right;">${fNum(data.taxAmt!)}</td></tr>` : ''}
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:5px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="font-size:12px;">TOTAL</td><td style="text-align:right;font-size:12px;">${fNum(data.total || 0)}</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr style="font-weight:bold;"><td>DP / Bayar Muka${Number(data.dp || 0) > 0 && data.payMethod && data.payMethod !== '-' ? ` (${escHtml(data.payMethod)})` : ''}</td><td style="text-align:right;">${fNum(data.dp || 0)}</td></tr>
      <tr style="font-weight:bold;"><td>Sisa Bayar</td><td style="text-align:right;color:${(calculateCurrentSisa(data)) > 0 ? '#B91C1C' : '#15803D'};">${fNum(calculateCurrentSisa(data))}</td></tr>
      ${(data.kembalian || 0) > 0 ? `<tr style="font-weight:bold;"><td style="color:#15803D;">Kembalian</td><td style="text-align:right;color:#15803D;">${fNum(data.kembalian!)}</td></tr>` : ''}
  </table>`;

  const rekeningVal = s.rekening || '';
  if (rekeningVal) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div style="text-align:center;font-size:8.5px;font-weight:bold;margin-top:2px;">REKENING PEMBAYARAN:</div>`;
    h += `<div style="text-align:center;font-size:8.5px;font-weight:bold;white-space:pre-line;">${escHtml(rekeningVal)}</div>`;
  }

  const historyItems = resolveHistoryList(data);
  if (historyItems.length > 0) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div style="text-align:center;font-weight:bold;font-size:10px;margin:3px 0;letter-spacing:0.5px;">HISTORI PEMBAYARAN & ANGSURAN</div>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:3px 0;"></div>';
    h += `<table style="font-size:9px;width:100%;border-collapse:collapse;">`;
    if (Number(data.dp || 0) > 0) {
      h += `<tr><td style="font-weight:bold;">1. DP / Bayar Muka${data.payMethod && data.payMethod !== '-' ? ` (${escHtml(data.payMethod)})` : ''}</td><td style="text-align:right;font-weight:bold;">${fNum(data.dp || 0)}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(data.date || '')} ${escHtml(data.time || '')}</td></tr>`;
    }

    historyItems.forEach((hItem, idx) => {
      h += `<tr><td style="font-weight:bold;">${idx + 2}. Angsuran #${idx + 1} (${escHtml(hItem.payMethod || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(hItem.jumlahBayar || 0)}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')} · Sisa: ${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}${hItem.catatan ? ` (${escHtml(hItem.catatan)})` : ''}</td></tr>`;
    });

    h += `</table>`;
  }

  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  if (s.footer) h += `<div style="text-align:center;font-weight:bold;font-size:11px;margin-top:6px;">${escHtml(s.footer)}</div>`;
  return h;
}

export function generateA5HTML(data: Partial<Invoice>, s: StoreSettings): string {
  const orderDateStr = data.date || '';
  const deadlineStr = data.deadline || '';
  const customer = data.customer || 'Umum';
  const sisa = calculateCurrentSisa(data);

  const phoneVal = data.customerPhone ? escHtml(data.customerPhone) : '';
  const addressVal = data.customerAddress ? escHtml(data.customerAddress) : '';

  let contactAndAddress = '';
  if (phoneVal && addressVal) {
    contactAndAddress = `${phoneVal} &bull; ${addressVal}`;
  } else if (phoneVal) {
    contactAndAddress = phoneVal;
  } else if (addressVal) {
    contactAndAddress = addressVal;
  } else {
    contactAndAddress = '<span style="color:#999;">—</span>';
  }

  let rows = '';
  (data.items || []).forEach((item, i) => {
    const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
    const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
    const ukuranStr = hasDim ? `${fDec(item.panjang, 2)} × ${fDec(item.lebar, 2)} m` : '-';
    const areaStr = hasDim ? `${fDec(parseFloat(item.panjang as any) * parseFloat(item.lebar as any), 2)} m²` : '-';
    const diskonItemAmt = parseFloat(item.diskonItem as any) || 0;
    const hargaCell = diskonItemAmt > 0
      ? `${fNum(item.harga || 0)}<br><span style="color:#B91C1C;font-size:8px;">-${fNum(diskonItemAmt)}</span>`
      : `${fNum(item.harga || 0)}`;

    rows += `<tr>
        <td class="tc">${i + 1}</td>
        <td><strong>${escHtml(item.nama || '')}</strong></td>
        <td>${escHtml(ukuranStr)}</td>
        <td>${escHtml(areaStr)}</td>
        <td class="tc">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td>
        <td>${escHtml(item.satuan || '')}</td>
        <td>${escHtml(item.bahan || '-')}</td>
        <td>${escHtml(item.catatan || '-')}</td>
        <td class="tr">${hargaCell}</td>
        <td class="tr bold">${fNum(total)}</td>
    </tr>`;
  });

  const historyItems = resolveHistoryList(data);
  const dpAmount = Number(data.dp || 0);
  const hasHistory = dpAmount > 0 || historyItems.length > 0;

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Invoice ${escHtml(data.invoiceNo || '')}</title>
<style>
    @page { size: A5 landscape; margin: 8mm; }
    @media print { body { margin:0; } }
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size:10px; color:#1a1a1a; }
    .page { width:100%; }
    .inv-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; padding-bottom:8px; border-bottom:2.5px solid #C2410C; }
    .inv-brand .bname { font-size:18px; font-weight:800; color:#C2410C; letter-spacing:0.5px; }
    .inv-brand .bsub { font-size:9px; color:#555; margin-top:2px; }
    .inv-title-block { text-align:right; }
    .inv-title { font-size:20px; font-weight:800; color:#C2410C; letter-spacing:1px; }
    .inv-no { font-size:9px; color:#555; margin-top:2px; }
    .inv-info { display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:8px; }
    .inv-info-box { background:#FFF7ED; border:1px solid #FED7AA; border-radius:6px; padding:5px 8px; }
    .inv-info-box-split { display:flex; gap:8px; align-items:stretch; }
    .split-col { flex:1; min-width:0; }
    .split-col-border { border-left:1px solid #FED7AA; padding-left:8px; }
    .inv-info-box .lbl { font-size:8px; color:#9A3412; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:2px; }
    .inv-info-box .val { font-size:10px; font-weight:600; color:#1a1a1a; word-break:break-word; }
    .inv-info-box .val.big { font-size:12px; font-weight:800; }
    table.items { width:100%; border-collapse:collapse; margin-bottom:8px; }
    table.items thead tr { background:#C2410C; color:white; }
    table.items thead th { padding:5px 6px; text-align:left; font-size:8.5px; font-weight:700; white-space:nowrap; }
    table.items tbody tr { border-bottom:1px solid #E7E5E4; }
    table.items tbody tr:nth-child(even) { background:#FAFAF9; }
    table.items tbody td { padding:5px 6px; font-size:9px; vertical-align:top; }
    .tc { text-align:center; }
    .tr { text-align:right; }
    .bold { font-weight:700; }
    .inv-summary { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; gap:12px; }
    .inv-rekening-box { flex:1; max-width:320px; background:#FFF7ED; border:1px solid #FED7AA; border-radius:6px; padding:6px 8px; }
    .inv-rekening-box .lbl { font-size:8px; color:#C2410C; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:3px; }
    .inv-rekening-box .val { font-size:9.5px; font-weight:700; color:#1A1A1A; line-height:1.4; white-space:pre-line; }
    .inv-summary table { width:240px; border-collapse:collapse; }
    .inv-summary td { padding:3px 6px; font-size:10px; }
    .inv-summary .total-row td { font-size:12px; font-weight:800; border-top:2px solid #C2410C; padding-top:4px; color:#C2410C; }
    .inv-summary .dp-row td { color:#15803D; font-weight:700; }
    .inv-summary .sisa-row td { color:#B91C1C; font-weight:800; font-size:11px; border-top:1px dashed #ccc; padding-top:3px; }
    .inv-footer { display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-top:10px; padding-top:8px; border-top:1px solid #E7E5E4; }
    .sig-box { text-align:center; }
    .sig-box .sig-title { font-size:9px; font-weight:700; margin-bottom:28px; color:#555; }
    .sig-box .sig-line { border-top:1px solid #333; margin:0 10px; }
    .sig-box .sig-name { font-size:9px; margin-top:3px; font-weight:600; }
    .inv-note { font-size:8px; color:#777; margin-top:6px; text-align:center; font-style:italic; }
    .status-lunas { background:#15803D; color:white; padding:2px 10px; border-radius:20px; font-size:9px; font-weight:700; display:inline-block; }
    .status-dp { background:#D97706; color:white; padding:2px 10px; border-radius:20px; font-size:9px; font-weight:700; display:inline-block; }
</style>
</head>
<body>
<div class="page">
    <div class="inv-header">
        <div class="inv-brand">
            <div class="bname">${escHtml(s.name.toUpperCase())}</div>
            <div class="bsub">${escHtml(s.address)}${s.phone ? ' &nbsp;|&nbsp; Telp/WA: ' + escHtml(s.phone) : ''}</div>
        </div>
        <div class="inv-title-block">
            <div class="inv-title">INVOICE</div>
            <div class="inv-no">No. ${escHtml(data.invoiceNo || '')}&nbsp;&nbsp;
                ${sisa <= 0 ? '<span class="status-lunas">LUNAS</span>' : '<span class="status-dp">DP / BELUM LUNAS</span>'}
            </div>
        </div>
    </div>

    <div class="inv-info">
        <div class="inv-info-box">
            <div class="lbl">Pelanggan</div>
            <div class="val big">${escHtml(customer)}</div>
        </div>
        <div class="inv-info-box">
            <div class="lbl">No. Tlp / WA</div>
            <div class="val">${phoneVal || '<span style="color:#999;">—</span>'}</div>
        </div>
        <div class="inv-info-box">
            <div class="lbl">Alamat</div>
            <div class="val">${addressVal || '<span style="color:#999;">—</span>'}</div>
        </div>
        <div class="inv-info-box inv-info-box-split">
            <div class="split-col">
                <div class="lbl">Tanggal Order</div>
                <div class="val">${escHtml(orderDateStr)} ${escHtml(data.time || '')}</div>
            </div>
            <div class="split-col split-col-border">
                <div class="lbl">Estimasi Selesai</div>
                <div class="val">${deadlineStr ? escHtml(deadlineStr) : '<span style="color:#999;">—</span>'}</div>
            </div>
        </div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th style="width:20px;" class="tc">No</th>
                <th>Nama Jasa / Item</th>
                <th>Ukuran</th>
                <th>Luas</th>
                <th class="tc">Qty</th>
                <th>Satuan</th>
                <th>Bahan / Finishing</th>
                <th>Keterangan</th>
                <th class="tr">Harga Sat.</th>
                <th class="tr">Total</th>
            </tr>
        </thead>
        <tbody>${rows}</tbody>
    </table>

    <div class="inv-summary">
        <div class="inv-rekening-box">
            <div class="lbl">💳 No. Rekening Pembayaran (Transfer Bank)</div>
            <div class="val">${s.rekening ? escHtml(s.rekening) : '<span style="color:#78350F;font-weight:normal;font-style:italic;">(Atur No. Rekening di Google Sheets "Rekening" atau Pengaturan)</span>'}</div>
            <div style="font-size:8px;color:#78350F;margin-top:3px;">* Mohon konfirmasi bukti transfer jika pembayaran dilakukan via Transfer Bank.</div>
        </div>
        <table>
            <tr><td>Subtotal</td><td class="tr">${fNum(data.subtotal || 0)}</td></tr>
            ${(data.discAmt || 0) > 0 ? `<tr><td>Diskon ${data.discPct || 0}%</td><td class="tr" style="color:#B91C1C;">- ${fNum(data.discAmt!)}</td></tr>` : ''}
            ${(data.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td class="tr" style="color:#B91C1C;">- ${fNum(data.negoAmt!)}</td></tr>` : ''}
            ${(data.taxAmt || 0) > 0 ? `<tr><td>PPN ${data.taxPct || 0}%</td><td class="tr">${fNum(data.taxAmt!)}</td></tr>` : ''}
            <tr class="total-row"><td>TOTAL</td><td class="tr">${fNum(data.total || 0)}</td></tr>
            <tr class="dp-row"><td>DP / Bayar Muka${dpAmount > 0 && data.payMethod && data.payMethod !== '-' ? ` (${escHtml(data.payMethod)})` : ''}</td><td class="tr">${fNum(dpAmount)}</td></tr>
            <tr class="sisa-row"><td>Sisa Bayar</td><td class="tr">${fNum(sisa)}</td></tr>
            ${(data.kembalian || 0) > 0 ? `<tr style="font-weight:800;color:#15803D;"><td>Kembalian</td><td class="tr">${fNum(data.kembalian!)}</td></tr>` : ''}
        </table>
    </div>

    ${hasHistory ? `
    <div style="margin-top:6px;margin-bottom:8px;padding:6px 8px;background:#FFF7ED;border:1px solid #FED7AA;border-radius:6px;">
        <div style="font-size:9px;font-weight:800;color:#C2410C;margin-bottom:4px;letter-spacing:0.5px;">
            HISTORI PEMBAYARAN & ANGSURAN PIUTANG
        </div>
        <table style="width:100%;font-size:8.5px;border-collapse:collapse;">
            <thead>
                <tr style="background:#EA580C;color:white;">
                    <th style="padding:3px 5px;text-align:center;width:24px;">No</th>
                    <th style="padding:3px 5px;text-align:left;">Jenis Pembayaran</th>
                    <th style="padding:3px 5px;text-align:left;">Tanggal & Waktu</th>
                    <th style="padding:3px 5px;text-align:left;">Metode</th>
                    <th style="padding:3px 5px;text-align:right;">Jumlah Bayar</th>
                    <th style="padding:3px 5px;text-align:right;">Sisa Piutang</th>
                </tr>
            </thead>
            <tbody>
                ${dpAmount > 0 ? `
                <tr style="border-bottom:1px solid #FED7AA;background:#FFFFFF;">
                    <td style="padding:3px 5px;text-align:center;">1</td>
                    <td style="padding:3px 5px;font-weight:bold;">DP / Pembayaran Awal</td>
                    <td style="padding:3px 5px;">${escHtml(orderDateStr)} ${escHtml(data.time || '')}</td>
                    <td style="padding:3px 5px;">${escHtml(data.payMethod || (data as any).metodePembayaran || 'Tunai')}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:#15803D;">${fNum(dpAmount)}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;">${fNum(Math.max(0, (data.total || 0) - dpAmount))}</td>
                </tr>
                ` : ''}
                ${historyItems.map((hItem, idx) => {
                  const rowNum = dpAmount > 0 ? idx + 2 : idx + 1;
                  return `
                <tr style="border-bottom:1px solid #FED7AA;background:${idx % 2 === 0 ? '#FFFAF0' : '#FFFFFF'};">
                    <td style="padding:3px 5px;text-align:center;">${rowNum}</td>
                    <td style="padding:3px 5px;font-weight:bold;">Pelunasan / Angsuran #${idx + 1}</td>
                    <td style="padding:3px 5px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')}</td>
                    <td style="padding:3px 5px;">${escHtml(hItem.payMethod || 'Tunai')}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:#15803D;">${fNum(hItem.jumlahBayar || 0)}</td>
                    <td style="padding:3px 5px;text-align:right;font-weight:bold;color:${(hItem.newSisa || 0) > 0 ? '#B91C1C' : '#15803D'};">${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}</td>
                </tr>
                `;
                }).join('')}
            </tbody>
        </table>
    </div>
    ` : ''}

    <div class="inv-footer">
        <div class="sig-box">
            <div class="sig-title">Diterima Oleh (Pelanggan)</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(customer)})</div>
        </div>
        <div class="sig-box">
            <div class="sig-title">Dibuat Oleh</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(data.cashier || s.cashier || 'Admin')})</div>
        </div>
        <div class="sig-box">
            <div class="sig-title">Pimpinan / Pemilik</div>
            <div class="sig-line"></div>
            <div class="sig-name">(${escHtml(s.name)})</div>
        </div>
    </div>
    ${s.footer ? `<div class="inv-note">${escHtml(s.footer)}</div>` : ''}
</div>
</body>
</html>`;
}

export function generatePelunasanReceiptHTML(inv: any, s: StoreSettings): string {
  const bayar = inv.bayarPelunasan || inv.jumlahBayar || 0;
  const newSisa = inv.newSisa !== undefined ? inv.newSisa : 0;
  const kembalian = inv.kembalianBayar || inv.kembalian || 0;
  const payMethod = inv.payMethodBayar || inv.payMethod || (inv as any).metodePembayaran || 'Tunai';

  // Resolve items if available or retrieve from cache
  let items = Array.isArray(inv.items) && inv.items.length > 0 ? inv.items : [];
  if (items.length === 0 && inv.invoiceNo) {
    try {
      const cached = localStorage.getItem('strukku_recent_invoices');
      if (cached) {
        const list = JSON.parse(cached);
        const found = list.find((x: any) => x.invoiceNo && x.invoiceNo.trim().toLowerCase() === String(inv.invoiceNo).trim().toLowerCase());
        if (found && Array.isArray(found.items) && found.items.length > 0) {
          items = found.items;
        }
      }
    } catch {}
  }

  const orderDate = inv.orderDate || inv.invoiceDate || (inv.date && inv.paymentDate && inv.date !== inv.paymentDate ? inv.date : '');
  const paymentDate = inv.paymentDate || inv.date || '';
  const paymentTime = inv.paymentTime || inv.time || '';

  let h = '';
  h += `<div class="center bold" style="font-size:13px;letter-spacing:1px;text-align:center;">${escHtml(s.name.toUpperCase())}</div>`;
  if (s.address) h += `<div class="center" style="font-size:9px;text-align:center;">${escHtml(s.address)}</div>`;
  if (s.phone) h += `<div class="center" style="font-size:9px;text-align:center;">Telp/WA: ${escHtml(s.phone)}</div>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<div class="center bold" style="font-size:11px;letter-spacing:1px;text-align:center;font-weight:bold;">*** NOTA PELUNASAN PIUTANG ***</div>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
      <tr><td style="width:75px;">No. Invoice</td><td>: ${escHtml(String(inv.invoiceNo || ''))}</td></tr>
      ${orderDate ? `<tr><td>Tgl Order</td><td>: ${escHtml(orderDate)} ${inv.orderTime ? escHtml(inv.orderTime) : ''}</td></tr>` : ''}
      <tr><td>Tgl Bayar</td><td>: ${escHtml(paymentDate)} ${escHtml(paymentTime)}</td></tr>
      <tr><td>Kasir</td><td>: ${escHtml(inv.cashier || s.cashier || 'Admin')}</td></tr>
      <tr><td>Pelanggan</td><td>: ${escHtml(String(inv.customer || 'Umum'))}</td></tr>
      <tr><td>Metode Bayar</td><td>: ${escHtml(payMethod)}</td></tr>
      ${inv.deadline ? `<tr><td>Est Selesai</td><td>: ${escHtml(inv.deadline)}</td></tr>` : ''}
  </table>`;

  // Item / Service Details Breakdown
  if (items.length > 0) {
    h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
    h += `<table style="font-size:10px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="width:60%;">Jasa/Item</td><td style="width:15%;text-align:right;">Qty</td><td style="width:25%;text-align:right;">Total</td></tr></table>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">`;

    items.forEach((item: any) => {
      const total = item.totalItem !== undefined ? item.totalItem : computeItemTotal(item);
      const nameShort = String(item.nama || '').substring(0, 100);
      const hasDim = parseFloat(item.panjang as any) > 0 && parseFloat(item.lebar as any) > 0;
      const sizeStr = hasDim ? ` (${fDec(item.panjang, 2)}x${fDec(item.lebar, 2)}m)` : '';
      h += `<tr><td style="width:60%;padding:1px 0;vertical-align:top;">${escHtml(nameShort)}${escHtml(sizeStr)}</td><td style="width:15%;text-align:right;padding:1px 0;vertical-align:top;">${fDec(item.qty, 2).replace(/\.?0+$/, '')}</td><td style="width:25%;text-align:right;padding:1px 0;vertical-align:top;">${fNum(total)}</td></tr>`;

      const diskon = parseFloat(item.diskonItem as any) || 0;
      const hargaAsli = parseFloat(item.harga as any) || 0;
      const hargaJadi = Math.max(0, hargaAsli - diskon);
      const satuanLabel = hasDim ? '/m²' : `/${item.satuan || 'pcs'}`;

      const subParts: string[] = [];
      if (diskon > 0) {
        subParts.push(`@${fNum(hargaAsli)}<span style="color:#B91C1C;"> -${fNum(diskon)}</span> =${fNum(hargaJadi)}${satuanLabel}`);
      } else {
        subParts.push(`@${fNum(hargaJadi)}${satuanLabel}`);
      }
      if (item.bahan) subParts.push(escHtml(item.bahan));
      if (item.catatan) subParts.push(escHtml(item.catatan));
      h += `<tr><td colspan="3" style="font-size:9px;padding:0 0 3px 3px;color:#444;">${subParts.join(' · ')}</td></tr>`;
    });

    h += `</table>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<table style="font-size:10px;font-weight:bold;width:100%;border-collapse:collapse;">
        <tr><td>Subtotal</td><td style="text-align:right;">${fNum(inv.subtotal || 0)}</td></tr>
        ${(inv.discAmt || 0) > 0 ? `<tr><td>Diskon ${inv.discPct || 0}%</td><td style="text-align:right;">-${fNum(inv.discAmt!)}</td></tr>` : ''}
        ${(inv.negoAmt || 0) > 0 ? `<tr><td>Nego / Potongan</td><td style="text-align:right;">-${fNum(inv.negoAmt!)}</td></tr>` : ''}
        ${(inv.taxAmt || 0) > 0 ? `<tr><td>PPN ${inv.taxPct || 0}%</td><td style="text-align:right;">${fNum(inv.taxAmt!)}</td></tr>` : ''}
    </table>`;
  }

  // Invoice & Pelunasan Summary Section
  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;"><td style="font-size:12px;">TOTAL NOTA</td><td style="text-align:right;font-size:12px;">${fNum(inv.total || 0)}</td></tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr><td>DP Awal${Number(inv.dp || 0) > 0 && inv.payMethod && inv.payMethod !== '-' ? ` (${escHtml(inv.payMethod)})` : ''}</td><td style="text-align:right;">${fNum(Number(inv.dp || 0))}</td></tr>
      <tr><td>Sisa Sebelum Bayar</td><td style="text-align:right;">${fNum(inv.sisaAwal || 0)}</td></tr>
  </table>`;
  h += '<div class="dline" style="border-top:2px double #000;margin:5px 0;"></div>';
  h += `<table style="font-size:11px;width:100%;border-collapse:collapse;"><tr style="font-weight:bold;">
      <td style="font-size:11px;">BAYAR PELUNASAN (${escHtml(payMethod)})</td><td style="text-align:right;font-size:11px;">${fNum(bayar)}</td>
  </tr></table>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  h += `<table style="font-size:10px;width:100%;border-collapse:collapse;">
      <tr style="font-weight:bold;"><td>Sisa Akhir</td><td style="text-align:right;color:${newSisa > 0 ? '#B91C1C' : '#15803D'};">${fNum(newSisa)}</td></tr>
      ${kembalian > 0 ? `<tr style="font-weight:bold;"><td style="color:#15803D;">Kembalian</td><td style="text-align:right;color:#15803D;">${fNum(kembalian)}</td></tr>` : ''}
  </table>`;

  const rekeningPelunasan = s.rekening || '';
  if (rekeningPelunasan) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div class="center bold" style="font-size:8.5px;text-align:center;font-weight:bold;">REKENING PEMBAYARAN:</div>`;
    h += `<div class="center bold" style="font-size:8.5px;text-align:center;font-weight:bold;white-space:pre-line;">${escHtml(rekeningPelunasan)}</div>`;
  }

  const historyItems = resolveHistoryList(inv);
  if (historyItems.length > 0) {
    h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
    h += `<div class="center bold" style="font-size:9.5px;text-align:center;font-weight:bold;letter-spacing:0.5px;">HISTORI PEMBAYARAN & ANGSURAN</div>`;
    h += '<div class="line" style="border-top:1px dashed #000;margin:3px 0;"></div>';
    h += `<table style="font-size:8.5px;width:100%;border-collapse:collapse;">`;
    if (Number(inv.dp || 0) > 0) {
      h += `<tr><td style="font-weight:bold;">1. DP / Bayar Muka${inv.payMethod && inv.payMethod !== '-' ? ` (${escHtml(inv.payMethod)})` : ''}</td><td style="text-align:right;font-weight:bold;">${fNum(Number(inv.dp || 0))}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${orderDate || inv.date || ''}</td></tr>`;
    }

    historyItems.forEach((hItem, idx) => {
      const rowIdx = Number(inv.dp || 0) > 0 ? idx + 2 : idx + 1;
      h += `<tr><td style="font-weight:bold;">${rowIdx}. Angsuran #${idx + 1} (${escHtml(hItem.payMethod || 'Tunai')})</td><td style="text-align:right;font-weight:bold;">${fNum(hItem.jumlahBayar || 0)}</td></tr>`;
      h += `<tr><td colspan="2" style="font-size:8px;color:#444;padding-bottom:2px;">${escHtml(hItem.date || '')} ${escHtml(hItem.time || '')} · Sisa: ${fNum(hItem.newSisa !== undefined ? hItem.newSisa : 0)}${hItem.catatan ? ` (${escHtml(hItem.catatan)})` : ''}</td></tr>`;
    });

    h += `</table>`;
  }

  h += '<div class="dline" style="border-top:2px double #000;margin:6px 0;"></div>';
  const statusText = newSisa <= 0 ? '*** LUNAS ***' : 'DIBAYAR SEBAGIAN';
  h += `<div class="center bold" style="font-size:12px;margin:4px 0;text-align:center;font-weight:bold;">${statusText}</div>`;
  h += '<div class="line" style="border-top:1px dashed #000;margin:5px 0;"></div>';
  if (s.footer) h += `<div class="center bold" style="font-size:10px;margin-top:4px;text-align:center;">${escHtml(s.footer)}</div>`;

  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Nota Pelunasan ${escHtml(inv.invoiceNo)}</title>
  <style>@page{size:80mm auto;margin:2mm;}*{margin:0;padding:0;box-sizing:border-box;}body{width:80mm;font-family:'Courier New',Courier,monospace;font-size:10px;color:#000;line-height:1.4;padding:2mm;}.center{text-align:center;}.r{text-align:right;}.bold{font-weight:bold;}table{width:100%;border-collapse:collapse;}</style></head>
  <body>${h}</body></html>`;
}
