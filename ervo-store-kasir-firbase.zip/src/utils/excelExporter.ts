import * as XLSX from 'xlsx';
import { Product } from '../types';

export interface ExcelTransactionRow {
  'No Struk': string;
  'Tanggal Transaksi': string;
  'Kasir / Operator': string;
  'Metode Bayar': string;
  'Kategori Penjualan': string;
  'Total Penjualan / Omzet (Rp)': number;
  'Kas Keluar / Biaya (Rp)': number;
  'Keterangan': string;
}

/**
 * Format any date input string/Date to YYYY-MM-DD
 */
function normalizeDateToYMD(dateVal: any): string {
  if (!dateVal) return new Date().toISOString().split('T')[0];
  if (dateVal instanceof Date) {
    return isNaN(dateVal.getTime()) ? new Date().toISOString().split('T')[0] : dateVal.toISOString().split('T')[0];
  }
  const str = String(dateVal).trim();
  // If already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }
  // If DD/MM/YYYY
  const parts = str.split('/');
  if (parts.length === 3) {
    const [d, m, y] = parts;
    const year = y.length === 2 ? `20${y}` : y;
    return `${year.padStart(4, '20')}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }
  // Try ISO or generic parse
  try {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
  } catch {}

  return new Date().toISOString().split('T')[0];
}

/**
 * Export unified cash book & transactions to Excel (.xlsx) exactly matching pic1 format
 */
export function exportUnifiedTransactionsToExcel(options: {
  invoices: any[];
  expenses: any[];
  products?: Product[];
  activeKasir?: string;
  fileName?: string;
}): { success: boolean; rowCount: number; error?: string } {
  try {
    const { invoices = [], expenses = [], products = [], activeKasir = 'Kasir Ervo 1', fileName } = options;

    const rows: (ExcelTransactionRow & { _sortDate: string; _sortKey: string })[] = [];

    // 1. Map Sales / Invoices
    for (const inv of invoices) {
      if (!inv) continue;
      const receiptNo = String(inv.invoiceNo || inv.noInvoice || inv.id || 'STRUK-UNKNOWN').trim();
      const dateYMD = normalizeDateToYMD(inv.date || inv.tanggal || inv.createdAt);
      const cashierName = String(inv.cashier || inv.kasir || inv.operator || activeKasir || 'Kasir Ervo 1').trim();
      const paymentMethod = String(
        inv.payMethod || 
        inv.metodePembayaran || 
        (Number(inv.dp || 0) === 0 && Number(inv.sisa || 0) > 0 ? 'Belum Bayar' : 'Tunai')
      ).trim();

      // Resolve category from items or product master
      let category = 'Penjualan Toko';
      const itemsList = Array.isArray(inv.items) ? inv.items : [];
      if (itemsList.length > 0) {
        const foundCategories: string[] = [];
        for (const item of itemsList) {
          if (!item) continue;
          if (item.kategori && String(item.kategori).trim()) {
            foundCategories.push(String(item.kategori).trim());
          } else {
            const matchedProd = products.find(
              (p) => (item.kode && p.kode === item.kode) || (p.nama && p.nama.toLowerCase() === String(item.nama || item.name || '').toLowerCase())
            );
            if (matchedProd?.kategori) {
              foundCategories.push(matchedProd.kategori);
            }
          }
        }
        if (foundCategories.length > 0) {
          const uniqueCats = Array.from(new Set(foundCategories));
          category = uniqueCats.join(', ');
        }
      }

      // Build readable description from item names & specs
      let description = '';
      if (itemsList.length > 0) {
        const itemDescriptions = itemsList.map((it: any) => {
          const name = it.nama || it.name || 'Produk';
          const qtyPart = it.qty ? ` (${it.qty} ${it.satuan || 'pcs'})` : '';
          return `${name}${qtyPart}`;
        });
        description = itemDescriptions.join(' & ');
      } else {
        description = inv.customer ? `Pesanan ${inv.customer}` : 'Penjualan Toko';
      }

      const totalOmzet = Number(inv.total || inv.totalBayar || 0);

      rows.push({
        'No Struk': receiptNo,
        'Tanggal Transaksi': dateYMD,
        'Kasir / Operator': cashierName,
        'Metode Bayar': paymentMethod,
        'Kategori Penjualan': category,
        'Total Penjualan / Omzet (Rp)': totalOmzet,
        'Kas Keluar / Biaya (Rp)': 0,
        'Keterangan': description,
        _sortDate: dateYMD,
        _sortKey: `0_${receiptNo}`,
      });
    }

    // 2. Map Kas Keluar / Expenses
    for (const exp of expenses) {
      if (!exp) continue;
      const expenseNo = String(exp.id || 'EXP-UNKNOWN').trim();
      const dateYMD = normalizeDateToYMD(exp.tanggal || exp.date || exp.createdAt);
      const cashierName = String(exp.petugas || exp.kasir || exp.operator || activeKasir || 'Kasir Ervo 1').trim();
      const paymentMethod = String(exp.metodePembayaran || exp.metode || 'Tunai').trim();
      const category = String(exp.kategori || 'Operasional').trim();
      const nominal = Number(exp.nominal || exp.amount || 0);
      const description = String(exp.keterangan || exp.deskripsi || 'Pengeluaran Toko').trim();

      rows.push({
        'No Struk': expenseNo,
        'Tanggal Transaksi': dateYMD,
        'Kasir / Operator': cashierName,
        'Metode Bayar': paymentMethod,
        'Kategori Penjualan': category,
        'Total Penjualan / Omzet (Rp)': 0,
        'Kas Keluar / Biaya (Rp)': nominal,
        'Keterangan': description,
        _sortDate: dateYMD,
        _sortKey: `1_${expenseNo}`,
      });
    }

    // Sort chronologically by Tanggal Transaksi ascending (YYYY-MM-DD), then by key
    rows.sort((a, b) => {
      const dateCmp = a._sortDate.localeCompare(b._sortDate);
      if (dateCmp !== 0) return dateCmp;
      return a._sortKey.localeCompare(b._sortKey);
    });

    // Strip internal sorting fields
    const finalData: ExcelTransactionRow[] = rows.map((r) => ({
      'No Struk': r['No Struk'],
      'Tanggal Transaksi': r['Tanggal Transaksi'],
      'Kasir / Operator': r['Kasir / Operator'],
      'Metode Bayar': r['Metode Bayar'],
      'Kategori Penjualan': r['Kategori Penjualan'],
      'Total Penjualan / Omzet (Rp)': r['Total Penjualan / Omzet (Rp)'],
      'Kas Keluar / Biaya (Rp)': r['Kas Keluar / Biaya (Rp)'],
      'Keterangan': r['Keterangan'],
    }));

    // Create workbook and worksheet
    const worksheet = XLSX.utils.json_to_sheet(finalData);

    // Set nice column widths for Excel
    worksheet['!cols'] = [
      { wch: 18 }, // No Struk
      { wch: 16 }, // Tanggal Transaksi
      { wch: 18 }, // Kasir / Operator
      { wch: 16 }, // Metode Bayar
      { wch: 22 }, // Kategori Penjualan
      { wch: 25 }, // Total Penjualan / Omzet (Rp)
      { wch: 22 }, // Kas Keluar / Biaya (Rp)
      { wch: 45 }, // Keterangan
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Laporan Transaksi');

    const nowStr = new Date().toISOString().split('T')[0];
    const outputFileName = fileName ? (fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`) : `Laporan_Transaksi_ERVO_${nowStr}.xlsx`;

    XLSX.writeFile(workbook, outputFileName);
    return { success: true, rowCount: finalData.length };
  } catch (err: any) {
    console.error('Failed to export unified transactions to Excel:', err);
    return { success: false, rowCount: 0, error: err?.message || String(err) };
  }
}
