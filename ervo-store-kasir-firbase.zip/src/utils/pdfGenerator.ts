import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { RecentInvoiceItem, getPelunasanHistory, sortPelunasanHistoryAsc } from '../services/gasService';
import { ExpenseRecord, PelunasanRecord, StockOpnameRecord, StoreSettings, InvoiceItem, StockInRecord } from '../types';
import { 
  fRp, 
  computeItemTotal,
  calculateCashInflowByPaymentMethod,
  getInvoicePaymentCategory,
  PeriodCashInflowBreakdown,
  PelunasanInflowItem,
  parsePaymentCategory,
  parseUniversalDate,
  isDatesDifferent,
  fDateInput,
  fTime,
} from './formatters';

function resolveInvoiceHistory(inv: RecentInvoiceItem): Array<{
  jenis: string;
  date: string;
  payMethod: string;
  jumlahBayar: number;
  sisa: number;
  catatan?: string;
}> {
  const invoiceNo = inv.invoiceNo || '';
  const backendHist = Array.isArray((inv as any).historiPelunasan)
    ? (inv as any).historiPelunasan
    : Array.isArray((inv as any).history)
    ? (inv as any).history
    : null;

  const rawList: PelunasanRecord[] = backendHist !== null
    ? backendHist
    : (invoiceNo ? getPelunasanHistory(invoiceNo) : []);

  const sortedList = sortPelunasanHistoryAsc(rawList);
  const tot = Number(inv.total || 0);
  const totalPelunasan = sortedList.reduce((acc, item) => acc + Number(item.jumlahBayar || 0), 0);
  const sisaCurrent = inv.sisa !== undefined ? Number(inv.sisa) : tot;

  const calculatedDp = Math.max(0, tot - sisaCurrent - totalPelunasan);
  const dp = (inv.dp !== undefined && Number(inv.dp) > 0) ? Number(inv.dp) : calculatedDp;

  const sisaAwal = Math.max(0, tot - dp);
  let currentSisa = sisaAwal;

  const result: Array<{
    jenis: string;
    date: string;
    payMethod: string;
    jumlahBayar: number;
    sisa: number;
    catatan?: string;
  }> = [];

  if (dp > 0) {
    const dpDate = [inv.date || '', (inv as any).time || ''].filter(Boolean).join(' ') || '-';
    result.push({
      jenis: 'Uang Muka (DP)',
      date: dpDate,
      payMethod: (inv as any).payMethod || (inv as any).metodePembayaran || 'Tunai',
      jumlahBayar: dp,
      sisa: sisaAwal,
    });
  }

  sortedList.forEach((hItem, idx) => {
    const bayar = Number(hItem.jumlahBayar || 0);
    currentSisa = Math.max(0, currentSisa - bayar);
    const hDate = [hItem.date || '', hItem.time || ''].filter(Boolean).join(' ') || '-';
    const isLast = idx === sortedList.length - 1 && currentSisa <= 0;
    const cicilanLabel = isLast
      ? `Pelunasan Akhir (Angsuran #${idx + 1})`
      : (sortedList.length === 1 && dp === 0 ? 'Cicilan Pembayaran' : `Cicilan Ke-${idx + 1}`);

    result.push({
      jenis: cicilanLabel,
      date: hDate,
      payMethod: hItem.payMethod || 'Tunai',
      jumlahBayar: bayar,
      sisa: currentSisa,
      catatan: hItem.catatan || (hItem.cashier ? `Kasir: ${hItem.cashier}` : undefined),
    });
  });

  // Fallback if there is additional recorded payment not captured in sortedList
  const totalPaidReal = Math.max(0, tot - sisaCurrent);
  const totalCaptured = (dp > 0 ? dp : 0) + totalPelunasan;
  if (totalPaidReal > totalCaptured) {
    const uncaptured = totalPaidReal - totalCaptured;
    result.push({
      jenis: 'Cicilan Pembayaran',
      date: inv.date || '-',
      payMethod: (inv as any).payMethod || 'Tunai',
      jumlahBayar: uncaptured,
      sisa: sisaCurrent,
    });
  }

  return result;
}

interface GeneratePdfOptions {
  periodLabel: string;
  invoices: RecentInvoiceItem[];
  stats: {
    totalGross: number;
    totalPaid: number;
    totalPiutang: number;
    count: number;
    countLunas: number;
    countDP: number;
    fromNewSales?: number;
    fromPelunasanPiutang?: number;
  };
  storeName?: string;
  printedBy?: string;
  periodCashInflow?: PeriodCashInflowBreakdown;
  pelunasanItems?: PelunasanInflowItem[];
}

export function generateMonthlyReportPdf({
  periodLabel,
  invoices,
  stats,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Kasir Utama',
  periodCashInflow,
  pelunasanItems = [],
}: GeneratePdfOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const marginX = 12; // 12mm left & right margins
  const contentWidth = pageWidth - marginX * 2; // 186mm

  // Resolve breakdown metrics
  const actualPelunasan = stats.fromPelunasanPiutang !== undefined
    ? stats.fromPelunasanPiutang
    : (periodCashInflow?.fromPelunasanPiutang ?? pelunasanItems.reduce((acc, p) => acc + (p.jumlahBayar || 0), 0));
  
  const actualNewSales = stats.fromNewSales !== undefined
    ? stats.fromNewSales
    : (periodCashInflow?.fromNewSales ?? Math.max(0, stats.totalPaid - actualPelunasan));

  // --- HEADER DECORATION ---
  // Top Banner Dark Bar
  doc.setFillColor(30, 41, 59); // Slate-800
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Top Accent Orange Strip
  doc.setFillColor(234, 88, 12); // Orange-600
  doc.rect(0, 28, pageWidth, 2, 'F');

  // Title Text inside Banner
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(203, 213, 225); // Slate-300
  doc.text('LAPORAN REKAPITULASI TRANSAKSI & PENJUALAN SALES', marginX, 18);

  // Print Meta info (Top Right)
  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  // --- METADATA & SUMMARY BOX ---
  let currentY = 35;

  // Period Badge
  doc.setFillColor(241, 245, 249); // Slate-100
  doc.setDrawColor(203, 213, 225); // Slate-300
  doc.roundedRect(marginX, currentY, contentWidth, 11, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42); // Slate-900
  doc.text(`PERIODE LAPORAN: ${periodLabel.toUpperCase()}`, marginX + 4, currentY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Total Transaksi: ${stats.count} Order`, pageWidth - marginX - 4, currentY + 7, { align: 'right' });

  currentY += 15;

  // Calculate exact totals directly from the sales invoices list
  let salesGross = 0;
  let salesPaid = 0;
  let salesPiutang = 0;

  invoices.forEach((inv) => {
    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const paid = Math.max(0, tot - sisa);
    salesGross += tot;
    salesPaid += paid;
    salesPiutang += sisa;
  });

  // Use calculated values from the sales invoices table
  const finalGross = salesGross > 0 || invoices.length > 0 ? salesGross : Number(stats.totalGross || 0);
  const finalPaid = salesPaid > 0 || invoices.length > 0 ? salesPaid : Number(stats.fromNewSales !== undefined ? stats.fromNewSales : stats.totalPaid || 0);
  const finalPiutang = salesPiutang > 0 || invoices.length > 0 ? salesPiutang : Number(stats.totalPiutang || 0);

  // Key Financial Metrics Grid (3 Box Columns)
  const gap = 4;
  const boxWidth = (contentWidth - gap * 2) / 3; // 59.33mm each
  const boxHeight = 18;

  // Box 1: Total Omzet (Total Nilai Transaksi Penjualan)
  doc.setFillColor(254, 243, 199); // Amber 100
  doc.setDrawColor(252, 211, 77);
  doc.roundedRect(marginX, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(146, 64, 14); // Amber 800
  doc.text('TOTAL OMZET PENJUALAN', marginX + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(120, 53, 15);
  doc.text(fRp(finalGross), marginX + 3.5, currentY + 13);

  // Box 2: Total Dibayar / Diterima dari Penjualan Sales
  const box2X = marginX + boxWidth + gap;
  doc.setFillColor(220, 252, 231); // Emerald 100
  doc.setDrawColor(134, 239, 172);
  doc.roundedRect(box2X, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(22, 101, 52); // Emerald 800
  doc.text('TOTAL DIBAYAR (DITERIMA)', box2X + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(20, 83, 45);
  doc.text(fRp(finalPaid), box2X + 3.5, currentY + 13);

  // Box 3: Total Sisa Piutang Penjualan
  const box3X = marginX + (boxWidth + gap) * 2;
  doc.setFillColor(254, 226, 226); // Red 100
  doc.setDrawColor(252, 165, 165);
  doc.roundedRect(box3X, currentY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(153, 27, 27); // Red 800
  doc.text('SISA PIUTANG (BELUM LUNAS)', box3X + 3.5, currentY + 5.5);
  doc.setFontSize(10.5);
  doc.setTextColor(127, 29, 29);
  doc.text(fRp(finalPiutang), box3X + 3.5, currentY + 13);

  // --- BREAKDOWN ARUS KAS MASUK BERDASARKAN METODE PEMBAYARAN TRANSAKSI SALES ---
  const monthlyCashByMethod = periodCashInflow || calculateCashInflowByPaymentMethod(invoices);
  const mBreakdownY = currentY + boxHeight + 3.5;
  const mBreakGap = 2.5;
  const mBreakW = (contentWidth - mBreakGap * 3) / 4;
  const mBreakH = 11;

  // Box 1: Tunai
  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(187, 247, 208);
  doc.roundedRect(marginX, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('KAS TUNAI', marginX + 3, mBreakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(monthlyCashByMethod.Tunai), marginX + 3, mBreakdownY + 8.8);

  // Box 2: Transfer
  const mb2X = marginX + mBreakW + mBreakGap;
  doc.setFillColor(239, 246, 255);
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(mb2X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TRANSFER BANK', mb2X + 3, mBreakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(monthlyCashByMethod.Transfer), mb2X + 3, mBreakdownY + 8.8);

  // Box 3: Debet
  const mb3X = marginX + (mBreakW + mBreakGap) * 2;
  doc.setFillColor(250, 245, 255);
  doc.setDrawColor(233, 213, 255);
  doc.roundedRect(mb3X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(107, 33, 168);
  doc.text('KARTU DEBET', mb3X + 3, mBreakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(monthlyCashByMethod.Debet), mb3X + 3, mBreakdownY + 8.8);

  // Box 4: QRIS
  const mb4X = marginX + (mBreakW + mBreakGap) * 3;
  doc.setFillColor(254, 252, 232);
  doc.setDrawColor(254, 240, 138);
  doc.roundedRect(mb4X, mBreakdownY, mBreakW, mBreakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(133, 77, 14);
  doc.text('QRIS', mb4X + 3, mBreakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(monthlyCashByMethod.QRIS), mb4X + 3, mBreakdownY + 8.8);

  currentY = mBreakdownY + mBreakH + 6;

  // Section Label
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('RINCIAN LENGKAP TRANSAKSI PENJUALAN & MUTASI ITEM', marginX, currentY);
  currentY += 3.5;

  // --- TRANSACTION TABLE (SESUAI FORMAT BUKU BESAR PIUTANG) ---
  const tableData = invoices.map((inv, idx) => {
    const totalVal = Number(inv.total || 0);
    const sisaVal = Number(inv.sisa || 0);
    const paidVal = totalVal - sisaVal;
    const isLunas = sisaVal <= 0;
    const method = getInvoicePaymentCategory(inv);

    const rawItems = Array.isArray(inv.items) ? inv.items : [];
    let itemsDesc = '';
    if (rawItems.length > 0) {
      const itemLines = rawItems.map((it: any, itIdx: number) => {
        const prefix = rawItems.length > 1 ? `${itIdx + 1}. ` : '• ';
        let line = `${prefix}${it.nama || 'Produk Cetak'}`;
        if (it.tipeHarga === 'ukuran' && Number(it.panjang) > 0 && Number(it.lebar) > 0) {
          line += ` (${it.panjang}×${it.lebar} m)`;
        }
        line += ` [${it.qty || 1} ${it.satuan || 'pcs'}]`;
        if (it.bahan) {
          line += ` - ${it.bahan}`;
        }
        if (it.catatan && it.catatan.trim()) {
          line += `\n   Catatan/ Nama File Cetak: ${it.catatan.trim()}`;
        }
        return line;
      });
      itemsDesc = itemLines.join('\n');
    } else {
      itemsDesc = 'Pesanan Percetakan / Jasa Digital Print';
    }

    const invCatatan = (inv as any).catatan;
    if (invCatatan && typeof invCatatan === 'string' && invCatatan.trim()) {
      itemsDesc += `\nCatatan Nota: ${invCatatan.trim()}`;
    }

    return [
      (idx + 1).toString(),
      `${inv.invoiceNo || '-'}\n${inv.date || '-'}`,
      inv.customer || 'Umum',
      itemsDesc,
      inv.cashier || 'Kasir',
      method,
      fRp(totalVal),
      fRp(paidVal),
      fRp(sisaVal),
      isLunas ? 'LUNAS' : 'DP/SISA',
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Invoice & Tgl', 'Pelanggan', 'Rincian Barang Yang Dibeli & Catatan/ Nama File Cetak', 'Kasir', 'Metode', 'Total', 'Dibayar', 'Sisa', 'Status']],
    body: tableData.length > 0 ? tableData : [['-', '-', '-', 'Tidak ada transaksi', '-', '-', 'Rp 0', 'Rp 0', 'Rp 0', '-']],
    foot: [
      [
        '',
        '',
        '',
        'TOTAL REKAPITULASI PENJUALAN:',
        '',
        '',
        fRp(finalGross),
        fRp(finalPaid),
        fRp(finalPiutang),
        finalPiutang <= 0 ? 'LUNAS' : 'BELUM LUNAS',
      ],
    ],
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: {
      overflow: 'linebreak',
      cellPadding: 1.8,
      fontSize: 7,
    },
    headStyles: {
      fillColor: [30, 41, 59], // Slate 800
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.2,
      halign: 'center',
      valign: 'middle',
    },
    bodyStyles: {
      fontSize: 6.8,
      textColor: [30, 41, 59],
      valign: 'top',
    },
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 7.2,
      valign: 'middle',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 6 },   // No
      1: { halign: 'center', cellWidth: 22, fontStyle: 'bold' }, // Invoice & Tgl
      2: { cellWidth: 18, fontStyle: 'bold' }, // Pelanggan
      3: { cellWidth: 52 },                    // Rincian Barang & Catatan File
      4: { cellWidth: 13 },                    // Kasir
      5: { halign: 'center', cellWidth: 13 },  // Metode
      6: { halign: 'right', cellWidth: 17, fontStyle: 'bold' }, // Total
      7: { halign: 'right', cellWidth: 16, textColor: [22, 101, 52] }, // Dibayar
      8: { halign: 'right', cellWidth: 15, textColor: [185, 28, 28] }, // Sisa
      9: { halign: 'center', cellWidth: 14 },  // Status
    },
    didParseCell: (data) => {
      // Highlight Status Column
      if (data.section === 'body' && data.column.index === 9) {
        if (data.cell.raw === 'LUNAS') {
          data.cell.styles.textColor = [22, 101, 52]; // Emerald 800
          data.cell.styles.fontStyle = 'bold';
        } else {
          data.cell.styles.textColor = [185, 28, 28]; // Red 700
          data.cell.styles.fontStyle = 'bold';
        }
      }
      // Sisa column highlighting
      if (data.section === 'body' && data.column.index === 8) {
        const raw = String(data.cell.raw || '');
        if (raw !== 'Rp 0' && raw !== '-' && raw !== '') {
          data.cell.styles.textColor = [185, 28, 28];
          data.cell.styles.fontStyle = 'bold';
        } else {
          data.cell.styles.textColor = [100, 116, 139];
        }
      }
      // Footer styling
      if (data.section === 'foot') {
        if (data.column.index === 6) {
          data.cell.styles.halign = 'right';
          data.cell.styles.textColor = [15, 23, 42];
        }
        if (data.column.index === 7) {
          data.cell.styles.halign = 'right';
          data.cell.styles.textColor = [22, 101, 52];
        }
        if (data.column.index === 8) {
          data.cell.styles.halign = 'right';
          data.cell.styles.textColor = [185, 28, 28];
        }
        if (data.column.index === 9) {
          data.cell.styles.halign = 'center';
          data.cell.styles.textColor = [15, 23, 42];
        }
      }
    },
  });

  // Get position after table
  const finalY = (doc as any).lastAutoTable?.finalY || currentY + 40;

  // --- SIGNATURE / VALIDATION BLOCK ---
  let sigY = finalY + 12;
  if (sigY + 35 > pageHeight) {
    doc.addPage();
    sigY = 25;
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const leftX = marginX + 10;
  const rightX = pageWidth - marginX - 50;

  doc.text('Dibuat Oleh,', leftX, sigY);
  doc.text('Kasir / Petugas', leftX, sigY + 4.5);

  doc.text('Disetujui Oleh,', rightX, sigY);
  doc.text('Pemilik / Manager', rightX, sigY + 4.5);

  // Line for signatures
  doc.setDrawColor(148, 163, 184);
  doc.line(leftX, sigY + 22, leftX + 40, sigY + 22);
  doc.line(rightX, sigY + 22, rightX + 40, sigY + 22);

  doc.setFontSize(8);
  doc.text('( ................................. )', leftX, sigY + 26);
  doc.text('( ................................. )', rightX, sigY + 26);

  // Footer Page Number
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Dokumen Resmi Laporan Keuangan ERVO PRINT - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  // Save the PDF
  const filenameStr = periodLabel.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Laporan_Sales_${filenameStr}_${new Date().toISOString().split('T')[0]}.pdf`);
}

export interface CustomerPiutangSummary {
  customerName: string;
  invoices: RecentInvoiceItem[];
  totalGross: number;
  totalPaid: number;
  totalSisa: number;
  count: number;
}

export interface GenerateCustomerBillingOptions {
  customerName: string;
  invoices: RecentInvoiceItem[];
  storeName?: string;
  storeAddress?: string;
  storePhone?: string;
  printedBy?: string;
  rekening?: string;
  customerPhone?: string;
  customerAddress?: string;
  customerClass?: string;
}

export function generateCustomerBillingPdf({
  customerName,
  invoices,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  storeAddress,
  storePhone,
  printedBy = 'Kasir Utama',
  rekening,
  customerPhone,
  customerAddress,
  customerClass,
}: GenerateCustomerBillingOptions) {
  let rekeningVal = rekening;
  let storeAddressVal = storeAddress;
  let storePhoneVal = storePhone;
  try {
    const raw = localStorage.getItem('strukku_settings');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (!rekeningVal) rekeningVal = parsed.rekening;
      if (!storeAddressVal) storeAddressVal = parsed.address;
      if (!storePhoneVal) storePhoneVal = parsed.phone;
    }
  } catch {}
  if (!storeAddressVal) storeAddressVal = 'Jl. HOS Cokroaminoto No.17, Ciamis';
  if (!storePhoneVal) storePhoneVal = '0812-2247-2007';

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  let totalGross = 0;
  let totalSisa = 0;
  invoices.forEach((inv) => {
    totalGross += Number(inv.total || 0);
    totalSisa += Number(inv.sisa || 0);
  });
  const totalPaid = Math.max(0, totalGross - totalSisa);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const timeStr = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const safeCustCode = customerName.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'CUST';
  const docNumber = `SOA/BB/${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}/${safeCustCode}`;

  // ==========================================
  // 1. HEADER KOP FORMAL (NAVY & ORANGE ACCENT)
  // ==========================================
  doc.setFillColor(30, 41, 59); // Slate-800
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setFillColor(234, 88, 12); // Orange-600 accent
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 11.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(226, 232, 240);
  doc.text('BUKU BESAR KARTU PIUTANG & MUTASI TRANSAKSI PELANGGAN', marginX, 17.5);
  doc.setFontSize(7.5);
  doc.setTextColor(203, 213, 225);
  doc.text('STATEMENT OF ACCOUNT (SOA) - RESMI & AKUNTABEL', marginX, 22.5);

  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text(`No. Dokumen: ${docNumber}`, pageWidth - marginX, 11.5, { align: 'right' });
  doc.setTextColor(226, 232, 240);
  doc.text(`Tgl Cetak: ${dateStr} ${timeStr}`, pageWidth - marginX, 17, { align: 'right' });
  doc.text(`Petugas Kasir: ${printedBy}`, pageWidth - marginX, 22.5, { align: 'right' });

  let currentY = 35;

  // ==========================================
  // 2. KARTU IDENTITAS DEBITUR & TOKO
  // ==========================================
  const halfWidth = (contentWidth - 4) / 2;
  const infoBoxHeight = 25;

  // Box Kiri: Debitur / Pelanggan
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, currentY, halfWidth, infoBoxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(194, 65, 12);
  doc.text('DATA DEBITUR / PELANGGAN:', marginX + 3.5, currentY + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text(customerName.toUpperCase(), marginX + 3.5, currentY + 11.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Kategori: ${customerClass || 'Pelanggan Umum'}  |  Telp: ${customerPhone || '-'}`, marginX + 3.5, currentY + 16.5);
  const truncatedAddr = customerAddress ? (customerAddress.length > 42 ? customerAddress.slice(0, 42) + '...' : customerAddress) : 'Alamat: Sesuai data tersimpan';
  doc.text(truncatedAddr, marginX + 3.5, currentY + 21);

  // Box Kanan: Informasi Toko & Status Buku
  const boxRightX = marginX + halfWidth + 4;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(boxRightX, currentY, halfWidth, infoBoxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('INFORMASI PENERBIT & STATUS BUKU:', boxRightX + 3.5, currentY + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(storeName, boxRightX + 3.5, currentY + 10.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Telp/WA: ${storePhoneVal}`, boxRightX + 3.5, currentY + 15);
  doc.text(`Faktur Belum Lunas: ${invoices.length} Faktur Aktif`, boxRightX + 3.5, currentY + 19.5);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(185, 28, 28);
  doc.text(`STATUS: WAJIB DILUNASI`, boxRightX + halfWidth - 3.5, currentY + 19.5, { align: 'right' });

  currentY += infoBoxHeight + 5;

  // ==========================================
  // 3. RINGKASAN REKAPITULASI BUKU BESAR (KPI METRICS)
  // ==========================================
  const gap = 4;
  const metricWidth = (contentWidth - gap * 2) / 3;
  const metricHeight = 16;

  // Metric 1: Total Debit (Semua Order)
  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, currentY, metricWidth, metricHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text('TOTAL DEBIT (TAGIHAN BARU)', marginX + 3.5, currentY + 5);
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalGross), marginX + 3.5, currentY + 12);

  // Metric 2: Total Kredit (DP & Setoran Masuk)
  const metric2X = marginX + metricWidth + gap;
  doc.setFillColor(220, 252, 231);
  doc.setDrawColor(134, 239, 172);
  doc.roundedRect(metric2X, currentY, metricWidth, metricHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(22, 101, 52);
  doc.text('TOTAL KREDIT (PEMBAYARAN / DP)', metric2X + 3.5, currentY + 5);
  doc.setFontSize(10.5);
  doc.setTextColor(20, 83, 45);
  doc.text(fRp(totalPaid), metric2X + 3.5, currentY + 12);

  // Metric 3: Saldo Akhir Piutang (Current Balance)
  const metric3X = marginX + (metricWidth + gap) * 2;
  doc.setFillColor(254, 226, 226);
  doc.setDrawColor(239, 68, 68);
  doc.roundedRect(metric3X, currentY, metricWidth, metricHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(153, 27, 27);
  doc.text('SALDO PIUTANG AKHIR (SISA)', metric3X + 3.5, currentY + 5);
  doc.setFontSize(11);
  doc.setTextColor(185, 28, 28);
  doc.text(fRp(totalSisa), metric3X + 3.5, currentY + 12);

  currentY += metricHeight + 7;

  // ==========================================
  // 4. TABEL UTAMA: BUKU BESAR MUTASI PIUTANG
  // (DEBIT - KREDIT - SALDO BERJALAN)
  // ==========================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('BUKU BESAR MUTASI PIUTANG (CUSTOMER STATEMENT OF ACCOUNT)', marginX, currentY);
  currentY += 4.5;

  interface LedgerEvent {
    dateObj: Date;
    dateStr: string;
    refNo: string;
    description: string;
    debit: number;
    kredit: number;
    orderPriority: number;
  }

  const events: LedgerEvent[] = [];

  invoices.forEach((inv) => {
    const invDateObj = parseUniversalDate(inv.date) || new Date(0);
    const rawItems = Array.isArray(inv.items) ? inv.items : [];

    let orderDesc = 'Faktur Pesanan:';
    if (rawItems.length > 0) {
      const itemLines = rawItems.map((it, idx) => {
        const prefix = rawItems.length > 1 ? `${idx + 1}. ` : '• ';
        let n = `${prefix}${it.nama || 'Produk Cetak'}`;
        if (it.tipeHarga === 'ukuran' && Number(it.panjang) > 0 && Number(it.lebar) > 0) {
          n += ` (${it.panjang}x${it.lebar}m)`;
        }
        n += ` [${it.qty || 1} ${it.satuan || 'pcs'}]`;
        if (it.bahan) {
          n += ` - ${it.bahan}`;
        }
        if (it.catatan && it.catatan.trim()) {
          n += `\n   Catatan/ Nama File Cetak: ${it.catatan.trim()}`;
        }
        return n;
      });
      orderDesc += `\n${itemLines.join('\n')}`;
    } else {
      orderDesc += ' Pesanan Percetakan / Jasa Digital Print';
    }

    const invCatatan = (inv as any).catatan;
    if (invCatatan && typeof invCatatan === 'string' && invCatatan.trim()) {
      orderDesc += `\nCatatan Nota: ${invCatatan.trim()}`;
    }

    const invDeadline = (inv as any).deadline;
    if (invDeadline) {
      orderDesc += ` (Jatuh Tempo: ${invDeadline})`;
    }

    // 1. Faktur Baru (Debit)
    events.push({
      dateObj: invDateObj,
      dateStr: inv.date || '-',
      refNo: inv.invoiceNo || '-',
      description: orderDesc,
      debit: Number(inv.total || 0),
      kredit: 0,
      orderPriority: 1,
    });

    // 2. Histori Pembayaran (DP & Cicilan / Pelunasan - Kredit)
    const histories = resolveInvoiceHistory(inv);
    histories.forEach((hist, hIdx) => {
      const histDateObj = parseUniversalDate(hist.date) || invDateObj;
      const isDP = hist.jenis.toLowerCase().includes('dp') || hist.jenis.toLowerCase().includes('awal');
      const payDesc = isDP
        ? `Pembayaran Uang Muka (DP) - [${hist.payMethod || 'Tunai'}]`
        : `Pembayaran ${hist.jenis} - [${hist.payMethod || 'Tunai'}]${hist.catatan ? ` (Ket: ${hist.catatan})` : ''}`;

      events.push({
        dateObj: histDateObj,
        dateStr: hist.date || inv.date || '-',
        refNo: inv.invoiceNo || '-',
        description: payDesc,
        debit: 0,
        kredit: Number(hist.jumlahBayar || 0),
        orderPriority: isDP ? 2 : 3 + hIdx,
      });
    });
  });

  // Urutkan secara kronologis
  events.sort((a, b) => {
    const tDiff = a.dateObj.getTime() - b.dateObj.getTime();
    if (tDiff !== 0) return tDiff;
    return a.orderPriority - b.orderPriority;
  });

  let runningBalance = 0;
  const ledgerTableRows = events.map((ev, idx) => {
    runningBalance += (ev.debit - ev.kredit);
    return [
      (idx + 1).toString(),
      ev.dateStr,
      ev.refNo,
      ev.description,
      ev.debit > 0 ? fRp(ev.debit) : '-',
      ev.kredit > 0 ? fRp(ev.kredit) : '-',
      fRp(runningBalance),
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Tanggal', 'No. Referensi', 'Keterangan Mutasi Transaksi', 'Debit / Tagihan (+)', 'Kredit / Bayar (-)', 'Saldo Piutang']],
    body: ledgerTableRows,
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 2, fontSize: 7.5 },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },
      1: { halign: 'center', cellWidth: 20 },
      2: { halign: 'center', cellWidth: 26, fontStyle: 'bold' },
      3: { cellWidth: 67 },
      4: { halign: 'right', cellWidth: 22, fontStyle: 'bold', textColor: [15, 23, 42] },
      5: { halign: 'right', cellWidth: 22, fontStyle: 'bold', textColor: [22, 101, 52] },
      6: { halign: 'right', cellWidth: 22, fontStyle: 'bold', textColor: [185, 28, 28] },
    },
  });

  // ==========================================
  // 5. INFORMASI REKENING & INSTRUKSI PEMBAYARAN
  // ==========================================
  let payInfoY = (doc as any).lastAutoTable?.finalY || currentY + 40;
  payInfoY += 6;
  const rekLines = rekeningVal ? rekeningVal.split('\n').map((l) => l.trim()).filter(Boolean) : [];
  const rekExtraHeight = rekLines.length > 0 ? (rekLines.length * 4.5 + 5) : 0;
  const payBoxHeight = 18 + rekExtraHeight;

  if (payInfoY + payBoxHeight + 35 > pageHeight) {
    doc.addPage();
    payInfoY = 20;
  }

  doc.setFillColor(255, 247, 237);
  doc.setDrawColor(254, 215, 170);
  doc.roundedRect(marginX, payInfoY, contentWidth, payBoxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(194, 65, 12);
  doc.text('PETUNJUK & KETENTUAN PEMBAYARAN RESMI:', marginX + 3.5, payInfoY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text('Pelunasan sisa piutang dapat dilakukan langsung di kasir toko atau transfer melalui rekening bank resmi berikut:', marginX + 3.5, payInfoY + 9.5);

  let currentTextY = payInfoY + 14;

  if (rekLines.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(154, 52, 18);
    doc.text('DAFTAR REKENING TRANSFER RESMI:', marginX + 3.5, currentTextY);
    currentTextY += 4;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    rekLines.forEach((line) => {
      doc.text(`•  ${line}`, marginX + 5, currentTextY);
      currentTextY += 4.5;
    });
  }

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(120, 53, 15);
  doc.text('Bukti transfer mohon dikirimkan kepada kasir / admin toko untuk diverifikasi dan diterbitkan bukti pelunasan sah.', marginX + 3.5, currentTextY);

  // ==========================================
  // 8. TANDA TANGAN FORMAL & KONFIRMASI SALDO
  // ==========================================
  let sigY = payInfoY + payBoxHeight + 6;
  if (sigY + 38 > pageHeight) {
    doc.addPage();
    sigY = 20;
  }

  // Pernyataan Konfirmasi Saldo
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'Buku Besar Piutang ini diterbitkan secara resmi oleh sistem komputer ERVO PRINT sebagai rincian mutasi transaksi dan saldo tagihan yang sah.',
    marginX,
    sigY
  );
  doc.text(
    'Apabila terdapat perbedaan pencatatan pembayaran atau nota, mohon segera melakukan konfirmasi dalam waktu 3x24 jam kepada pihak keuangan kami.',
    marginX,
    sigY + 3.5
  );

  sigY += 9;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const leftX = marginX + 10;
  const rightX = pageWidth - marginX - 55;

  doc.text('Bagian Keuangan / Penagihan,', leftX, sigY);
  doc.text('Debitur / Diterima Oleh,', rightX, sigY);

  doc.setDrawColor(148, 163, 184);
  doc.line(leftX, sigY + 20, leftX + 48, sigY + 20);
  doc.line(rightX, sigY + 20, rightX + 48, sigY + 20);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(`( ${printedBy} )`, leftX, sigY + 24);
  doc.text(`( ${customerName} )`, rightX, sigY + 24);

  // ==========================================
  // 9. NUMBERING FOOTER HALAMAN
  // ==========================================
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Buku Besar Piutang Pelanggan - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const safeCustName = customerName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Buku_Besar_Piutang_${safeCustName}_${new Date().toISOString().split('T')[0]}.pdf`);
}

export function generateAllPiutangReportPdf({
  customerSummaries,
  totalPiutang,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Kasir Utama',
}: {
  customerSummaries: CustomerPiutangSummary[];
  totalPiutang: number;
  storeName?: string;
  printedBy?: string;
}) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  doc.setFillColor(30, 41, 59);
  doc.rect(0, 0, pageWidth, 28, 'F');
  doc.setFillColor(234, 88, 12);
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text('REKAPITULASI SISA PIUTANG PER PELANGGAN (BELUM LUNAS)', marginX, 18);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  let currentY = 35;

  doc.setFillColor(254, 226, 226);
  doc.setDrawColor(239, 68, 68);
  doc.roundedRect(marginX, currentY, contentWidth, 14, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(153, 27, 27);
  doc.text(`TOTAL SISA PIUTANG KELUAR: ${fRp(totalPiutang)}`, marginX + 4, currentY + 8.5);
  doc.text(`Total Pelanggan Berpiutang: ${customerSummaries.length} Pelanggan`, pageWidth - marginX - 4, currentY + 8.5, { align: 'right' });

  currentY += 19;

  const tableData = customerSummaries.map((c, idx) => [
    (idx + 1).toString(),
    c.customerName,
    `${c.count} Invoice`,
    fRp(c.totalGross),
    fRp(c.totalPaid),
    fRp(c.totalSisa),
  ]);

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Nama Pelanggan', 'Jml Invoice', 'Total Transaksi', 'Total Dibayar', 'Sisa Piutang']],
    body: tableData,
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 2, fontSize: 8 },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { fontStyle: 'bold', cellWidth: 50 },
      2: { halign: 'center', cellWidth: 25 },
      3: { halign: 'right', cellWidth: 32 },
      4: { halign: 'right', cellWidth: 32 },
      5: { halign: 'right', cellWidth: 37, fontStyle: 'bold', textColor: [185, 28, 28] },
    },
    didParseCell: (data) => {
      if (data.section === 'foot') {
        if (data.column.index === 2) {
          data.cell.styles.halign = 'center';
        } else if (data.column.index >= 3) {
          data.cell.styles.halign = 'right';
        }
      }
    },
    foot: [
      [
        '',
        'TOTAL SELURUH PIUTANG',
        `${customerSummaries.reduce((a, b) => a + b.count, 0)} Inv`,
        fRp(customerSummaries.reduce((a, b) => a + b.totalGross, 0)),
        fRp(customerSummaries.reduce((a, b) => a + b.totalPaid, 0)),
        fRp(totalPiutang),
      ],
    ],
    footStyles: {
      fillColor: [254, 226, 226],
      textColor: [185, 28, 28],
      fontStyle: 'bold',
      fontSize: 8.5,
    },
  });

  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Rekapitulasi Piutang Pelanggan - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  doc.save(`Rekap_Piutang_Pelanggan_${new Date().toISOString().split('T')[0]}.pdf`);
}

interface GenerateFinancialReportOptions {
  periodLabel: string;
  totalOmset: number;
  totalPaid: number;
  totalPiutang: number;
  totalExpenses: number;
  expenses: ExpenseRecord[];
  expensesByCategory: Record<string, number>;
  invoices?: RecentInvoiceItem[];
  allInvoices?: RecentInvoiceItem[];
  storeName?: string;
  printedBy?: string;
  periodCashInflow?: PeriodCashInflowBreakdown;
  pelunasanItems?: PelunasanInflowItem[];
  fromNewSales?: number;
  fromPelunasanPiutang?: number;
}

function parseDateForLedgerSort(dateStr?: string, timeStr?: string): Date {
  if (!dateStr) return new Date(0);
  const parsed = parseUniversalDate(dateStr) || new Date(0);
  if (timeStr && typeof timeStr === 'string' && timeStr.includes(':')) {
    const [hh, mm] = timeStr.split(':');
    const hNum = parseInt(hh, 10);
    const mNum = parseInt(mm, 10);
    if (!isNaN(hNum) && !isNaN(mNum)) {
      parsed.setHours(hNum, mNum, 0, 0);
    }
  }
  return parsed;
}

export function generateFinancialReportPdf({
  periodLabel,
  totalOmset,
  totalPaid,
  totalPiutang,
  totalExpenses,
  expenses,
  expensesByCategory,
  invoices = [],
  allInvoices,
  storeName = 'ERVO PRINT DIGITAL PRINTING',
  printedBy = 'Owner / Manajemen',
  periodCashInflow,
  pelunasanItems = [],
  fromNewSales,
  fromPelunasanPiutang,
}: GenerateFinancialReportOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2;

  // Resolve breakdown metrics
  const actualPelunasan = fromPelunasanPiutang !== undefined
    ? fromPelunasanPiutang
    : (periodCashInflow?.fromPelunasanPiutang ?? pelunasanItems.reduce((acc, p) => acc + (p.jumlahBayar || 0), 0));
  
  const actualNewSales = fromNewSales !== undefined
    ? fromNewSales
    : (periodCashInflow?.fromNewSales ?? Math.max(0, totalPaid - actualPelunasan));

  const netBalance = totalPaid - totalExpenses;
  const netProfit = totalOmset - totalExpenses;
  const profitMarginPct = totalOmset > 0 ? ((netProfit / totalOmset) * 100).toFixed(1) : '0.0';

  // --- HEADER DECORATION ---
  doc.setFillColor(15, 23, 42); // Slate-900
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setFillColor(234, 88, 12); // Orange-600
  doc.rect(0, 28, pageWidth, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(storeName.toUpperCase(), marginX, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(226, 232, 240);
  doc.text(`Laporan Keuangan : ${periodLabel}`, marginX, 18);

  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  doc.setFontSize(8);
  doc.text(`Tgl Cetak: ${dateStr}`, pageWidth - marginX, 12, { align: 'right' });
  doc.text(`Dicetak Oleh: ${printedBy}`, pageWidth - marginX, 17, { align: 'right' });

  let currentY = 34;

  // --- 1 ROW FINANCIAL INDICATORS (4 COLUMNS LEFT TO RIGHT) ---
  const cardGap = 3;
  const cardW = (contentWidth - cardGap * 3) / 4; // ~44.25mm each
  const cardH = 26; // 26mm provides ample height for 2 clean, spacious detail rows
  const cY = currentY;

  // CARD 1: TOTAL OMSET
  const c1X = marginX;
  doc.setFillColor(239, 246, 255); // Blue 50
  doc.setDrawColor(191, 219, 254); // Blue 200
  doc.roundedRect(c1X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TOTAL OMSET', c1X + 3.2, cY + 5.2);
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalOmset), c1X + 3.2, cY + 11.8);
  doc.setDrawColor(219, 234, 254);
  doc.line(c1X + 3, cY + 14.8, c1X + cardW - 3, cY + 14.8);
  // Row 1: Sales Real / DP
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Sales Real/DP:', c1X + 3.2, cY + 18.8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text(fRp(actualNewSales), c1X + cardW - 3.2, cY + 18.8, { align: 'right' });
  // Row 2: Sisa Piutang
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Sisa Piutang:', c1X + 3.2, cY + 22.8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(180, 83, 9);
  doc.text(fRp(totalPiutang), c1X + cardW - 3.2, cY + 22.8, { align: 'right' });

  // CARD 2: TOTAL PENGELUARAN
  const c2X = marginX + cardW + cardGap;
  doc.setFillColor(254, 242, 242); // Red 50
  doc.setDrawColor(254, 202, 202); // Red 200
  doc.roundedRect(c2X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(153, 27, 27);
  doc.text('TOTAL PENGELUARAN', c2X + 3.2, cY + 5.2);
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(totalExpenses), c2X + 3.2, cY + 11.8);
  doc.setDrawColor(254, 226, 226);
  doc.line(c2X + 3, cY + 14.8, c2X + cardW - 3, cY + 14.8);
  // Row 1: Trx Biaya
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(153, 27, 27);
  doc.text('Jumlah Biaya:', c2X + 3.2, cY + 18.8);
  doc.setFont('helvetica', 'bold');
  doc.text(`${expenses.length} Transaksi`, c2X + cardW - 3.2, cY + 18.8, { align: 'right' });
  // Row 2: Kategori
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.text('Klasifikasi:', c2X + 3.2, cY + 22.8);
  doc.setFont('helvetica', 'bold');
  doc.text('Biaya Operasional', c2X + cardW - 3.2, cY + 22.8, { align: 'right' });

  // CARD 3: LABA BERSIH (PROFIT)
  const c3X = marginX + (cardW + cardGap) * 2;
  doc.setFillColor(236, 253, 245); // Emerald 50
  doc.setDrawColor(167, 243, 208); // Emerald 200
  doc.roundedRect(c3X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(6, 95, 70);
  doc.text('LABA BERSIH (PROFIT)', c3X + 3.2, cY + 5.2);
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text(fRp(netProfit), c3X + 3.2, cY + 11.8);
  doc.setDrawColor(209, 250, 229);
  doc.line(c3X + 3, cY + 14.8, c3X + cardW - 3, cY + 14.8);
  // Row 1: Profit Margin
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(4, 120, 87);
  doc.text('Profit Margin:', c3X + 3.2, cY + 18.8);
  doc.setFont('helvetica', 'bold');
  doc.text(`${profitMarginPct}%`, c3X + cardW - 3.2, cY + 18.8, { align: 'right' });
  // Row 2: Status
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.text('Status Keuangan:', c3X + 3.2, cY + 22.8);
  doc.setFont('helvetica', 'bold');
  doc.text(netProfit >= 0 ? 'Surplus Usaha' : 'Defisit Usaha', c3X + cardW - 3.2, cY + 22.8, { align: 'right' });

  // CARD 4: ARUS KAS MASUK (REAL)
  const c4X = marginX + (cardW + cardGap) * 3;
  doc.setFillColor(24, 24, 27); // Zinc 900
  doc.setDrawColor(39, 39, 42); // Zinc 800
  doc.roundedRect(c4X, cY, cardW, cardH, 2, 2, 'FD');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(228, 228, 231);
  doc.text('ARUS KAS MASUK (REAL)', c4X + 3.2, cY + 5.2);
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text(fRp(totalPaid), c4X + 3.2, cY + 11.8);
  doc.setDrawColor(63, 63, 70);
  doc.line(c4X + 3, cY + 14.8, c4X + cardW - 3, cY + 14.8);
  // Row 1: Sales Baru
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(161, 161, 170);
  doc.text('Sales Baru:', c4X + 3.2, cY + 18.8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(244, 244, 245);
  doc.text(fRp(actualNewSales), c4X + cardW - 3.2, cY + 18.8, { align: 'right' });
  // Row 2: Pelunasan Piutang
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(161, 161, 170);
  doc.text('Pelunasan:', c4X + 3.2, cY + 22.8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(251, 191, 36);
  doc.text(fRp(actualPelunasan), c4X + cardW - 3.2, cY + 22.8, { align: 'right' });

  // --- BREAKDOWN ARUS KAS MASUK BERDASARKAN METODE PEMBAYARAN ---
  const cashByMethod = periodCashInflow || calculateCashInflowByPaymentMethod(invoices);
  const breakdownY = cY + cardH + 3.5;
  const breakGap = 2.5;
  const breakW = (contentWidth - breakGap * 3) / 4; // 4 equal boxes (~44.6mm)
  const breakH = 11;

  // Box 1: Tunai
  doc.setFillColor(240, 253, 244); // Emerald 50
  doc.setDrawColor(187, 247, 208); // Emerald 200
  doc.roundedRect(marginX, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(22, 101, 52);
  doc.text('KAS TUNAI', marginX + 3, breakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(cashByMethod.Tunai), marginX + 3, breakdownY + 8.8);

  // Box 2: Transfer
  const b2X = marginX + breakW + breakGap;
  doc.setFillColor(239, 246, 255); // Blue 50
  doc.setDrawColor(191, 219, 254); // Blue 200
  doc.roundedRect(b2X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text('TRANSFER BANK', b2X + 3, breakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(cashByMethod.Transfer), b2X + 3, breakdownY + 8.8);

  // Box 3: Debet
  const b3X = marginX + (breakW + breakGap) * 2;
  doc.setFillColor(250, 245, 255); // Purple 50
  doc.setDrawColor(233, 213, 255); // Purple 200
  doc.roundedRect(b3X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(107, 33, 168);
  doc.text('KARTU DEBET', b3X + 3, breakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(cashByMethod.Debet), b3X + 3, breakdownY + 8.8);

  // Box 4: QRIS
  const b4X = marginX + (breakW + breakGap) * 3;
  doc.setFillColor(254, 252, 232); // Amber 50
  doc.setDrawColor(254, 240, 138); // Amber 200
  doc.roundedRect(b4X, breakdownY, breakW, breakH, 1.5, 1.5, 'FD');
  doc.setFontSize(5.2);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(133, 77, 14);
  doc.text('QRIS', b4X + 3, breakdownY + 4);
  doc.setFontSize(8);
  doc.text(fRp(cashByMethod.QRIS), b4X + 3, breakdownY + 8.8);

  currentY = breakdownY + breakH + 6;

  // --- SECTION TITLE: BUKU KAS & ARUS KAS ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  const cleanPeriodTitle = periodLabel.replace(/^\(|\)$/g, '').trim();
  doc.text(`BUKU KAS & MUTASI ARUS KAS — ${cleanPeriodTitle.toUpperCase()}`, marginX, currentY);
  currentY += 4;

  // --- BUILD CHRONOLOGICAL LEDGER ENTRIES ---
  interface LedgerEntry {
    date: string;
    ref: string;
    description: string;
    account: string;
    debit: number;
    kredit: number;
    rawDate: Date;
  }

  const combinedLedgerEntries: LedgerEntry[] = [];

  // 1. Initial & Same-Day Payments from Sales Created in this period
  invoices.forEach((inv) => {
    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const totalPaidOnInv = Math.max(0, tot - sisa);
    
    const histori: any[] = Array.isArray((inv as any).historiPelunasan)
      ? (inv as any).historiPelunasan
      : Array.isArray((inv as any).pelunasanHistory)
      ? (inv as any).pelunasanHistory
      : [];

    // Calculate cross-date payments on other days
    const totalCrossDatePaid = histori.reduce((sum, h) => {
      if (!h) return sum;
      const paymentDate = h.date || h.tanggal || inv.date;
      return isDatesDifferent(inv.date, paymentDate) ? sum + Number(h.jumlahBayar || 0) : sum;
    }, 0);

    // Cash received on invoice creation date (initial DP + any same-day settlement)
    const salesCashReceived = Math.max(0, totalPaidOnInv - totalCrossDatePaid);

    if (salesCashReceived > 0) {
      const payMethod = getInvoicePaymentCategory(inv);
      const statusText = sisa <= 0 ? 'Lunas Langsung' : `DP (Sisa Piutang ${fRp(sisa)})`;
      const invRefNo = inv.invoiceNo || (inv as any).noInvoice || (inv as any).id || 'INV';
      combinedLedgerEntries.push({
        date: inv.date || '-',
        ref: invRefNo,
        description: `Penjualan Baru - ${inv.customer || 'Umum'} (${statusText}) [${payMethod}]`,
        account: 'Pendapatan Penjualan',
        debit: salesCashReceived,
        kredit: 0,
        rawDate: parseDateForLedgerSort(inv.date, (inv as any).time),
      });
    }
  });

  // 2. Pelunasan & Angsuran Piutang received in this period
  pelunasanItems.forEach((pel) => {
    const noteExtra = pel.catatan ? ` - ${pel.catatan}` : '';
    const crossDateNote = pel.isCrossDate ? ` [Nota Tgl: ${pel.invoiceDate}]` : '';
    const pelRefNo = pel.invoiceNo || (pel as any).noInvoice || (pel as any).id || 'INV';
    combinedLedgerEntries.push({
      date: pel.date || '-',
      ref: pelRefNo,
      description: `Penerimaan Pelunasan/Angsuran - ${pel.customer} [${pel.payMethod}]${crossDateNote}${noteExtra}`,
      account: 'Penerimaan Piutang Usaha',
      debit: pel.jumlahBayar,
      kredit: 0,
      rawDate: parseDateForLedgerSort(pel.date, pel.time),
    });
  });

  // 3. Expenses in this period
  expenses.forEach((exp) => {
    const nom = Number(exp.nominal || 0);
    if (nom > 0) {
      const expRefNo = exp.buktiRef || exp.id || 'EXP';
      combinedLedgerEntries.push({
        date: exp.tanggal || '-',
        ref: expRefNo,
        description: `${exp.keterangan || 'Biaya Operasional'} [PJ: ${exp.pj || 'Admin'}]`,
        account: `Beban ${exp.kategori || 'Operasional'}`,
        debit: 0,
        kredit: nom,
        rawDate: parseDateForLedgerSort(exp.tanggal),
      });
    }
  });

  // Sort Chronologically
  combinedLedgerEntries.sort((a, b) => a.rawDate.getTime() - b.rawDate.getTime());

  // Compute Running Balance
  let runningBalance = 0;
  const ledgerRows = combinedLedgerEntries.map((entry, idx) => {
    runningBalance += entry.debit - entry.kredit;
    return [
      (idx + 1).toString(),
      entry.date,
      entry.ref,
      entry.description,
      entry.account,
      entry.debit > 0 ? fRp(entry.debit) : '-',
      entry.kredit > 0 ? fRp(entry.kredit) : '-',
      fRp(runningBalance),
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['No', 'Tanggal', 'No. Ref', 'Uraian Transaksi / Keterangan', 'Akun / Kategori', 'Debit (Masuk)', 'Kredit (Keluar)', 'Saldo Kas']],
    body: ledgerRows.length > 0 ? ledgerRows : [['-', '-', '-', 'Belum ada transaksi recorded pada periode ini', '-', 'Rp 0', 'Rp 0', 'Rp 0']],
    foot: [
      [
        '',
        '',
        '',
        'TOTAL MUTASI ARUS KAS PERIODE INI',
        '',
        fRp(totalPaid),
        fRp(totalExpenses),
        fRp(netBalance),
      ],
    ],
    margin: { left: marginX, right: marginX },
    theme: 'grid',
    styles: { cellPadding: 1.5, fontSize: 7, valign: 'middle' },
    headStyles: {
      fillColor: [30, 41, 59], // Slate 800
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    footStyles: {
      fillColor: [241, 245, 249], // Slate 100
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 7,
      valign: 'middle',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },                  // No
      1: { halign: 'center', cellWidth: 18 },                 // Tanggal
      2: { cellWidth: 29, fontStyle: 'bold', halign: 'center' }, // No. Ref (Wide enough for ERV-202608-xxx without wrapping)
      3: { cellWidth: 48 },                                   // Uraian
      4: { cellWidth: 26 },                                   // Akun
      5: { halign: 'right', cellWidth: 19, fontStyle: 'bold', textColor: [22, 101, 52] }, // Debit (Green)
      6: { halign: 'right', cellWidth: 18, fontStyle: 'bold', textColor: [185, 28, 28] }, // Kredit (Red)
      7: { halign: 'right', cellWidth: 21, fontStyle: 'bold', textColor: [15, 23, 42] },  // Saldo
    },
    didParseCell: (data) => {
      if (data.section === 'foot') {
        if (data.column.index === 3) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
        } else if (data.column.index === 5) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.textColor = [22, 101, 52];
        } else if (data.column.index === 6) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.textColor = [185, 28, 28];
        } else if (data.column.index === 7) {
          data.cell.styles.halign = 'right';
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.textColor = [15, 23, 42];
        }
      }
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 12;

  // Signatures Section
  if (currentY + 35 > pageHeight - 15) {
    doc.addPage();
    currentY = 20;
  }

  const signW = 60;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  // Left Signature (Manajemen Keuangan)
  doc.text('Dibuat & Divalidasi oleh,', marginX + 10, currentY);
  doc.text('Petugas / Manajemen Keuangan', marginX + 10, currentY + 4);
  doc.line(marginX + 10, currentY + 22, marginX + 10 + signW, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${printedBy})`, marginX + 10, currentY + 26);

  // Right Signature (Pemilik Studio)
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Menyetujui,', pageWidth - marginX - signW - 10, currentY);
  doc.text('Pemilik / Owner', pageWidth - marginX - signW - 10, currentY + 4);
  doc.line(pageWidth - marginX - signW - 10, currentY + 22, pageWidth - marginX - 10, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text('( Owner / Direktur )', pageWidth - marginX - signW - 10, currentY + 26);

  // Footer Page Numbering
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Dokumen Resmi Laporan Keuangan - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const filenameStr = periodLabel.toLowerCase().replace(/[^a-z0-9]/g, '_');
  doc.save(`Laporan_Keuangan_${filenameStr}_${new Date().toISOString().split('T')[0]}.pdf`);
}

// Generate Official Stock Opname & Inventory Audit PDF
export function generateStockOpnamePdf(
  record: StockOpnameRecord,
  settings?: Partial<StoreSettings>
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 14;

  const storeName = settings?.name || 'ERVO PRINT';
  const storeAddress = settings?.address || 'Jl. HOS Cokroaminoto No.17, Ciamis';
  const storePhone = settings?.phone || '0812-2247-2007';

  // 1. Header Banner
  doc.setFillColor(249, 115, 22); // Orange Ervo
  doc.rect(0, 0, pageWidth, 5, 'F');

  // Store & Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(30, 41, 59);
  doc.text(storeName, marginX, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`${storeAddress} | Telp/WA: ${storePhone}`, marginX, 20);

  // Document Badge on Right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  if (record.status === 'DRAFT') {
    doc.setTextColor(217, 119, 6);
    doc.text('DRAF BERITA ACARA OPNAME', pageWidth - marginX, 15, { align: 'right' });
  } else {
    doc.setTextColor(194, 65, 12);
    doc.text('BERITA ACARA STOK OPNAME', pageWidth - marginX, 15, { align: 'right' });
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`NO: #${record.id}`, pageWidth - marginX, 20, { align: 'right' });

  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(marginX, 24, pageWidth - marginX, 24);

  // 2. Metadata Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(marginX, 27, pageWidth - (marginX * 2), 20, 2, 2, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, 27, pageWidth - (marginX * 2), 20, 2, 2, 'D');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Periode / Waktu Audit:', marginX + 4, 32.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  const auditPeriodText = record.tanggalSelesai && record.tanggalSelesai !== record.tanggal
    ? `${record.tanggal} s/d ${record.tanggalSelesai} (${record.jam || '-'} WIB)`
    : `${record.tanggal} pukul ${record.jam || '-'} WIB`;
  doc.text(auditPeriodText, marginX + 34, 32.5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Metode Penyesuaian:', marginX + 4, 38);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text(
    record.metodePenyesuaian === 'DELTA' 
      ? 'Koreksi Delta Otomatis (Penjualan Multi-Hari Terakomodasi)' 
      : 'Timpa Stok Fisik Statis', 
    marginX + 32, 
    38
  );

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Petugas Lapangan:', marginX + 4, 43.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(record.pjKasir || 'Admin', marginX + 28, 43.5);

  const midX = marginX + ((pageWidth - (marginX * 2)) / 2);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Status & Otorisasi:', midX, 32.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(record.status === 'DRAFT' ? 180 : 15, record.status === 'DRAFT' ? 83 : 23, record.status === 'DRAFT' ? 9 : 42);
  doc.text(
    record.status === 'DRAFT' 
      ? 'DRAF BERJALAN (Belum Disahkan)' 
      : `${record.authorizedBy || 'Supervisor'} (Disahkan SPV)`, 
    midX + 28, 
    32.5
  );

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Mutasi Penjualan Interim:', midX, 38);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(record.totalPenjualanInterimQty ? 180 : 100, record.totalPenjualanInterimQty ? 83 : 116, record.totalPenjualanInterimQty ? 9 : 139);
  doc.text(
    record.totalPenjualanInterimQty 
      ? `${record.totalPenjualanInterimQty} unit terjual selama sesi` 
      : 'Tidak ada mutasi penjualan', 
    midX + 34, 
    38
  );

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Catatan Sesi:', midX, 43.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  const truncatedNote = (record.catatanUmum || '-').length > 38
    ? (record.catatanUmum || '-').substring(0, 35) + '...'
    : (record.catatanUmum || '-');
  doc.text(truncatedNote, midX + 18, 43.5);

  // 3. Summary KPI Cards
  const boxW = (pageWidth - (marginX * 2) - 9) / 4;
  const boxY = 50;
  const boxH = 15;

  // Box 1: Total Diperiksa
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(marginX, boxY, boxW, boxH, 1.5, 1.5, 'F');
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('ITEM DIPERIKSA', marginX + 3, boxY + 5);
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text(`${record.totalItemDiperiksa} Item`, marginX + 3, boxY + 11.5);

  // Box 2: Item Berselisih
  doc.setFillColor(254, 242, 242);
  doc.roundedRect(marginX + boxW + 3, boxY, boxW, boxH, 1.5, 1.5, 'F');
  doc.setFontSize(6.5);
  doc.setTextColor(185, 28, 28);
  doc.text('ITEM BERSELISIH', marginX + boxW + 6, boxY + 5);
  doc.setFontSize(11);
  doc.setTextColor(153, 27, 27);
  doc.text(`${record.totalItemSelisih} Item`, marginX + boxW + 6, boxY + 11.5);

  // Box 3: Qty Kurang & Lebih
  doc.setFillColor(254, 243, 199);
  doc.roundedRect(marginX + (boxW * 2) + 6, boxY, boxW, boxH, 1.5, 1.5, 'F');
  doc.setFontSize(6.5);
  doc.setTextColor(180, 83, 9);
  doc.text('TOTAL SELISIH QTY', marginX + (boxW * 2) + 9, boxY + 5);
  doc.setFontSize(10);
  doc.setTextColor(146, 64, 14);
  doc.text(`-${record.totalSelisihKurangQty || 0} / +${record.totalSelisihLebihQty || 0}`, marginX + (boxW * 2) + 9, boxY + 11.5);

  // Box 4: Net Nominal Rp
  const isLoss = (record.totalSelisihNominalRp || 0) < 0;
  doc.setFillColor(isLoss ? 254 : 240, isLoss ? 242 : 253, isLoss ? 242 : 244);
  doc.roundedRect(marginX + (boxW * 3) + 9, boxY, boxW, boxH, 1.5, 1.5, 'F');
  doc.setFontSize(6.5);
  doc.setTextColor(isLoss ? 185 : 21, isLoss ? 28 : 128, isLoss ? 28 : 61);
  doc.text('SELISIH NILAI (RP)', marginX + (boxW * 3) + 12, boxY + 5);
  doc.setFontSize(10);
  doc.setTextColor(isLoss ? 153 : 22, isLoss ? 27 : 101, isLoss ? 27 : 52);
  const formattedNominal = record.totalSelisihNominalRp < 0
    ? `-${fRp(Math.abs(record.totalSelisihNominalRp))}`
    : record.totalSelisihNominalRp > 0
    ? `+${fRp(record.totalSelisihNominalRp)}`
    : 'Rp 0';
  doc.text(formattedNominal, marginX + (boxW * 3) + 12, boxY + 11.5);

  // 4. Detail Table
  const tableData = record.items.map((item, idx) => {
    let diffLabel = `${item.selisih}`;
    if (item.selisih > 0) diffLabel = `+${item.selisih}`;

    let selisihRpText = 'Rp 0';
    if (item.selisihNilaiRp < 0) selisihRpText = `-${fRp(Math.abs(item.selisihNilaiRp))}`;
    else if (item.selisihNilaiRp > 0) selisihRpText = `+${fRp(item.selisihNilaiRp)}`;

    let reasonText = item.selisih === 0
      ? 'Sesuai'
      : item.alasan + (item.catatan ? ` (${item.catatan})` : '');
    if ((item.penjualanInterim || 0) > 0) {
      reasonText += ` (Terjual kasir: ${item.penjualanInterim})`;
    }

    const finalStock = item.stokPenyesuaianAkhir !== undefined ? item.stokPenyesuaianAkhir : item.stokFisik;

    return [
      idx + 1,
      item.kode || '-',
      item.nama,
      item.satuan || 'pcs',
      item.stokSistem,
      item.stokFisik,
      diffLabel,
      finalStock,
      reasonText,
      selisihRpText,
    ];
  });

  autoTable(doc, {
    startY: 70,
    margin: { left: marginX, right: marginX, bottom: 35 },
    head: [[
      'No',
      'Kode',
      'Nama Produk',
      'Satuan',
      'Baseline',
      'Fisik',
      'Delta',
      'Stok Akhir',
      'Alasan & Mutasi Interim',
      'Selisih Nilai (Rp)',
    ]],
    body: tableData,
    theme: 'striped',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 7,
      textColor: [51, 65, 85],
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },
      1: { halign: 'center', cellWidth: 16 },
      2: { halign: 'left' },
      3: { halign: 'center', cellWidth: 12 },
      4: { halign: 'center', cellWidth: 13 },
      5: { halign: 'center', cellWidth: 13 },
      6: { halign: 'center', cellWidth: 13, fontStyle: 'bold' },
      7: { halign: 'center', cellWidth: 14, fontStyle: 'bold' },
      8: { halign: 'left', cellWidth: 42 },
      9: { halign: 'right', cellWidth: 22, fontStyle: 'bold' },
    },
    didParseCell: (hookData) => {
      if (hookData.section === 'body' && hookData.column.index === 6) {
        const valStr = String(hookData.cell.raw);
        if (valStr.startsWith('-')) {
          hookData.cell.styles.textColor = [220, 38, 38]; // Red
        } else if (valStr.startsWith('+')) {
          hookData.cell.styles.textColor = [37, 99, 235]; // Blue
        } else {
          hookData.cell.styles.textColor = [16, 149, 193]; // Match
        }
      }
      if (hookData.section === 'body' && hookData.column.index === 9) {
        const valStr = String(hookData.cell.raw);
        if (valStr.startsWith('-')) {
          hookData.cell.styles.textColor = [220, 38, 38];
        } else if (valStr.startsWith('+')) {
          hookData.cell.styles.textColor = [37, 99, 235];
        }
      }
    },
  });

  // 5. Signature Section
  let currentY = (doc as any).lastAutoTable.finalY + 10;
  if (currentY + 30 > pageHeight) {
    doc.addPage();
    currentY = 20;
  }

  const signW = 60;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  // Left Signature (Petugas Pemeriksa)
  doc.text('Petugas Lapangan / Kasir,', marginX + 10, currentY);
  doc.text('Yang Melakukan Pengecekan Fisik', marginX + 10, currentY + 4);
  doc.line(marginX + 10, currentY + 22, marginX + 10 + signW, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${record.pjKasir || 'Petugas'})`, marginX + 10, currentY + 26);

  // Right Signature (Supervisor / Owner)
  doc.setFont('helvetica', 'normal');
  doc.text('Disetujui & Divalidasi oleh,', pageWidth - marginX - signW - 10, currentY);
  doc.text('Supervisor / Pemilik Usaha', pageWidth - marginX - signW - 10, currentY + 4);
  doc.line(pageWidth - marginX - signW - 10, currentY + 22, pageWidth - marginX - 10, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${record.authorizedBy || 'Supervisor / Owner'})`, pageWidth - marginX - signW - 10, currentY + 26);

  // 6. Footer Page Numbering
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Berita Acara Stok Opname - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const dateStr = record.tanggal || new Date().toISOString().split('T')[0];
  doc.save(`Berita_Acara_Stok_Opname_${record.id}_${dateStr}.pdf`);
}

// Generate Physical Count Blank Worksheet PDF for Field Staff
export function generateStockOpnameWorksheetPdf(
  items: Array<{
    kode?: string;
    nama: string;
    kategori?: string;
    satuan?: string;
    stokSistem?: number;
    stokFisik?: number;
  }>,
  sessionInfo: {
    sessionId: string;
    tanggal: string;
    jam?: string;
    pjKasir?: string;
    catatan?: string;
    kategoriFilter?: string;
  },
  settings?: Partial<StoreSettings>
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 12;

  const storeName = settings?.name || 'ERVO PRINT';
  const storeAddress = settings?.address || 'Jl. HOS Cokroaminoto No.17, Ciamis';
  const storePhone = settings?.phone || '0812-2247-2007';

  // 1. Header Banner
  doc.setFillColor(37, 99, 235); // Royal Blue
  doc.rect(0, 0, pageWidth, 5, 'F');

  // Store & Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(30, 41, 59);
  doc.text(storeName, marginX, 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`${storeAddress} | Telp/WA: ${storePhone}`, marginX, 19);

  // Document Badge on Right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(29, 78, 216);
  doc.text('LEMBAR KERJA PENGHITUNGAN FISIK', pageWidth - marginX, 14, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`SESI: #${sessionInfo.sessionId} (BLANGKO AUDIT)`, pageWidth - marginX, 19, { align: 'right' });

  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(marginX, 23, pageWidth - marginX, 23);

  // 2. Metadata Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(marginX, 26, pageWidth - (marginX * 2), 22, 2, 2, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, 26, pageWidth - (marginX * 2), 22, 2, 2, 'D');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Tanggal & Jam Audit:', marginX + 4, 31.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`${sessionInfo.tanggal} ${sessionInfo.jam ? `pukul ${sessionInfo.jam} WIB` : ''}`, marginX + 32, 31.5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Petugas Pelaksana:', marginX + 4, 37);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(sessionInfo.pjKasir || 'Tim Auditor Lapangan', marginX + 32, 37);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('Total Item Daftar:', marginX + 4, 42.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`${items.length} Item Produk ${sessionInfo.kategoriFilter && sessionInfo.kategoriFilter !== 'ALL' ? `(Kategori: ${sessionInfo.kategoriFilter})` : ''}`, marginX + 32, 42.5);

  const midX = marginX + ((pageWidth - (marginX * 2)) / 2);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59);
  doc.text('Petunjuk Pengisian Fisik Lapangan:', midX, 31.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.setFontSize(7);
  doc.text('1. Hitung jumlah fisik riil di rak/etalase dan tulis jelas di kolom "Fisik Riil".', midX, 36);
  doc.text('2. Cantumkan kondisi bila ada barang rusak/cacat/kadaluarsa di kolom Keterangan.', midX, 40);
  doc.text('3. Bubuhkan paraf petugas setelah item selesai dihitung untuk validitas audit.', midX, 44);

  // 3. Table
  const tableData = items.map((it, idx) => [
    idx + 1,
    it.kode || '-',
    it.nama,
    it.kategori || '-',
    it.satuan || 'pcs',
    it.stokSistem !== undefined ? String(it.stokSistem) : '-',
    it.stokFisik !== undefined && it.stokFisik > 0 ? String(it.stokFisik) : '[          ]',
    '', // Kolom Keterangan / Catatan kondisi (tulis tangan)
    '[    ]', // Kolom Paraf
  ]);

  autoTable(doc, {
    startY: 52,
    margin: { left: marginX, right: marginX, bottom: 35 },
    head: [[
      'No',
      'Kode / Barcode',
      'Nama Produk',
      'Kategori',
      'Satuan',
      'Stok Sistem',
      'Fisik Riil [Tulis]',
      'Kondisi & Catatan Fisik',
      'Paraf',
    ]],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 7,
      textColor: [51, 65, 85],
      minCellHeight: 6.5,
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 7 },
      1: { halign: 'center', cellWidth: 20 },
      2: { halign: 'left' },
      3: { halign: 'left', cellWidth: 24 },
      4: { halign: 'center', cellWidth: 12 },
      5: { halign: 'center', cellWidth: 15, fontStyle: 'bold' },
      6: { halign: 'center', cellWidth: 24, fontStyle: 'bold' },
      7: { halign: 'left', cellWidth: 32 },
      8: { halign: 'center', cellWidth: 12 },
    },
  });

  // 4. Signature Section
  let currentY = (doc as any).lastAutoTable.finalY + 10;
  if (currentY + 30 > pageHeight) {
    doc.addPage();
    currentY = 20;
  }

  const signW = 60;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  // Left Signature (Petugas Penghitung)
  doc.text('Petugas Penghitung Lapangan,', marginX + 10, currentY);
  doc.text('Telah melakukan hitungan fisik riil', marginX + 10, currentY + 4);
  doc.line(marginX + 10, currentY + 22, marginX + 10 + signW, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${sessionInfo.pjKasir || 'Petugas Lapangan'})`, marginX + 10, currentY + 26);

  // Right Signature (Saksi / Supervisor)
  doc.setFont('helvetica', 'normal');
  doc.text('Saksi / Supervisor Gudang,', pageWidth - marginX - signW - 10, currentY);
  doc.text('Memverifikasi keabsahan hitungan', pageWidth - marginX - signW - 10, currentY + 4);
  doc.line(pageWidth - marginX - signW - 10, currentY + 22, pageWidth - marginX - 10, currentY + 22);
  doc.setFont('helvetica', 'bold');
  doc.text('(..................................................)', pageWidth - marginX - signW - 10, currentY + 26);

  // 5. Page Numbers
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Lembar Kerja Fisik Stok Opname - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 7,
      { align: 'center' }
    );
  }

  const dateClean = (sessionInfo.tanggal || new Date().toISOString().split('T')[0]).replace(/-/g, '');
  doc.save(`Lembar_Kerja_Opname_${sessionInfo.sessionId}_${dateClean}.pdf`);
}

// Generate Official Stock In & Purchase Order (PO) History PDF
export function generateStockInHistoryPdf(
  items: StockInRecord[],
  settings?: Partial<StoreSettings>,
  operator?: string
): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 297mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 210mm
  const marginX = 14;

  const storeName = settings?.name || 'ERVO PRINT';
  const storeAddress = settings?.address || 'Jl. HOS Cokroaminoto No.17, Ciamis';
  const storePhone = settings?.phone || '0812-2247-2007';

  // 1. Header Banner
  doc.setFillColor(79, 70, 229); // Indigo 600
  doc.rect(0, 0, pageWidth, 5, 'F');

  // Store & Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(30, 41, 59);
  doc.text(storeName, marginX, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`${storeAddress} | Telp/WA: ${storePhone}`, marginX, 20);

  // Document Badge on Right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(67, 56, 202);
  doc.text('LAPORAN RIWAYAT BARANG MASUK & PO', pageWidth - marginX, 15, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  const now = new Date();
  const printDateStr = `${fDateInput(now)} ${fTime(now)} WIB`;
  doc.text(`Dicetak: ${printDateStr} | Operator: ${operator || 'Admin'}`, pageWidth - marginX, 20, { align: 'right' });

  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(marginX, 24, pageWidth - marginX, 24);

  // 2. Summary KPI Cards
  const totalLogs = items.length;
  const totalQty = items.reduce((acc, it) => acc + (Number(it.qty) || 0), 0);
  const totalBiaya = items.reduce((acc, it) => acc + (Number(it.totalBiaya) || 0), 0);
  const totalPo = items.filter(it => it.noPo).length;

  const cardY = 27;
  const cardH = 14;
  const cardGap = 4;
  const cardW = (pageWidth - (marginX * 2) - (cardGap * 3)) / 4;

  // Card 1: Total Catatan Log
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(marginX, cardY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(marginX, cardY, cardW, cardH, 1.5, 1.5, 'D');
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL LOG AKTIVITAS', marginX + 3, cardY + 4.5);
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`${totalLogs} Catatan Log`, marginX + 3, cardY + 10.5);

  // Card 2: Total Qty Masuk
  const c2X = marginX + cardW + cardGap;
  doc.setFillColor(240, 253, 244);
  doc.roundedRect(c2X, cardY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setDrawColor(187, 247, 208);
  doc.roundedRect(c2X, cardY, cardW, cardH, 1.5, 1.5, 'D');
  doc.setFontSize(7);
  doc.setTextColor(22, 101, 52);
  doc.text('TOTAL STOK MASUK (QTY)', c2X + 3, cardY + 4.5);
  doc.setFontSize(10);
  doc.setTextColor(21, 128, 61);
  doc.text(`+${totalQty.toLocaleString('id-ID')} Satuan`, c2X + 3, cardY + 10.5);

  // Card 3: Total Transaksi PO
  const c3X = c2X + cardW + cardGap;
  doc.setFillColor(238, 242, 255);
  doc.roundedRect(c3X, cardY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setDrawColor(199, 210, 254);
  doc.roundedRect(c3X, cardY, cardW, cardH, 1.5, 1.5, 'D');
  doc.setFontSize(7);
  doc.setTextColor(67, 56, 202);
  doc.text('TRANSAKSI NO. PO', c3X + 3, cardY + 4.5);
  doc.setFontSize(10);
  doc.setTextColor(79, 70, 229);
  doc.text(`${totalPo} Transaksi PO`, c3X + 3, cardY + 10.5);

  // Card 4: Total Belanja / Biaya PO
  const c4X = c3X + cardW + cardGap;
  doc.setFillColor(254, 252, 232);
  doc.roundedRect(c4X, cardY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setDrawColor(254, 240, 138);
  doc.roundedRect(c4X, cardY, cardW, cardH, 1.5, 1.5, 'D');
  doc.setFontSize(7);
  doc.setTextColor(133, 77, 14);
  doc.text('TOTAL BIAYA PEMBELIAN', c4X + 3, cardY + 4.5);
  doc.setFontSize(10);
  doc.setTextColor(161, 98, 7);
  doc.text(totalBiaya > 0 ? fRp(totalBiaya) : 'Rp 0', c4X + 3, cardY + 10.5);

  // 3. Table Rows
  const tableData = items.map((it, idx) => {
    const dateTimeStr = [it.date || it.tanggal || '', it.time || it.jam || ''].filter(Boolean).join(' ') || '-';
    const poStr = it.noPo ? it.noPo : (Number(it.qty) > 0 ? 'Restock Langsung' : 'Edit / Penyesuaian');
    const prodStr = `${it.nama || '-'}\n[${it.kode || '-'}]`;
    const qtyStr = Number(it.qty) > 0 ? `+${it.qty} ${it.satuan || ''}` : 'Edit Data';
    const biayaStr = it.totalBiaya ? fRp(it.totalBiaya) : (it.hargaBeli ? fRp(it.hargaBeli) : '-');
    const supplierStr = it.supplier || 'Suplier Umum';
    const cashierStr = it.cashier || it.penanggungJawab || '-';
    const notesStr = it.catatan || '-';

    return [
      idx + 1,
      dateTimeStr,
      poStr,
      prodStr,
      supplierStr,
      qtyStr,
      biayaStr,
      cashierStr,
      notesStr,
    ];
  });

  autoTable(doc, {
    startY: 46,
    margin: { left: marginX, right: marginX, bottom: 25 },
    head: [[
      'No',
      'Waktu',
      'No. PO / Tipe',
      'Produk & Kode',
      'Suplier / Vendor',
      'Masuk (Qty)',
      'Total Biaya',
      'Operator',
      'Catatan / Penyesuaian',
    ]],
    body: tableData,
    theme: 'striped',
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [51, 65, 85],
      cellPadding: 2,
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 26 },
      2: { halign: 'center', cellWidth: 25, fontStyle: 'bold' },
      3: { halign: 'left', cellWidth: 48, fontStyle: 'bold' },
      4: { halign: 'left', cellWidth: 38 },
      5: { halign: 'center', cellWidth: 22, fontStyle: 'bold' },
      6: { halign: 'right', cellWidth: 25, fontStyle: 'bold' },
      7: { halign: 'center', cellWidth: 20 },
      8: { halign: 'left' },
    },
    didParseCell: (data) => {
      if (data.section === 'body') {
        if (data.column.index === 5) {
          const raw = String(data.cell.raw);
          if (raw.startsWith('+')) {
            data.cell.styles.textColor = [21, 128, 61]; // Green
          } else if (raw === 'Edit Data') {
            data.cell.styles.textColor = [30, 64, 175]; // Blue
          }
        }
        if (data.column.index === 6) {
          const raw = String(data.cell.raw);
          if (raw.startsWith('Rp')) {
            data.cell.styles.textColor = [180, 83, 9]; // Amber
          }
        }
      }
    },
  });

  // 4. Signatures
  let currentY = (doc as any).lastAutoTable.finalY + 8;
  if (currentY + 28 > pageHeight) {
    doc.addPage();
    currentY = 20;
  }

  const signW = 55;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(30, 41, 59);

  // Left Signature
  doc.text('Petugas Logistik / Gudang,', marginX + 15, currentY);
  doc.line(marginX + 15, currentY + 18, marginX + 15 + signW, currentY + 18);
  doc.setFont('helvetica', 'bold');
  doc.text(`(${operator || 'Petugas'})`, marginX + 15, currentY + 22);

  // Right Signature
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui & Menyetujui,', pageWidth - marginX - signW - 15, currentY);
  doc.line(pageWidth - marginX - signW - 15, currentY + 18, pageWidth - marginX - 15, currentY + 18);
  doc.setFont('helvetica', 'bold');
  doc.text('(Supervisor / Owner)', pageWidth - marginX - signW - 15, currentY + 22);

  // 5. Page numbering
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Laporan Riwayat Barang Masuk & PO - ${storeName} - Halaman ${i} dari ${totalPages}`,
      pageWidth / 2,
      pageHeight - 6,
      { align: 'center' }
    );
  }

  const dateFile = new Date().toISOString().slice(0, 10);
  doc.save(`Laporan_Riwayat_Barang_Masuk_${dateFile}.pdf`);
}



