import { InvoiceItem, StoreSettings } from '../types';

export function fRp(n: number): string {
  if (isNaN(n)) return 'Rp 0';
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

export function fNum(n: number): string {
  if (isNaN(n)) return '0';
  return Math.round(n).toLocaleString('id-ID');
}

export function fDec(n: number, d = 2): string {
  if (isNaN(n)) return '0';
  return Number(n).toFixed(d);
}

export function fDate(d: Date): string {
  return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
}

export function fTime(d: Date): string {
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

export function fDateInput(d: Date): string {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

export function formatDateFromInput(val: string): string {
  if (!val) return '';
  const parts = val.split('-');
  if (parts.length !== 3) return val;
  const [y, m, d] = parts;
  return `${d}/${m}/${y}`;
}

export function escHtml(s: any): string {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function computeItemTotal(item: InvoiceItem): number {
  const parseNum = (v: any): number => {
    if (v === undefined || v === null || v === '') return 0;
    if (typeof v === 'number') return isNaN(v) ? 0 : v;
    const cleaned = String(v).trim().replace(',', '.');
    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
  };

  const rawQty = parseNum(item.qty);
  const qty = rawQty > 0 ? rawQty : 0;
  const diskon = parseNum(item.diskonItem);
  const harga = parseNum(item.harga);
  const hargaSatuan = Math.max(0, harga - diskon);
  const p = parseNum(item.panjang);
  const l = parseNum(item.lebar);

  if (item.tipeHarga === 'ukuran' && p > 0 && l > 0) {
    return qty * p * l * hargaSatuan;
  }
  return qty * hargaSatuan;
}

export const INITIAL_PRODUCTS = [
  { kode: 'BHN01', nama: 'Bahan Roll Flexi Banner 280g', harga: 0, kategori: 'Bahan Baku', stok: '3', satuan: 'roll', tipeHarga: 'fix' },
  { kode: 'BHN02', nama: 'Bahan Kertas Art Paper 230g A3+', harga: 0, kategori: 'Bahan Baku', stok: '8', satuan: 'pack', tipeHarga: 'fix' },
  { kode: 'BHN03', nama: 'Bahan Stiker Vinyl Glossy Roll', harga: 0, kategori: 'Bahan Baku', stok: '0', satuan: 'roll', tipeHarga: 'fix' },
  { kode: 'BNR01', nama: 'Cetak Banner / Spanduk 280g', harga: 25000, kategori: 'Banner', stok: '', satuan: 'm²', tipeHarga: 'ukuran' },
  { kode: 'BNR02', nama: 'Cetak Banner Flexi High-Res 340g', harga: 35000, kategori: 'Banner', stok: '', satuan: 'm²', tipeHarga: 'ukuran' },
  { kode: 'BNR03', nama: 'Cetak MMT Billboard 440g', harga: 55000, kategori: 'Banner', stok: '', satuan: 'm²', tipeHarga: 'ukuran' },
  { kode: 'SUB01', nama: 'Cetak Sublime Jersey Printing', harga: 85000, kategori: 'Sublime', stok: '', satuan: 'pcs', tipeHarga: 'fix' },
  { kode: 'SUB02', nama: 'Cetak Sublime Tote Bag Canvas', harga: 45000, kategori: 'Sublime', stok: '', satuan: 'pcs', tipeHarga: 'fix' },
  { kode: 'A3P01', nama: 'Cetak A3+ Photo Paper 230g', harga: 15000, kategori: 'Cetak A3+', stok: '500', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'A3P02', nama: 'Cetak A3+ Art Paper 150g', harga: 12000, kategori: 'Cetak A3+', stok: '1000', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'DTF01', nama: 'Cetak DTF UV Lembaran (A3)', harga: 25000, kategori: 'DTF UV', stok: '', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'DTF02', nama: 'Cetak DTF UV Meteran (Roll)', harga: 45000, kategori: 'DTF UV', stok: '', satuan: 'meter', tipeHarga: 'fix' },
  { kode: 'STK01', nama: 'Stiker Vinyl UV Outdoor (m²)', harga: 120000, kategori: 'Stiker UV', stok: '', satuan: 'm²', tipeHarga: 'ukuran' },
  { kode: 'STK02', nama: 'Stiker Cromo A3+ (Print & Cut)', harga: 18000, kategori: 'Stiker UV', stok: '250', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'STK03', nama: 'Stiker Transparan A3+ UV', harga: 22000, kategori: 'Stiker UV', stok: '300', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'ADD01', nama: 'Finishing Laminasi Doff A3+', harga: 8000, kategori: 'Finishing', stok: '', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'ADD02', nama: 'Finishing Laminasi Glossy A3+', harga: 8000, kategori: 'Finishing', stok: '', satuan: 'lembar', tipeHarga: 'fix' },
  { kode: 'ADD03', nama: 'Jasa Cutting Stiker KissCut', harga: 5000, kategori: 'Finishing', stok: '', satuan: 'lembar', tipeHarga: 'fix' },
];

export const INITIAL_CUSTOMERS = [
  { nama: 'Umum', kelas: 'Reguler', diskon: 0, telepon: '', catatan: 'Pelanggan tanpa data khusus', alamat: '' },
  { nama: 'Budi Santoso', kelas: 'Member VIP', diskon: 10, telepon: '081299887766', catatan: 'Langganan Komunitas Digital', alamat: 'Jl. Ahmad Yani No. 45' },
  { nama: 'Studio Desain Ervo', kelas: 'Agen Reseller', diskon: 15, telepon: '081344556677', catatan: 'Mitra Reseller Cetak', alamat: 'Jl. Riau No. 12' }
];

export interface CashInflowByMethod {
  Tunai: number;
  Transfer: number;
  Debet: number;
  QRIS: number;
  Total: number;
  counts: {
    Tunai: number;
    Transfer: number;
    Debet: number;
    QRIS: number;
    Total: number;
  };
}

export function getInvoicePaymentCategory(inv: any): 'Tunai' | 'Transfer' | 'Debet' | 'QRIS' | 'Belum Bayar' {
  if (!inv) return 'Belum Bayar';

  const tot = Number(inv.total || 0);
  const sisa = Number(inv.sisa !== undefined ? inv.sisa : 0);
  const paid = Math.max(0, tot - sisa);
  const dp = Number(inv.dp || 0);
  const mainMethod = String(inv.payMethod || inv.metodePembayaran || inv.caraBayar || inv.metode || inv.paymentMethod || '').trim().toUpperCase();

  const histori = Array.isArray(inv.historiPelunasan)
    ? inv.historiPelunasan
    : Array.isArray(inv.pelunasanHistory)
    ? inv.pelunasanHistory
    : Array.isArray(inv.history)
    ? inv.history
    : [];
  const hasPaidHistory = histori.some((h: any) => Number(h?.jumlahBayar || 0) > 0);

  // If explicitly 'BELUM BAYAR' or no payment has ever been made on this invoice
  if (mainMethod.includes('BELUM') || (paid <= 0 && dp <= 0 && !hasPaidHistory)) {
    return 'Belum Bayar';
  }

  const parseCatStr = (s: string): 'Tunai' | 'Transfer' | 'Debet' | 'QRIS' | null => {
    const raw = (s || '').toString().trim().toUpperCase();
    if (!raw) return null;
    if (
      raw.includes('TRANSFER') ||
      raw.includes('BANK') ||
      raw.includes('BCA') ||
      raw.includes('MANDIRI') ||
      raw.includes('BRI') ||
      raw.includes('BNI') ||
      raw.includes('BSI') ||
      raw.includes('PERMATA') ||
      raw.includes('CIMB') ||
      raw.includes('ATM') ||
      raw.includes('TF') ||
      raw.includes('VA') ||
      raw.includes('REKENING') ||
      raw.includes('SEABANK') ||
      raw.includes('JAGO') ||
      raw.includes('NEO') ||
      raw.includes('BLU')
    ) {
      return 'Transfer';
    }
    if (raw.includes('QRIS') || raw.includes('Q-RIS')) {
      return 'QRIS';
    }
    if (raw.includes('DEBET') || raw.includes('DEBIT') || raw.includes('KARTU') || raw.includes('EDC') || raw.includes('CARD')) {
      return 'Debet';
    }
    if (raw.includes('TUNAI') || raw.includes('CASH')) {
      return 'Tunai';
    }
    return null;
  };

  // 1. Check primary payMethod / metodePembayaran / aliases if explicitly set
  const mainCat = parseCatStr(mainMethod);

  // 2. Check historiPelunasan / pelunasanHistory / history for any non-tunai payment method first
  for (const h of histori) {
    if (!h) continue;
    const hCat = parseCatStr(h.payMethod || h.metodePembayaran || h.metode || h.caraBayar || '');
    if (hCat && hCat !== 'Tunai') {
      return hCat;
    }
  }

  if (mainCat) {
    return mainCat;
  }

  // 3. If mainCat was not detected, check if any history payment exists
  for (const h of histori) {
    if (!h) continue;
    const hCat = parseCatStr(h.payMethod || h.metodePembayaran || h.metode || h.caraBayar || '');
    if (hCat) {
      return hCat;
    }
  }

  return 'Tunai';
}

export function parseUniversalDate(dateStr?: string): Date | null {
  if (!dateStr || typeof dateStr !== 'string' || !dateStr.trim()) return null;
  const cleaned = dateStr.trim();

  // Format 1: DD/MM/YYYY or DD/MM/YYYY HH:mm or D/M/YYYY
  if (cleaned.includes('/')) {
    const spaceSplit = cleaned.split(' ')[0];
    const parts = spaceSplit.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const year = parseInt(parts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month, day);
      }
    }
  }

  // Format 2: YYYY-MM-DD or YYYY-MM-DD HH:mm or YYYY-MM-DDTHH:mm
  if (cleaned.includes('-')) {
    const spaceSplit = cleaned.split('T')[0].split(' ')[0];
    const parts = spaceSplit.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month, day);
      }
    }
  }

  // Fallback
  const d = new Date(cleaned);
  if (!isNaN(d.getTime())) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  return null;
}

export function isDateInPeriod(
  dateStr?: string,
  period: string = 'today',
  customStartDate?: string,
  customEndDate?: string
): boolean {
  if (period === 'all') return true;
  const itemDate = parseUniversalDate(dateStr);
  if (!itemDate) return false;

  const now = new Date();
  const todayLocal = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (period === 'today') {
    return (
      itemDate.getFullYear() === todayLocal.getFullYear() &&
      itemDate.getMonth() === todayLocal.getMonth() &&
      itemDate.getDate() === todayLocal.getDate()
    );
  }

  if (period === 'week') {
    const sevenDaysAgo = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate() - 6);
    const endOfToday = new Date(todayLocal.getFullYear(), todayLocal.getMonth(), todayLocal.getDate(), 23, 59, 59, 999);
    return itemDate >= sevenDaysAgo && itemDate <= endOfToday;
  }

  if (period === 'month') {
    return (
      itemDate.getFullYear() === todayLocal.getFullYear() &&
      itemDate.getMonth() === todayLocal.getMonth()
    );
  }

  if (period === 'custom') {
    if (!customStartDate && !customEndDate) return true;
    const startD = customStartDate ? new Date(customStartDate + 'T00:00:00') : new Date(0);
    const endD = customEndDate ? new Date(customEndDate + 'T23:59:59.999') : new Date(8640000000000000);
    return itemDate >= startD && itemDate <= endD;
  }

  return true;
}

export function parsePaymentCategory(methodStr?: string): 'Tunai' | 'Transfer' | 'Debet' | 'QRIS' {
  const u = (methodStr || '').toString().trim().toUpperCase();
  if (
    u.includes('TRANSFER') ||
    u.includes('BANK') ||
    u.includes('BCA') ||
    u.includes('MANDIRI') ||
    u.includes('BRI') ||
    u.includes('BNI') ||
    u.includes('BSI') ||
    u.includes('PERMATA') ||
    u.includes('CIMB') ||
    u.includes('ATM') ||
    u.includes('TF') ||
    u.includes('VA') ||
    u.includes('REKENING') ||
    u.includes('SEABANK') ||
    u.includes('JAGO') ||
    u.includes('NEO') ||
    u.includes('BLU')
  ) {
    return 'Transfer';
  }
  if (u.includes('QRIS') || u.includes('Q-RIS')) {
    return 'QRIS';
  }
  if (u.includes('DEBET') || u.includes('DEBIT') || u.includes('KARTU') || u.includes('EDC') || u.includes('CARD')) {
    return 'Debet';
  }
  return 'Tunai';
}

export interface PelunasanInflowItem {
  invoiceNo: string;
  customer: string;
  cashier: string;
  date: string;
  time: string;
  payMethod: string;
  category: 'Tunai' | 'Transfer' | 'Debet' | 'QRIS';
  jumlahBayar: number;
  sisaSetelahBayar: number;
  sisaAfter?: number;
  isLunas?: boolean;
  catatan?: string;
  isCrossDate: boolean;
  invoiceDate: string;
  invoiceTotal: number;
}

export interface PeriodCashInflowBreakdown {
  Tunai: number;
  Transfer: number;
  Debet: number;
  QRIS: number;
  Total: number;
  totalCashIn?: number;
  fromNewSales: number;
  fromPelunasanPiutang: number;
  pelunasanItems: PelunasanInflowItem[];
  counts: {
    Tunai: number;
    Transfer: number;
    Debet: number;
    QRIS: number;
    Total: number;
  };
}

export function isDatesDifferent(dateStr1?: string, dateStr2?: string): boolean {
  if (!dateStr1 || !dateStr2) return false;
  const d1 = parseUniversalDate(dateStr1);
  const d2 = parseUniversalDate(dateStr2);
  if (!d1 || !d2) return false;
  return (
    d1.getFullYear() !== d2.getFullYear() ||
    d1.getMonth() !== d2.getMonth() ||
    d1.getDate() !== d2.getDate()
  );
}

export function calculatePeriodCashFlow(
  allInvoices: any[],
  period: string | ((dateStr?: string) => boolean) = 'all',
  customStartDateOrAllInvoices?: string | any[],
  customEndDate?: string
): PeriodCashInflowBreakdown {
  let tunai = 0;
  let transfer = 0;
  let debet = 0;
  let qris = 0;

  let countTunai = 0;
  let countTransfer = 0;
  let countDebet = 0;
  let countQris = 0;

  let fromNewSales = 0;
  let fromPelunasanPiutang = 0;
  const pelunasanItems: PelunasanInflowItem[] = [];

  const addCash = (cat: 'Tunai' | 'Transfer' | 'Debet' | 'QRIS', amt: number) => {
    if (amt <= 0) return;
    if (cat === 'Transfer') transfer += amt;
    else if (cat === 'QRIS') qris += amt;
    else if (cat === 'Debet') debet += amt;
    else tunai += amt;
  };

  const incCount = (cat: 'Tunai' | 'Transfer' | 'Debet' | 'QRIS') => {
    if (cat === 'Transfer') countTransfer++;
    else if (cat === 'QRIS') countQris++;
    else if (cat === 'Debet') countDebet++;
    else countTunai++;
  };

  const checkDateInPeriod = (dStr?: string): boolean => {
    if (typeof period === 'function') {
      return period(dStr);
    }
    const customStart = typeof customStartDateOrAllInvoices === 'string' ? customStartDateOrAllInvoices : undefined;
    return isDateInPeriod(dStr, period, customStart, customEndDate);
  };

  (allInvoices || []).forEach((inv) => {
    if (!inv) return;

    const tot = Number(inv.total || 0);
    const sisa = Number(inv.sisa || 0);
    const totalPaidOnInvoice = Math.max(0, tot - sisa);

    const histori: any[] = Array.isArray(inv.historiPelunasan)
      ? inv.historiPelunasan
      : Array.isArray(inv.pelunasanHistory)
      ? inv.pelunasanHistory
      : [];

    const isInvoiceInPeriod = checkDateInPeriod(inv.date);

    // Group history entries by cross-date (lintas hari) vs same-day
    const crossDateHistori: any[] = [];
    const sameDayHistori: any[] = [];

    histori.forEach((h) => {
      if (!h) return;
      const bayar = Number(h.jumlahBayar || 0);
      if (bayar <= 0) return;
      const paymentDate = h.date || h.tanggal || inv.date;
      const isCross = isDatesDifferent(inv.date, paymentDate);
      if (isCross) {
        crossDateHistori.push({ ...h, paymentDate });
      } else {
        sameDayHistori.push({ ...h, paymentDate });
      }
    });

    // 1. Initial Cash & Same-Day Payments Received on the Invoice Creation Date (part of fromNewSales)
    if (isInvoiceInPeriod && totalPaidOnInvoice > 0) {
      const totalCrossDatePaid = crossDateHistori.reduce((sum, h) => sum + Number(h.jumlahBayar || 0), 0);
      const totalSameDayPaid = sameDayHistori.reduce((sum, h) => sum + Number(h.jumlahBayar || 0), 0);
      
      // Initial creation payment (DP or direct full payment at checkout)
      const initialCash = Math.max(0, totalPaidOnInvoice - totalCrossDatePaid - totalSameDayPaid);
      if (initialCash > 0) {
        const initialMethod = inv.payMethod || inv.metodePembayaran || 'Tunai';
        const initialCat = parsePaymentCategory(initialMethod);
        addCash(initialCat, initialCash);
        incCount(initialCat);
        fromNewSales += initialCash;
      }

      // Same-day history payments (counted as part of today's sales cash inflow)
      sameDayHistori.forEach((h) => {
        const hBayar = Number(h.jumlahBayar || 0);
        if (hBayar > 0) {
          const hMethod = h.payMethod || h.metodePembayaran || inv.payMethod || 'Tunai';
          const hCat = parsePaymentCategory(hMethod);
          addCash(hCat, hBayar);
          incCount(hCat);
          fromNewSales += hBayar;
        }
      });
    }

    // 2. Cross-Date Installments / Pelunasan Piutang Payments (LINTAS HARI ONLY)
    // Same-day pelunasan is not recorded here to prevent confusion and duplicate entries
    crossDateHistori.forEach((h) => {
      const bayar = Number(h.jumlahBayar || 0);
      if (bayar <= 0) return;

      const isPaymentInPeriod = checkDateInPeriod(h.paymentDate);

      if (isPaymentInPeriod) {
        const hMethod = h.payMethod || h.metodePembayaran || inv.payMethod || 'Tunai';
        const hCat = parsePaymentCategory(hMethod);

        addCash(hCat, bayar);
        incCount(hCat);
        fromPelunasanPiutang += bayar;

        const sisaVal = Number(h.newSisa !== undefined ? h.newSisa : h.sisa !== undefined ? h.sisa : 0);

        pelunasanItems.push({
          invoiceNo: inv.invoiceNo || inv.noInvoice || '-',
          customer: h.customer || inv.customer || inv.pelanggan || 'Umum',
          cashier: h.cashier || h.kasir || inv.cashier || 'Admin',
          date: h.paymentDate,
          time: h.time || h.jam || '',
          payMethod: hMethod,
          category: hCat,
          jumlahBayar: bayar,
          sisaSetelahBayar: sisaVal,
          sisaAfter: sisaVal,
          isLunas: sisaVal <= 0,
          catatan: h.catatan || '',
          isCrossDate: true,
          invoiceDate: inv.date || '-',
          invoiceTotal: tot,
        });
      }
    });
  });

  // Sort pelunasan items newest first by date and time
  pelunasanItems.sort((a, b) => {
    const da = parseUniversalDate(a.date)?.getTime() || 0;
    const db = parseUniversalDate(b.date)?.getTime() || 0;
    if (db !== da) return db - da;
    return (b.time || '').localeCompare(a.time || '');
  });

  const total = tunai + transfer + debet + qris;
  const totalCount = countTunai + countTransfer + countDebet + countQris;

  return {
    Tunai: tunai,
    Transfer: transfer,
    Debet: debet,
    QRIS: qris,
    Total: total,
    totalCashIn: total,
    fromNewSales,
    fromPelunasanPiutang,
    pelunasanItems,
    counts: {
      Tunai: countTunai,
      Transfer: countTransfer,
      Debet: countDebet,
      QRIS: countQris,
      Total: totalCount,
    },
  };
}

export function calculateCashInflowByPaymentMethod(invoices: any[]): CashInflowByMethod {
  return calculatePeriodCashFlow(invoices, 'all');
}

export const INITIAL_KASIR = ['Admin', 'Budi', 'Siti', 'Operator 1'];

export function checkIsSpvOrOwner(userName?: string | null, kasirUsers?: { nama: string; role?: string; password?: string }[]): boolean {
  if (!userName) return false;
  const lower = userName.trim().toLowerCase();
  
  // 1. Check if user is registered in kasirUsers list
  if (kasirUsers && kasirUsers.length > 0) {
    const userObj = kasirUsers.find((u) => u.nama.trim().toLowerCase() === lower);
    if (userObj) {
      if (userObj.role) {
        const r = userObj.role.toLowerCase().trim();
        if (r === 'owner' || r === 'spv' || r === 'supervisor' || r === 'admin' || r === 'pimpinan' || r === 'pemilik') {
          return true;
        }
        // Explicit non-supervisor roles
        if (r === 'kasir' || r === 'cashier' || r === 'operator' || r === 'staff' || r === 'karyawan') {
          return false;
        }
      }
    }
  }

  // 2. Strict name keyword heuristics (only if not an explicit kasir/operator role)
  return (
    lower === 'owner' ||
    lower === 'spv' ||
    lower === 'supervisor' ||
    lower === 'admin' ||
    lower === 'master' ||
    lower.includes('spv') ||
    lower.includes('supervisor') ||
    lower.includes('owner') ||
    lower.includes('pemilik') ||
    lower.includes('pimpinan')
  );
}

/**
 * Safely compares two invoices descending (newest first).
 * Uses numeric-aware natural collation so 'ERV-202610-1127' correctly sorts BEFORE 'ERV-202610-996' (1127 > 996).
 * Falls back to date and time if invoice numbers are identical or missing.
 */
export function compareInvoicesDesc(
  a: { invoiceNo?: string; noInvoice?: string; date?: string; time?: string },
  b: { invoiceNo?: string; noInvoice?: string; date?: string; time?: string }
): number {
  const noA = (a.invoiceNo || a.noInvoice || '').trim();
  const noB = (b.invoiceNo || b.noInvoice || '').trim();
  if (noA && noB) {
    const cmp = noB.localeCompare(noA, undefined, { numeric: true, sensitivity: 'base' });
    if (cmp !== 0) return cmp;
  } else if (noB) {
    return 1;
  } else if (noA) {
    return -1;
  }

  const dtA = (a.date || '') + ' ' + (a.time || '');
  const dtB = (b.date || '') + ' ' + (b.time || '');
  return dtB.localeCompare(dtA, undefined, { numeric: true });
}

