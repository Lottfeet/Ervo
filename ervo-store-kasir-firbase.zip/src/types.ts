export interface Product {
  kode: string;
  nama: string;
  harga: number;
  kategori: string;
  stok: string | number;
  satuan: string;
  tipeHarga: 'ukuran' | 'fix' | string;
  pricingScheme?: 'meter_fix' | 'per_meter' | 'per_cm' | 'a3_plus' | 'lembaran_custom' | string;
  hargaJualModal?: number;
  minStok?: number;
  supplier?: string;
  catatan?: string;
}

export interface KasirUser {
  nama: string;
  password?: string;
  role?: 'owner' | 'spv' | 'kasir' | string;
}

export interface Customer {
  nama: string;
  kelas: string;
  diskon: number;
  telepon: string;
  catatan: string;
  alamat: string;
}

export interface InvoiceItem {
  kode: string;
  nama: string;
  harga: number;
  qty: number;
  satuan: string;
  tipeHarga: 'ukuran' | 'fix' | string;
  panjang: number;
  lebar: number;
  bahan: string;
  catatan: string;
  diskonItem: number;
  totalItem?: number;
}

export interface InvoiceAuditLog {
  editedBy: string;
  editedAt: string;
  reason: string;
  previousTotal?: number;
  previousPayMethod?: string;
  previousDp?: number;
  previousSisa?: number;
  previousCustomer?: string;
}

export interface Invoice {
  invoiceNo: string;
  noInvoice?: string;
  date: string;
  time: string;
  customer: string;
  pelanggan?: string;
  cashier: string;
  kasir?: string;
  operator?: string;
  subtotal: number;
  discPct: number;
  discAmt: number;
  taxPct: number;
  taxAmt: number;
  negoAmt: number;
  total: number;
  payMethod: string;
  metodePembayaran?: string;
  dp: number;
  sisa: number;
  kembalian: number;
  deadline: string;
  status: 'LUNAS' | 'DP' | string;
  customerPhone?: string;
  customerAddress?: string;
  items: InvoiceItem[];
  pelunasanHistory?: PelunasanRecord[];
  historiPelunasan?: PelunasanRecord[];
  lastEditedBy?: string;
  lastEditedAt?: string;
  editReason?: string;
  auditLogs?: InvoiceAuditLog[];
}

export interface StoreSettings {
  name: string;
  address: string;
  phone: string;
  footer: string;
  cashier: string;
  prefixInvoice?: string;
  autoLogoutMinutes?: number;
  rekening?: string;
  sheetUrl?: string;
}

export interface PiutangItem {
  invoiceNo: string;
  date: string;
  customer: string;
  total: number;
  dp: number;
  sisa: number;
  deadline: string;
  historiPelunasan?: PelunasanRecord[];
}

export interface PelunasanRecord {
  id?: string;
  invoiceNo: string;
  date: string;
  time: string;
  customer?: string;
  cashier: string;
  kasir?: string;
  payMethod: string;
  jumlahBayar: number;
  sisaAwal?: number;
  newSisa?: number;
  kembalian?: number;
  status?: string;
  catatan?: string;
}

export interface StockInRecord {
  id: string;
  kode: string;
  kodeProduct?: string;
  nama: string;
  namaProduct?: string;
  qty: number;
  jumlahMasuk?: number;
  satuan: string;
  supplier: string;
  cashier: string;
  penanggungJawab?: string;
  date: string;
  tanggal?: string;
  time: string;
  jam?: string;
  catatan?: string;
  noPo?: string;
  hargaBeli?: number;
  totalBiaya?: number;
  gudang?: string;
}

export interface StockOpnameItem {
  kode: string;
  nama: string;
  kategori: string;
  satuan: string;
  stokSistem: number; // Baseline stok saat barang dihitung
  stokFisik: number; // Jumlah fisik riil yang diinput petugas
  selisih: number; // Delta = stokFisik - stokSistem
  hargaSatuan: number;
  selisihNilaiRp: number;
  alasan: string;
  catatan?: string;
  // Multi-day & Delta tracking
  countedAt?: string; // e.g. "2026-09-01 10:15" (waktu fisik dicatat)
  stokSistemTerkini?: number; // Real-time stok sistem di database saat pengesahan
  penjualanInterim?: number; // Berapa unit keluar/terjual sejak fisik dihitung
  stokPenyesuaianAkhir?: number; // Hasil akhir setelah delta (stokSistemTerkini + selisih)
  isEditedInDraft?: boolean; // Penanda barang sudah dihitung dalam sesi
}

export interface StockOpnameRecord {
  id: string;
  tanggal: string; // YYYY-MM-DD (tanggal mulai sesi)
  jam: string; // HH:mm (jam mulai sesi)
  tanggalSelesai?: string; // YYYY-MM-DD (tanggal disahkan SPV)
  jamSelesai?: string; // HH:mm (jam disahkan SPV)
  pjKasir: string;
  authorizedBy: string;
  catatanUmum?: string;
  totalItemDiperiksa: number;
  totalItemSelisih: number;
  totalSelisihKurangQty: number;
  totalSelisihLebihQty: number;
  totalSelisihNominalRp: number;
  items: StockOpnameItem[];
  status: 'APPROVED' | 'DRAFT';
  metodePenyesuaian?: 'DELTA' | 'REPLACE'; // Default: 'DELTA' (mengakomodasi penjualan selama opname)
  totalPenjualanInterimQty?: number; // Total unit yang terjual selama masa opname berjalan
}

export interface ExpenseRecord {
  id: string;
  tanggal: string; // YYYY-MM-DD
  kategori: string; // e.g. 'Bahan Baku', 'Gaji / Honorer', 'Sewa & Utilitas', 'Operasional & Makanan', 'Maintenance & Service', 'Lain-lain'
  keterangan: string;
  nominal: number;
  pj: string; // Cashier / Admin name
  buktiRef?: string;
}

export interface Vendor {
  id: string;
  nama: string;
  kategori?: string;
  telepon?: string;
  email?: string;
  alamat?: string;
  kontakPerson?: string;
  nomorRekening?: string;
  catatan?: string;
  createdAt?: string;
}

export type MainViewTab = 'dashboard' | 'transaksi' | 'barang_masuk' | 'vendor' | 'laporan' | 'pelanggan' | 'reprint';

export interface GasResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  invoiceNo?: string;
  alreadyLunas?: boolean;
  newSisa?: number;
  kembalian?: number;
  status?: string;
  total?: number;
  pelanggan?: string;
}

export type ViewTab = 'catalog' | 'cart' | 'preview' | 'pelunasan' | 'settings' | 'guide';

export type CheckpointTrigger = 'MANUAL' | 'AUTO_TIMER' | 'AUTO_TRANSACTION' | 'AUTO_RESTOCK' | 'AUTO_OPNAME';

export interface CheckpointLayerStatus {
  cloudFirestore: {
    status: 'success' | 'failed' | 'skipped';
    message?: string;
    docId?: string;
    timestamp?: string;
  };
  googleSheets: {
    status: 'success' | 'failed' | 'skipped';
    message?: string;
    syncedAt?: string;
  };
  localOffline: {
    status: 'success' | 'failed' | 'skipped';
    message?: string;
    storageKey?: string;
    sizeKb?: number;
  };
}

export interface CheckpointPayload {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  expenses: ExpenseRecord[];
  stockIn: StockInRecord[];
  stockOpnames: StockOpnameRecord[];
  kasirUsers: KasirUser[];
  settings: StoreSettings;
  vendors?: Vendor[];
  sheetUrl?: string;
}

export interface CheckpointRecord {
  id: string;
  timestamp: string;
  formattedDate: string;
  formattedTime: string;
  trigger: CheckpointTrigger;
  label: string;
  operator: string;
  counts: {
    products: number;
    customers: number;
    invoices: number;
    expenses: number;
    stockIn: number;
    stockOpnames: number;
    vendors?: number;
  };
  layers: CheckpointLayerStatus;
  sizeBytes?: number;
  payload?: CheckpointPayload;
}

export interface AutoCheckpointConfig {
  enabled: boolean;
  intervalMinutes: number;
  triggerOnTransactionsCount: number;
  lastCheckpointTime?: string;
  maxStoredCheckpoints: number;
}
