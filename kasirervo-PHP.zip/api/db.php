<?php
/**
 * db.php — Backend MySQL API untuk Ervo Store Kasir (cPanel).
 *
 * Frontend (assets/index-*.js) memanggil file INI, bukan api/index.php.
 * Endpoint yang didukung:
 *   GET  api/db.php?c=<collection>&since=<rev>      -> daftar dokumen + rev server
 *   GET  api/db.php?c=<collection>&id=<docId>       -> satu dokumen
 *   GET  api/db.php?action=list&collection=<col>    -> daftar dokumen (format {docs:[...]})
 *   POST api/db.php  body {action:"put", collection, id, data}        -> upsert (merge)
 *   POST api/db.php  body {action:"delete", collection, id}           -> hapus dokumen
 *                    (khusus invoices: otomatis mengembalikan stok barang — atomik)
 *   POST api/db.php  body {action:"batch", operations:[{op,collection,id,data}]}
 *   POST api/db.php  body {action:"cleanup"}                          -> beres-beres (no-op aman)
 *
 * Setiap koleksi disimpan pada satu tabel MySQL:
 *   id VARCHAR(191) PRIMARY KEY, data LONGTEXT (JSON dokumen), rev BIGINT.
 * Tabel dibuat otomatis saat pertama kali dipakai, sehingga import schema.sql
 * tidak wajib lagi.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

// ---------- CORS ----------
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
if ($origin !== '') {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Max-Age: 86400');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------- Helper respon ----------
function out($arr)
{
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Koneksi DB ----------
$config = require __DIR__ . '/config.php';

try {
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['host'],
        $config['port'],
        $config['database'],
        $config['charset']
    );
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    // Jangan bocorkan kredensial ke klien
    error_log('[ervo-db] Koneksi DB gagal: ' . $e->getMessage());
    out([
        'success' => false,
        'code'    => 'DB_CONNECTION_FAILED',
        'message' => 'Koneksi database gagal. Periksa api/config.php & pastikan database sudah dibuat di cPanel.',
    ]);
}

// ---------- Whitelist koleksi ----------
$ALLOWED_COLLECTIONS = [
    'products',
    'customers',
    'kasirUsers',
    'settings',
    'invoices',
    'expenses',
    'stockIn',
    'stockOpname',
    'vendors',
    'deletedProducts',
    'deletedCustomers',
    'deletedInvoices',
    'deletedExpenses',
    'backupCheckpoints',
    'businessTransactions',
    // Tambahan: dipakai fitur "Koreksi Stok" (patch.js) & mirror GAS action
    // 'deleteInvoice' yang dikirim frontend saat invoice dihapus.
    'stockAdjustments',
    // Tambahan: salinan history lokal (strukku_recent_invoices_v3 /
    // strukku_stock_in_history) yang dikelola patch.js untuk anti-duplikat
    // riwayat + urutan terbaru-di-atas lintas perangkat.
    'invoiceHistory',
    'stockInHistory',
];

/**
 * Fingerprint dokumen barang-masuk/PO utk menolak pencatatan ganda:
 * kombinasi produk + qty + supplier + tanggal/jam (bukan id acak, karena
 * browser yang sama dapat mengirim ulang entri yang sama dengan id baru).
 */
function stockInFingerprint(array $d)
{
    $kode = mb_strtolower(trim((string)(isset($d['kode']) ? $d['kode'] : '')));
    $nama = mb_strtolower(trim((string)(isset($d['nama']) ? $d['nama'] : '')));
    $qty  = rtrim(rtrim(number_format((float)(isset($d['qty']) ? $d['qty'] : 0), 3, '.', ''), '0'), '.');
    if ($qty === '') $qty = '0';
    $sup  = mb_strtolower(trim((string)(isset($d['supplier']) ? $d['supplier'] : (isset($d['vendor']) ? $d['vendor'] : ''))));
    $tg   = trim((string)(isset($d['tanggal']) ? $d['tanggal'] : (isset($d['date']) ? $d['date'] : '')));
    $jm   = trim((string)(isset($d['jam']) ? $d['jam'] : (isset($d['time']) ? $d['time'] : '')));
    return md5($kode . '|' . $nama . '|' . $qty . '|' . $sup . '|' . $tg . '|' . $jm);
}

/**
 * Simpan dokumen stockIn dg dedup fingerprint (idempoten thd retry/double-send).
 * Bila duplikat -> tidak menulis apa pun, cukup kembalikan rev dokumen lama.
 * Mengembalikan [revAtauNull, isDuplicate].
 */
function putStockInDedup(PDO $pdo, $table, $id, array $fields, $inTransaction = false)
{
    $fp = stockInFingerprint($fields);
    $rows = $pdo->query("SELECT id, data, rev FROM {$table}")->fetchAll();
    foreach ($rows as $r) {
        if (trim((string)$r['id']) === trim((string)$id)) continue; // beda id => biarkan (edit/manual)
        $d = json_decode($r['data'], true);
        if (!is_array($d)) continue;
        if (stockInFingerprint($d) === $fp) {
            return [(int)$r['rev'], true];
        }
    }
    $fields['_fp'] = $fp;
    $rev = putDoc($pdo, $table, $id, $fields, $inTransaction);
    return [$rev, false];
}

function checkCollection($col, $allowed)
{
    if (!in_array($col, $allowed, true)) {
        out(['success' => false, 'message' => 'Koleksi tidak dikenal: ' . $col]);
    }
    return '`' . $col . '`';
}


/** Nama tabel polos (tanpa backtick). */
function tableName($table)
{
    return trim($table, '`');
}

/** Cek cepat tanpa DDL (untuk jalur baca & di dalam transaksi). */
function tableExists(PDO $pdo, $name)
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS c FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->execute([$name]);
    $row = $stmt->fetch();
    return $row && (int)$row['c'] > 0;
}

/** Daftar kolom sebuah tabel (lowercase). Hasil di-cache per-request. */
function columnInfo(PDO $pdo, $name)
{
    static $cache = [];
    $key = strtolower($name);
    if (isset($cache[$key])) return $cache[$key];
    $stmt = $pdo->prepare(
        "SELECT COLUMN_NAME AS c, DATA_TYPE AS t FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->execute([$name]);
    $cols = [];
    foreach ($stmt->fetchAll() as $r) {
        $cols[strtolower($r['c'])] = strtolower($r['t']);
    }
    return $cache[$key] = $cols;
}

/**
 * Peta kolom kanonik (id/data/rev/updated_at) -> nama kolom aktual di tabel.
 * Menangani tabel legacy dari schema.sql lama yang memakai nama berbeda
 * (doc_id/document_id/key -> id ; json/data/payload/content/doc -> data ;
 *  revision/version/_rev -> rev ; updated_at/modified_at -> updated_at).
 */
function colMap(PDO $pdo, $table)
{
    static $maps = [];
    $name = tableName($table);
    if (isset($maps[$name])) return $maps[$name];
    $cols = columnInfo($pdo, $name);
    $pick = function (array $candidates) use ($cols) {
        foreach ($candidates as $c) {
            if (isset($cols[$c])) return $cols[$c] === $c ? $c : '`' . $c . '`';
        }
        return null;
    };
    $map = [
        'id'         => $pick(['id', 'doc_id', 'document_id', 'key', 'kode']),
        'data'       => $pick(['data', 'json', 'payload', 'content', 'doc', 'value']),
        'rev'        => $pick(['rev', 'revision', 'version', '_rev']),
        'updated_at' => $pick(['updated_at', 'modified_at', 'updatedAt']),
    ];
    return $maps[$name] = $map;
}

/** Apakah tabel butuh perbaikan struktur (kolom tidak pas / tanpa PK)? */
function tableNeedsRepair(PDO $pdo, $table)
{
    $cols = columnInfo($pdo, tableName($table));
    if (!$cols) return false;
    $m = colMap($pdo, $table);
    if (!$m['id'] || !$m['data']) return true;
    if (!isset($cols['id'])) return true;                      // PK harus tetap bernama id
    if ($m['data'] !== 'data') return true;                    // query API memakai nama `data`
    if ($m['id'] !== 'id') return true;                        // query API memakai nama `id`
    if (!$m['rev'] || !isset($cols['rev'])) return true;       // kolom rev wajib persis
    if (in_array($cols[$m['data']], ['text', 'mediumtext', 'tinytext'], true)) return true; // kapasitas kecil
    if (!$m['updated_at']) return true;
    try {
        $pk = $pdo->query("SHOW KEYS FROM {$table} WHERE Key_name = 'PRIMARY'")->fetchAll();
        if (count($pk) !== 1 || strtolower($pk[0]['Column_name']) !== 'id') return true;
    } catch (Exception $e) {
        return true;
    }
    return false;
}

/**
 * Self-healing penuh untuk tabel legacy: rename kolom ke skema kanonik
 * (id/data/rev/updated_at), tambahkan kolom yang hilang, naikkan TEXT->LONGTEXT,
 * dan perbaiki primary key. Data lama TIDAK dibuang. Idempotent & di-cache.
 *
 * DDL memicu implicit commit sehingga fungsi ini TIDAK boleh dipanggil di
 * tengah transaksi — pemanggil wajib menyiapkan tabel sebelum beginTransaction().
 */
function migrateTable(PDO $pdo, $table)
{
    static $done = [];
    $name = tableName($table);
    if (isset($done[$name])) return;
    $cols = columnInfo($pdo, $name);
    if (!$cols) { $done[$name] = true; return; }

    // 1) Rename kolom legacy ke nama kanonik (hanya jika target belum dipakai).
    $renames = [
        'id'         => ['doc_id', 'document_id', 'key'],
        'data'       => ['json', 'payload', 'content', 'doc', 'value'],
        'rev'        => ['revision', 'version', '_rev'],
        'updated_at' => ['modified_at', 'updatedAt'],
    ];
    foreach ($renames as $target => $alts) {
        if (isset($cols[$target])) continue;
        foreach ($alts as $alt) {
            if (isset($cols[$alt])) {
                $type = $cols[$alt];
                $pdo->exec("ALTER TABLE {$table} CHANGE `{$alt}` `{$target}` " . sqlTypeOf($type));
                $cols[$target] = $type;
                unset($cols[$alt]);
                break;
            }
        }
    }

    // 2) Tambah kolom yang masih hilang.
    if (!isset($cols['id']))   $pdo->exec("ALTER TABLE {$table} ADD COLUMN id VARCHAR(191) NOT NULL FIRST");
    if (!isset($cols['data'])) $pdo->exec("ALTER TABLE {$table} ADD COLUMN data LONGTEXT NULL");
    if (!isset($cols['rev']))  $pdo->exec("ALTER TABLE {$table} ADD COLUMN rev BIGINT NOT NULL DEFAULT 0");
    if (!isset($cols['updated_at'])) $pdo->exec("ALTER TABLE {$table} ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

    // 3) Kapasitas kolom data harus LONGTEXT.
    if (in_array($cols['data'], ['text', 'mediumtext', 'tinytext'], true)) {
        $pdo->exec("ALTER TABLE {$table} MODIFY COLUMN data LONGTEXT NULL");
    }

    // 4) Primary key harus tunggal pada id.
    $fixPk = false;
    try {
        $pk = $pdo->query("SHOW KEYS FROM {$table} WHERE Key_name = 'PRIMARY'")->fetchAll();
        $fixPk = (count($pk) !== 1 || strtolower($pk[0]['Column_name']) !== 'id');
    } catch (Exception $e) {
        $fixPk = true;
    }
    if ($fixPk) {
        if ($pk) $pdo->exec("ALTER TABLE {$table} DROP PRIMARY KEY");
        $pdo->exec("ALTER TABLE {$table} MODIFY COLUMN id VARCHAR(191) NOT NULL");
        try {
            $pdo->exec("ALTER TABLE {$table} ADD PRIMARY KEY (id)");
        } catch (Exception $e) {
            error_log('[ervo-db] Gagal memasang PK pada ' . $name . ': ' . $e->getMessage());
        }
    }

    $done[$name] = true;
}

/**
 * LOG IDEMPOTENSI penghapusan invoice (mencegah stok double-restore).
 * Tabel ini TIDAK termasuk whitelist API — tidak bisa dibaca/ditulis lewat
 * aksi publik; hanya dipakai internal oleh jalur delete invoices.
 * Kolom `meta` (JSON: {"kodeLower": qty}) di-upgrade otomatis untuk tabel
 * lama sehingga client (patch.js) bisa menerima "claim" dari response server.
 */
function ensureRestoreLogTable(PDO $pdo)
{
    static $ok = false;
    if ($ok) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS _invoice_restore_log (
            invoice_key VARCHAR(191) PRIMARY KEY,
            restored_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        // Upgrade self-healing: tambah kolom meta LONGTEXT bila belum ada.
        try {
            $has = $pdo->prepare("SELECT COUNT(*) c FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '_invoice_restore_log' AND COLUMN_NAME = 'meta'");
            $has->execute();
            $row = $has->fetch();
            if ($row && (int)$row['c'] === 0) {
                $pdo->exec("ALTER TABLE _invoice_restore_log ADD COLUMN meta LONGTEXT NULL");
            }
        } catch (Exception $e) {
            error_log('[ervo-db] Upgrade kolom meta gagal (masih jalan tanpa claim): ' . $e->getMessage());
        }
        $ok = true;
    } catch (Exception $e) {
        error_log('[ervo-db] Tabel log restore tidak tersedia: ' . $e->getMessage());
    }
}

/** Gabungkan qty per kode produk (lowercase) dari item invoice — kunci &
 *  pembulatan SAMA dengan restoreInvoiceStock() dan WD() di frontend. */
function invoiceItemQtyMap(array $invoice)
{
    $items = isset($invoice['items']) && is_array($invoice['items']) ? $invoice['items'] : [];
    $perKey = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $kode = trim((string)(isset($it['kode']) ? $it['kode'] : ''));
        if ($kode === '') continue;
        $qty = 1;
        foreach (['qty', 'jumlah', 'quantity'] as $qf) {
            if (isset($it[$qf]) && is_numeric($it[$qf])) { $qty = (float)$it[$qf]; break; }
        }
        $k = mb_strtolower($kode);
        if (!isset($perKey[$k])) $perKey[$k] = 0.0;
        $perKey[$k] += $qty;
    }
    return $perKey;
}

/** True bila invoice ini sudah pernah di-restore+hapus (cek & catat atomik).
 *  $meta disimpan dalam kolom JSON (isi: {"kodeLower": qty, ...}) supaya bisa
 *  dikembalikan lagi ke client sebagai "claim" — penanda bahwa PUT produk
 *  dengan kode-kode tersebut adalah rollback ganda yang harus dibuang patch. */
function alreadyRestored(PDO $pdo, $key, $meta = null)
{
    if (!tableExists($pdo, '_invoice_restore_log')) return false;
    $metaJson = ($meta && is_array($meta))
        ? json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        : null;
    $stmt = null;
    // Coba dengan kolom meta lebih dulu (di-upgrade otomatis oleh ensure).
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO _invoice_restore_log (invoice_key, meta) VALUES (?, ?)");
        $stmt->execute([$key, $metaJson]);
    } catch (Exception $e) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO _invoice_restore_log (invoice_key) VALUES (?)");
        $stmt->execute([$key]);
    }
    return $stmt->rowCount() === 0; // 0 baris masuk = key sudah tercatat sebelumnya
}

/** Ambil meta claim tersimpan utk sebuah invoice (null bila tak ada). */
function getRestoreMeta(PDO $pdo, $key)
{
    if (!tableExists($pdo, '_invoice_restore_log')) return null;
    try {
        $stmt = $pdo->prepare("SELECT meta FROM _invoice_restore_log WHERE invoice_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        if (!$row || empty($row['meta'])) return null;
        $m = json_decode($row['meta'], true);
        return is_array($m) ? $m : null;
    } catch (Exception $e) {
        return null; // kolom meta belum ada — fitur L1 patch tetap jalan via L2
    }
}

/** Bersihkan catatan log (dipakai saat user mengunggah ulang/memulihkan invoice). */
function clearRestoreLog(PDO $pdo, $key)
{
    if (!tableExists($pdo, '_invoice_restore_log')) return;
    try {
        $pdo->prepare("DELETE FROM _invoice_restore_log WHERE invoice_key = ?")->execute([$key]);
    } catch (Exception $e) { /* abaikan */ }
}

/** Ambil qty-map tersimpan utk sebuah invoice dari log restore (null bila tak ada). */
function getLoggedQtyMap(PDO $pdo, $key)
{
    $m = getRestoreMeta($pdo, $key);
    return (is_array($m) && $m) ? $m : null;
}

/**
 * LOG IDEMPOTENSI penghapusan barang masuk / PO (collection stockIn).
 * Mencegah "pencatatan double": client menulis tombstone _deleted=true yang
 * bisa di-retry/ditulis ulang; delta stok hanya diterapkan SEKALI per id.
 */
function ensureStockInDeleteLogTable(PDO $pdo)
{
    static $ok = false;
    if ($ok) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS _stockin_delete_log (
            stockin_key VARCHAR(191) PRIMARY KEY,
            meta LONGTEXT NULL,
            deleted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $ok = true;
    } catch (Exception $e) {
        error_log('[ervo-db] Tabel log delete stockIn tidak tersedia: ' . $e->getMessage());
    }
}

/** True bila id barang masuk sudah pernah diproses hapusnya (cek+catat atomik). */
function alreadyDeletedStockIn(PDO $pdo, $key, $meta = null)
{
    if (!tableExists($pdo, '_stockin_delete_log')) return false;
    $metaJson = ($meta && is_array($meta))
        ? json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        : null;
    try {
        $stmt = $pdo->prepare("INSERT IGNORE INTO _stockin_delete_log (stockin_key, meta) VALUES (?, ?)");
        $stmt->execute([$key, $metaJson]);
        return $stmt->rowCount() === 0;
    } catch (Exception $e) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO _stockin_delete_log (stockin_key) VALUES (?)");
        $stmt->execute([$key]);
        return $stmt->rowCount() === 0;
    }
}

/**
 * Terapkan SATU delta stok absolut (satu produk) secara atomik dengan lock.
 * Dipakai jalur delete/tombstone stockIn: eL() frontend MENGURANGI stok saat
 * barang masuk dihapus (stok_new = stok_lama - qty), BUKAN menambah.
 * Mengembalikan stok baru (string) atau null bila produk tidak ditemukan.
 */
function applySingleStockDelta(PDO $pdo, $prodId, $delta)
{
    $delta = (float)$delta;
    $sel = $pdo->prepare("SELECT id, data, rev FROM products WHERE LOWER(id) = ? LIMIT 1 FOR UPDATE");
    $sel->execute([mb_strtolower(trim((string)$prodId))]);
    $r = $sel->fetch();
    if (!$r) return null;
    $p = json_decode($r['data'], true);
    if (!is_array($p)) return null;
    $kelola = isset($p['kelolaStok']) ? $p['kelolaStok'] : true;
    if ($kelola === false || $kelola === 'false') return null;
    if (!isset($p['stok']) || $p['stok'] === '' || $p['stok'] === null) return null;
    $cur = is_numeric(str_replace(',', '', (string)$p['stok']))
        ? (float)str_replace(',', '.', (string)$p['stok']) : null;
    if ($cur === null) return null;
    $new = max(0, $cur + $delta);
    $stokStr = rtrim(rtrim(number_format($new, 6, '.', ''), '0'), '.');
    if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
    $p['stok'] = $stokStr;
    $p['updatedAt'] = date('c');
    $upd = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
    $upd->execute([json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                   (int)$r['rev'] + 1, $r['id']]);
    return $stokStr;
}

/**
 * Hapus dokumen barang masuk/PO DAN sesuaikan stok SEKALI saja (idempoten via
 * _stockin_delete_log). Dibagi oleh jalur delete tunggal & batch.
 * Konvensi stok (sama dengan frontend eL/dH): qty POSITIF => stok DIKURANGI.
 * $hint = ['kode'=>..., 'qty'=>...] dari body (opsional, dipakai bila dokumen
 * tidak ditemukan di tabel). Mengembalikan ['done'=>bool,'kode'=>..,'qty'=>..].
 */
function deleteStockInWithAdjustment(PDO $pdo, $table, $idRaw, $hint = null)
{
    $lower = mb_strtolower(trim((string)$idRaw));
    if ($lower === '') return ['done' => false];
    $doc = readDocRaw($pdo, $table, $idRaw);
    if ($doc === null) $doc = readDocRaw($pdo, $table, $lower);
    $kode = ''; $qty = 0.0;
    if (is_array($doc)) {
        $kode = trim((string)(isset($doc['kode']) ? $doc['kode'] : (isset($doc['kodeProduct']) ? $doc['kodeProduct'] : '')));
        $q = isset($doc['qty']) ? $doc['qty'] : (isset($doc['jumlahMasuk']) ? $doc['jumlahMasuk'] : 0);
        $qty = is_numeric($q) ? abs((float)$q) : 0.0;
    }
    if (($kode === '' || $qty <= 0) && is_array($hint)) {
        $kode = trim((string)(isset($hint['kode']) ? $hint['kode'] : ''));
        $q = isset($hint['qty']) ? $hint['qty'] : 0;
        $qty = is_numeric($q) ? abs((float)$q) : 0.0;
    }
    // Catat ke log lebih dulu (atomik INSERT IGNORE) — retry write yang sama
    // akan mengembalikan rowCount 0 => TIDAK menyesuaikan stok lagi.
    $meta = ($kode !== '' && $qty > 0) ? [mb_strtolower($kode) => $qty] : null;
    $dup = alreadyDeletedStockIn($pdo, $lower, $meta);
    if (!$dup && $kode !== '' && $qty > 0) {
        ensureTable($pdo, '`products`');
        applySingleStockDelta($pdo, $kode, -$qty);
    }
    delDoc($pdo, $table, $idRaw, true);
    delDoc($pdo, $table, $lower, true);
    return ['done' => true, 'dup' => $dup, 'kode' => $kode, 'qty' => $qty];
}

/** True bila ada baris invoice lain dengan LOWER(id) sama tapi id berbeda
 *  (variasi kapital nomor yang sama). Dipakai sebelum menghapus satu variasi
 *  id agar tidak salah menganggap "sudah pernah di-restore". */
function hasOtherInvoiceVariants(PDO $pdo, $invTable, $lowerId)
{
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) c FROM {$invTable} WHERE LOWER(id) = ? AND BINARY id <> ?");
        $stmt->execute([$lowerId, $lowerId]);
        $row = $stmt->fetch();
        return $row && (int)$row['c'] > 0;
    } catch (Exception $e) {
        return false;
    }
}

/** Tipe SQL sederhana utk hasil rename kolom berdasarkan DATA_TYPE information_schema. */
function sqlTypeOf($dataType)
{
    switch ($dataType) {
        case 'varchar':  return 'VARCHAR(191) NOT NULL';
        case 'char':     return 'CHAR(191) NOT NULL';
        case 'int': case 'bigint': case 'mediumint': case 'smallint': return 'BIGINT NOT NULL DEFAULT 0';
        case 'longtext': case 'mediumtext': case 'text': case 'tinytext': return 'LONGTEXT NULL';
        case 'timestamp': return 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP';
        default:         return 'LONGTEXT NULL';
    }
}

/** Baca dokumen mentah dari tabel (tanpa DDL). */
function readDocRaw(PDO $pdo, $table, $id)
{
    $stmt = $pdo->prepare("SELECT data FROM {$table} WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row || $row['data'] === null) return null;
    $d = json_decode($row['data'], true);
    return is_array($d) ? $d : null;
}

/** Lowercase aman walau ekstensi mbstring tidak terpasang di hosting. */
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($s) { return strtolower((string)$s); }
}

/**
 * Kembalikan stok barang yang terjual pada sebuah invoice (+qty tiap item).
 * Pencocokan produk SAMA PERSIS dengan frontend (fungsi WD/JD di bundle):
 *   - kunci produk = kode (trim, lowercase); id dokumen = kode
 *   - hanya produk kelolaStok !== false & stok numeric
 *   - stok baru = max(0, stok lama + total qty) — disimpan sebagai string
 * Mengembalikan jumlah produk yang stoknya berhasil dipulihkan.
 * WAJIB dipanggil di dalam transaksi & setelah tabel products dipastikan ada.
 */
function restoreInvoiceStock(PDO $pdo, array $invoice)
{
    $items = isset($invoice['items']) && is_array($invoice['items']) ? $invoice['items'] : [];
    if (!$items) return 0;

    // Gabungkan qty per kode (case-insensitive) — meniru Map kode->qty frontend.
    $perKey = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $kode = trim((string)(isset($it['kode']) ? $it['kode'] : ''));
        if ($kode === '') continue;
        $qty = 1;
        foreach (['qty', 'jumlah', 'quantity'] as $qf) {
            if (isset($it[$qf]) && is_numeric($it[$qf])) { $qty = (float)$it[$qf]; break; }
        }
        $k = mb_strtolower($kode);
        if (!isset($perKey[$k])) $perKey[$k] = 0.0;
        $perKey[$k] += $qty;
    }
    if (!$perKey) return 0;

    $restored = 0;
    $sel = $pdo->prepare("SELECT id, data, rev FROM products WHERE id = ? LIMIT 1 FOR UPDATE");
    foreach ($perKey as $k => $addQty) {
        $sel->execute([$k]);
        $r = $sel->fetch();
        if (!$r) continue;
        $p = json_decode($r['data'], true);
        if (!is_array($p)) continue;
        $kelola = isset($p['kelolaStok']) ? $p['kelolaStok'] : true;
        if ($kelola === false || $kelola === 'false') continue;
        if (!isset($p['stok']) || $p['stok'] === '' || $p['stok'] === null) continue;
        $cur = is_numeric($p['stok']) ? (float)str_replace(',', '.', (string)$p['stok']) : null;
        if ($cur === null) continue;
        $new = max(0, $cur + $addQty);
        // Format seperti frontend: String(number) — tanpa pemisah ribuan.
        $stokStr = rtrim(rtrim(number_format($new, 6, '.', ''), '0'), '.');
        if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
        $p['stok'] = $stokStr;
        $p['updatedAt'] = date('c');
        $rev = (int)$r['rev'] + 1;
        $upd = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
        $upd->execute([json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $rev, $r['id']]);
        $restored++;
    }
    return $restored;
}

/** Kumpulkan qty-map dari SEMUA variasi id invoice (case-insensitive) di tabel. */
function collectInvoiceQtyVariants(PDO $pdo, $invTable, $lower)
{
    $map = [];
    try {
        $stmt = $pdo->prepare("SELECT data FROM {$invTable} WHERE LOWER(id) = ?");
        $stmt->execute([$lower]);
        while (($r = $stmt->fetch())) {
            $d = json_decode((string)$r['data'], true);
            if (!is_array($d)) continue;
            foreach (invoiceItemQtyMap($d) as $k => $q) {
                if (!isset($map[$k])) $map[$k] = 0.0;
                $map[$k] += $q;
            }
        }
    } catch (Exception $e) { /* abaikan */ }
    return $map;
}

/**
 * PULIHKAN-SEKALI untuk penghapusan invoice yang dilakukan client lain:
 * jika dokumen invoice sudah TIDAK ada di server tetapi belum pernah tercatat
 * di log restore, pulihkan stok dari qty-map (dari body request atau sisa
 * variasi di tabel), catat log, dan buat tombstone deletedInvoices.
 * Ini menutup celah "server tidak pernah melihat dokumennya" sehingga stok
 * tidak pernah kembali sama sekali — tanpa membuka peluang double-restore,
 * karena idempotensi tetap dijaga oleh _invoice_restore_log.
 * Dipanggil dari jalur `put` pada deletedInvoices & deletedProducts.
 */
function compensateRestoreForDeletedDoc(PDO $pdo, $idRaw, $qtyMapFromBody)
{
    $lower = mb_strtolower(trim((string)$idRaw));
    if ($lower === '') return 0;
    ensureTable($pdo, '`products`');
    ensureRestoreLogTable($pdo);
    $pdo->beginTransaction();
    try {
        // Sudah pernah dipulihkan? (INSERT IGNORE = cek+catat atomik)
        if (alreadyRestored($pdo, $lower, $qtyMapFromBody ?: null)) {
            $pdo->commit();
            return 0;
        }
        // Ambil qty-map dari sisa variasi dokumen di tabel bila body kosong.
        $map = $qtyMapFromBody;
        if (!is_array($map) || !$map) {
            $map = collectInvoiceQtyVariants($pdo, '`invoices`', $lower);
        }
        if (!is_array($map) || !$map) { $pdo->commit(); return 0; }
        // Pulihkan stok dari map (tanpa membaca dokumen invoice).
        $restored = 0;
        $sel = $pdo->prepare("SELECT id, data, rev FROM products WHERE id = ? LIMIT 1 FOR UPDATE");
        $upd = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
        foreach ($map as $k => $addQty) {
            $addQty = (float)$addQty;
            if ($addQty <= 0) continue;
            $sel->execute([(string)$k]);
            $r = $sel->fetch();
            if (!$r) continue;
            $p = json_decode($r['data'], true);
            if (!is_array($p)) continue;
            $kelola = isset($p['kelolaStok']) ? $p['kelolaStok'] : true;
            if ($kelola === false || $kelola === 'false') continue;
            if (!isset($p['stok']) || $p['stok'] === '' || $p['stok'] === null) continue;
            $cur = is_numeric($p['stok']) ? (float)str_replace(',', '.', (string)$p['stok']) : null;
            if ($cur === null) continue;
            $new = max(0, $cur + $addQty);
            $stokStr = rtrim(rtrim(number_format($new, 6, '.', ''), '0'), '.');
            if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
            $p['stok'] = $stokStr;
            $p['updatedAt'] = date('c');
            $upd->execute([json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                           (int)$r['rev'] + 1, $r['id']]);
            $restored++;
        }
        // Bersihkan sisa variasi invoice (case-insensitive) + mirror GAS.
        try { $pdo->prepare("DELETE FROM `invoices` WHERE LOWER(id) = ?")->execute([$lower]); } catch (Exception $e) {}
        try { $pdo->prepare("DELETE FROM `businessTransactions` WHERE LOWER(id) = ?")->execute([$lower]); } catch (Exception $e) {}
        // Pastikan meta tersimpan utk claim client-device lain.
        putRestoreMeta($pdo, $lower, $map);
        $pdo->commit();
        return $restored;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/** Simpan/perbarui kolom meta (qty-map JSON) pada baris log yang sudah ada. */
function putRestoreMeta(PDO $pdo, $key, array $map)
{
    try {
        $stmt = $pdo->prepare("UPDATE _invoice_restore_log SET meta = ? WHERE invoice_key = ?");
        $stmt->execute([json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $key]);
    } catch (Exception $e) { /* kolom meta belum ada — abaikan */ }
}

/**
 * KOREKSI STOK ATOMIK DI SERVER (action adjustStock).
 * delta per kode (+n menambah, -n mengurangi). Idempoten per adjustmentId
 * melalui tabel internal _adjustment_log. Dipakai patch.js agar barang masuk
 * / pembatalan PO ditulis SEKALI di server (bukan dihitung ulang per browser),
 * sekaligus menjadi pengganti write-through cache browser yang lama.
 */
function adjustStockAction(PDO $pdo, array $body)
{
    ensureTable($pdo, '`products`');
    static $adjOk = false;
    if (!$adjOk) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS _adjustment_log (
            adj_id VARCHAR(191) PRIMARY KEY,
            applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            meta LONGTEXT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $adjOk = true;
    }
    $adjId = trim((string)(isset($body['adjustmentId']) ? $body['adjustmentId'] : ''));
    if ($adjId === '') $adjId = 'ADJ-' . substr(md5(mt_rand() . microtime(true)), 0, 12);
    $deltas = isset($body['deltas']) && is_array($body['deltas']) ? $body['deltas'] : [];
    if (!$deltas) out(['success' => false, 'message' => 'Parameter deltas kosong.']);

    // Normalisasi + validasi delta (kode lowercase => float, hanya != 0).
    $clean = [];
    foreach ($deltas as $k => $v) {
        $kk = mb_strtolower(trim((string)$k));
        if ($kk === '') continue;
        $vv = is_numeric($v) ? (float)$v : 0.0;
        if ($vv == 0.0) continue;
        if (!isset($clean[$kk])) $clean[$kk] = 0.0;
        $clean[$kk] += $vv;
    }
    if (!$clean) out(['success' => false, 'message' => 'Tidak ada delta stok valid.']);

    $pdo->beginTransaction();
    try {
        $ins = $pdo->prepare("INSERT IGNORE INTO _adjustment_log (adj_id, meta) VALUES (?, ?)");
        $ins->execute([$adjId, json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        if ($ins->rowCount() === 0) {
            // Adjustment dengan id ini sudah pernah diterapkan — idempoten.
            $pdo->commit();
            out(['success' => true, 'applied' => 0, 'skipped' => 'already-applied',
                 'adjustmentId' => $adjId]);
        }
        $sel = $pdo->prepare("SELECT id, data, rev FROM products WHERE id = ? LIMIT 1 FOR UPDATE");
        $upd = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
        $applied = 0;
        $notFound = [];
        foreach ($clean as $kode => $delta) {
            $sel->execute([$kode]);
            $r = $sel->fetch();
            if (!$r) { $notFound[] = $kode; continue; }
            $p = json_decode($r['data'], true);
            if (!is_array($p)) { $notFound[] = $kode; continue; }
            $kelola = isset($p['kelolaStok']) ? $p['kelolaStok'] : true;
            if ($kelola === false || $kelola === 'false') continue;
            $cur = isset($p['stok']) && is_numeric(str_replace(',', '', (string)$p['stok']))
                ? (float)str_replace(',', '.', (string)$p['stok']) : 0.0;
            $new = max(0, $cur + $delta);
            $stokStr = rtrim(rtrim(number_format($new, 6, '.', ''), '0'), '.');
            if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
            $p['stok'] = $stokStr;
            $p['updatedAt'] = date('c');
            $upd->execute([json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                           (int)$r['rev'] + 1, $r['id']]);
            $applied++;
        }
        $pdo->commit();
        out(['success' => true, 'applied' => $applied, 'adjustmentId' => $adjId,
             'notFound' => $notFound]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Hapus invoice + kembalikan stok secara atomik (satu transaksi MySQL).
 * Dipakai oleh action delete (collection=invoices) dan op delete pada batch.
 *
 * PENTING: fungsi ini TIDAK lagi memulihkan stok untuk invoices — pemulihan
 * dilakukan sekali saja oleh pemanggil setelah pengecekan idempotensi
 * (alreadyRestored), sehingga penghapusan ganda / pre-restore patch tidak
 * membuat stok menjadi dobel (+2 jadi +4).
 * Mengembalikan true bila baris invoice benar-benar ada & terhapus.
 */
function deleteInvoiceWithStockRestore(PDO $pdo, $invTable, $prodTable, $id, $inTransaction = false)
{
    if (!$inTransaction) {
        $pdo->beginTransaction();
    }
    try {
        $inv = readDocRaw($pdo, $invTable, $id);
        $existed = ($inv !== null);
        // Stok TIDAK dikembalikan di sini — lihat catatan di atas.
        $pdo->prepare("DELETE FROM {$invTable} WHERE id = ?")->execute([$id]);
        if (!$inTransaction) $pdo->commit();
        return $existed;
    } catch (Exception $e) {
        if (!$inTransaction && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Pastikan tabel ada DAN kompatibel dengan API (kolom id/data/rev/updated_at + PK id).
 * Tabel lama hasil schema.sql otomatis di-upgrade tanpa membuang data.
 */
function ensureTable(PDO $pdo, $table)
{
    static $done = [];
    $name = tableName($table);
    if (isset($done[$name])) return;
    if (!tableExists($pdo, $name)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS {$table} (
            id VARCHAR(191) PRIMARY KEY,
            data LONGTEXT NULL,
            rev BIGINT NOT NULL DEFAULT 0,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } elseif (tableNeedsRepair($pdo, $table)) {
        try {
            migrateTable($pdo, $table);
        } catch (Exception $e) {
            error_log('[ervo-db] Self-healing tabel ' . $name . ' gagal: ' . $e->getMessage());
            out([
                'success' => false,
                'code'    => 'SCHEMA_REPAIR_REQUIRED',
                'message' => 'Struktur tabel `' . $name . '` tidak cocok & user MySQL tidak berhak memperbaikinya (perlu ALTER/CREATE). Buka phpMyAdmin > tab SQL, jalankan file api/repair.sql sekali, lalu ulangi migrasi. Detail: ' . $e->getMessage(),
            ]);
        }
    } else {
        $done[$name] = true;
    }
    $done[$name] = true;
}

/**
 * Pastikan tabel ada & kompatibel SEBELUM transaksi dimulai (jalur batch).
 * DDL di sini sengaja dilakukan di luar transaksi agar tidak memicu
 * implicit commit.
 */
function prepareTablesForBatch(PDO $pdo, array $tables)
{
    foreach ($tables as $t) {
        ensureTable($pdo, $t);
    }
}

/**
 * Jalur DALAM transaksi: hanya cek eksistensi (tabel sudah dipastikan oleh
 * prepareTablesForBatch sebelum beginTransaction). Tidak melakukan DDL.
 */
function ensureTableNoDdl(PDO $pdo, $table)
{
    $name = tableName($table);
    if (tableExists($pdo, $name)) return;
    throw new RuntimeException("Tabel {$name} belum tersedia saat transaksi berjalan.");
}

/**
 * Upsert merge (setara setDoc merge:true di Firestore).
 * Nilai null menghapus field. Rev naik tiap tulis agar sync `since` bekerja.
 * Parameter $inTransaction=true dipakai jalur batch (DDL dihindari).
 */
function putDoc(PDO $pdo, $table, $id, array $fields, $inTransaction = false)
{
    $inTransaction ? ensureTableNoDdl($pdo, $table) : ensureTable($pdo, $table);
    $stmt = $pdo->prepare("SELECT data, rev FROM {$table} WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    $old = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: []) : [];
    $rev = $row ? (int)$row['rev'] : 0;

    foreach ($fields as $k => $v) {
        if ($k === 'id') continue;
        if ($v === null) {
            unset($old[$k]);
        } else {
            $old[$k] = $v;
        }
    }
    $old['id'] = $id;
    $rev++;

    $json = json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $upd = $pdo->prepare("INSERT INTO {$table} (id, data, rev) VALUES (?, ?, ?)
                          ON DUPLICATE KEY UPDATE data = VALUES(data), rev = VALUES(rev)");
    $upd->execute([$id, $json, $rev]);
    return $rev;
}

function delDoc(PDO $pdo, $table, $id, $inTransaction = false)
{
    $inTransaction ? ensureTableNoDdl($pdo, $table) : ensureTable($pdo, $table);
    $stmt = $pdo->prepare("DELETE FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
}

function listDocs(PDO $pdo, $table, $since = 0)
{
    // Jalur baca: buat/upgrade tabel bila belum ada/belum kompatibel (masih di luar transaksi).
    if (!tableExists($pdo, tableName($table))) {
        ensureTable($pdo, $table);
    } elseif (tableNeedsRepair($pdo, $table)) {
        ensureTable($pdo, $table); // self-healing penuh
    }
    $rows = $pdo->query("SELECT id, data, rev FROM {$table}")->fetchAll();
    $maxRev = 0;
    $docs = [];
    foreach ($rows as $r) {
        if ((int)$r['rev'] > $maxRev) $maxRev = (int)$r['rev'];
        if ($since > 0 && (int)$r['rev'] <= $since) continue;
        $d = ($r['data'] !== null) ? (json_decode($r['data'], true) ?: []) : [];
        if (!is_array($d)) continue;
        if (!isset($d['id'])) $d['id'] = $r['id'];
        $docs[] = [
            'id'         => $r['id'],
            'data'       => $d,
            '_rev'       => (int)$r['rev'],
            '_createdAt' => isset($d['createdAt']) ? $d['createdAt'] : null,
            '_updatedAt' => isset($d['updatedAt']) ? $d['updatedAt'] : null,
        ];
    }
    // Urutkan: TERBARU PALING ATAS. Prioritas waktu = updatedAt/createdAt dari
    // dokumen; cadangan = kolom updated_at MySQL & rev (naik tiap tulis).
    // Berlaku utk semua koleksi (stockIn/barang-masuk & PO ikut terurut).
    usort($docs, function ($a, $b) {
        $ta = isoTs($a['_createdAt']) . '|' . isoTs($a['_updatedAt']) . '|' . sprintf('%020d', $a['_rev']);
        $tb = isoTs($b['_createdAt']) . '|' . isoTs($b['_updatedAt']) . '|' . sprintf('%020d', $b['_rev']);
        return strcmp($tb, $ta);
    });
    return [$docs, $maxRev];
}

/**
 * Normalisasi nilai waktu apa pun (ISO8601, "2025-01-05", epoch ms/detik, dll.)
 * menjadi string YYYY-MM-DD HH:MM:SS agar bisa dibandingkan secara leksikografis.
 * Nilai tak dikenal => '0000-00-00 00:00:00' (terurut paling bawah/terlama).
 */
function isoTs($v)
{
    if ($v === null || $v === '') return '0000-00-00 00:00:00';
    if (is_numeric($v)) {
        $n = (float)$v;
        if ($n > 1e12) $n = $n / 1000.0; // epoch milliseconds
        if ($n <= 0) return '0000-00-00 00:00:00';
        return gmdate('Y-m-d H:i:s', (int)$n);
    }
    $s = trim((string)$v);
    // tanggal lokal app: "05/01/2025" atau "05-01-2025" (dd/mm/yyyy)
    if (preg_match('#^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$#', $s, $m)) {
        return sprintf('%04d-%02d-%02d 00:00:00', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    $t = strtotime(str_replace('T', ' ', preg_replace('/Z$/', '+00:00', $s)));
    if ($t === false) return '0000-00-00 00:00:00';
    return date('Y-m-d H:i:s', $t);
}

// ---------- Routing ----------
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    try {
        // format lama index.php: ?action=list&collection=X
        if (isset($_GET['action']) && $_GET['action'] === 'list') {
            $table = checkCollection(isset($_GET['collection']) ? $_GET['collection'] : '', $ALLOWED_COLLECTIONS);
            list($docs, $rev) = listDocs($pdo, $table);
            out(['success' => true, 'docs' => $docs, 'data' => $docs, 'rev' => $rev]);
        }

        // format frontend baru: ?c=<collection>[&id=..][&since=..]
        $col = isset($_GET['c']) ? $_GET['c'] : (isset($_GET['collection']) ? $_GET['collection'] : '');
        $table = checkCollection($col, $ALLOWED_COLLECTIONS);

        if (isset($_GET['id']) && $_GET['id'] !== '') {
            ensureTable($pdo, $table);
            $id = trim((string)$_GET['id']);
            $stmt = $pdo->prepare("SELECT data, rev FROM {$table} WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            $doc = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: null) : null;
            if (is_array($doc) && !isset($doc['id'])) $doc['id'] = $id;
            out(['success' => true, 'data' => $doc]);
        }

        $since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
        list($docs, $rev) = listDocs($pdo, $table, $since);
        out(['success' => true, 'data' => $docs, 'docs' => $docs, 'rev' => $rev]);
    } catch (Exception $e) {
        error_log('[ervo-db] GET gagal: ' . $e->getMessage());
        out(['success' => false, 'message' => 'Query database gagal: ' . $e->getMessage()]);
    }
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $body = json_decode((string)$raw, true);
    if (!is_array($body)) {
        out(['success' => false, 'message' => 'Body permintaan bukan JSON yang valid.']);
    }

    $action = isset($body['action']) ? $body['action'] : '';

    try {
        switch ($action) {
            case 'adjustStock': {
                // Aksi internal (patch.js): koreksi stok atomik + idempoten.
                adjustStockAction($pdo, $body);
            }

            case 'put': {
                $table = checkCollection(isset($body['collection']) ? $body['collection'] : '', $ALLOWED_COLLECTIONS);
                $id = trim((string)(isset($body['id']) ? $body['id'] : ''));
                if ($id === '' || strlen($id) > 191) {
                    out(['success' => false, 'message' => 'Parameter id tidak valid.']);
                }
                $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : [];

                // --- PULIHKAN-SEKALI saat client menulis tombstone penghapusan.
                // deletedInvoices: invoice dihapus oleh client lain; jika server
                // belum pernah memproses delete-nya (dokumen sudah tak ada),
                // pulihkan stok SEKALI dari qty-map body / sisa tabel.
                if (tableName($table) === 'deletedInvoices') {
                    // Tombstone MURNI (patch.js / Zy-FS mirror): hanya berisi field
                    // meta penghapusan — TIDAK boleh memicu restore kompensasi.
                    $metaOnlyKeys = ['invoiceNo','noInvoice','id','deletedBy','reason','deletedAt','updatedAt','createdAt','_deleted'];
                    $isPureTombstone = true;
                    foreach ($data as $k => $v) {
                        if (!in_array($k, $metaOnlyKeys, true)) { $isPureTombstone = false; break; }
                    }
                    if (!$isPureTombstone) {
                        $qtyMapFromBody = [];
                        if (isset($data['items']) && is_array($data['items'])) {
                            $qtyMapFromBody = invoiceItemQtyMap($data);
                        }
                        $keyRaw = '';
                        foreach (['invoiceNo', 'noInvoice', 'id'] as $kf) {
                            if (isset($data[$kf]) && trim((string)$data[$kf]) !== '') { $keyRaw = $data[$kf]; break; }
                        }
                        if ($keyRaw === '') $keyRaw = $id;
                        compensateRestoreForDeletedDoc($pdo, $keyRaw, $qtyMapFromBody);
                    }
                }

                // products dengan _deleted=true: pembatalan barang masuk/PO oleh
                // browser lain — kurangi stok SEKALI saja via adjustment idempoten
                // (dijaga _adjustment_log, jadi write-ulang yang sama tidak dobel).
                if (tableName($table) === 'products'
                    && isset($data['_deleted']) && ($data['_deleted'] === true || $data['_deleted'] === 'true')) {
                    $prev = readDocRaw($pdo, $table, $id);
                    $oldStok = null; $newStok = null;
                    if (is_array($prev) && isset($prev['stok']) && is_numeric(str_replace(',', '', (string)$prev['stok']))) {
                        $oldStok = (float)str_replace(',', '.', (string)$prev['stok']);
                    }
                    if (array_key_exists('stok', $data) && is_numeric(str_replace(',', '', (string)$data['stok']))) {
                        $newStok = (float)str_replace(',', '.', (string)$data['stok']);
                    }
                    if ($oldStok !== null && $newStok !== null && $newStok < $oldStok) {
                        $adjId = substr(md5('DELPROD|' . mb_strtolower($id) . '|' . number_format($newStok, 6, '.', '')), 0, 24);
                        $bk = $body;
                        $bk['adjustmentId'] = $adjId;
                        $bk['deltas'] = [mb_strtolower($id) => $newStok - $oldStok];
                        adjustStockAction($pdo, $bk);
                    }
                }

                // stockIn (barang masuk / PO): tolak pencatatan ganda berbasis
                // fingerprint produk+qty+supplier+tanggal — retry jaringan atau
                // double-click tidak lagi membuat dua entri identik.
                if (tableName($table) === 'stockIn') {
                    list($rev2, $dup) = putStockInDedup($pdo, $table, $id, $data);
                    out(['success' => true,
                         'data' => ['id' => $id, '_rev' => $rev2],
                         'duplicate' => $dup]);
                }
                // deletedInvoices: sinkronkan penghapusan antar perangkat —
                // buang dokumen invoice dengan nomor yang sama dari tabel
                // `invoices` (TANPA menyentuh stok; idempoten).
                if (tableName($table) === 'deletedInvoices') {
                    $keyRaw = '';
                    foreach (['invoiceNo', 'noInvoice', 'id'] as $kf) {
                        if (isset($data[$kf]) && trim((string)$data[$kf]) !== '') { $keyRaw = $data[$kf]; break; }
                    }
                    if ($keyRaw !== '') {
                        $lk = mb_strtolower(trim($keyRaw));
                        try {
                            $pdo->prepare("DELETE FROM `invoices` WHERE LOWER(id) = ?")->execute([$lk]);
                        } catch (Exception $e) { /* tabel invoices belum ada */ }
                    }
                }

                $rev = putDoc($pdo, $table, $id, $data);
                out(['success' => true, 'data' => ['id' => $id, '_rev' => $rev]]);
            }

            case 'delete': {
                $table = checkCollection(isset($body['collection']) ? $body['collection'] : '', $ALLOWED_COLLECTIONS);
                $id = trim((string)(isset($body['id']) ? $body['id'] : ''));
                if ($id === '') {
                    out(['success' => false, 'message' => 'Parameter id tidak valid.']);
                }
                // KHUSUS invoices: hapus + kembalikan stok barang secara atomik.
                // BUG DOUBLE-RESTORE (stok +2 jadi +4) dicegah dengan dua lapis:
                //  (a) idempotensi server: tabel _invoice_restore_log mencatat
                //      invoice yang sudah pernah di-restore; request delete ulang
                //      untuk nomor yang sama TIDAK menambah stok lagi.
                //  (b) patch.js tidak lagi pre-restore — hanya server yang restore.
                if (tableName($table) === 'invoices') {
                    ensureTable($pdo, '`products`');
                    ensureRestoreLogTable($pdo);
                    $invLower = mb_strtolower(trim($id));
                    $claims = [];
                    // Opsi: client boleh mengirim qtyMap hasil pembacaan dokumen
                    // sebelum dihapus — dipakai server bila dokumen tak ditemukan.
                    $qtyFromBody = (isset($body['qtyMap']) && is_array($body['qtyMap'])) ? $body['qtyMap'] : null;
                    $pdo->beginTransaction();
                    try {
                        // Cari dokumen (id asli / lowercase) sebelum dihapus.
                        $inv = readDocRaw($pdo, $table, $id);
                        if ($inv === null && $invLower !== $id) {
                            $inv = readDocRaw($pdo, $table, $invLower);
                        }
                        $restored = 0;
                        if ($inv !== null) {
                            $qtyMap = invoiceItemQtyMap($inv);
                            // Jangan tandai "sudah dipulihkan" selama masih ada
                            // variasi id lain dengan nomor yang sama — variasi
                            // berikutnya harus tetap dapat memulihkan stoknya.
                            $othersExist = hasOtherInvoiceVariants($pdo, $table, $invLower);
                            if (!alreadyRestored($pdo, $invLower, $qtyMap)) {
                                $restored = restoreInvoiceStock($pdo, $inv);
                            } elseif ($othersExist) {
                                $restored = restoreInvoiceStock($pdo, $inv);
                            }
                            if ($qtyMap) $claims[$invLower] = $qtyMap;
                        } else {
                            // Dokumen tak ditemukan — kirim meta lama bila ada.
                            $old = getLoggedQtyMap($pdo, $invLower);
                            if (!$old && $qtyFromBody) {
                                // PULIHKAN-SEKALI: delete dikirim setelah dokumen
                                // keburu hilang (mis. dihapus device lain). Pulihkan
                                // dari qtyMap body, dijaga idempotensi log.
                                $old = $qtyFromBody;
                                if (!alreadyRestored($pdo, $invLower, $qtyFromBody)) {
                                    $tmp = ['items' => []];
                                    foreach ($qtyFromBody as $k => $q) {
                                        $tmp['items'][] = ['kode' => (string)$k, 'qty' => (float)$q];
                                    }
                                    $restored = restoreInvoiceStock($pdo, $tmp);
                                }
                            }
                            if ($old) $claims[$invLower] = $old;
                        }
                        // Hapus semua variasi id dokumen invoice di tabel.
                        $stmt = $pdo->prepare("DELETE FROM {$table} WHERE LOWER(id) = ?");
                        $stmt->execute([$invLower]);
                        delDoc($pdo, '`deletedInvoices`', $invLower, true); // sinkronkan tombstone
                        $pdo->commit();
                    } catch (Exception $e) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        throw $e;
                    }
                    out(['success' => true, 'data' => ['id' => $id, 'stockRestored' => $restored],
                         'claims' => $claims]);
                }
                // KHUSUS stockIn (barang masuk / PO): hapus + sesuaikan stok
                // SEKALI saja. BUG "pencatatan double" dicegah dengan:
                //  (a) idempotensi server via _stockin_delete_log — delete ulang
                //      untuk id yang sama tidak mengubah stok lagi;
                //  (b) arah penyesuaian MENGIKUTI frontend eL(): qty positif =>
                //      stok DIKURANGI (membatalkan barang masuk), bukan ditambah.
                if (tableName($table) === 'stockIn') {
                    ensureTable($pdo, '`products`');
                    ensureStockInDeleteLogTable($pdo);
                    $hint = null;
                    if (isset($body['kode']) || isset($body['qty'])) {
                        $hint = ['kode' => isset($body['kode']) ? $body['kode'] : '',
                                 'qty'  => isset($body['qty']) ? $body['qty'] : 0];
                    }
                    $res = deleteStockInWithAdjustment($pdo, $table, $id, $hint);
                    out(['success' => true, 'data' => ['id' => $id,
                         'stockAdjusted' => (!$res['dup'] && $res['qty'] > 0),
                         'kode' => isset($res['kode']) ? $res['kode'] : '',
                         'qty' => isset($res['qty']) ? $res['qty'] : 0]]);
                }
                delDoc($pdo, $table, $id);
                out(['success' => true, 'data' => ['id' => $id]]);
            }

            case 'batch': {
                $ops = isset($body['operations']) && is_array($body['operations'])
                     ? $body['operations']
                     : (isset($body['ops']) && is_array($body['ops']) ? $body['ops'] : []);

                // Validasi SEMUA op sebelum transaksi agar tidak ada tulis sebagian
                foreach ($ops as $i => $op) {
                    if (!is_array($op)) out(['success' => false, 'message' => "ops[$i] bukan objek."]);
                    $col = isset($op['collection']) ? $op['collection'] : '';
                    if (!in_array($col, $ALLOWED_COLLECTIONS, true)) {
                        out(['success' => false, 'message' => 'Koleksi tidak dikenal pada batch: ' . $col]);
                    }
                    $o = isset($op['op']) ? $op['op'] : 'put';
                    $idRaw = isset($op['id']) ? $op['id'] : '';
                    // id boleh berupa string, ATAU array daftar id (bulk delete).
                    $ids = is_array($idRaw) ? $idRaw : [trim((string)$idRaw)];
                    if (!$ids) $ids = [];
                    foreach ($ids as $oneId) {
                        $oneId = trim((string)$oneId);
                        if ($oneId === '' || strlen($oneId) > 191) {
                            out(['success' => false, 'message' => "ops[$i].id tidak valid."]);
                        }
                    }
                    if ($o !== 'delete' && count($ids) !== 1) {
                        out(['success' => false, 'message' => "ops[$i]: id array hanya untuk op delete."]);
                    }
                    if (!in_array($o, ['put', 'set', 'update', 'delete'], true)) {
                        out(['success' => false, 'message' => "ops[$i].op tidak valid: " . $o]);
                    }
                }

                // Pastikan semua tabel ada SEBELUM transaksi dimulai,
                // karena CREATE TABLE memicu implicit commit di MySQL/MariaDB.
                foreach ($ops as $op) {
                    ensureTable($pdo, '`' . $op['collection'] . '`');
                }
                // Jalur batch yang menghapus invoice juga butuh tabel products
                // (rollback stok dilakukan atomik di dalam transaksi).
                foreach ($ops as $op) {
                    if ((isset($op['op']) ? $op['op'] : 'put') === 'delete'
                        && $op['collection'] === 'invoices') {
                        ensureTable($pdo, '`products`');
                        break;
                    }
                }

                $pdo->beginTransaction();
                $written = 0;
                $restoredTotal = 0;
                $batchClaims = [];
                $hasInvoiceDelete = false;
                $hasStockInDelete = false;
                foreach ($ops as $op) {
                    if ((isset($op['op']) ? $op['op'] : 'put') === 'delete' && $op['collection'] === 'invoices') {
                        $hasInvoiceDelete = true; break;
                    }
                }
                foreach ($ops as $op) {
                    if ((isset($op['op']) ? $op['op'] : 'put') === 'delete' && $op['collection'] === 'stockIn') {
                        $hasStockInDelete = true; break;
                    }
                }
                if ($hasStockInDelete) ensureStockInDeleteLogTable($pdo);
                if ($hasInvoiceDelete) ensureRestoreLogTable($pdo); // DDL di luar transaksi sudah, ini fallback aman
                // Peta qtyMap opsional dari client per invoice (id lowercase).
                $qtyHints = (isset($body['qtyMaps']) && is_array($body['qtyMaps'])) ? $body['qtyMaps'] : [];
                foreach ($ops as $op) {
                    $table = '`' . $op['collection'] . '`';
                    $o = isset($op['op']) ? $op['op'] : 'put';
                    $idRaw = isset($op['id']) ? $op['id'] : '';
                    $ids = is_array($idRaw) ? $idRaw : [trim((string)$idRaw)];
                    if ($o === 'delete') {
                        foreach ($ids as $oneId) {
                            $oneId = trim((string)$oneId);
                            if ($oneId === '') continue;
                            if ($op['collection'] === 'invoices') {
                                // Hapus invoice + kembalikan stok SEKALI saja
                                // (idempoten via _invoice_restore_log).
                                $lower = mb_strtolower($oneId);
                                $inv = readDocRaw($pdo, $table, $oneId);
                                if ($inv === null && $lower !== $oneId) $inv = readDocRaw($pdo, $table, $lower);
                                if ($inv !== null) {
                                    $qtyMap = invoiceItemQtyMap($inv);
                                    $othersExist = hasOtherInvoiceVariants($pdo, $table, $lower);
                                    if (!alreadyRestored($pdo, $lower, $qtyMap)) {
                                        $restoredTotal += restoreInvoiceStock($pdo, $inv);
                                    } elseif ($othersExist) {
                                        $restoredTotal += restoreInvoiceStock($pdo, $inv);
                                    }
                                    if ($qtyMap) $batchClaims[$lower] = $qtyMap;
                                } else {
                                    $old = getLoggedQtyMap($pdo, $lower);
                                    if (!$old && isset($qtyHints[$lower]) && is_array($qtyHints[$lower])) {
                                        $old = $qtyHints[$lower];
                                        if (!alreadyRestored($pdo, $lower, $old)) {
                                            $tmp = ['items' => []];
                                            foreach ($old as $k => $q) {
                                                $tmp['items'][] = ['kode' => (string)$k, 'qty' => (float)$q];
                                            }
                                            $restoredTotal += restoreInvoiceStock($pdo, $tmp);
                                        }
                                    }
                                    if ($old) $batchClaims[$lower] = $old;
                                }
                                $delStmt = $pdo->prepare("DELETE FROM {$table} WHERE LOWER(id) = ?");
                                $delStmt->execute([$lower]);
                            } elseif ($op['collection'] === 'stockIn') {
                                // Barang masuk / PO: hapus + sesuaikan stok
                                // SEKALI saja (idempoten via _stockin_delete_log,
                                // arah mengikuti frontend eL: qty => stok dikurangi).
                                deleteStockInWithAdjustment($pdo, $table, $oneId);
                            } else {
                                delDoc($pdo, $table, $oneId, true);
                            }
                            $written++;
                        }
                    } else {
                        $data = isset($op['data']) && is_array($op['data']) ? $op['data'] : [];
                        $oneIdTrim = trim((string)$idRaw);

                        // Mirror jalur `put` tunggal: pulihkan-stok-sekali utk
                        // tombstone deletedInvoices & anti-dobel utk pembatalan
                        // produk (_deleted=true dengan stok turun).
                        if ($op['collection'] === 'deletedInvoices') {
                            $qtyMapFromBody = (isset($data['items']) && is_array($data['items']))
                                ? invoiceItemQtyMap($data) : [];
                            $keyRaw = '';
                            foreach (['invoiceNo', 'noInvoice', 'id'] as $kf) {
                                if (isset($data[$kf]) && trim((string)$data[$kf]) !== '') { $keyRaw = $data[$kf]; break; }
                            }
                            if ($keyRaw === '') $keyRaw = $oneIdTrim;
                            compensateRestoreForDeletedDoc($pdo, $keyRaw, $qtyMapFromBody);
                        }
                        if ($op['collection'] === 'products'
                            && isset($data['_deleted']) && ($data['_deleted'] === true || $data['_deleted'] === 'true')) {
                            $prev = readDocRaw($pdo, $table, $oneIdTrim);
                            $oldStok = null; $newStok = null;
                            if (is_array($prev) && isset($prev['stok']) && is_numeric(str_replace(',', '', (string)$prev['stok']))) {
                                $oldStok = (float)str_replace(',', '.', (string)$prev['stok']);
                            }
                            if (array_key_exists('stok', $data) && is_numeric(str_replace(',', '', (string)$data['stok']))) {
                                $newStok = (float)str_replace(',', '.', (string)$data['stok']);
                            }
                            if ($oldStok !== null && $newStok !== null && $newStok < $oldStok) {
                                $adjId = substr(md5('DELPROD|' . mb_strtolower($oneIdTrim) . '|' . number_format($newStok, 6, '.', '')), 0, 24);
                                $ins = $pdo->prepare("INSERT IGNORE INTO _adjustment_log (adj_id, meta) VALUES (?, ?)");
                                $deltas = [mb_strtolower($oneIdTrim) => $newStok - $oldStok];
                                $ins->execute([$adjId, json_encode($deltas)]);
                                if ($ins->rowCount() > 0) {
                                    $selP = $pdo->prepare("SELECT id, data, rev FROM products WHERE id = ? LIMIT 1 FOR UPDATE");
                                    $updP = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
                                    $selP->execute([mb_strtolower($oneIdTrim)]);
                                    $rp = $selP->fetch();
                                    if ($rp) {
                                        $pp = json_decode($rp['data'], true);
                                        if (is_array($pp)) {
                                            $kelola = isset($pp['kelolaStok']) ? $pp['kelolaStok'] : true;
                                            if (!($kelola === false || $kelola === 'false')) {
                                                $cur = is_numeric(str_replace(',', '', (string)(isset($pp['stok']) ? $pp['stok'] : 0)))
                                                    ? (float)str_replace(',', '.', (string)$pp['stok']) : 0.0;
                                                $newv = max(0, $cur + ($newStok - $oldStok));
                                                $stokStr = rtrim(rtrim(number_format($newv, 6, '.', ''), '0'), '.');
                                                if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
                                                $pp['stok'] = $stokStr;
                                                $pp['updatedAt'] = date('c');
                                                $updP->execute([json_encode($pp, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                                                               (int)$rp['rev'] + 1, $rp['id']]);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        putDoc($pdo, $table, $oneIdTrim, $data, true);
                        $written++;
                    }
                }
                $pdo->commit();
                out(['success' => true, 'written' => $written, 'stockRestored' => $restoredTotal,
                     'claims' => $batchClaims,
                     'data' => ['written' => $written, 'stockRestored' => $restoredTotal,
                                'claims' => $batchClaims]]);
            }

            case 'cleanup': {
                // Tombstone dikelola oleh aplikasi; tidak ada yang perlu dibersihkan di sini.
                out(['success' => true, 'removed' => 0]);
            }

            default:
                out(['success' => false, 'message' => 'Aksi tidak dikenal: ' . $action]);
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[ervo-db] POST gagal: ' . $e->getMessage());
        out(['success' => false, 'message' => 'Query database gagal: ' . $e->getMessage()]);
    }
}

out(['success' => false, 'message' => 'Metode tidak didukung.']);
