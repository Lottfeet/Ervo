/*!
 * patch.js — Ervo Store Kasir (tambal client-side, dimuat SETELAH bundle utama)
 *
 * 1) BUG STOK: Saat invoice dihapus / dikoreksi, aplikasi hanya mengembalikan
 *    stok di cache browser (localStorage) tanpa menulis hasilnya ke server MySQL,
 *    sehingga stok di database & perangkat lain tidak pernah pulih.
 *    -> Patch ini mengunci hasil koreksi stok lokal lalu MENULIS-nya balik ke
 *       server (PUT /api/db.php action=put collection=products), plus
 *       fallback "Koreksi Stok Manual" bila invoice tidak ditemukan di server.
 *
 * 2) LAPORAN LAMBAT: fetch ke /api/db.php tidak dibatasi waktunya; satu request
 *    yang menggantung (shared hosting sering begini) membuat halaman Laporan
 *    tampak loading terus. -> Patch memasang timeout 20 detik pada seluruh
 *    request db.php; kegagalan otomatis di-retry oleh engine sync bawaan.
 *
 * Cara pasang: tambahkan <script src="/assets/patch.js?v=fix25"></script>
 *               tepat SEBELUM </body> di index.html (sudah terpasang).
 */
(function () {
  'use strict';

  var API = '/api/db.php';
  var TIMEOUT_MS = 20000;

  /* ---------- util JSON ---------- */
  function jget(url) {
    return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }
  function jpost(body) {
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  /* =========================================================
   * 2) Timeout untuk semua request db.php (laporan tak lagi
   *    menggantung selamanya). Membungkus window.fetch.
   * ========================================================= */
  var nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    var url = typeof input === 'string' ? input : ((input && input.url) || '');
    if (url.indexOf('/api/db.php') !== -1) {
      try {
        init = init || {};
        var prevSignal = init.signal;
        var ctrl = new AbortController();
        var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
        init.signal = ctrl.signal;
        if (prevSignal) {
          if (prevSignal.aborted) ctrl.abort();
          else prevSignal.addEventListener('abort', function () { ctrl.abort(); });
        }
        return nativeFetch(input, init).finally(function () { clearTimeout(timer); });
      } catch (e) { /* fallback: biarkan apa adanya */ }
    }
    return nativeFetch(input, init);
  };

  /* =========================================================
   * 1a) KUNCI PENCEGAH ROLLBACK GANDA (satu-satunya jalur flush)
   *     Dulu patch ini menulis-balik stok cache browser ke MySQL
   *     ("proof-of-restore"). Karena server db.php kini yang
   *     memulihkan stok saat delete invoice, flush tersebut justru
   *     menjadi sumber RESTORE KETIGA (+2 jadi +4). Maka:
   *       - localStorage.setItem TIDAK memicu flush apa pun;
   *       - window.fetch (bagian 1c) membuang PUT produk yang
   *         merupakan hasil rollback lokal (WD() di bundle);
   *       - "Koreksi Stok Manual" (1b) tetap tersedia sebagai
   *         jalur tulis manual satu-satunya.
   * ========================================================= */
  var LS_PRODUCTS = 'strukku_products';
  function normKey(x) { return String(x == null ? '' : x).trim().toLowerCase(); }
  var nativeSetItem = localStorage.setItem.bind(localStorage);

  /* =========================================================
   * 1c) PENCEGAH ROLLBACK GANDA — PENDEKATAN DETERMINISTIK
   *
   * BUG: "+2 pcs harusnya pulih 2, malah pulih 4".
   * Akar masalah (hasil audit bundle index--bMBpxKA.js, fungsi XD):
   *   a) Saat tombol hapus ditekan, aplikasi memanggil WD(items,+1) yang
   *      MENAMBAH stok ke cache browser lalu mengirim
   *      POST {action:"put",collection:"products"} ke MySQL  -- RESTORE #1
   *   b) Aplikasi juga mengirim {action:"delete",collection:"invoices"};
   *      server db.php ikut mengembalikan stok                    -- RESTORE #2
   *   => total +2+2 = +4. Versi patch lama memakai tebakan waktu
   *   (window 60 detik + selisih stok) yang RACE-PRONE sehingga kadang
   *   tidak tertangkap dan stok tetap dobel.
   *
   * FIX FINAL (deterministik, dua lapis):
   *  L1 — "claim" di server: db.php menyimpan kolom `claimed` pada dokumen
   *       invoice saat restore. PUT produk dari client yang membawa stok hasil
   *       rollback (selisih = qty item invoice yang sedang di-claim) dibuang.
   *  L2 — marker per nomor invoice di localStorage + pencocokan item dari
   *       cache invoice app (strukku_recent_invoices_v3 / ervo_server_cache_v1).
   *       Selama delete belum dikonfirmasi server, penulisan stok utk kode
   *       produk terkait invoice tsb TIDAK diteruskan.
   *  Idempotensi tetap dijaga tabel _invoice_restore_log di MySQL, sehingga
   *  penghapusan ulang / retry jaringan tidak pernah menambah stok dua kali.
   * ========================================================= */

  var LS_MARKERS = 'ervo_pending_invoice_deletes_v1';
  var LS_CLAIMS  = 'ervo_invoice_claims_v1';
  function readMarkers() {
    try {
      var raw = JSON.parse(localStorage.getItem(LS_MARKERS) || '{}');
      return (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    } catch (e) { return {}; }
  }
  function writeMarkers(m) {
    try { nativeSetItem(LS_MARKERS, JSON.stringify(m)); } catch (e) {}
  }
  function addMarker(invNo) {
    var k = normInv(invNo); if (!k) return;
    var m = readMarkers(); m[k] = Date.now(); writeMarkers(m);
  }
  function consumeMarker(invNo) {
    var k = normInv(invNo); if (!k) return;
    var m = readMarkers(); if (k in m) { delete m[k]; writeMarkers(m); }
  }
  // Claim dari SERVER: {invKeyLower: {kodeLower: qty}} — dikirim db.php
  // pada response action delete/batch invoices.
  function readClaims() {
    try {
      var raw = JSON.parse(localStorage.getItem(LS_CLAIMS) || '{}');
      return (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
    } catch (e) { return {}; }
  }
  function writeClaims(c) { try { nativeSetItem(LS_CLAIMS, JSON.stringify(c)); } catch (e) {} }
  function saveClaimFromResponse(j) {
    try {
      if (!j) return;
      var claims = j.claims || (j.data && j.data.claims);
      if (claims && typeof claims === 'object') {
        var c = readClaims();
        Object.keys(claims).forEach(function (k) {
          c[normInv(k)] = claims[k];
          c['@ts_' + normInv(k)] = Date.now();
        });
        writeClaims(c);
      }
    } catch (e) {}
  }
  // Sampah claim >7 hari
  (function gcClaims() {
    try {
      var c = readClaims(), ch = false, now = Date.now();
      Object.keys(c).forEach(function (k) {
        if (k.indexOf('@ts_') === 0 && now - Number(c[k] || 0) > 7 * 864e5) {
          delete c[k]; delete c[k.slice(4)]; ch = true;
        }
      });
      if (ch) writeClaims(c);
    } catch (e) {}
  })();

  // Sampah: marker >30 hari dianggap basi (mis. user menghapus lewat mode offline)
  (function gcMarkers() {
    try {
      var m = readMarkers(), ch = false, now = Date.now();
      Object.keys(m).forEach(function (k) {
        if (!(m[k] > 0) || now - m[k] > 30 * 864e5) { delete m[k]; ch = true; }
      });
      if (ch) writeMarkers(m);
    } catch (e) {}
  })();

  function normInv(x) { return String(x == null ? '' : x).trim().toLowerCase(); }
  function invKeyOfDoc(d) {
    if (!d || typeof d !== 'object') return '';
    return normInv(d.invoiceNo || d.noInvoice || d.id || '');
  }

  function qtyOfItem(it) {
    var q = Number(it.qty != null ? it.qty : (it.jumlah != null ? it.jumlah : (it.quantity != null ? it.quantity : 1)));
    return isNaN(q) ? 1 : q;
  }
  // Kumpulkan {kodeLower: totalQty} dari daftar item invoice
  function keysFromItems(items) {
    var set = {};
    if (!Array.isArray(items)) return set;
    items.forEach(function (it) {
      if (!it) return;
      var kk = normKey(it.kode || '');
      if (kk) set[kk] = (set[kk] || 0) + qtyOfItem(it);
    });
    return set;
  }

  /* Cocokkan satu operasi tulis produk terhadap proses penghapusan invoice.
   * Mengembalikan true bila penulisan ini adalah hasil rollback klien yang
   * harus DIBUANG (server yang akan memulihkan stok). */
  function isRolledBackWrite(opId, opData) {
    try {
      var kk = normKey((opData && opData.kode) || opId || '');
      if (!kk) return false;
      var newStok = (opData && opData.stok != null) ? parseFloat(String(opData.stok)) : NaN;

      // ---- L1: claim dari server (paling akurat — ada qty & idem cap) ----
      var claims = readClaims();
      var keys = Object.keys(claims);
      for (var i = 0; i < keys.length; i++) {
        var ik = keys[i];
        if (ik.indexOf('@ts_') === 0) continue;
        var cl = claims[ik];
        if (!cl || !(kk in cl)) continue;
        var qty = Number(cl[kk] || 0);
        if (opData && opData.__restoreFor === ik) return true;           // cap eksplisit
        if (!isNaN(newStok)) {
          var base = newStok - qty;                                      // nilai pra-rollback versi klien
          // Bila server sudah restore lalu sync, stok server == base → klien
          // mengirim base+qty lagi = dobel. Drop selama claim aktif.
          return true;
        }
        return true;
      }

      // ---- L2: marker lokal + item dari cache invoice app ----
      var markers = readMarkers();
      var mkKeys = Object.keys(markers);
      if (!mkKeys.length) return false;
      var docs = [];
      try {
        ['strukku_recent_invoices_v3', 'strukku_recent_invoices'].forEach(function (key) {
          var v = JSON.parse(localStorage.getItem(key) || 'null');
          if (Array.isArray(v)) docs = docs.concat(v);
          else if (v && Array.isArray(v.data)) docs = docs.concat(v.data);
        });
      } catch (e) {}
      if (!docs.length) {
        try {
          var sc = JSON.parse(localStorage.getItem('ervo_server_cache_v1') || '{}');
          if (Array.isArray(sc.invoices)) docs = sc.invoices;
        } catch (e) {}
      }
      for (var a = 0; a < mkKeys.length; a++) {
        for (var b = 0; b < docs.length; b++) {
          var d = docs[b];
          if (invKeyOfDoc(d) !== mkKeys[a]) continue;
          var ks = keysFromItems(d.items);
          if (kk in ks) return true;
        }
      }
      return false;
    } catch (e) { return false; }
  }

  async function handlePostBody(bodyObj) {
    try {
      if (!bodyObj || typeof bodyObj !== 'object') return null;

      // ---- (1) DELETE invoice (tunggal): pasang marker, biarkan server restore
      if (bodyObj.action === 'delete' && bodyObj.collection === 'invoices' && bodyObj.id) {
        addMarker(String(bodyObj.id));
        return null; // teruskan — server yang memulihkan stok (sekali, idempoten)
      }

      // ---- (2) BATCH berisi delete invoices: pasang marker utk tiap id
      if (bodyObj.action === 'batch' && Array.isArray(bodyObj.operations)) {
        var sawInvDel = false;
        bodyObj.operations.forEach(function (op) {
          if (!op || op.collection !== 'invoices' || op.op !== 'delete') return;
          sawInvDel = true;
          var ids = Array.isArray(op.id) ? op.id : [op.id];
          ids.forEach(function (idv) { if (idv) addMarker(String(idv)); });
        });
        if (sawInvDel) return null;
        // batch murni put products -> saring di (4)
      }

      // ---- (3) PUT produk tunggal: buang bila ini hasil rollback lokal
      if (bodyObj.action === 'put' && bodyObj.collection === 'products') {
        // (3a-DEDUP) Pembatalan barang masuk/PO dari browser: aplikasi menulis
        // stok_final = stok_lokal - qty. Bila nilai final yang dikirim SUDAH SAMA
        // dengan stok di server, pengurangan sudah pernah diterapkan (oleh device
        // lain / retry) -> tulisan ulang hanya memicu re-sync dobel. Buang.
        // (Bila beda — mis. ada penjualan setelahnya — penulisan DITERUSKAN agar
        //  tidak menimpa stok dengan nilai basi.)
        if (bodyObj.data && (bodyObj.data._deleted === true || bodyObj.data._deleted === 'true') &&
            bodyObj.data.stok != null && bodyObj.id) {
          return jget(API + '?c=products&id=' + encodeURIComponent(bodyObj.id)).then(function (r) {
            var cur = r && r.success && r.data ? r.data.stok : null;
            if (cur != null && String(cur) === String(bodyObj.data.stok)) {
              console.info('[patch] Pembatalan barang masuk SUDAH diterapkan server, tulis-ulang DIBUANG:', bodyObj.id);
              return 'DROP';
            }
            return isRolledBackWrite(bodyObj.id, bodyObj.data) ? 'DROP' : null;
          }).catch(function () { return isRolledBackWrite(bodyObj.id, bodyObj.data) ? 'DROP' : null; });
        }
        if (isRolledBackWrite(bodyObj.id, bodyObj.data)) {
          console.info('[patch] Rollback lokal DIBUANG (server akan restore):', bodyObj.id);
          return 'DROP';
        }
        return null;
      }

      // ---- (3b) PUT products dengan _deleted=true = pembatalan barang
      //      masuk/PO dari browser lain. Server (db.php) sudah mengurangi
      //      stok SEKALI via adjustment idempoten — penulisan yang sama dari
      //      perangkat KEDUA adalah sumber "+2 jadi +4". Buang di sini agar
      //      hanya jalur delete resmi / device penghapus yang memprosesnya.
      if (bodyObj.action === 'put' && bodyObj.collection === 'products' &&
          bodyObj.data && (bodyObj.data._deleted === true || bodyObj.data._deleted === 'true')) {
        console.info('[patch] Tombstone produk DIBUANG (server menangani sekali):', bodyObj.id);
        return 'DROP';
      }

      // ---- (4) PUT bulk produk: buang HANYA op yang merupakan rollback lokal
      if (bodyObj.action === 'batch' && Array.isArray(bodyObj.operations)) {
        var dropAny = false;
        bodyObj.operations.forEach(function (op) {
          if (!op || op.collection !== 'products') return;
          if (!(op.op == null || op.op === 'put' || op.op === 'set' || op.op === 'update')) return;
          // (4b) tombstone _deleted=true => pembatalan barang masuk dari device
          // lain; server sudah mengurangi stok SEKALI — jangan dobel.
          if (op.data && (op.data._deleted === true || op.data._deleted === 'true')) {
            op.__drop = true; dropAny = true; return;
          }
          if (isRolledBackWrite(op.id, op.data)) { op.__drop = true; dropAny = true; }
        });
        if (!dropAny) return null;
        var kept = bodyObj.operations.filter(function (op) { return !op.__drop; });
        console.info('[patch] Batch: operasi rollback lokal dibuang:', bodyObj.operations.length - kept.length);
        if (!kept.length) return 'DROP';
        return { action: 'batch', operations: kept };
      }

      return null;
    } catch (e) { return null; } // jangan pernah ganggu request asli
  }

  var nativeFetch2 = window.fetch; // sudah dibungkus timeout di atas
  window.fetch = function (input, init) {
    try {
      var url = typeof input === 'string' ? input : ((input && input.url) || '');
      if (url.indexOf('/api/db.php') !== -1 && init && String(init.method || '').toUpperCase() === 'POST' && init.body) {
        var bodyObj = null;
        try { bodyObj = JSON.parse(init.body); } catch (e) {}
        if (bodyObj && (
              (bodyObj.action === 'delete' && bodyObj.collection === 'invoices') ||
              (bodyObj.action === 'put' && bodyObj.collection === 'products') ||
              (bodyObj.action === 'batch' && Array.isArray(bodyObj.operations)))) {
          return Promise.resolve(handlePostBody(bodyObj)).then(function (verdict) {
            if (verdict === 'DROP') {
              return new Response(JSON.stringify({ success: true, skipped: 'double-restore-guard' }),
                                  { status: 200, headers: { 'Content-Type': 'application/json' } });
            }
            if (verdict && typeof verdict === 'object') {
              init = Object.assign({}, init, { body: JSON.stringify(verdict) });
            }
            return nativeFetch2(input, init);
          }).catch(function () { return nativeFetch2(input, init); });
        }
      }
    } catch (e) { /* jangan ganggu request asli */ }
    return nativeFetch2(input, init);
  };

  /* ---- Lapis pembersih: ketika server mengonfirmasi delete invoice
   *       (response success), simpan CLAIM qty dari server lalu matikan
   *       marker-nya supaya penulisan stok NORMAL (jual/edit barang biasa)
   *       kembali diteruskan — hanya rollback utk invoice tsb yang dibuang. ---- */
  var origFetch3 = window.fetch;
  window.fetch = function (input, init) {
    var url = typeof input === 'string' ? input : ((input && input.url) || '');
    var isDb = url.indexOf('/api/db.php') !== -1;
    var bodyObj = null;
    if (isDb && init && String(init.method || '').toUpperCase() === 'POST' && init.body) {
      try { bodyObj = JSON.parse(init.body); } catch (e) {}
    }
    var p = origFetch3(input, init);
    if (!isDb || !bodyObj) return p;
    return p.then(function (res) {
      try {
        if (res.ok && res.clone) {
          res.clone().json().then(function (j) {
            if (!j || j.success !== true) return;
            saveClaimFromResponse(j);
            if (bodyObj.action === 'delete' && bodyObj.collection === 'invoices') {
              consumeMarker(String(bodyObj.id));
            } else if (bodyObj.action === 'batch' && Array.isArray(bodyObj.operations)) {
              bodyObj.operations.forEach(function (op) {
                if (op && op.collection === 'invoices' && op.op === 'delete') {
                  var ids = Array.isArray(op.id) ? op.id : [op.id];
                  ids.forEach(function (idv) { if (idv) consumeMarker(String(idv)); });
                }
              });
            }
          }).catch(function () {});
        }
      } catch (e) {}
      return res;
    });
  };

  /* ---------- baca daftar produk lokal ---------- */
  function parseMaybe(s) {
    if (typeof s !== 'string') return s;
    try {
      var v = JSON.parse(s);
      // beberapa versi app membungkus: {data:[...]} atau string ganda
      if (typeof v === 'string') { try { v = JSON.parse(v); } catch (e) {} }
      return v;
    } catch (e) { return null; }
  }
  function localProducts() {
    var raw = parseMaybe(localStorage.getItem(LS_PRODUCTS));
    if (Array.isArray(raw)) return raw;
    if (raw && Array.isArray(raw.data)) return raw.data;
    if (raw && Array.isArray(raw.barang)) return raw.barang;
    return [];
  }

  /* ---------- (dibersihkan) flush otomatis cache→server ----------
   * flushToServer() lama MENULIS SELURUH cache stok browser ke MySQL.
   * Karena server db.php kini memulihkan stok saat delete invoice, dan
   * WD() aplikasi juga menulis rollback ke browser, flush ini justru
   * menjadi RESTORE KETIGA (+2 menjadi +4). Fungsi & timer-nya dihapus;
   * koreksi tetap bisa dilakukan lewat tombol "Koreksi Stok Manual" (1b).
   */

  /* =========================================================
   * 1b) UI "Koreksi Stok Manual" — dipakai bila invoice sudah
   *     terlanjur terhapus / stok lama belum sempat tercatat,
   *     atau rollback otomatis tidak menemukan dokumennya.
   *     Menambah stok langsung ke MySQL (server-first).
   * ========================================================= */
  function ensureUI() {
    if (document.getElementById('ervo-stock-helper')) return;
    var btn = document.createElement('button');
    btn.id = 'ervo-stock-helper';
    btn.textContent = '🔧 Koreksi Stok';
    btn.title = 'Kembalikan stok ke database (mis. setelah invoice terhapus)';
    btn.style.cssText = 'position:fixed;right:14px;bottom:86px;z-index:9998;width:44px;height:44px;' +
      'border-radius:50%;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font-size:18px;' +
      'box-shadow:0 2px 10px rgba(0,0,0,.18);cursor:pointer;display:none';
    document.body.appendChild(btn);

    // tampilkan hanya di area transaksi/produk/laporan (cocokkan URL/hash umum)
    function toggle() {
      var h = (location.hash + location.pathname).toLowerCase();
      var show = /transaksi|riwayat|invoice|produk|barang|lapor/.test(h);
      btn.style.display = show ? 'block' : 'none';
    }
    toggle();
    window.addEventListener('hashchange', toggle);
    window.addEventListener('popstate', toggle);
    setInterval(toggle, 3000);

    btn.addEventListener('click', openDialog);
  }

  function openDialog() {
    if (document.getElementById('ervo-stock-dlg')) return;
    var dlg = document.createElement('div');
    dlg.id = 'ervo-stock-dlg';
    dlg.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.45);' +
      'display:flex;align-items:center;justify-content:center;padding:16px';
    dlg.innerHTML =
      '<div style="background:#fff;border-radius:14px;max-width:420px;width:100%;padding:20px;font-family:system-ui,sans-serif">' +
      '<h3 style="margin:0 0 4px;font-size:16px">Koreksi Stok Manual</h3>' +
      '<p style="margin:0 0 12px;font-size:12px;color:#64748b">Kembalikan qty ke database (dipakai bila stok tidak pulih setelah invoice dihapus).</p>' +
      '<label style="font-size:12px;display:block;margin-bottom:4px">Cari produk (kode / nama)</label>' +
      '<input id="ev-q" placeholder="cth: BRG-001 / stiker" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:8px">' +
      '<div id="ev-list" style="max-height:150px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:10px"></div>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">' +
      '<span style="font-size:12px">Δ qty (+masuk / −keluar)</span>' +
      '<input id="ev-qty" type="number" step="any" value="0" style="width:90px;padding:6px;border:1px solid #cbd5e1;border-radius:8px">' +
      '</div>' +
      '<div id="ev-msg" style="font-size:12px;color:#b91c1c;min-height:16px;margin-bottom:8px"></div>' +
      '<div style="display:flex;justify-content:flex-end;gap:8px">' +
      '<button id="ev-cancel" style="padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer">Batal</button>' +
      '<button id="ev-save" style="padding:8px 14px;border-radius:8px;border:0;background:#2563eb;color:#fff;cursor:pointer">Simpan ke Database</button>' +
      '</div></div>';
    document.body.appendChild(dlg);

    var qEl = dlg.querySelector('#ev-q'), listEl = dlg.querySelector('#ev-list');
    var qtyEl = dlg.querySelector('#ev-qty'), msgEl = dlg.querySelector('#ev-msg');
    var chosen = null, cache = null;

    function loadCache() {
      if (cache) return Promise.resolve(cache);
      return jget(API + '?c=products&since=0').then(function (r) {
        cache = (r && r.success && Array.isArray(r.data)) ? r.data : [];
        return cache;
      });
    }
    function render() {
      var q = normKey(qEl.value);
      loadCache().then(function (rows) {
        listEl.innerHTML = '';
        rows.filter(function (row) {
          if (!q) return true;
          var d = row.data || {};
          return normKey(d.nama).indexOf(q) > -1 || normKey(d.kode).indexOf(q) > -1 || normKey(row.id).indexOf(q) > -1;
        }).slice(0, 30).forEach(function (row) {
          var d = row.data || {};
          var it = document.createElement('div');
          it.style.cssText = 'padding:6px 10px;font-size:12px;cursor:pointer;border-bottom:1px solid #f1f5f9';
          it.textContent = (d.kode ? d.kode + ' — ' : '') + (d.nama || row.id) + ' (stok: ' + (d.stok != null ? d.stok : '-') + ')';
          it.onclick = function () {
            chosen = row; it.parentNode.querySelectorAll('div').forEach(function (x) { x.style.background = '#fff'; });
            it.style.background = '#dbeafe';
          };
          listEl.appendChild(it);
        });
      }).catch(function (e) { msgEl.textContent = 'Gagal memuat produk: ' + e.message; });
    }
    qEl.addEventListener('input', render);
    render();

    dlg.querySelector('#ev-cancel').onclick = function () { dlg.remove(); };
    dlg.querySelector('#ev-save').onclick = function () {
      msgEl.textContent = '';
      if (!chosen) { msgEl.textContent = 'Pilih produk dulu.'; return; }
      var delta = parseFloat(qtyEl.value || '0');
      if (!delta) { msgEl.textContent = 'Isi Δ qty (tidak boleh 0).'; return; }
      var cur = parseFloat(String((chosen.data || {}).stok == null ? '0' : chosen.data.stok));
      if (isNaN(cur)) cur = 0;
      var next = Math.max(0, cur + delta);
      var btn = dlg.querySelector('#ev-save'); btn.disabled = true; btn.textContent = 'Menyimpan…';
      jpost({
        action: 'put', collection: 'products', id: chosen.id,
        data: { stok: String(next), updatedAt: new Date().toISOString() }
      }).then(function (r) {
        if (!r || !r.success) throw new Error((r && r.message) || 'server menolak');
        // samakan cache lokal agar UI langsung konsisten
        try {
          var locals = localProducts(), hit = false;
          for (var i = 0; i < locals.length; i++) {
            if (locals[i] && normKey(locals[i].kode) === normKey(chosen.id)) { locals[i].stok = String(next); hit = true; }
          }
          if (hit) nativeSetItem(LS_PRODUCTS, JSON.stringify(locals));
        } catch (e) {}
        alert('Stok "' + ((chosen.data || {}).nama || chosen.id) + '" diperbarui: ' + cur + ' → ' + next);
        dlg.remove();
      }).catch(function (e) {
        msgEl.textContent = 'Gagal: ' + e.message;
        btn.disabled = false; btn.textContent = 'Simpan ke Database';
      });
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureUI);
  } else {
    ensureUI();
  }

  /* =========================================================
   * 4) RIWAYAT BARANG MASUK / PO — PERBAIKAN FINAL
   *    Bug lama: pengurutan berbasis TEKS DOM (tanggal per-baris, bukan
   *    per-nota; qty/nominal ikut tercampur teks lain). Karena React
   *    me-render ulang daftar tiap beberapa detik (polling sync), urutan
   *    hasil sort patch selalu berbeda-beda → nomor 1 naik-turun terus.
   *    Fix baru: JANGAN pernah reorder DOM. Sumber kebenaran urutan =
   *    data aplikasi di localStorage ('strukku_stock_in_history'), field
   *    createdAt/updatedAt/tanggal (epoch ms / ISO string). Patch hanya:
   *      a) menormalkan + mengurut array itu DESC (terbaru di atas),
   *      b) menghapus duplikat (id sama / fingerprint sama),
   *      c) menandai versi agar app tidak membalik urutan saat hydrate,
   *    lalu membiarkan React render dari data yang sudah stabil.
   * ========================================================= */
  var LS_STOCKIN_KEYS = ['strukku_stock_in_history', 'stockInHistory', 'strukku_barang_masuk'];
  var SORTED_FLAG = '__evo_sorted_v1__';

  function toEpoch(v) {
    if (v == null) return 0;
    if (typeof v === 'number') return v < 1e12 ? v * 1000 : v; // unix detik vs ms
    var s = String(v);
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime() || 0;
    m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})(?:[ ,]+(\d{1,2}):(\d{2}))?/);
    if (m) { var y = +m[3]; if (y < 100) y += 2000; return new Date(y, +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0)).getTime() || 0; }
    m = s.match(/^\d+$/);
    if (m) { var n = +s; return n < 1e12 ? n * 1000 : n; }
    var d = Date.parse(s);
    return isNaN(d) ? 0 : d;
  }
  function entryTs(e) {
    return toEpoch(e.createdAt || e.updatedAt || e.timestamp || e.tanggal || e.date || e.time || 0);
  }
  function entryFp(e) {
    // fingerprint stabil untuk dedup lintas sumber (cache lokal vs server)
    var items = Array.isArray(e.items) ? e.items.map(function (it) {
      return String(it.kode || it.id || it.nama || '') + ':' + (it.qty != null ? it.qty : it.jumlah || '');
    }).join(',') : '';
    return [String(e.no_po || e.nomor || e.invoice || e.no || '').toUpperCase(),
      String(e.vendor || e.supplier || ''), String(e.total || e.nilai || e.amount || ''), items].join('|');
  }
  function normalizeStockInArray(arr) {
    var changed = false, out = [], seenId = {}, seenFp = {};
    arr.forEach(function (e) {
      if (!e || typeof e !== 'object') { changed = true; return; }
      var id = String(e.id || e._id || '');
      if (id && seenId[id]) { changed = true; return; }           // duplikat id
      var fp = entryFp(e);
      if (fp !== '|||' && seenFp[fp]) { changed = true; return; } // duplikat konten
      if (id) seenId[id] = 1;
      if (fp !== '|||') seenFp[fp] = 1;
      if (!e[SORTED_FLAG]) { try { Object.defineProperty(e, SORTED_FLAG, { value: 1, enumerable: false }); } catch (_e) {} }
      out.push(e);
    });
    out.sort(function (a, b) {
      var d = entryTs(b) - entryTs(a);
      if (d !== 0) return d;
      return String(b.id || '').localeCompare(String(a.id || '')); // tie-break deterministik
    });
    return { list: out, changed: changed };
  }
  /* Peta stabil per-key: id -> entri. KUNCI PERBAIKAN BUG "nomor urut 1
   * naik-turun terus": dulu kita menulis-ulang localStorage dengan urutan
   * hasil sort; engine sync aplikasi lalu MEMBALAS menulis cache-nya (urutan
   * sumber berbeda tiap siklus polling) -> dua penulis bergantian = daftar
   * berubah-ubah tanpa henti. Sekarang patch TIDAK pernah menulis cache app.
   * Kita hanya mencatat versi terbaru tiap entri di peta internal, dan
   * menerapkannya ke state render React SESAI-BUTUH (targeted setState),
   * bukan lewat mutasi localStorage/DOM. */
  var stockInMap = {};                 // id -> entry (salinan)
  var lastSig = '';                    // fingerprint isi array cache

  function collectStockIn(arr) {
    (arr || []).forEach(function (e) {
      if (!e || typeof e !== 'object') return;
      var id = String(e.id || e._id || '');
      if (!id) return;
      var prev = stockInMap[id];
      var t = entryTs(e), pt = prev ? entryTs(prev) : -1;
      if (!prev || t >= pt) stockInMap[id] = e;   // menangkan yang lebih baru
    });
  }

  function sortedStockIn() {
    var seenId = {}, seenFp = {}, out = [];
    Object.keys(stockInMap).forEach(function (id) {
      var e = stockInMap[id];
      if (seenId[id]) return;
      var fp = entryFp(e);
      if (fp !== '|||' && seenFp[fp]) return;     // duplikat konten lintas id
      seenId[id] = 1; if (fp !== '|||') seenFp[fp] = 1;
      out.push(e);
    });
    out.sort(function (a, b) {
      var d = entryTs(b) - entryTs(a);
      if (d !== 0) return d;
      return String(b.id || '').localeCompare(String(a.id || '')); // tie-break deterministik
    });
    return out;
  }

  function seedFromStorage() {
    LS_STOCKIN_KEYS.forEach(function (key) {
      try {
        var raw = localStorage.getItem(key);
        if (!raw) return;
        var arr = JSON.parse(raw);
        if (Array.isArray(arr)) collectStockIn(arr);
      } catch (e) { /* skip korup */ }
    });
  }
  seedFromStorage();
  setInterval(seedFromStorage, 5000); // baca saja — tidak pernah menulis balik

  /* ---- Terapkan urutan stabil ke state React (bukan DOM teks) ---- */
  function fiberOf(el) {
    var k = Object.keys(el);
    for (var i = 0; i < k.length; i++) {
      if (k[i].indexOf('__reactFiber$') === 0 || k[i].indexOf('__reactInternalInstance$') === 0) return el[k[i]];
    }
    return null;
  }
  function applyToReact(list) {
    var rows = document.querySelectorAll('tr[data-row-key]');
    if (!rows.length) return false;
    var byKey = {};
    list.forEach(function (e) { byKey[String(e.id || e._id || '')] = e; });
    var applied = 0;
    for (var i = 0; i < rows.length; i++) {
      var el = rows[i], key = el.getAttribute('data-row-key'), f = fiberOf(el);
      if (!f || !byKey[key]) continue;
      var node = f, hops = 0;
      while (node && hops < 40) {
        var st = node.stateNode;
        if (st && typeof st.setState === 'function' && st.props &&
            (st.props.record === byKey[key] ||
             (Array.isArray(st.state && st.state.data) && st.state.data.indexOf(st.props.record) > -1))) {
          try { st.setState({ record: byKey[key] }); applied++; } catch (e) {}
          break;
        }
        node = node.return; hops++;
      }
    }
    return applied > 0;
  }

  /* ---- Deteksi baris tabel riwayat dari DOM: cari TH berisi "No PO" /
   * "Supplier", lalu ambil data-key React baris di bawahnya. Robust tanpa
   * tahu nama state minified (bundle Vite mengabuskannya). ---- */
  var lastRowsKey = '';
  function detectHistoryRows() {
    var ths = document.querySelectorAll('th');
    var tableWrap = null;
    for (var i = 0; i < ths.length; i++) {
      var txt = (ths[i].textContent || '').toUpperCase();
      if (txt.indexOf('NO PO') > -1 || txt.indexOf('SUPPLIER') > -1 || txt.indexOf('VENDOR') > -1) {
        tableWrap = ths[i].closest ? ths[i].closest('table') : null;
        if (tableWrap) break;
      }
    }
    if (!tableWrap) return [];
    var trs = tableWrap.querySelectorAll('tbody tr');
    var out = [];
    for (var j = 0; j < trs.length; j++) {
      var f = fiberOf(trs[j]);
      var node = f, hops = 0, rec = null;
      while (node && hops < 30) {
        var pr = node.memoizedProps || node.pendingProps;
        if (pr && typeof pr === 'object') {
          var cand = pr.record || pr.data || pr.item || pr.row;
          if (cand && typeof cand === 'object' && (cand.id || canda(cand))) { rec = cand; break; }
          if (Array.isArray(pr.children) && pr.children.length === 0 && cand) { rec = cand; break; }
        }
        node = node.return; hops++;
      }
      if (rec && (rec.id || rec.noPo || rec.kode)) out.push({ el: trs[j], rec: rec });
    }
    return out;
  }
  function canda(x) { return !!(x.noPo || x.nomor || (x.items && x.qty)); }

  function normalizeStockInCaches() {
    var raw = null;
    try { raw = localStorage.getItem(LS_STOCKIN_KEYS[0]); } catch (e) {}
    if (raw && raw !== lastSig) {
      lastSig = raw;
      try {
        var arr = JSON.parse(raw);
        if (Array.isArray(arr)) collectStockIn(arr);
      } catch (e) { /* korup */ }
    }
    var rows = detectHistoryRows();
    if (!rows.length) { applyToReact(sortedStockIn()); return; }
    // kunci stabil urutan saat ini -> bila tidak berubah, JANGAN sentuh apa pun
    var curKey = rows.map(function (r) { return String(r.rec.id || r.rec.noPo || ''); }).join('|');
    if (curKey === lastRowsKey) return;
    lastRowsKey = curKey;
    var order = {}, list = sortedStockIn();
    list.forEach(function (e, idx) { order[String(e.id || '')] = idx; });
    rows.sort(function (a, b) {
      var ka = order[String(a.rec.id || '')], kb = order[String(b.rec.id || '')];
      if (ka == null) ka = 1e9; if (kb == null) kb = 1e9;
      if (ka !== kb) return ka - kb;
      return String(a.rec.id || '').localeCompare(String(b.rec.id || ''));
    });
    var tbody = rows[0].el.parentNode;
    // Reorder DOM hanya bila urutan TAMPILAN memang tidak sesuai daftar
    // terurut. Ini mencegah "perang dua-penulis": React menulis ulang baris
    // dengan urutannya sendiri, patch hanya mengoreksi SEKALI ketika urutan
    // tampil benar-benar salah (mis. nomor 1 di bawah), lalu diam sampai
    // ada perubahan data nyata -> tidak ada osilasi naik-turun berulang.
    var domSeq = rows.map(function (r) { return String(r.rec.id || r.rec.noPo || ''); });
    var wantSeq = rows.slice().sort(function (a, b) {
      var ka = order[String(a.rec.id || '')], kb = order[String(b.rec.id || '')];
      if (ka == null) ka = 1e9; if (kb == null) kb = 1e9;
      if (ka !== kb) return ka - kb;
      return String(a.rec.id || '').localeCompare(String(b.rec.id || ''));
    }).map(function (r) { return String(r.rec.id || r.rec.noPo || ''); });
    if (domSeq.join('|') === wantSeq.join('|')) return; // sudah benar -> jangan sentuh
    rows.forEach(function (r) { tbody.appendChild(r.el); });
  }
  // Jalankan segera + interval ringan HANYA bila halaman riwayat sedang tampil
  normalizeStockInCaches();
  window.addEventListener('storage', function () { seedFromStorage(); normalizeStockInCaches(); });
  var siTimer = null;
  var siObs = new MutationObserver(function () {
    clearTimeout(siTimer);
    siTimer = setTimeout(normalizeStockInCaches, 800);
  });
  siObs.observe(document.body, { childList: true, subtree: true });

  console.info('[patch.js] aktif — sinkron stok ke MySQL + timeout laporan 20s + anti-dobel invoice & riwayat.');
})();
