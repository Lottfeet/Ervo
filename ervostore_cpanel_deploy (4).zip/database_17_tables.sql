-- ==============================================================
-- ERVO STORE POS - Database Dump Lengkap untuk phpMyAdmin / MySQL
-- Kompatibel: MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+
-- 17 Tabel Lengkap Siap Import di phpMyAdmin cPanel
-- ==============================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

-- --------------------------------------------------------------
-- 1. Table: backupCheckpoints
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `backupCheckpoints`;
CREATE TABLE `backupCheckpoints` (
  `id` VARCHAR(100) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `formattedDate` VARCHAR(50) DEFAULT '',
  `formattedTime` VARCHAR(50) DEFAULT '',
  `triggerType` VARCHAR(50) DEFAULT 'MANUAL',
  `label` VARCHAR(255) DEFAULT '',
  `operator` VARCHAR(100) DEFAULT 'Admin',
  `counts_json` LONGTEXT,
  `layers_json` LONGTEXT,
  `payload_json` LONGTEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 2. Table: businessTransactions
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `businessTransactions`;
CREATE TABLE `businessTransactions` (
  `id` VARCHAR(100) NOT NULL,
  `date` DATE NOT NULL,
  `businessUnit` VARCHAR(100) DEFAULT 'ERVO STORE',
  `type` VARCHAR(50) DEFAULT 'income',
  `category` VARCHAR(100) DEFAULT 'Penjualan Kasir',
  `amount` DECIMAL(15,2) DEFAULT 0.00,
  `description` TEXT,
  `paymentMethod` VARCHAR(50) DEFAULT 'Tunai',
  `referenceNo` VARCHAR(100) DEFAULT '',
  `status` VARCHAR(50) DEFAULT 'completed',
  `source` VARCHAR(50) DEFAULT 'api_sync',
  `sourceApp` VARCHAR(255) DEFAULT '',
  `createdAt` VARCHAR(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 3. Table: customers
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `nama` VARCHAR(150) NOT NULL,
  `kelas` VARCHAR(50) DEFAULT 'Reguler',
  `diskon` DECIMAL(5,2) DEFAULT 0.00,
  `telepon` VARCHAR(50) DEFAULT '',
  `alamat` TEXT,
  `catatan` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` (`nama`, `kelas`, `diskon`, `telepon`, `alamat`, `catatan`) VALUES
('Umum', 'Reguler', 0.00, '', '', 'Pelanggan umum tanpa data khusus'),
('Budi Santoso', 'Member VIP', 10.00, '081299887766', 'Jl. Ahmad Yani No. 45', 'Langganan Komunitas Digital'),
('Studio Desain Ervo', 'Agen Reseller', 15.00, '081344556677', 'Jl. Riau No. 12', 'Mitra Reseller Cetak');

-- --------------------------------------------------------------
-- 4. Table: deletedCustomers
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `deletedCustomers`;
CREATE TABLE `deletedCustomers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nama` VARCHAR(150) NOT NULL,
  `deleted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 5. Table: deletedExpenses
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `deletedExpenses`;
CREATE TABLE `deletedExpenses` (
  `id` VARCHAR(50) NOT NULL,
  `deleted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 6. Table: deletedInvoices
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `deletedInvoices`;
CREATE TABLE `deletedInvoices` (
  `invoice_no` VARCHAR(50) NOT NULL,
  `deleted_by` VARCHAR(100) DEFAULT 'Admin',
  `reason` TEXT,
  `deleted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 7. Table: deletedProducts
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `deletedProducts`;
CREATE TABLE `deletedProducts` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `kode_or_nama` VARCHAR(200) NOT NULL,
  `deleted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 8. Table: expenses
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` VARCHAR(50) NOT NULL,
  `tanggal` DATE NOT NULL,
  `kategori` VARCHAR(100) DEFAULT 'Beban Operasional',
  `keterangan` TEXT,
  `nominal` DECIMAL(15,2) DEFAULT 0.00,
  `pj` VARCHAR(100) DEFAULT 'Admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 9. Table: invoices
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `invoice_no` VARCHAR(50) NOT NULL,
  `date` DATE NOT NULL,
  `time` VARCHAR(20) DEFAULT '',
  `customer` VARCHAR(150) DEFAULT 'Umum',
  `cashier` VARCHAR(100) DEFAULT 'Admin',
  `pay_method` VARCHAR(50) DEFAULT 'Tunai',
  `subtotal` DECIMAL(15,2) DEFAULT 0.00,
  `disc_pct` DECIMAL(5,2) DEFAULT 0.00,
  `disc_amt` DECIMAL(15,2) DEFAULT 0.00,
  `tax_pct` DECIMAL(5,2) DEFAULT 0.00,
  `tax_amt` DECIMAL(15,2) DEFAULT 0.00,
  `nego_amt` DECIMAL(15,2) DEFAULT 0.00,
  `total` DECIMAL(15,2) DEFAULT 0.00,
  `dp` DECIMAL(15,2) DEFAULT 0.00,
  `sisa` DECIMAL(15,2) DEFAULT 0.00,
  `kembalian` DECIMAL(15,2) DEFAULT 0.00,
  `deadline` VARCHAR(50) DEFAULT '',
  `status` VARCHAR(50) DEFAULT 'LUNAS',
  `items_json` LONGTEXT,
  `histori_pelunasan_json` LONGTEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 10. Table: kasirUsers
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `kasirUsers`;
CREATE TABLE `kasirUsers` (
  `nama` VARCHAR(100) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'Kasir',
  `password` VARCHAR(100) DEFAULT 'ervo123',
  `aktif` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kasirUsers` (`nama`, `role`, `password`, `aktif`) VALUES
('Admin', 'Admin', 'ervo123', 1),
('Kasir 1', 'Kasir', 'ervo123', 1);

-- --------------------------------------------------------------
-- 11. Table: products
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `kode` VARCHAR(50) NOT NULL,
  `nama` VARCHAR(200) NOT NULL,
  `harga` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `kategori` VARCHAR(100) DEFAULT 'Umum',
  `stok` VARCHAR(50) DEFAULT '',
  `satuan` VARCHAR(50) DEFAULT 'pcs',
  `tipe_harga` VARCHAR(50) DEFAULT 'fix',
  `harga_jual_modal` DECIMAL(15,2) DEFAULT 0.00,
  `supplier` VARCHAR(150) DEFAULT '',
  `pricing_scheme_json` LONGTEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`kode`, `nama`, `harga`, `kategori`, `stok`, `satuan`, `tipe_harga`, `harga_jual_modal`, `supplier`, `pricing_scheme_json`) VALUES
('BHN01', 'Bahan Roll Flexi Banner 280g', 0.00, 'Bahan Baku', '3', 'roll', 'fix', 0.00, '', NULL),
('BHN02', 'Bahan Kertas Art Paper 230g A3+', 0.00, 'Bahan Baku', '8', 'pack', 'fix', 0.00, '', NULL),
('BHN03', 'Bahan Stiker Vinyl Glossy Roll', 0.00, 'Bahan Baku', '0', 'roll', 'fix', 0.00, '', NULL),
('BNR01', 'Cetak Banner / Spanduk 280g', 25000.00, 'Banner', '', 'm²', 'ukuran', 15000.00, '', NULL),
('BNR02', 'Cetak Banner Flexi High-Res 340g', 35000.00, 'Banner', '', 'm²', 'ukuran', 20000.00, '', NULL),
('BNR03', 'Cetak MMT Billboard 440g', 55000.00, 'Banner', '', 'm²', 'ukuran', 32000.00, '', NULL),
('SUB01', 'Cetak Sublime Jersey Printing', 85000.00, 'Sublime', '', 'pcs', 'fix', 50000.00, '', NULL),
('SUB02', 'Cetak Sublime Tote Bag Canvas', 45000.00, 'Sublime', '', 'pcs', 'fix', 25000.00, '', NULL),
('A3P01', 'Cetak A3+ Photo Paper 230g', 15000.00, 'Cetak A3+', '500', 'lembar', 'fix', 8000.00, '', NULL),
('A3P02', 'Cetak A3+ Art Paper 150g', 12000.00, 'Cetak A3+', '1000', 'lembar', 'fix', 6000.00, '', NULL),
('DTF01', 'Cetak DTF UV Lembaran (A3)', 25000.00, 'DTF UV', '', 'lembar', 'fix', 14000.00, '', NULL),
('DTF02', 'Cetak DTF UV Meteran (Roll)', 45000.00, 'DTF UV', '', 'meter', 'fix', 26000.00, '', NULL),
('STK01', 'Stiker Vinyl UV Outdoor (m²)', 120000.00, 'Stiker UV', '', 'm²', 'ukuran', 70000.00, '', NULL),
('STK02', 'Stiker Cromo A3+ (Print & Cut)', 18000.00, 'Stiker UV', '250', 'lembar', 'fix', 10000.00, '', NULL),
('STK03', 'Stiker Transparan A3+ UV', 22000.00, 'Stiker UV', '300', 'lembar', 'fix', 12000.00, '', NULL),
('ADD01', 'Finishing Laminasi Doff A3+', 8000.00, 'Finishing', '', 'lembar', 'fix', 4000.00, '', NULL),
('ADD02', 'Finishing Laminasi Glossy A3+', 8000.00, 'Finishing', '', 'lembar', 'fix', 4000.00, '', NULL),
('ADD03', 'Jasa Cutting Stiker KissCut', 5000.00, 'Finishing', '', 'lembar', 'fix', 2000.00, '', NULL);

-- --------------------------------------------------------------
-- 12. Table: settings
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `address` TEXT,
  `phone` VARCHAR(50),
  `footer` TEXT,
  `rekening` TEXT,
  `prefix_invoice` VARCHAR(20) DEFAULT 'INV-',
  `auto_logout_minutes` INT(11) DEFAULT 15,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `name`, `address`, `phone`, `footer`, `rekening`, `prefix_invoice`, `auto_logout_minutes`) VALUES
(1, 'ERVO PRINT', 'Jl. HOS Cokroaminoto No.17, Ciamis', '0812-2247-2007', 'Terima Kasih Atas Kunjungan Anda', '', 'INV-', 15);

-- --------------------------------------------------------------
-- 13. Table: stockIn
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `stockIn`;
CREATE TABLE `stockIn` (
  `id` VARCHAR(50) NOT NULL,
  `tanggal` DATE NOT NULL,
  `time` VARCHAR(20) DEFAULT '',
  `kode_produk` VARCHAR(50) DEFAULT '',
  `nama_produk` VARCHAR(200) NOT NULL,
  `jumlah` DECIMAL(15,2) DEFAULT 0.00,
  `satuan` VARCHAR(50) DEFAULT 'pcs',
  `harga_beli` DECIMAL(15,2) DEFAULT 0.00,
  `total_biaya` DECIMAL(15,2) DEFAULT 0.00,
  `supplier` VARCHAR(150) DEFAULT '',
  `no_po` VARCHAR(100) DEFAULT '',
  `gudang` VARCHAR(100) DEFAULT 'Gudang Utama',
  `catatan` TEXT,
  `cashier` VARCHAR(100) DEFAULT 'Admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 14. Table: stockOpname
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `stockOpname`;
CREATE TABLE `stockOpname` (
  `id` VARCHAR(50) NOT NULL,
  `tanggal` DATE NOT NULL,
  `jam` VARCHAR(20) DEFAULT '',
  `tanggal_selesai` VARCHAR(50) DEFAULT '',
  `jam_selesai` VARCHAR(50) DEFAULT '',
  `pj_kasir` VARCHAR(100) DEFAULT 'Admin',
  `authorized_by` VARCHAR(100) DEFAULT 'Supervisor',
  `catatan_umum` TEXT,
  `total_item_diperiksa` INT(11) DEFAULT 0,
  `total_item_selisih` INT(11) DEFAULT 0,
  `total_selisih_kurang_qty` DECIMAL(15,2) DEFAULT 0.00,
  `total_selisih_lebih_qty` DECIMAL(15,2) DEFAULT 0.00,
  `total_selisih_nominal_rp` DECIMAL(15,2) DEFAULT 0.00,
  `total_penjualan_interim_qty` DECIMAL(15,2) DEFAULT 0.00,
  `metode_penyesuaian` VARCHAR(50) DEFAULT 'DELTA',
  `status` VARCHAR(50) DEFAULT 'APPROVED',
  `items_json` LONGTEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 15. Table: vendors
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` VARCHAR(50) NOT NULL,
  `nama` VARCHAR(150) NOT NULL,
  `kategori` VARCHAR(100) DEFAULT 'Umum',
  `telepon` VARCHAR(50) DEFAULT '',
  `email` VARCHAR(100) DEFAULT '',
  `alamat` TEXT,
  `kontak_person` VARCHAR(100) DEFAULT '',
  `nomor_rekening` VARCHAR(100) DEFAULT '',
  `catatan` TEXT,
  `created_at` DATE,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `vendors` (`id`, `nama`, `kategori`, `telepon`, `email`, `alamat`, `kontak_person`, `nomor_rekening`, `catatan`, `created_at`) VALUES
('VND-001', 'Supplier Bahan Baku Utama', 'Bahan Baku', '081234567890', 'supplier@example.com', 'Kawasan Industri Ciamis', 'Bpk. Hendra', 'BCA 1234567890', 'Penyedia bahan roll flexi dan banner', '2026-01-01');

-- --------------------------------------------------------------
-- 16. Table: _invoice_restore_log
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `_invoice_restore_log`;
CREATE TABLE `_invoice_restore_log` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` VARCHAR(50) NOT NULL,
  `restored_by` VARCHAR(100) DEFAULT 'Admin',
  `checkpoint_id` VARCHAR(100) DEFAULT '',
  `notes` TEXT,
  `data_json` LONGTEXT,
  `restored_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------
-- 17. Table: _stockin_delete_log
-- --------------------------------------------------------------
DROP TABLE IF EXISTS `_stockin_delete_log`;
CREATE TABLE `_stockin_delete_log` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `stockin_id` VARCHAR(50) NOT NULL,
  `kode_produk` VARCHAR(50) DEFAULT '',
  `nama_produk` VARCHAR(200) DEFAULT '',
  `qty` DECIMAL(15,2) DEFAULT 0.00,
  `rollback_stock` TINYINT(1) DEFAULT 0,
  `deleted_by` VARCHAR(100) DEFAULT 'Admin',
  `notes` TEXT,
  `deleted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
-- ==============================================================
-- Akhir dari Dump Database (17 Tabel Siap Pakai di phpMyAdmin)
-- ==============================================================
