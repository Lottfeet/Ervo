<?php
/**
 * ==============================================================
 * ERVO STORE POS - Konfigurasi Database cPanel MySQL / MariaDB
 * ==============================================================
 * 
 * Silakan sesuaikan data koneksi di bawah ini dengan database cPanel Anda:
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'nama_database_anda');     // Ganti dengan nama database cPanel Anda
define('DB_USER', 'username_database_anda'); // Ganti dengan username user database cPanel Anda
define('DB_PASS', 'password_database_anda'); // Ganti dengan password database cPanel Anda
define('DB_PORT', '3306');

// Header CORS agar API dapat diakses dengan aman
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode([
        "success" => false,
        "message" => "Koneksi database MySQL gagal: " . $e->getMessage() . ". Pastikan DB_NAME, DB_USER, dan DB_PASS di config.php sudah sesuai dengan pengaturan MySQL Databases di cPanel Anda."
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
