<?php
declare(strict_types=1);

require_once __DIR__ . '/auth_helper.php';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$action = strtolower(trim((string) ($_GET['action'] ?? 'list')));
$pdo = rp_get_pdo();

// 1. Ambil riwayat Log Aktivitas (Admin melihat semua pengguna; Staff/Viewer melihat aktivitas sendiri)
if ($action === 'list' && $method === 'GET') {
    $auth = rp_require_auth($pdo);
    $limit = max(10, min(200, (int) ($_GET['limit'] ?? 100)));
    $filterAction = strtoupper(trim((string) ($_GET['filterAction'] ?? '')));

    $where = [];
    $params = [];

    if ($auth['role'] !== 'admin') {
        $where[] = 'user_id = :uid';
        $params[':uid'] = $auth['id'];
    }

    if ($filterAction !== '' && $filterAction !== 'ALL') {
        $where[] = 'action = :act';
        $params[':act'] = $filterAction;
    }

    $sql = 'SELECT id, user_id, username, display_name, role, action, summary, target_period, device_label, ip_address, created_at
            FROM rp_activity_logs';
    if (!empty($where)) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY id DESC LIMIT ' . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = array_map(static function (array $r): array {
        return [
            'id' => (int) $r['id'],
            'userId' => $r['user_id'] !== null ? (int) $r['user_id'] : null,
            'username' => (string) $r['username'],
            'displayName' => (string) $r['display_name'],
            'role' => (string) $r['role'],
            'action' => (string) $r['action'],
            'summary' => (string) $r['summary'],
            'targetPeriod' => $r['target_period'] !== null ? (string) $r['target_period'] : null,
            'deviceLabel' => $r['device_label'] !== null ? (string) $r['device_label'] : null,
            'ipAddress' => $r['ip_address'] !== null ? (string) $r['ip_address'] : null,
            'createdAt' => (string) $r['created_at'],
        ];
    }, $stmt->fetchAll());

    rp_json_response(['ok' => true, 'logs' => $logs, 'scope' => $auth['role'] === 'admin' ? 'all' : 'self']);
}

// 2. Catat event klien tertentu yang diizinkan (Cetak PDF, Ekspor CSV, Backup JSON)
if ($action === 'record' && $method === 'POST') {
    $auth = rp_require_auth($pdo);
    $body = rp_read_json_body(16384);
    $eventAction = strtoupper(trim((string) ($body['action'] ?? '')));
    $allowedClientEvents = ['PRINT_PDF', 'EXPORT_CSV', 'EXPORT_JSON', 'IMPORT_JSON'];

    if (!in_array($eventAction, $allowedClientEvents, true)) {
        rp_json_response(['ok' => false, 'error' => 'Jenis aktivitas tidak valid.'], 400);
    }

    $summary = trim((string) ($body['summary'] ?? $eventAction));
    $targetPeriod = isset($body['targetPeriod']) ? trim((string) $body['targetPeriod']) : null;
    $deviceLabel = isset($body['deviceLabel']) ? (string) $body['deviceLabel'] : null;

    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], $eventAction, $summary, $targetPeriod, $deviceLabel);
    rp_json_response(['ok' => true]);
}

// 3. Hapus satu catatan log aktivitas (khusus Admin)
if ($action === 'delete' && $method === 'POST') {
    rp_require_auth($pdo, ['admin']);
    $body = rp_read_json_body(4096);
    $logId = (int) ($body['id'] ?? 0);

    if ($logId <= 0) {
        rp_json_response(['ok' => false, 'error' => 'ID log aktivitas tidak valid.'], 400);
    }

    $stmt = $pdo->prepare('DELETE FROM rp_activity_logs WHERE id = :id');
    $stmt->execute([':id' => $logId]);
    if ($stmt->rowCount() === 0) {
        rp_json_response(['ok' => false, 'error' => 'Catatan log aktivitas tidak ditemukan.'], 404);
    }

    rp_json_response(['ok' => true]);
}

// 4. Bersihkan seluruh catatan log aktivitas (khusus Admin)
if ($action === 'clear' && $method === 'POST') {
    rp_require_auth($pdo, ['admin']);
    $stmt = $pdo->prepare('DELETE FROM rp_activity_logs');
    $stmt->execute();
    $deletedCount = $stmt->rowCount();

    rp_json_response(['ok' => true, 'deletedCount' => $deletedCount]);
}

rp_json_response(['ok' => false, 'error' => 'Endpoint tidak ditemukan.'], 404);
