<?php
declare(strict_types=1);

/**
 * Helper koneksi PDO MySQL dan respons JSON aman untuk cPanel (tanpa Node.js).
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function rp_json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function rp_read_json_body(int $maxBytes = 5242880): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    if (strlen($raw) > $maxBytes) {
        rp_json_response(['ok' => false, 'error' => 'Ukuran data melebihi batas maksimum.'], 413);
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        rp_json_response(['ok' => false, 'error' => 'Format JSON tidak valid.'], 400);
    }
    return $decoded;
}

function rp_load_config(): ?array
{
    $configPath = __DIR__ . '/config.php';
    if (!is_file($configPath)) {
        return null;
    }
    $cfg = require $configPath;
    if (!is_array($cfg) || empty($cfg['db_name']) || empty($cfg['db_user'])) {
        return null;
    }
    if (!empty($cfg['timezone'])) {
        @date_default_timezone_set((string) $cfg['timezone']);
    }
    return $cfg;
}

function rp_get_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $cfg = rp_load_config();
    if ($cfg === null) {
        rp_json_response([
            'ok' => false,
            'code' => 'DB_NOT_CONFIGURED',
            'backend' => 'php-mysql',
            'error' => 'File api/config.php belum dikonfigurasi. Salin api/config.example.php menjadi api/config.php lalu isi kredensial database cPanel Anda.',
        ], 503);
    }

    $host = (string) ($cfg['db_host'] ?? 'localhost');
    $port = (int) ($cfg['db_port'] ?? 3306);
    $dbname = (string) $cfg['db_name'];
    $charset = (string) ($cfg['db_charset'] ?? 'utf8mb4');
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $host, $port, $dbname, $charset);

    try {
        $pdo = new PDO($dsn, (string) $cfg['db_user'], (string) ($cfg['db_pass'] ?? ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Throwable $e) {
        rp_json_response([
            'ok' => false,
            'code' => 'DB_CONNECTION_FAILED',
            'backend' => 'php-mysql',
            'error' => 'Gagal terhubung ke database MySQL. Periksa kembali host, nama database, user, dan password di api/config.php.',
        ], 503);
    }

    return $pdo;
}

function rp_get_client_ip(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return substr((string) $ip, 0, 64);
}

function rp_parse_user_agent_short(string $ua): string
{
    if ($ua === '') {
        return 'Perangkat Web';
    }
    $browser = 'Browser';
    if (stripos($ua, 'Edg/') !== false) {
        $browser = 'Edge';
    } elseif (stripos($ua, 'OPR/') !== false || stripos($ua, 'Opera') !== false) {
        $browser = 'Opera';
    } elseif (stripos($ua, 'Chrome/') !== false) {
        $browser = 'Chrome';
    } elseif (stripos($ua, 'Firefox/') !== false) {
        $browser = 'Firefox';
    } elseif (stripos($ua, 'Safari/') !== false) {
        $browser = 'Safari';
    }

    $os = 'Desktop';
    if (stripos($ua, 'Android') !== false) {
        $os = 'Android';
    } elseif (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPad') !== false || stripos($ua, 'iPod') !== false) {
        $os = 'iOS';
    } elseif (stripos($ua, 'Windows') !== false) {
        $os = 'Windows';
    } elseif (stripos($ua, 'Mac OS X') !== false || stripos($ua, 'Macintosh') !== false) {
        $os = 'macOS';
    } elseif (stripos($ua, 'Linux') !== false) {
        $os = 'Linux';
    }

    return "{$browser} · {$os}";
}

function rp_get_device_label(?string $clientProvided = null): string
{
    if ($clientProvided !== null && trim($clientProvided) !== '') {
        return substr(trim($clientProvided), 0, 160);
    }
    $headerLabel = trim((string) ($_SERVER['HTTP_X_DEVICE_LABEL'] ?? ''));
    if ($headerLabel !== '') {
        return substr($headerLabel, 0, 160);
    }
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    return substr(rp_parse_user_agent_short($ua), 0, 160);
}
