<?php
declare(strict_types=1);

require_once __DIR__ . '/auth_helper.php';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$action = strtolower(trim((string) ($_GET['action'] ?? 'list')));
$pdo = rp_get_pdo();

// 1. Daftar semua periode laporan yang tersimpan di MySQL
if ($action === 'list' && $method === 'GET') {
    rp_require_auth($pdo);
    $stmt = $pdo->query(
        'SELECT id, report_key, branch_title, month_name, year, version, updated_by_name, updated_at
         FROM rp_reports
         ORDER BY year DESC, updated_at DESC'
    );
    $items = array_map(static function (array $r): array {
        return [
            'id' => (int) $r['id'],
            'reportKey' => (string) $r['report_key'],
            'branchTitle' => (string) $r['branch_title'],
            'monthName' => (string) $r['month_name'],
            'year' => (int) $r['year'],
            'version' => (int) $r['version'],
            'updatedByName' => $r['updated_by_name'] !== null ? (string) $r['updated_by_name'] : null,
            'updatedAt' => (string) $r['updated_at'],
        ];
    }, $stmt->fetchAll());

    rp_json_response(['ok' => true, 'reports' => $items]);
}

// 2. Ambil 1 laporan lengkap berdasarkan id atau report_key
if ($action === 'get' && $method === 'GET') {
    rp_require_auth($pdo);
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    $key = trim((string) ($_GET['key'] ?? ''));

    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM rp_reports WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
    } elseif ($key !== '') {
        $stmt = $pdo->prepare('SELECT * FROM rp_reports WHERE report_key = :k LIMIT 1');
        $stmt->execute([':k' => $key]);
    } else {
        $stmt = $pdo->query('SELECT * FROM rp_reports ORDER BY updated_at DESC LIMIT 1');
    }

    $row = $stmt->fetch();
    if (!$row) {
        rp_json_response(['ok' => true, 'report' => null]);
    }

    $payload = json_decode((string) $row['payload_json'], true);
    if (!is_array($payload)) {
        rp_json_response(['ok' => false, 'error' => 'Data laporan di database rusak.'], 500);
    }

    rp_json_response([
        'ok' => true,
        'report' => [
            'id' => (int) $row['id'],
            'reportKey' => (string) $row['report_key'],
            'branchTitle' => (string) $row['branch_title'],
            'monthName' => (string) $row['month_name'],
            'year' => (int) $row['year'],
            'version' => (int) $row['version'],
            'updatedByName' => $row['updated_by_name'] !== null ? (string) $row['updated_by_name'] : null,
            'updatedAt' => (string) $row['updated_at'],
            'data' => $payload,
        ],
    ]);
}

// 3. Simpan / sinkronkan laporan ke MySQL (Admin & Staff; optimistic locking untuk multi-device)
if ($action === 'save' && $method === 'POST') {
    $auth = rp_require_auth($pdo, ['admin', 'staff']);
    $body = rp_read_json_body();

    $reportId = isset($body['id']) ? (int) $body['id'] : 0;
    $data = $body['data'] ?? null;
    $expectedVersion = isset($body['expectedVersion']) ? (int) $body['expectedVersion'] : null;
    $forceOverwrite = !empty($body['forceOverwrite']);
    $changeSummary = trim((string) ($body['changeSummary'] ?? ''));

    if (!is_array($data) || !isset($data['config']) || !is_array($data['config'])) {
        rp_json_response(['ok' => false, 'error' => 'Struktur data laporan tidak valid.'], 400);
    }

    $cfg = $data['config'];
    $branchTitle = substr(trim((string) ($cfg['branchTitle'] ?? 'CABANG UTAMA')), 0, 150);
    $monthName = substr(trim((string) ($cfg['monthName'] ?? 'Oktober')), 0, 40);
    $year = max(2000, min(2100, (int) ($cfg['year'] ?? date('Y'))));
    $reportKey = trim((string) ($body['reportKey'] ?? ''));
    if ($reportKey === '') {
        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($monthName . '-' . $year));
        $reportKey = trim((string) $slug, '-') . '-' . substr(hash('crc32b', strtolower($branchTitle)), 0, 6);
    }
    $reportKey = substr($reportKey, 0, 100);
    $payloadJson = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($payloadJson === false) {
        rp_json_response(['ok' => false, 'error' => 'Gagal menyandikan data laporan.'], 400);
    }

    $periodLabel = "{$monthName} {$year} ({$branchTitle})";

    // Cek apakah update record existing
    $existing = null;
    if ($reportId > 0) {
        $stmt = $pdo->prepare('SELECT * FROM rp_reports WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $reportId]);
        $existing = $stmt->fetch();
    } elseif ($reportKey !== '') {
        $stmt = $pdo->prepare('SELECT * FROM rp_reports WHERE report_key = :k LIMIT 1');
        $stmt->execute([':k' => $reportKey]);
        $existing = $stmt->fetch();
    }

    if ($existing) {
        $serverVersion = (int) $existing['version'];
        if (!$forceOverwrite && $expectedVersion !== null && $expectedVersion !== $serverVersion) {
            rp_json_response([
                'ok' => false,
                'code' => 'VERSION_CONFLICT',
                'error' => 'Data telah diperbarui dari perangkat lain. Muat versi terbaru atau timpa perubahan.',
                'serverVersion' => $serverVersion,
                'updatedByName' => $existing['updated_by_name'],
                'updatedAt' => $existing['updated_at'],
            ], 409);
        }

        $nextVersion = $serverVersion + 1;
        $upd = $pdo->prepare(
            'UPDATE rp_reports
             SET branch_title = :b, month_name = :m, year = :y, payload_json = :p,
                 version = :v, updated_by = :uid, updated_by_name = :uname
             WHERE id = :id'
        );
        $upd->execute([
            ':b' => $branchTitle,
            ':m' => $monthName,
            ':y' => $year,
            ':p' => $payloadJson,
            ':v' => $nextVersion,
            ':uid' => $auth['id'],
            ':uname' => $auth['displayName'],
            ':id' => (int) $existing['id'],
        ]);

        $summary = $changeSummary !== '' ? $changeSummary : "Menyimpan pembaruan laporan (v{$nextVersion})";
        rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'SAVE_REPORT', $summary, $periodLabel);

        rp_json_response([
            'ok' => true,
            'id' => (int) $existing['id'],
            'reportKey' => (string) $existing['report_key'],
            'version' => $nextVersion,
            'updatedByName' => $auth['displayName'],
            'updatedAt' => date('Y-m-d H:i:s'),
        ]);
    }

    // Insert laporan periode baru
    $ins = $pdo->prepare(
        'INSERT INTO rp_reports (report_key, branch_title, month_name, year, payload_json, version, updated_by, updated_by_name)
         VALUES (:k, :b, :m, :y, :p, 1, :uid, :uname)'
    );
    $ins->execute([
        ':k' => $reportKey,
        ':b' => $branchTitle,
        ':m' => $monthName,
        ':y' => $year,
        ':p' => $payloadJson,
        ':uid' => $auth['id'],
        ':uname' => $auth['displayName'],
    ]);
    $newId = (int) $pdo->lastInsertId();

    $summary = $changeSummary !== '' ? $changeSummary : "Membuat periode laporan {$monthName} {$year}";
    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'CREATE_REPORT', $summary, $periodLabel);

    rp_json_response([
        'ok' => true,
        'id' => $newId,
        'reportKey' => $reportKey,
        'version' => 1,
        'updatedByName' => $auth['displayName'],
        'updatedAt' => date('Y-m-d H:i:s'),
    ], 201);
}

// 4. Hapus periode laporan (Admin only)
if ($action === 'delete' && $method === 'POST') {
    $auth = rp_require_auth($pdo, ['admin']);
    $body = rp_read_json_body();
    $id = (int) ($body['id'] ?? 0);
    if ($id <= 0) {
        rp_json_response(['ok' => false, 'error' => 'ID laporan tidak valid.'], 400);
    }

    $stmt = $pdo->prepare('SELECT id, month_name, year, branch_title FROM rp_reports WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $existing = $stmt->fetch();
    if (!$existing) {
        rp_json_response(['ok' => false, 'error' => 'Laporan tidak ditemukan.'], 404);
    }

    $pdo->prepare('DELETE FROM rp_reports WHERE id = :id')->execute([':id' => $id]);
    $periodLabel = "{$existing['month_name']} {$existing['year']} ({$existing['branch_title']})";
    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'DELETE_REPORT', "Menghapus periode laporan {$existing['month_name']} {$existing['year']}", $periodLabel);

    rp_json_response(['ok' => true]);
}

rp_json_response(['ok' => false, 'error' => 'Endpoint tidak ditemukan.'], 404);
