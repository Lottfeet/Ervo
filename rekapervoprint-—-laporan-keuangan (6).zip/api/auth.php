<?php
declare(strict_types=1);

require_once __DIR__ . '/auth_helper.php';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$action = strtolower(trim((string) ($_GET['action'] ?? 'status')));

if ($action === 'status' && $method === 'GET') {
    $cfg = rp_load_config();
    if ($cfg === null) {
        rp_json_response([
            'ok' => true,
            'backend' => 'php-mysql',
            'configured' => false,
            'needsSetup' => false,
            'message' => 'File api/config.php belum diisi.',
        ]);
    }

    try {
        $pdo = rp_get_pdo();
        $count = (int) $pdo->query('SELECT COUNT(*) FROM rp_users')->fetchColumn();
        rp_json_response([
            'ok' => true,
            'backend' => 'php-mysql',
            'configured' => true,
            'needsSetup' => $count === 0,
        ]);
    } catch (Throwable $e) {
        rp_json_response([
            'ok' => true,
            'backend' => 'php-mysql',
            'configured' => false,
            'needsSetup' => false,
            'message' => 'Tabel database belum ditemukan. Import database/schema.sql di phpMyAdmin.',
        ]);
    }
}

$pdo = rp_get_pdo();

// 1. Setup akun Admin pertama (hanya bisa sekali ketika tabel rp_users kosong)
if ($action === 'setup' && $method === 'POST') {
    $body = rp_read_json_body();
    $username = strtolower(trim((string) ($body['username'] ?? '')));
    $displayName = trim((string) ($body['displayName'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $deviceLabel = isset($body['deviceLabel']) ? (string) $body['deviceLabel'] : null;

    if (!preg_match('/^[a-z0-9._-]{3,40}$/', $username)) {
        rp_json_response(['ok' => false, 'error' => 'Username harus 3–40 karakter (huruf, angka, titik, atau garis bawah).'], 400);
    }
    if (mb_strlen($displayName) < 2 || mb_strlen($displayName) > 100) {
        rp_json_response(['ok' => false, 'error' => 'Nama lengkap harus 2–100 karakter.'], 400);
    }
    if (strlen($password) < 6) {
        rp_json_response(['ok' => false, 'error' => 'Password minimal 6 karakter.'], 400);
    }

    try {
        $pdo->beginTransaction();
        $count = (int) $pdo->query('SELECT COUNT(*) FROM rp_users FOR UPDATE')->fetchColumn();
        if ($count > 0) {
            $pdo->rollBack();
            rp_json_response(['ok' => false, 'error' => 'Akun admin sudah pernah dibuat. Silakan login.'], 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            'INSERT INTO rp_users (username, display_name, password_hash, role, is_active) VALUES (:u, :d, :p, :r, 1)'
        );
        $stmt->execute([
            ':u' => $username,
            ':d' => $displayName,
            ':p' => $hash,
            ':r' => 'admin',
        ]);
        $userId = (int) $pdo->lastInsertId();
        $pdo->commit();

        $token = rp_create_session($pdo, $userId, rp_get_device_label($deviceLabel));
        rp_log_activity($pdo, $userId, $username, $displayName, 'admin', 'SETUP_ADMIN', 'Membuat akun Administrator pertama', null, $deviceLabel);

        rp_json_response([
            'ok' => true,
            'token' => $token,
            'user' => [
                'id' => $userId,
                'username' => $username,
                'displayName' => $displayName,
                'role' => 'admin',
            ],
        ], 201);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        rp_json_response(['ok' => false, 'error' => 'Gagal membuat akun admin pertama.'], 500);
    }
}

// 2. Login Multi-User & Multi-Device
if ($action === 'login' && $method === 'POST') {
    $body = rp_read_json_body();
    $username = strtolower(trim((string) ($body['username'] ?? '')));
    $password = (string) ($body['password'] ?? '');
    $deviceLabel = isset($body['deviceLabel']) ? (string) $body['deviceLabel'] : null;

    if ($username === '' || $password === '') {
        rp_json_response(['ok' => false, 'error' => 'Username dan password wajib diisi.'], 400);
    }

    $stmt = $pdo->prepare(
        'SELECT id, username, display_name, password_hash, role, is_active FROM rp_users WHERE username = :u LIMIT 1'
    );
    $stmt->execute([':u' => $username]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($password, (string) $row['password_hash'])) {
        rp_log_activity($pdo, $row ? (int) $row['id'] : null, $username, $row ? (string) $row['display_name'] : $username, $row ? (string) $row['role'] : 'guest', 'LOGIN_FAILED', 'Percobaan login gagal (username atau password salah)', null, $deviceLabel);
        rp_json_response(['ok' => false, 'error' => 'Username atau password tidak sesuai.'], 401);
    }

    if ((int) $row['is_active'] !== 1) {
        rp_log_activity($pdo, (int) $row['id'], (string) $row['username'], (string) $row['display_name'], (string) $row['role'], 'LOGIN_FAILED', 'Percobaan login pada akun nonaktif', null, $deviceLabel);
        rp_json_response(['ok' => false, 'error' => 'Akun Anda sedang dinonaktifkan oleh Administrator.'], 403);
    }

    $userId = (int) $row['id'];
    $token = rp_create_session($pdo, $userId, rp_get_device_label($deviceLabel));
    rp_log_activity($pdo, $userId, (string) $row['username'], (string) $row['display_name'], (string) $row['role'], 'LOGIN', 'Masuk ke aplikasi', null, $deviceLabel);

    rp_json_response([
        'ok' => true,
        'token' => $token,
        'user' => [
            'id' => $userId,
            'username' => (string) $row['username'],
            'displayName' => (string) $row['display_name'],
            'role' => (string) $row['role'],
        ],
    ]);
}

// 3. Logout
if ($action === 'logout' && $method === 'POST') {
    $auth = rp_require_auth($pdo);
    $stmt = $pdo->prepare('DELETE FROM rp_sessions WHERE token_hash = :hash');
    $stmt->execute([':hash' => $auth['tokenHash']]);
    rp_clear_session_cookie();
    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'LOGOUT', 'Keluar dari aplikasi');
    rp_json_response(['ok' => true]);
}

// 4. Profil sesi aktif (pemulihan sesi saat reload)
if ($action === 'me' && $method === 'GET') {
    $auth = rp_get_optional_auth($pdo);
    if ($auth === null) {
        rp_json_response([
            'ok' => true,
            'authenticated' => false,
            'user' => null,
        ]);
    }
    rp_json_response([
        'ok' => true,
        'authenticated' => true,
        'user' => [
            'id' => $auth['id'],
            'username' => $auth['username'],
            'displayName' => $auth['displayName'],
            'role' => $auth['role'],
        ],
    ]);
}

// 5. Ubah password sendiri
if ($action === 'change_password' && $method === 'POST') {
    $auth = rp_require_auth($pdo);
    $body = rp_read_json_body();
    $currentPassword = (string) ($body['currentPassword'] ?? '');
    $newPassword = (string) ($body['newPassword'] ?? '');

    if (strlen($newPassword) < 6) {
        rp_json_response(['ok' => false, 'error' => 'Password baru minimal 6 karakter.'], 400);
    }

    $stmt = $pdo->prepare('SELECT password_hash FROM rp_users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $auth['id']]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($currentPassword, (string) $row['password_hash'])) {
        rp_json_response(['ok' => false, 'error' => 'Password saat ini tidak sesuai.'], 400);
    }

    $upd = $pdo->prepare('UPDATE rp_users SET password_hash = :p WHERE id = :id');
    $upd->execute([
        ':p' => password_hash($newPassword, PASSWORD_DEFAULT),
        ':id' => $auth['id'],
    ]);

    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'CHANGE_PASSWORD', 'Mengubah password akun sendiri');
    rp_json_response(['ok' => true]);
}

// 6. Daftar pengguna (Admin only)
if ($action === 'users' && $method === 'GET') {
    rp_require_auth($pdo, ['admin']);
    $stmt = $pdo->query(
        'SELECT id, username, display_name, role, is_active, created_at FROM rp_users ORDER BY id ASC'
    );
    $users = array_map(static function (array $u): array {
        return [
            'id' => (int) $u['id'],
            'username' => (string) $u['username'],
            'displayName' => (string) $u['display_name'],
            'role' => (string) $u['role'],
            'isActive' => (int) $u['is_active'] === 1,
            'createdAt' => (string) $u['created_at'],
        ];
    }, $stmt->fetchAll());

    rp_json_response(['ok' => true, 'users' => $users]);
}

// 7. Tambah pengguna baru (Admin only)
if ($action === 'create_user' && $method === 'POST') {
    $auth = rp_require_auth($pdo, ['admin']);
    $body = rp_read_json_body();
    $username = strtolower(trim((string) ($body['username'] ?? '')));
    $displayName = trim((string) ($body['displayName'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $role = strtolower(trim((string) ($body['role'] ?? 'staff')));

    if (!preg_match('/^[a-z0-9._-]{3,40}$/', $username)) {
        rp_json_response(['ok' => false, 'error' => 'Username harus 3–40 karakter (huruf, angka, titik, atau garis bawah).'], 400);
    }
    if (mb_strlen($displayName) < 2 || mb_strlen($displayName) > 100) {
        rp_json_response(['ok' => false, 'error' => 'Nama lengkap harus 2–100 karakter.'], 400);
    }
    if (strlen($password) < 6) {
        rp_json_response(['ok' => false, 'error' => 'Password minimal 6 karakter.'], 400);
    }
    if (!in_array($role, ['admin', 'staff', 'viewer'], true)) {
        rp_json_response(['ok' => false, 'error' => 'Peran pengguna tidak valid.'], 400);
    }

    $check = $pdo->prepare('SELECT id FROM rp_users WHERE username = :u LIMIT 1');
    $check->execute([':u' => $username]);
    if ($check->fetch()) {
        rp_json_response(['ok' => false, 'error' => 'Username sudah digunakan.'], 409);
    }

    $stmt = $pdo->prepare(
        'INSERT INTO rp_users (username, display_name, password_hash, role, is_active) VALUES (:u, :d, :p, :r, 1)'
    );
    $stmt->execute([
        ':u' => $username,
        ':d' => $displayName,
        ':p' => password_hash($password, PASSWORD_DEFAULT),
        ':r' => $role,
    ]);
    $newId = (int) $pdo->lastInsertId();

    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'CREATE_USER', "Menambah akun {$username} ({$role})");

    rp_json_response([
        'ok' => true,
        'user' => [
            'id' => $newId,
            'username' => $username,
            'displayName' => $displayName,
            'role' => $role,
            'isActive' => true,
        ],
    ], 201);
}

// 8. Perbarui pengguna (Admin only)
if ($action === 'update_user' && $method === 'POST') {
    $auth = rp_require_auth($pdo, ['admin']);
    $body = rp_read_json_body();
    $targetId = (int) ($body['id'] ?? 0);
    if ($targetId <= 0) {
        rp_json_response(['ok' => false, 'error' => 'ID pengguna tidak valid.'], 400);
    }

    $stmt = $pdo->prepare('SELECT id, username, display_name, role, is_active FROM rp_users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $targetId]);
    $existing = $stmt->fetch();
    if (!$existing) {
        rp_json_response(['ok' => false, 'error' => 'Pengguna tidak ditemukan.'], 404);
    }

    $nextDisplayName = isset($body['displayName']) ? trim((string) $body['displayName']) : (string) $existing['display_name'];
    $nextRole = isset($body['role']) ? strtolower(trim((string) $body['role'])) : (string) $existing['role'];
    $nextActive = isset($body['isActive']) ? ((bool) $body['isActive'] ? 1 : 0) : (int) $existing['is_active'];
    $newPassword = isset($body['newPassword']) ? (string) $body['newPassword'] : '';

    if (!in_array($nextRole, ['admin', 'staff', 'viewer'], true)) {
        rp_json_response(['ok' => false, 'error' => 'Peran pengguna tidak valid.'], 400);
    }
    if ($newPassword !== '' && strlen($newPassword) < 6) {
        rp_json_response(['ok' => false, 'error' => 'Password baru minimal 6 karakter.'], 400);
    }

    // Cegah menonaktifkan atau menurunkan role admin terakhir
    if ((string) $existing['role'] === 'admin' && ($nextRole !== 'admin' || $nextActive !== 1)) {
        $activeAdmins = (int) $pdo->query("SELECT COUNT(*) FROM rp_users WHERE role = 'admin' AND is_active = 1")->fetchColumn();
        if ($activeAdmins <= 1) {
            rp_json_response(['ok' => false, 'error' => 'Minimal harus ada 1 akun Admin yang aktif.'], 400);
        }
    }

    if ($newPassword !== '') {
        $upd = $pdo->prepare(
            'UPDATE rp_users SET display_name = :d, role = :r, is_active = :a, password_hash = :p WHERE id = :id'
        );
        $upd->execute([
            ':d' => $nextDisplayName,
            ':r' => $nextRole,
            ':a' => $nextActive,
            ':p' => password_hash($newPassword, PASSWORD_DEFAULT),
            ':id' => $targetId,
        ]);
    } else {
        $upd = $pdo->prepare(
            'UPDATE rp_users SET display_name = :d, role = :r, is_active = :a WHERE id = :id'
        );
        $upd->execute([
            ':d' => $nextDisplayName,
            ':r' => $nextRole,
            ':a' => $nextActive,
            ':id' => $targetId,
        ]);
    }

    if ($nextActive === 0) {
        $pdo->prepare('DELETE FROM rp_sessions WHERE user_id = :id')->execute([':id' => $targetId]);
    }

    $note = "Memperbarui akun {$existing['username']} (role: {$nextRole}, status: " . ($nextActive === 1 ? 'aktif' : 'nonaktif') . ($newPassword !== '' ? ', reset password' : '') . ')';
    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'UPDATE_USER', $note);

    rp_json_response(['ok' => true]);
}

// 9. Hapus pengguna (Admin only)
if ($action === 'delete_user' && $method === 'POST') {
    $auth = rp_require_auth($pdo, ['admin']);
    $body = rp_read_json_body();
    $targetId = (int) ($body['id'] ?? 0);

    if ($targetId <= 0) {
        rp_json_response(['ok' => false, 'error' => 'ID pengguna tidak valid.'], 400);
    }
    if ($targetId === $auth['id']) {
        rp_json_response(['ok' => false, 'error' => 'Anda tidak dapat menghapus akun sendiri yang sedang dipakai.'], 400);
    }

    $stmt = $pdo->prepare('SELECT id, username, role FROM rp_users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $targetId]);
    $existing = $stmt->fetch();
    if (!$existing) {
        rp_json_response(['ok' => false, 'error' => 'Pengguna tidak ditemukan.'], 404);
    }

    if ((string) $existing['role'] === 'admin') {
        $activeAdmins = (int) $pdo->query("SELECT COUNT(*) FROM rp_users WHERE role = 'admin' AND is_active = 1")->fetchColumn();
        if ($activeAdmins <= 1) {
            rp_json_response(['ok' => false, 'error' => 'Minimal harus ada 1 akun Admin yang aktif.'], 400);
        }
    }

    $pdo->prepare('DELETE FROM rp_users WHERE id = :id')->execute([':id' => $targetId]);
    rp_log_activity($pdo, $auth['id'], $auth['username'], $auth['displayName'], $auth['role'], 'DELETE_USER', "Menghapus akun {$existing['username']}");

    rp_json_response(['ok' => true]);
}

rp_json_response(['ok' => false, 'error' => 'Endpoint tidak ditemukan.'], 404);
