<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

/**
 * Helper autentikasi Bearer Token & Cookie HttpOnly (hash SHA-256 di database),
 * proteksi CSRF, RBAC, dan pencatatan Log Aktivitas.
 */

const RP_SESSION_COOKIE = 'rp_session';

function rp_is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
        return true;
    }
    $forwardedProto = strtolower(trim(explode(',', (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0]));
    if ($forwardedProto === 'https') {
        return true;
    }
    if (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '')) === 'on') {
        return true;
    }
    return false;
}

function rp_set_session_cookie(string $rawToken, int $ttlSeconds): void
{
    $maxAge = max(60, $ttlSeconds);
    $expires = gmdate('D, d M Y H:i:s \G\M\T', time() + $maxAge);
    $parts = [
        RP_SESSION_COOKIE . '=' . rawurlencode($rawToken),
        'Path=/',
        'Max-Age=' . $maxAge,
        'Expires=' . $expires,
        'HttpOnly',
    ];
    if (rp_is_https()) {
        $parts[] = 'Secure';
        $parts[] = 'SameSite=None';
        $parts[] = 'Partitioned';
    } else {
        $parts[] = 'SameSite=Strict';
    }
    header('Set-Cookie: ' . implode('; ', $parts), false);
}

function rp_clear_session_cookie(): void
{
    $parts = [
        RP_SESSION_COOKIE . '=',
        'Path=/',
        'Max-Age=0',
        'Expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'HttpOnly',
    ];
    if (rp_is_https()) {
        $parts[] = 'Secure';
        $parts[] = 'SameSite=None';
        $parts[] = 'Partitioned';
    } else {
        $parts[] = 'SameSite=Strict';
    }
    header('Set-Cookie: ' . implode('; ', $parts), false);
}

function rp_normalize_host(string $host): string
{
    $h = strtolower(trim($host));
    $h = preg_replace('/:80$|:443$/', '', $h) ?? $h;
    return $h;
}

function rp_verify_cookie_csrf(): bool
{
    $xrw = trim((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''));
    if (strcasecmp($xrw, 'XMLHttpRequest') !== 0) {
        return false;
    }

    $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin !== '') {
        if (strtolower($origin) === 'null') {
            return false;
        }
        $parsed = parse_url($origin);
        if (!is_array($parsed) || empty($parsed['host'])) {
            return false;
        }
        $originHost = (string) $parsed['host'];
        if (!empty($parsed['port'])) {
            $originHost .= ':' . (int) $parsed['port'];
        }

        $forwardedHost = trim(explode(',', (string) ($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''))[0]);
        $serverHost = $forwardedHost !== '' ? $forwardedHost : trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($serverHost === '' || rp_normalize_host($originHost) !== rp_normalize_host($serverHost)) {
            return false;
        }
    }

    return true;
}

function rp_extract_bearer_token(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? '';

    if ($header === '' && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        if (is_array($headers)) {
            foreach ($headers as $key => $val) {
                if (strtolower((string) $key) === 'authorization') {
                    $header = (string) $val;
                    break;
                }
            }
        }
    }

    if (preg_match('/^\s*Bearer\s+([A-Za-z0-9\-_]{32,128})\s*$/i', $header, $m)) {
        return $m[1];
    }
    return null;
}

/**
 * Mengambil token sesi dari header Authorization Bearer (prioritas) atau cookie HttpOnly.
 *
 * @return array{token: ?string, source: ?string}
 */
function rp_extract_session_token(): array
{
    $bearer = rp_extract_bearer_token();
    if ($bearer !== null) {
        return ['token' => $bearer, 'source' => 'bearer'];
    }

    $cookieVal = isset($_COOKIE[RP_SESSION_COOKIE]) ? trim((string) $_COOKIE[RP_SESSION_COOKIE]) : '';
    if ($cookieVal !== '' && preg_match('/^[A-Za-z0-9\-_]{32,128}$/', $cookieVal)) {
        return ['token' => $cookieVal, 'source' => 'cookie'];
    }

    return ['token' => null, 'source' => null];
}

function rp_create_session(PDO $pdo, int $userId, string $deviceLabel): string
{
    $cfg = rp_load_config();
    $ttlHours = max(1, (int) ($cfg['session_ttl_hours'] ?? 168));
    $rawToken = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $expiresAt = date('Y-m-d H:i:s', time() + ($ttlHours * 3600));

    // Bersihkan sesi kedaluwarsa secara berkala
    $pdo->prepare('DELETE FROM rp_sessions WHERE expires_at < NOW()')->execute();

    $stmt = $pdo->prepare(
        'INSERT INTO rp_sessions (user_id, token_hash, device_label, expires_at) VALUES (:uid, :hash, :dev, :exp)'
    );
    $stmt->execute([
        ':uid' => $userId,
        ':hash' => $tokenHash,
        ':dev' => substr($deviceLabel, 0, 160),
        ':exp' => $expiresAt,
    ]);

    rp_set_session_cookie($rawToken, $ttlHours * 3600);

    return $rawToken;
}

function rp_get_optional_auth(PDO $pdo): ?array
{
    $extracted = rp_extract_session_token();
    $token = $extracted['token'];
    $source = $extracted['source'];
    if ($token === null) {
        return null;
    }

    $tokenHash = hash('sha256', $token);
    $stmt = $pdo->prepare(
        'SELECT u.id, u.username, u.display_name, u.role, u.is_active, s.id AS session_id
         FROM rp_sessions s
         INNER JOIN rp_users u ON u.id = s.user_id
         WHERE s.token_hash = :hash AND s.expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([':hash' => $tokenHash]);
    $user = $stmt->fetch();

    if (!$user || (int) $user['is_active'] !== 1) {
        if ($source === 'cookie') {
            rp_clear_session_cookie();
        }
        return null;
    }

    return [
        'id' => (int) $user['id'],
        'username' => (string) $user['username'],
        'displayName' => (string) $user['display_name'],
        'role' => (string) $user['role'],
        'sessionId' => (int) $user['session_id'],
        'tokenHash' => $tokenHash,
        'source' => $source,
    ];
}

function rp_require_auth(PDO $pdo, array $allowedRoles = []): array
{
    $extracted = rp_extract_session_token();
    $token = $extracted['token'];
    $source = $extracted['source'];
    if ($token === null) {
        rp_json_response(['ok' => false, 'error' => 'Sesi login diperlukan. Silakan masuk terlebih dahulu.'], 401);
    }

    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($source === 'cookie' && in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        if (!rp_verify_cookie_csrf()) {
            rp_json_response(['ok' => false, 'error' => 'Permintaan ditolak (validasi asal permintaan gagal).'], 403);
        }
    }

    $tokenHash = hash('sha256', $token);
    $stmt = $pdo->prepare(
        'SELECT u.id, u.username, u.display_name, u.role, u.is_active, s.id AS session_id
         FROM rp_sessions s
         INNER JOIN rp_users u ON u.id = s.user_id
         WHERE s.token_hash = :hash AND s.expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([':hash' => $tokenHash]);
    $user = $stmt->fetch();

    if (!$user || (int) $user['is_active'] !== 1) {
        if ($source === 'cookie') {
            rp_clear_session_cookie();
        }
        rp_json_response(['ok' => false, 'error' => 'Sesi tidak valid atau akun dinonaktifkan.'], 401);
    }

    if (!empty($allowedRoles) && !in_array($user['role'], $allowedRoles, true)) {
        rp_json_response(['ok' => false, 'error' => 'Anda tidak memiliki izin untuk tindakan ini.'], 403);
    }

    return [
        'id' => (int) $user['id'],
        'username' => (string) $user['username'],
        'displayName' => (string) $user['display_name'],
        'role' => (string) $user['role'],
        'sessionId' => (int) $user['session_id'],
        'tokenHash' => $tokenHash,
        'source' => $source,
    ];
}

function rp_log_activity(
    PDO $pdo,
    ?int $userId,
    string $username,
    string $displayName,
    string $role,
    string $action,
    string $summary,
    ?string $targetPeriod = null,
    ?string $deviceLabel = null
): void {
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO rp_activity_logs
             (user_id, username, display_name, role, action, summary, target_period, device_label, ip_address)
             VALUES (:uid, :uname, :dname, :role, :act, :sum, :period, :dev, :ip)'
        );
        $stmt->execute([
            ':uid' => $userId,
            ':uname' => substr($username, 0, 60),
            ':dname' => substr($displayName, 0, 120),
            ':role' => substr($role, 0, 20),
            ':act' => substr($action, 0, 50),
            ':sum' => substr($summary, 0, 255),
            ':period' => $targetPeriod !== null ? substr($targetPeriod, 0, 100) : null,
            ':dev' => rp_get_device_label($deviceLabel),
            ':ip' => rp_get_client_ip(),
        ]);
    } catch (Throwable $e) {
        // Jangan gagalkan transaksi utama jika tabel log belum termigrasi
    }
}
