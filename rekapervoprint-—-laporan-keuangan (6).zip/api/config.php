<?php
/**
 * Konfigurasi Database MySQL untuk cPanel (phpMyAdmin)
 * ---------------------------------------------------
 * LANGKAH PENTING:
 * 1. Salin (Copy) file ini menjadi: api/config.php
 * 2. Isi DB_NAME, DB_USER, dan DB_PASS sesuai database MySQL yang Anda buat di cPanel.
 * 3. Jangan pernah membagikan file api/config.php ke publik.
 */

return [
   'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'hump6894_ervorekap', // contoh: cpaneluser_rekapprint
    'db_user' => 'hump6894_ervorekap', // contoh: cpaneluser_rpadmin
    'db_pass' => '10203040@rekap', // password user MySQL cPanel Anda
    'db_charset' => 'utf8mb4',
    'timezone' => 'Asia/Jakarta',
    'session_ttl_hours' => 168, // 7 hari sesi aktif per perangkat
];
