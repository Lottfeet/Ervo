-- ============================================================================
-- RekapPrint Multi-User & Multi-Device Database Schema
-- Kompatibel dengan MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.2+ (cPanel phpMyAdmin)
-- ============================================================================
-- Cara import di cPanel:
-- 1. Buka cPanel -> MySQL Databases -> buat database baru & user database,
--    lalu hubungkan user ke database dengan ALL PRIVILEGES.
-- 2. Buka phpMyAdmin -> pilih database yang baru dibuat -> tab "Import".
-- 3. Pilih file schema.sql ini lalu klik "Go" / "Import".
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Tabel Pengguna (Multi-User & Role Access)
CREATE TABLE IF NOT EXISTS `rp_users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `display_name` VARCHAR(120) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'staff', 'viewer') NOT NULL DEFAULT 'staff',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rp_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Tabel Sesi Login (Multi-Device Token Auth, disimpan dalam bentuk hash SHA-256)
CREATE TABLE IF NOT EXISTS `rp_sessions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_label` VARCHAR(160) DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rp_sessions_token_hash` (`token_hash`),
  KEY `idx_rp_sessions_user_id` (`user_id`),
  KEY `idx_rp_sessions_expires_at` (`expires_at`),
  CONSTRAINT `fk_rp_sessions_user`
    FOREIGN KEY (`user_id`) REFERENCES `rp_users` (`id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Tabel Laporan Bulanan (Sinkron Multi-Device dengan Optimistic Versioning)
CREATE TABLE IF NOT EXISTS `rp_reports` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `report_key` VARCHAR(100) NOT NULL,
  `branch_title` VARCHAR(150) NOT NULL,
  `month_name` VARCHAR(40) NOT NULL,
  `year` SMALLINT UNSIGNED NOT NULL,
  `payload_json` LONGTEXT NOT NULL,
  `version` INT UNSIGNED NOT NULL DEFAULT 1,
  `updated_by` INT UNSIGNED DEFAULT NULL,
  `updated_by_name` VARCHAR(120) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rp_reports_key` (`report_key`),
  KEY `idx_rp_reports_period` (`year`, `month_name`),
  CONSTRAINT `fk_rp_reports_updated_by`
    FOREIGN KEY (`updated_by`) REFERENCES `rp_users` (`id`)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Tabel Log Aktivitas (Audit Trail Multi-User & Multi-Device)
CREATE TABLE IF NOT EXISTS `rp_activity_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `username` VARCHAR(60) NOT NULL,
  `display_name` VARCHAR(120) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'staff',
  `action` VARCHAR(50) NOT NULL,
  `summary` VARCHAR(255) NOT NULL,
  `target_period` VARCHAR(100) DEFAULT NULL,
  `device_label` VARCHAR(160) DEFAULT NULL,
  `ip_address` VARCHAR(64) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rp_logs_created_at` (`created_at`),
  KEY `idx_rp_logs_user_id` (`user_id`),
  KEY `idx_rp_logs_action` (`action`),
  CONSTRAINT `fk_rp_logs_user`
    FOREIGN KEY (`user_id`) REFERENCES `rp_users` (`id`)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
