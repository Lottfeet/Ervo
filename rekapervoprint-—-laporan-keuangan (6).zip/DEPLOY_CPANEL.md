# Panduan Deploy RekapPrint di cPanel (Tanpa Node.js + phpMyAdmin)

Aplikasi RekapPrint sudah dikonfigurasi agar berjalan penuh di shared hosting cPanel standar (**Apache + PHP 7.4/8.x + MySQL/MariaDB via phpMyAdmin**) tanpa memerlukan Node.js di server.

## 1. Build Aplikasi (Sekali di Komputer / AI Studio)
Jalankan perintah berikut untuk menghasilkan folder `dist/`:
```bash
npm run build
```
Semua file web statis, API PHP (`api/*.php`), aturan Apache (`.htaccess`), dan skema SQL (`database/schema.sql`) sudah otomatis terkumpul di dalam folder `dist/`.

## 2. Buat Database MySQL di cPanel & Import via phpMyAdmin
1. Masuk ke **cPanel -> MySQL Databases**.
2. Buat **Database** baru (mis. `usercpanel_rekapprint`).
3. Buat **MySQL User** baru beserta password yang kuat.
4. Di bagian **Add User To Database**, hubungkan user tersebut ke database dengan mencentang **ALL PRIVILEGES**.
5. Buka **cPanel -> phpMyAdmin**, pilih database yang baru dibuat, klik tab **Import**, lalu unggah file `database/schema.sql` dan klik **Import / Go**.

## 3. Upload File ke cPanel (`public_html`)
1. Kompres seluruh isi folder `dist/` menjadi file `.zip` (pastikan file `.htaccess` ikut terkompres).
2. Buka **cPanel -> File Manager -> `public_html`** (atau subfolder seperti `public_html/rekapprint`).
3. Upload file `.zip` lalu klik **Extract**.

## 4. Konfigurasi Koneksi Database (`api/config.php`)
1. Di File Manager, buka folder `api/`.
2. Salin (Copy) `config.example.php` menjadi `config.php`.
3. Edit `api/config.php` lalu isi `db_name`, `db_user`, dan `db_pass` sesuai database cPanel yang dibuat pada Langkah 2.
4. File `api/config.php` otomatis dilindungi oleh `api/.htaccess` agar tidak dapat dibuka langsung dari browser.

## 5. Buka Aplikasi & Buat Akun Admin Pertama
1. Buka URL domain Anda di browser (mis. `https://domainanda.com` atau `https://domainanda.com/rekapprint`).
2. Pada kunjungan pertama (saat tabel `rp_users` masih kosong), aplikasi akan menampilkan halaman **Buat Akun Admin Pertama**.
3. Setelah Admin dibuat, gunakan menu **Pengguna & Hosting** untuk menambahkan akun **Staff** atau **Viewer** bagi perangkat dan pengguna lain.
