-- =====================================================================
-- repair.sql — Perbaikan sekali jalan struktur database Ervo POS (MySQL).
--
-- CARA PAKAI (bila tombol migrasi menampilkan kode SCHEMA_REPAIR_REQUIRED):
--   1. Buka cPanel -> phpMyAdmin, pilih database Anda (mis. hump6894_ervpos).
--   2. Klik tab "SQL", salin-tempel SELURUH isi file ini, klik Go/Kirim.
--   3. Kembali ke aplikasi, tekan tombol migrasi 1-klik lagi.
--
-- File ini juga dipakai oleh api/db.php sebagai acuan skema kanonik:
--   id VARCHAR(191) PK | data LONGTEXT | rev BIGINT | updated_at TIMESTAMP
-- =====================================================================

SET SESSION sql_mode = '';

CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(191) NOT NULL PRIMARY KEY,
  data LONGTEXT NULL,
  rev BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers LIKE products;
CREATE TABLE IF NOT EXISTS kasirUsers LIKE products;
CREATE TABLE IF NOT EXISTS settings LIKE products;
CREATE TABLE IF NOT EXISTS invoices LIKE products;
CREATE TABLE IF NOT EXISTS expenses LIKE products;
CREATE TABLE IF NOT EXISTS stockIn LIKE products;
CREATE TABLE IF NOT EXISTS stockOpname LIKE products;
CREATE TABLE IF NOT EXISTS vendors LIKE products;
CREATE TABLE IF NOT EXISTS deletedProducts LIKE products;
CREATE TABLE IF NOT EXISTS deletedCustomers LIKE products;
CREATE TABLE IF NOT EXISTS deletedInvoices LIKE products;
CREATE TABLE IF NOT EXISTS deletedExpenses LIKE products;
CREATE TABLE IF NOT EXISTS backupCheckpoints LIKE products;
CREATE TABLE IF NOT EXISTS businessTransactions LIKE products;

-- ---------------------------------------------------------------------
-- Upgrade tabel lama yang sudah ada namun berstruktur berbeda
-- (rename kolom doc_id/json/revision dst., tambah kolom rev/updated_at,
--  naikkan TEXT -> LONGTEXT, perbaiki primary key). Jalankan bagian ini
-- di phpMyAdmin tab SQL bila db.php menolak dengan SCHEMA_REPAIR_REQUIRED.
-- ---------------------------------------------------------------------
-- Contoh untuk tabel `products` versi schema.sql lama:
--
-- ALTER TABLE products CHANGE doc_id id VARCHAR(191) NOT NULL;
-- ALTER TABLE products CHANGE json   data LONGTEXT NULL;
-- ALTER TABLE products ADD COLUMN rev BIGINT NOT NULL DEFAULT 0;
-- ALTER TABLE products ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
-- ALTER TABLE products DROP PRIMARY KEY, ADD PRIMARY KEY (id);
--
-- Ulangi pola yang sama untuk tabel lain yang bermasalah, atau cukup
-- HAPUS tabel kosong/tua tersebut lalu biarkan API membuatnya ulang:
--   DROP TABLE IF EXISTS products;  -- hanya bila isinya boleh hilang!
