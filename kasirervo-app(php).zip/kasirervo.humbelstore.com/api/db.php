<?php
/**
 * db.php — Backend MySQL API untuk Ervo Store Kasir (cPanel).
 *
 * Frontend (assets/index-*.js) memanggil file INI, bukan api/index.php.
 * Endpoint yang didukung:
 *   GET  api/db.php?c=<collection>&since=<rev>      -> daftar dokumen + rev server
 *   GET  api/db.php?c=<collection>&id=<docId>       -> satu dokumen
 *   GET  api/db.php?action=list&collection=<col>    -> daftar dokumen (format {docs:[...]})
 *   POST api/db.php  body {action:"put", collection, id, data}        -> upsert (merge)
 *   POST api/db.php  body {action:"delete", collection, id}           -> hapus dokumen
 *                    (khusus invoices: otomatis mengembalikan stok barang — atomik)
 *   POST api/db.php  body {action:"batch", operations:[{op,collection,id,data}]}
 *   POST api/db.php  body {action:"cleanup"}                          -> beres-beres (no-op aman)
 *
 * Setiap koleksi disimpan pada satu tabel MySQL:
 *   id VARCHAR(191) PRIMARY KEY, data LONGTEXT (JSON dokumen), rev BIGINT.
 * Tabel dibuat otomatis saat pertama kali dipakai, sehingga import schema.sql
 * tidak wajib lagi.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

// ---------- CORS ----------
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
if ($origin !== '') {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Max-Age: 86400');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------- Helper respon ----------
function out($arr)
{
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ---------- Koneksi DB ----------
$config = require __DIR__ . '/config.php';

try {
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['host'],
        $config['port'],
        $config['database'],
        $config['charset']
    );
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    // Jangan bocorkan kredensial ke klien
    error_log('[ervo-db] Koneksi DB gagal: ' . $e->getMessage());
    out([
        'success' => false,
        'code'    => 'DB_CONNECTION_FAILED',
        'message' => 'Koneksi database gagal. Periksa api/config.php & pastikan database sudah dibuat di cPanel.',
    ]);
}

// ---------- Whitelist koleksi ----------
$ALLOWED_COLLECTIONS = [
    'products',
    'customers',
    'kasirUsers',
    'settings',
    'invoices',
    'expenses',
    'stockIn',
    'stockOpname',
    'vendors',
    'deletedProducts',
    'deletedCustomers',
    'deletedInvoices',
    'deletedExpenses',
    'backupCheckpoints',
    'businessTransactions',
    // Tambahan: dipakai fitur "Koreksi Stok" (patch.js) & mirror GAS action
    // 'deleteInvoice' yang dikirim frontend saat invoice dihapus.
    'stockAdjustments',
];

function checkCollection($col, $allowed)
{
    if (!in_array($col, $allowed, true)) {
        out(['success' => false, 'message' => 'Koleksi tidak dikenal: ' . $col]);
    }
    return '`' . $col . '`';
}


/** Nama tabel polos (tanpa backtick). */
function tableName($table)
{
    return trim($table, '`');
}

/** Cek cepat tanpa DDL (untuk jalur baca & di dalam transaksi). */
function tableExists(PDO $pdo, $name)
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS c FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->execute([$name]);
    $row = $stmt->fetch();
    return $row && (int)$row['c'] > 0;
}

/** Daftar kolom sebuah tabel (lowercase). Hasil di-cache per-request. */
function columnInfo(PDO $pdo, $name)
{
    static $cache = [];
    $key = strtolower($name);
    if (isset($cache[$key])) return $cache[$key];
    $stmt = $pdo->prepare(
        "SELECT COLUMN_NAME AS c, DATA_TYPE AS t FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->execute([$name]);
    $cols = [];
    foreach ($stmt->fetchAll() as $r) {
        $cols[strtolower($r['c'])] = strtolower($r['t']);
    }
    return $cache[$key] = $cols;
}

/**
 * Peta kolom kanonik (id/data/rev/updated_at) -> nama kolom aktual di tabel.
 * Menangani tabel legacy dari schema.sql lama yang memakai nama berbeda
 * (doc_id/document_id/key -> id ; json/data/payload/content/doc -> data ;
 *  revision/version/_rev -> rev ; updated_at/modified_at -> updated_at).
 */
function colMap(PDO $pdo, $table)
{
    static $maps = [];
    $name = tableName($table);
    if (isset($maps[$name])) return $maps[$name];
    $cols = columnInfo($pdo, $name);
    $pick = function (array $candidates) use ($cols) {
        foreach ($candidates as $c) {
            if (isset($cols[$c])) return $cols[$c] === $c ? $c : '`' . $c . '`';
        }
        return null;
    };
    $map = [
        'id'         => $pick(['id', 'doc_id', 'document_id', 'key', 'kode']),
        'data'       => $pick(['data', 'json', 'payload', 'content', 'doc', 'value']),
        'rev'        => $pick(['rev', 'revision', 'version', '_rev']),
        'updated_at' => $pick(['updated_at', 'modified_at', 'updatedAt']),
    ];
    return $maps[$name] = $map;
}

/** Apakah tabel butuh perbaikan struktur (kolom tidak pas / tanpa PK)? */
function tableNeedsRepair(PDO $pdo, $table)
{
    $cols = columnInfo($pdo, tableName($table));
    if (!$cols) return false;
    $m = colMap($pdo, $table);
    if (!$m['id'] || !$m['data']) return true;
    if (!isset($cols['id'])) return true;                      // PK harus tetap bernama id
    if ($m['data'] !== 'data') return true;                    // query API memakai nama `data`
    if ($m['id'] !== 'id') return true;                        // query API memakai nama `id`
    if (!$m['rev'] || !isset($cols['rev'])) return true;       // kolom rev wajib persis
    if (in_array($cols[$m['data']], ['text', 'mediumtext', 'tinytext'], true)) return true; // kapasitas kecil
    if (!$m['updated_at']) return true;
    try {
        $pk = $pdo->query("SHOW KEYS FROM {$table} WHERE Key_name = 'PRIMARY'")->fetchAll();
        if (count($pk) !== 1 || strtolower($pk[0]['Column_name']) !== 'id') return true;
    } catch (Exception $e) {
        return true;
    }
    return false;
}

/**
 * Self-healing penuh untuk tabel legacy: rename kolom ke skema kanonik
 * (id/data/rev/updated_at), tambahkan kolom yang hilang, naikkan TEXT->LONGTEXT,
 * dan perbaiki primary key. Data lama TIDAK dibuang. Idempotent & di-cache.
 *
 * DDL memicu implicit commit sehingga fungsi ini TIDAK boleh dipanggil di
 * tengah transaksi — pemanggil wajib menyiapkan tabel sebelum beginTransaction().
 */
function migrateTable(PDO $pdo, $table)
{
    static $done = [];
    $name = tableName($table);
    if (isset($done[$name])) return;
    $cols = columnInfo($pdo, $name);
    if (!$cols) { $done[$name] = true; return; }

    // 1) Rename kolom legacy ke nama kanonik (hanya jika target belum dipakai).
    $renames = [
        'id'         => ['doc_id', 'document_id', 'key'],
        'data'       => ['json', 'payload', 'content', 'doc', 'value'],
        'rev'        => ['revision', 'version', '_rev'],
        'updated_at' => ['modified_at', 'updatedAt'],
    ];
    foreach ($renames as $target => $alts) {
        if (isset($cols[$target])) continue;
        foreach ($alts as $alt) {
            if (isset($cols[$alt])) {
                $type = $cols[$alt];
                $pdo->exec("ALTER TABLE {$table} CHANGE `{$alt}` `{$target}` " . sqlTypeOf($type));
                $cols[$target] = $type;
                unset($cols[$alt]);
                break;
            }
        }
    }

    // 2) Tambah kolom yang masih hilang.
    if (!isset($cols['id']))   $pdo->exec("ALTER TABLE {$table} ADD COLUMN id VARCHAR(191) NOT NULL FIRST");
    if (!isset($cols['data'])) $pdo->exec("ALTER TABLE {$table} ADD COLUMN data LONGTEXT NULL");
    if (!isset($cols['rev']))  $pdo->exec("ALTER TABLE {$table} ADD COLUMN rev BIGINT NOT NULL DEFAULT 0");
    if (!isset($cols['updated_at'])) $pdo->exec("ALTER TABLE {$table} ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

    // 3) Kapasitas kolom data harus LONGTEXT.
    if (in_array($cols['data'], ['text', 'mediumtext', 'tinytext'], true)) {
        $pdo->exec("ALTER TABLE {$table} MODIFY COLUMN data LONGTEXT NULL");
    }

    // 4) Primary key harus tunggal pada id.
    $fixPk = false;
    try {
        $pk = $pdo->query("SHOW KEYS FROM {$table} WHERE Key_name = 'PRIMARY'")->fetchAll();
        $fixPk = (count($pk) !== 1 || strtolower($pk[0]['Column_name']) !== 'id');
    } catch (Exception $e) {
        $fixPk = true;
    }
    if ($fixPk) {
        if ($pk) $pdo->exec("ALTER TABLE {$table} DROP PRIMARY KEY");
        $pdo->exec("ALTER TABLE {$table} MODIFY COLUMN id VARCHAR(191) NOT NULL");
        try {
            $pdo->exec("ALTER TABLE {$table} ADD PRIMARY KEY (id)");
        } catch (Exception $e) {
            error_log('[ervo-db] Gagal memasang PK pada ' . $name . ': ' . $e->getMessage());
        }
    }

    $done[$name] = true;
}

/** Tipe SQL sederhana utk hasil rename kolom berdasarkan DATA_TYPE information_schema. */
function sqlTypeOf($dataType)
{
    switch ($dataType) {
        case 'varchar':  return 'VARCHAR(191) NOT NULL';
        case 'char':     return 'CHAR(191) NOT NULL';
        case 'int': case 'bigint': case 'mediumint': case 'smallint': return 'BIGINT NOT NULL DEFAULT 0';
        case 'longtext': case 'mediumtext': case 'text': case 'tinytext': return 'LONGTEXT NULL';
        case 'timestamp': return 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP';
        default:         return 'LONGTEXT NULL';
    }
}

/** Baca dokumen mentah dari tabel (tanpa DDL). */
function readDocRaw(PDO $pdo, $table, $id)
{
    $stmt = $pdo->prepare("SELECT data FROM {$table} WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row || $row['data'] === null) return null;
    $d = json_decode($row['data'], true);
    return is_array($d) ? $d : null;
}

/** Lowercase aman walau ekstensi mbstring tidak terpasang di hosting. */
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($s) { return strtolower((string)$s); }
}

/**
 * Kembalikan stok barang yang terjual pada sebuah invoice (+qty tiap item).
 * Pencocokan produk SAMA PERSIS dengan frontend (fungsi WD/JD di bundle):
 *   - kunci produk = kode (trim, lowercase); id dokumen = kode
 *   - hanya produk kelolaStok !== false & stok numeric
 *   - stok baru = max(0, stok lama + total qty) — disimpan sebagai string
 * Mengembalikan jumlah produk yang stoknya berhasil dipulihkan.
 * WAJIB dipanggil di dalam transaksi & setelah tabel products dipastikan ada.
 */
function restoreInvoiceStock(PDO $pdo, array $invoice)
{
    $items = isset($invoice['items']) && is_array($invoice['items']) ? $invoice['items'] : [];
    if (!$items) return 0;

    // Gabungkan qty per kode (case-insensitive) — meniru Map kode->qty frontend.
    $perKey = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $kode = trim((string)(isset($it['kode']) ? $it['kode'] : ''));
        if ($kode === '') continue;
        $qty = 1;
        foreach (['qty', 'jumlah', 'quantity'] as $qf) {
            if (isset($it[$qf]) && is_numeric($it[$qf])) { $qty = (float)$it[$qf]; break; }
        }
        $k = mb_strtolower($kode);
        if (!isset($perKey[$k])) $perKey[$k] = 0.0;
        $perKey[$k] += $qty;
    }
    if (!$perKey) return 0;

    $restored = 0;
    $sel = $pdo->prepare("SELECT id, data, rev FROM products WHERE id = ? LIMIT 1 FOR UPDATE");
    foreach ($perKey as $k => $addQty) {
        $sel->execute([$k]);
        $r = $sel->fetch();
        if (!$r) continue;
        $p = json_decode($r['data'], true);
        if (!is_array($p)) continue;
        $kelola = isset($p['kelolaStok']) ? $p['kelolaStok'] : true;
        if ($kelola === false || $kelola === 'false') continue;
        if (!isset($p['stok']) || $p['stok'] === '' || $p['stok'] === null) continue;
        $cur = is_numeric($p['stok']) ? (float)str_replace(',', '.', (string)$p['stok']) : null;
        if ($cur === null) continue;
        $new = max(0, $cur + $addQty);
        // Format seperti frontend: String(number) — tanpa pemisah ribuan.
        $stokStr = rtrim(rtrim(number_format($new, 6, '.', ''), '0'), '.');
        if ($stokStr === '' || $stokStr === '-') $stokStr = '0';
        $p['stok'] = $stokStr;
        $p['updatedAt'] = date('c');
        $rev = (int)$r['rev'] + 1;
        $upd = $pdo->prepare("UPDATE products SET data = ?, rev = ? WHERE id = ?");
        $upd->execute([json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $rev, $r['id']]);
        $restored++;
    }
    return $restored;
}

/**
 * Hapus invoice + kembalikan stok secara atomik (satu transaksi MySQL).
 * Dipakai oleh action delete (collection=invoices) dan op delete pada batch.
 */
function deleteInvoiceWithStockRestore(PDO $pdo, $invTable, $prodTable, $id, $inTransaction = false)
{
    if (!$inTransaction) {
        $pdo->beginTransaction();
    }
    try {
        $inv = readDocRaw($pdo, $invTable, $id);
        $restored = 0;
        if ($inv !== null) {
            $restored = restoreInvoiceStock($pdo, $inv);
        }
        $pdo->prepare("DELETE FROM {$invTable} WHERE id = ?")->execute([$id]);
        if (!$inTransaction) $pdo->commit();
        return $restored;
    } catch (Exception $e) {
        if (!$inTransaction && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Pastikan tabel ada DAN kompatibel dengan API (kolom id/data/rev/updated_at + PK id).
 * Tabel lama hasil schema.sql otomatis di-upgrade tanpa membuang data.
 */
function ensureTable(PDO $pdo, $table)
{
    static $done = [];
    $name = tableName($table);
    if (isset($done[$name])) return;
    if (!tableExists($pdo, $name)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS {$table} (
            id VARCHAR(191) PRIMARY KEY,
            data LONGTEXT NULL,
            rev BIGINT NOT NULL DEFAULT 0,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } elseif (tableNeedsRepair($pdo, $table)) {
        try {
            migrateTable($pdo, $table);
        } catch (Exception $e) {
            error_log('[ervo-db] Self-healing tabel ' . $name . ' gagal: ' . $e->getMessage());
            out([
                'success' => false,
                'code'    => 'SCHEMA_REPAIR_REQUIRED',
                'message' => 'Struktur tabel `' . $name . '` tidak cocok & user MySQL tidak berhak memperbaikinya (perlu ALTER/CREATE). Buka phpMyAdmin > tab SQL, jalankan file api/repair.sql sekali, lalu ulangi migrasi. Detail: ' . $e->getMessage(),
            ]);
        }
    } else {
        $done[$name] = true;
    }
    $done[$name] = true;
}

/**
 * Pastikan tabel ada & kompatibel SEBELUM transaksi dimulai (jalur batch).
 * DDL di sini sengaja dilakukan di luar transaksi agar tidak memicu
 * implicit commit.
 */
function prepareTablesForBatch(PDO $pdo, array $tables)
{
    foreach ($tables as $t) {
        ensureTable($pdo, $t);
    }
}

/**
 * Jalur DALAM transaksi: hanya cek eksistensi (tabel sudah dipastikan oleh
 * prepareTablesForBatch sebelum beginTransaction). Tidak melakukan DDL.
 */
function ensureTableNoDdl(PDO $pdo, $table)
{
    $name = tableName($table);
    if (tableExists($pdo, $name)) return;
    throw new RuntimeException("Tabel {$name} belum tersedia saat transaksi berjalan.");
}

/**
 * Upsert merge (setara setDoc merge:true di Firestore).
 * Nilai null menghapus field. Rev naik tiap tulis agar sync `since` bekerja.
 * Parameter $inTransaction=true dipakai jalur batch (DDL dihindari).
 */
function putDoc(PDO $pdo, $table, $id, array $fields, $inTransaction = false)
{
    $inTransaction ? ensureTableNoDdl($pdo, $table) : ensureTable($pdo, $table);
    $stmt = $pdo->prepare("SELECT data, rev FROM {$table} WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    $old = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: []) : [];
    $rev = $row ? (int)$row['rev'] : 0;

    foreach ($fields as $k => $v) {
        if ($k === 'id') continue;
        if ($v === null) {
            unset($old[$k]);
        } else {
            $old[$k] = $v;
        }
    }
    $old['id'] = $id;
    $rev++;

    $json = json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $upd = $pdo->prepare("INSERT INTO {$table} (id, data, rev) VALUES (?, ?, ?)
                          ON DUPLICATE KEY UPDATE data = VALUES(data), rev = VALUES(rev)");
    $upd->execute([$id, $json, $rev]);
    return $rev;
}

function delDoc(PDO $pdo, $table, $id, $inTransaction = false)
{
    $inTransaction ? ensureTableNoDdl($pdo, $table) : ensureTable($pdo, $table);
    $stmt = $pdo->prepare("DELETE FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
}

function listDocs(PDO $pdo, $table, $since = 0)
{
    // Jalur baca: buat/upgrade tabel bila belum ada/belum kompatibel (masih di luar transaksi).
    if (!tableExists($pdo, tableName($table))) {
        ensureTable($pdo, $table);
    } elseif (tableNeedsRepair($pdo, $table)) {
        ensureTable($pdo, $table); // self-healing penuh
    }
    $rows = $pdo->query("SELECT id, data, rev FROM {$table}")->fetchAll();
    $maxRev = 0;
    $docs = [];
    foreach ($rows as $r) {
        if ((int)$r['rev'] > $maxRev) $maxRev = (int)$r['rev'];
        if ($since > 0 && (int)$r['rev'] <= $since) continue;
        $d = ($r['data'] !== null) ? (json_decode($r['data'], true) ?: []) : [];
        if (!is_array($d)) continue;
        if (!isset($d['id'])) $d['id'] = $r['id'];
        $docs[] = [
            'id'         => $r['id'],
            'data'       => $d,
            '_rev'       => (int)$r['rev'],
            '_createdAt' => isset($d['createdAt']) ? $d['createdAt'] : null,
            '_updatedAt' => isset($d['updatedAt']) ? $d['updatedAt'] : null,
        ];
    }
    return [$docs, $maxRev];
}

// ---------- Routing ----------
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    try {
        // format lama index.php: ?action=list&collection=X
        if (isset($_GET['action']) && $_GET['action'] === 'list') {
            $table = checkCollection(isset($_GET['collection']) ? $_GET['collection'] : '', $ALLOWED_COLLECTIONS);
            list($docs, $rev) = listDocs($pdo, $table);
            out(['success' => true, 'docs' => $docs, 'data' => $docs, 'rev' => $rev]);
        }

        // format frontend baru: ?c=<collection>[&id=..][&since=..]
        $col = isset($_GET['c']) ? $_GET['c'] : (isset($_GET['collection']) ? $_GET['collection'] : '');
        $table = checkCollection($col, $ALLOWED_COLLECTIONS);

        if (isset($_GET['id']) && $_GET['id'] !== '') {
            ensureTable($pdo, $table);
            $id = trim((string)$_GET['id']);
            $stmt = $pdo->prepare("SELECT data, rev FROM {$table} WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            $doc = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: null) : null;
            if (is_array($doc) && !isset($doc['id'])) $doc['id'] = $id;
            out(['success' => true, 'data' => $doc]);
        }

        $since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
        list($docs, $rev) = listDocs($pdo, $table, $since);
        out(['success' => true, 'data' => $docs, 'docs' => $docs, 'rev' => $rev]);
    } catch (Exception $e) {
        error_log('[ervo-db] GET gagal: ' . $e->getMessage());
        out(['success' => false, 'message' => 'Query database gagal: ' . $e->getMessage()]);
    }
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $body = json_decode((string)$raw, true);
    if (!is_array($body)) {
        out(['success' => false, 'message' => 'Body permintaan bukan JSON yang valid.']);
    }

    $action = isset($body['action']) ? $body['action'] : '';

    try {
        switch ($action) {
            case 'put': {
                $table = checkCollection(isset($body['collection']) ? $body['collection'] : '', $ALLOWED_COLLECTIONS);
                $id = trim((string)(isset($body['id']) ? $body['id'] : ''));
                if ($id === '' || strlen($id) > 191) {
                    out(['success' => false, 'message' => 'Parameter id tidak valid.']);
                }
                $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : [];
                $rev = putDoc($pdo, $table, $id, $data);
                out(['success' => true, 'data' => ['id' => $id, '_rev' => $rev]]);
            }

            case 'delete': {
                $table = checkCollection(isset($body['collection']) ? $body['collection'] : '', $ALLOWED_COLLECTIONS);
                $id = trim((string)(isset($body['id']) ? $body['id'] : ''));
                if ($id === '') {
                    out(['success' => false, 'message' => 'Parameter id tidak valid.']);
                }
                // KHUSUS invoices: hapus + kembalikan stok barang secara atomik.
                // Ini memperbaiki bug "barang tidak kembali ke stok saat invoice dihapus".
                if (tableName($table) === 'invoices') {
                    ensureTable($pdo, '`products`');
                    $invLower = mb_strtolower(trim($id));
                    // id boleh nomor invoice asli ATAU versi lowercase (key cache
                    // server frontend memakai id.toLowerCase()).
                    $restored = deleteInvoiceWithStockRestore($pdo, $table, '`products`', $id, false);
                    if ($restored === 0 && $invLower !== $id) {
                        $restored = deleteInvoiceWithStockRestore($pdo, $table, '`products`', $invLower, false);
                    }
                    // Bersihkan semua variasi id dokumen invoice di tabel.
                    $stmt = $pdo->prepare("DELETE FROM {$table} WHERE LOWER(id) = ?");
                    $stmt->execute([$invLower]);
                    delDoc($pdo, '`deletedInvoices`', $invLower); // sinkronkan tombstone
                    out(['success' => true, 'data' => ['id' => $id, 'stockRestored' => $restored]]);
                }
                delDoc($pdo, $table, $id);
                out(['success' => true, 'data' => ['id' => $id]]);
            }

            case 'batch': {
                $ops = isset($body['operations']) && is_array($body['operations'])
                     ? $body['operations']
                     : (isset($body['ops']) && is_array($body['ops']) ? $body['ops'] : []);

                // Validasi SEMUA op sebelum transaksi agar tidak ada tulis sebagian
                foreach ($ops as $i => $op) {
                    if (!is_array($op)) out(['success' => false, 'message' => "ops[$i] bukan objek."]);
                    $col = isset($op['collection']) ? $op['collection'] : '';
                    if (!in_array($col, $ALLOWED_COLLECTIONS, true)) {
                        out(['success' => false, 'message' => 'Koleksi tidak dikenal pada batch: ' . $col]);
                    }
                    $o = isset($op['op']) ? $op['op'] : 'put';
                    $idRaw = isset($op['id']) ? $op['id'] : '';
                    // id boleh berupa string, ATAU array daftar id (bulk delete).
                    $ids = is_array($idRaw) ? $idRaw : [trim((string)$idRaw)];
                    if (!$ids) $ids = [];
                    foreach ($ids as $oneId) {
                        $oneId = trim((string)$oneId);
                        if ($oneId === '' || strlen($oneId) > 191) {
                            out(['success' => false, 'message' => "ops[$i].id tidak valid."]);
                        }
                    }
                    if ($o !== 'delete' && count($ids) !== 1) {
                        out(['success' => false, 'message' => "ops[$i]: id array hanya untuk op delete."]);
                    }
                    if (!in_array($o, ['put', 'set', 'update', 'delete'], true)) {
                        out(['success' => false, 'message' => "ops[$i].op tidak valid: " . $o]);
                    }
                }

                // Pastikan semua tabel ada SEBELUM transaksi dimulai,
                // karena CREATE TABLE memicu implicit commit di MySQL/MariaDB.
                foreach ($ops as $op) {
                    ensureTable($pdo, '`' . $op['collection'] . '`');
                }
                // Jalur batch yang menghapus invoice juga butuh tabel products
                // (rollback stok dilakukan atomik di dalam transaksi).
                foreach ($ops as $op) {
                    if ((isset($op['op']) ? $op['op'] : 'put') === 'delete'
                        && $op['collection'] === 'invoices') {
                        ensureTable($pdo, '`products`');
                        break;
                    }
                }

                $pdo->beginTransaction();
                $written = 0;
                $restoredTotal = 0;
                foreach ($ops as $op) {
                    $table = '`' . $op['collection'] . '`';
                    $o = isset($op['op']) ? $op['op'] : 'put';
                    $idRaw = isset($op['id']) ? $op['id'] : '';
                    $ids = is_array($idRaw) ? $idRaw : [trim((string)$idRaw)];
                    if ($o === 'delete') {
                        foreach ($ids as $oneId) {
                            $oneId = trim((string)$oneId);
                            if ($oneId === '') continue;
                            if ($op['collection'] === 'invoices') {
                                // Hapus invoice + kembalikan stok (atomik, tanpa DDL)
                                $lower = mb_strtolower($oneId);
                                $inv = readDocRaw($pdo, $table, $oneId);
                                if ($inv === null && $lower !== $oneId) $inv = readDocRaw($pdo, $table, $lower);
                                if ($inv !== null) {
                                    $restoredTotal += restoreInvoiceStock($pdo, $inv);
                                    $delStmt = $pdo->prepare("DELETE FROM {$table} WHERE LOWER(id) = ?");
                                    $delStmt->execute([$lower]);
                                } else {
                                    delDoc($pdo, $table, $oneId, true);
                                }
                            } else {
                                delDoc($pdo, $table, $oneId, true);
                            }
                            $written++;
                        }
                    } else {
                        $data = isset($op['data']) && is_array($op['data']) ? $op['data'] : [];
                        putDoc($pdo, $table, trim((string)$idRaw), $data, true);
                        $written++;
                    }
                }
                $pdo->commit();
                out(['success' => true, 'written' => $written, 'stockRestored' => $restoredTotal,
                     'data' => ['written' => $written, 'stockRestored' => $restoredTotal]]);
            }

            case 'cleanup': {
                // Tombstone dikelola oleh aplikasi; tidak ada yang perlu dibersihkan di sini.
                out(['success' => true, 'removed' => 0]);
            }

            default:
                out(['success' => false, 'message' => 'Aksi tidak dikenal: ' . $action]);
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[ervo-db] POST gagal: ' . $e->getMessage());
        out(['success' => false, 'message' => 'Query database gagal: ' . $e->getMessage()]);
    }
}

out(['success' => false, 'message' => 'Metode tidak didukung.']);
