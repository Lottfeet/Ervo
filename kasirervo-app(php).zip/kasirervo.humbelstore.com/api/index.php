<?php
/**
 * index.php — REST API pengganti Firebase Firestore untuk Ervo Store Kasir.
 *
 * Endpoint ini dipanggil oleh frontend (src/services/db.ts) dengan pola:
 *   GET    api/index.php?collection=products                 -> semua dokumen (array)
 *   GET    api/index.php?collection=products&id=XXX          -> satu dokumen (objek / {})
 *   POST   api/index.php?collection=products&id=XXX  body=JSON(fields) -> upsert (merge)
 *   DELETE api/index.php?collection=products&id=XXX          -> hapus dokumen
 *   POST   api/index.php?batch=1  body={ops:[...]}           -> transaksi massal
 *   GET    api/index.php?action=ping                         -> cek kesehatan
 *
 * Setiap "koleksi" Firestore dipetakan ke satu tabel MySQL; seluruh isi dokumen
 * disimpan pada kolom `data` (JSON) plus kolom `id` (VARCHAR) agar struktur,
 * nama field, dan tampilan aplikasi TIDAK berubah sama sekali.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

// ---------- CORS (memungkinkan akses dari domain/subdomain sendiri) ----------
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
if ($origin !== '') {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Max-Age: 86400');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------- Helper respon ----------
function respond($success, $data = null, $message = '', $code = 200)
{
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'data'    => $data,
        'message' => $message,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail($message, $code = 400)
{
    respond(false, null, $message, $code);
}

// ---------- Koneksi DB ----------
$config = require __DIR__ . '/config.php';

try {
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['host'],
        $config['port'],
        $config['database'],
        $config['charset']
    );
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    // Jangan bocorkan kredensial ke klien
    error_log('[ervo-api] Koneksi DB gagal: ' . $e->getMessage());
    fail('Koneksi database gagal. Periksa konfigurasi api/config.php.', 500);
}

// ---------- Whitelist koleksi (tabel yang diizinkan) ----------
$ALLOWED_COLLECTIONS = [
    'products',
    'customers',
    'kasirUsers',
    'settings',
    'invoices',
    'expenses',
    'stockIn',
    'stockOpname',
    'vendors',
    'deletedProducts',
    'deletedCustomers',
    'deletedInvoices',
    'deletedExpenses',
    'backupCheckpoints',
    'businessTransactions',
];

function tableName($collection, $allowed)
{
    if (!in_array($collection, $allowed, true)) {
        fail('Koleksi tidak dikenal: ' . $collection, 400);
    }
    // Nama koleksi whitelist-only => aman dipakai langsung sebagai nama tabel
    return '`' . $collection . '`';
}

function normalizeId($id)
{
    $id = trim((string)$id);
    if ($id === '' || strlen($id) > 191) {
        fail('Parameter id tidak valid.', 400);
    }
    return $id;
}

function readJsonBody()
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        fail('Body permintaan bukan JSON yang valid.', 400);
    }
    return $decoded;
}

/**
 * Upsert merge: baca data lama, gabungkan key-level (setara setDoc merge:true),
 * lalu simpan kembali. Nilai NULL menghapus field (setara perilaku app saat
 * mengirim undefined/null pada sebagian besar jalur tulis aplikasi).
 */
function upsertDoc(PDO $pdo, $table, $id, array $fields)
{
    $stmt = $pdo->prepare("SELECT data FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    $old = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: []) : [];

    foreach ($fields as $k => $v) {
        if ($k === 'id') continue; // id tetap dari parameter
        if ($v === null) {
            unset($old[$k]);
        } else {
            $old[$k] = $v;
        }
    }
    $old['id'] = $id;

    $json = json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    // Kompatibel MySQL 5.7+/8+ dan MariaDB 10.2+ (tanpa CAST(... AS JSON))
    $upd = $pdo->prepare("INSERT INTO {$table} (id, data) VALUES (?, ?)
                          ON DUPLICATE KEY UPDATE data = VALUES(data)");
    $upd->execute([$id, $json]);
}

function deleteDocRow(PDO $pdo, $table, $id)
{
    $stmt = $pdo->prepare("DELETE FROM {$table} WHERE id = ?");
    $stmt->execute([$id]);
}

// ---------- Routing ----------
$method = $_SERVER['REQUEST_METHOD'];

// Ping / cek kesehatan
if (isset($_GET['action']) && $_GET['action'] === 'ping') {
    $pdo->query('SELECT 1');
    respond(true, ['pong' => time()], 'OK');
}

// Batch write (pengganti firebase writeBatch.commit())
if ($method === 'POST' && isset($_GET['batch'])) {
    $body = readJsonBody();
    $ops = isset($body['ops']) && is_array($body['ops']) ? $body['ops'] : [];

    // Validasi semua op SEBELUM transaksi agar tidak ada perubahan parsial
    foreach ($ops as $i => $op) {
        if (!is_array($op)) fail("ops[$i] bukan objek.", 400);
        $col = isset($op['collection']) ? $op['collection'] : '';
        if (!in_array($col, $ALLOWED_COLLECTIONS, true)) {
            fail('Koleksi tidak dikenal pada batch: ' . $col, 400);
        }
        normalizeId(isset($op['id']) ? $op['id'] : '');
        $o = isset($op['op']) ? $op['op'] : 'set';
        if (!in_array($o, ['set', 'update', 'delete'], true)) {
            fail("ops[$i].op tidak valid: " . $o, 400);
        }
    }

    try {
        $pdo->beginTransaction();
        foreach ($ops as $op) {
            $table = tableName($op['collection'], $ALLOWED_COLLECTIONS);
            $id = normalizeId($op['id']);
            $o = isset($op['op']) ? $op['op'] : 'set';
            if ($o === 'delete') {
                deleteDocRow($pdo, $table, $id);
            } else {
                $data = isset($op['data']) && is_array($op['data']) ? $op['data'] : [];
                upsertDoc($pdo, $table, $id, $data);
            }
        }
        $pdo->commit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[ervo-api] Batch gagal: ' . $e->getMessage());
        fail('Gagal menyimpan batch: ' . $e->getMessage(), 500);
    }
    respond(true, ['written' => count($ops)], 'OK');
}

$collection = isset($_GET['collection']) ? $_GET['collection'] : '';
if (!in_array($collection, $ALLOWED_COLLECTIONS, true)) {
    fail('Parameter collection wajib diisi & terdaftar.', 400);
}
$table = tableName($collection, $ALLOWED_COLLECTIONS);

try {
    if ($method === 'GET') {
        if (isset($_GET['id']) && $_GET['id'] !== '') {
            // Satu dokumen
            $id = normalizeId($_GET['id']);
            $stmt = $pdo->prepare("SELECT data FROM {$table} WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            $doc = ($row && $row['data'] !== null) ? (json_decode($row['data'], true) ?: []) : [];
            if (!isset($doc['id'])) $doc['id'] = $id;
            respond(true, $doc, 'OK');
        } else {
            // Seluruh koleksi
            $stmt = $pdo->query("SELECT data FROM {$table}");
            $out = [];
            while ($row = $stmt->fetch()) {
                if ($row['data'] === null) continue;
                $decoded = json_decode($row['data'], true);
                if (!is_array($decoded)) continue;
                if (!isset($decoded['id'])) {
                    // fallback: ambil id kolom bila hilang di JSON
                }
                $out[] = $decoded;
            }
            respond(true, $out, 'OK');
        }
    }

    if ($method === 'POST') {
        $id = normalizeId(isset($_GET['id']) ? $_GET['id'] : '');
        $fields = readJsonBody();
        upsertDoc($pdo, $table, $id, $fields);
        respond(true, ['id' => $id], 'OK');
    }

    if ($method === 'DELETE') {
        $id = normalizeId(isset($_GET['id']) ? $_GET['id'] : '');
        deleteDocRow($pdo, $table, $id);
        respond(true, ['id' => $id], 'OK');
    }

    fail('Metode tidak didukung.', 405);
} catch (PDOException $e) {
    error_log('[ervo-api] Query gagal: ' . $e->getMessage());
    fail('Query database gagal: periksa apakah schema.sql sudah di-import.', 500);
} catch (Exception $e) {
    error_log('[ervo-api] Error: ' . $e->getMessage());
    fail('Terjadi kesalahan pada server.', 500);
}
