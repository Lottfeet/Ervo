<?php
/**
 * config.php — Konfigurasi koneksi database MySQL (phpMyAdmin) untuk Ervo Store Kasir.
 *
 * CARA PAKAI DI CPANEL:
 * 1. Buka cPanel → "MySQL® Databases".
 * 2. Buat database baru, misal: username_ervodb
 * 3. Buat user MySQL baru, misal: username_ervo (pakai password yang kuat)
 * 4. Tambahkan user ke database dengan privilege "ALL PRIVILEGES".
 * 5. Import file database/schema.sql lewat phpMyAdmin (menu Import).
 * 6. Isi 4 nilai di bawah ini sesuai data pada langkah 2 & 3.
 */

return [
    'host'     => 'localhost',           // hampir selalu 'localhost' di cPanel
    'port'     => 3306,
    'database' => 'hump6894_ervpos',     // GANTI: nama database hasil langkah 2
    'username' => 'hump6894_ervoprint', // GANTI: nama user MySQL hasil langkah 3
    'password' => '10203040@ervo', // GANTI: password user MySQL langkah 3
    'charset'  => 'utf8mb4',
];
