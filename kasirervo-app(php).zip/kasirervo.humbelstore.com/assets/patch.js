/*!
 * patch.js — Ervo Store Kasir (tambal client-side, dimuat SETELAH bundle utama)
 *
 * 1) BUG STOK: Saat invoice dihapus / dikoreksi, aplikasi hanya mengembalikan
 *    stok di cache browser (localStorage) tanpa menulis hasilnya ke server MySQL,
 *    sehingga stok di database & perangkat lain tidak pernah pulih.
 *    -> Patch ini mengunci hasil koreksi stok lokal lalu MENULIS-nya balik ke
 *       server (PUT /api/db.php action=put collection=products), plus
 *       fallback "Koreksi Stok Manual" bila invoice tidak ditemukan di server.
 *
 * 2) LAPORAN LAMBAT: fetch ke /api/db.php tidak dibatasi waktunya; satu request
 *    yang menggantung (shared hosting sering begini) membuat halaman Laporan
 *    tampak loading terus. -> Patch memasang timeout 20 detik pada seluruh
 *    request db.php; kegagalan otomatis di-retry oleh engine sync bawaan.
 *
 * Cara pasang: tambahkan <script src="/assets/patch.js?v=fix25"></script>
 *               tepat SEBELUM </body> di index.html (sudah terpasang).
 */
(function () {
  'use strict';

  var API = '/api/db.php';
  var TIMEOUT_MS = 20000;

  /* ---------- util JSON ---------- */
  function jget(url) {
    return fetch(url, { headers: { 'Accept': 'application/json' } }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }
  function jpost(body) {
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  /* =========================================================
   * 2) Timeout untuk semua request db.php (laporan tak lagi
   *    menggantung selamanya). Membungkus window.fetch.
   * ========================================================= */
  var nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    var url = typeof input === 'string' ? input : ((input && input.url) || '');
    if (url.indexOf('/api/db.php') !== -1) {
      try {
        init = init || {};
        var prevSignal = init.signal;
        var ctrl = new AbortController();
        var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
        init.signal = ctrl.signal;
        if (prevSignal) {
          if (prevSignal.aborted) ctrl.abort();
          else prevSignal.addEventListener('abort', function () { ctrl.abort(); });
        }
        return nativeFetch(input, init).finally(function () { clearTimeout(timer); });
      } catch (e) { /* fallback: biarkan apa adanya */ }
    }
    return nativeFetch(input, init);
  };

  /* =========================================================
   * 1a) Kunci hasil koreksi stok lokal agar TIDAK hilang saat
   *     halaman reload, lalu tulis ke server.
   *     Mengbungkus localStorage.setItem — perubahan stok dari
   *     fungsi rollback internal aplikasi (WD()) tersimpan di key
   *     "strukku_products". Kita catat salinannya sebagai bukti
   *     (proof-of-restore) supaya bisa ditulis ulang ke MySQL.
   * ========================================================= */
  var LS_PRODUCTS = 'strukku_products';
  var LS_PROOF = 'ervo_stock_restore_proof_v1';
  function normKey(x) { return String(x == null ? '' : x).trim().toLowerCase(); }
  var nativeSetItem = localStorage.setItem.bind(localStorage);
  localStorage.setItem = function (key, value) {
    nativeSetItem(key, value);
    if (key === LS_PRODUCTS) {
      try {
        nativeSetItem(LS_PROOF, String(Date.now()));
        queueFlush();
      } catch (e) { /* quota penuh — abaikan */ }
    }
  };

  /* ---------- intersepsi penghapusan invoice (server-first) ----------
   * Bug lama: frontend memanggil WD() yang kadang gagal menemukan produk
   * (cache kosong / beda huruf besar), sehingga stok tidak pernah pulih
   * di database. Patch ini membaca dokumen invoice LANGSUNG dari MySQL,
   * menghitung +qty tiap item, dan menulis stok baru ke server SEBELUM
   * perintah hapus diteruskan. Jika server mengembalikan stockRestored>0
   * (rollback atomik db.php berhasil), penulisan ganda dihindari.
   */
  var pendingDelete = {}; // invoiceNo(lowercase) -> true
  function normInv(x){ return String(x==null?'':x).trim().toLowerCase(); }

  async function preRestoreInvoice(invId) {
    try {
      var resp = await jget(API + '?c=invoices&id=' + encodeURIComponent(invId));
      var doc = resp && resp.success ? resp.data : null;
      if (!doc || !Array.isArray(doc.items)) return false;
      var prodsResp = await jget(API + '?c=products&since=0');
      if (!prodsResp || !prodsResp.success || !Array.isArray(prodsResp.data)) return false;
      var byId = {};
      prodsResp.data.forEach(function(row){ byId[normKey(row.id)] = row; });
      var perKey = {};
      doc.items.forEach(function(it){
        if(!it || !it.kode) return;
        var k = normKey(it.kode); if(!k) return;
        var q = Number(it.qty!=null?it.qty:(it.jumlah!=null?it.jumlah:(it.quantity!=null?it.quantity:1)));
        if(isNaN(q)) q = 1;
        perKey[k] = (perKey[k]||0) + q;
      });
      var ops = [];
      Object.keys(perKey).forEach(function(k){
        var row = byId[k]; if(!row) return;
        var d = row.data || {};
        if(d.kelolaStok === false || d.kelolaStok === 'false') return;
        var cur = parseFloat(String(d.stok==null?'':d.stok));
        if(isNaN(cur)) return;
        var next = Math.max(0, cur + perKey[k]);
        ops.push({ op:'put', collection:'products', id: row.id,
                   data:{ stok:String(next), updatedAt:new Date().toISOString() } });
      });
      for (var b=0;b<ops.length;b+=100){
        var res = await jpost({action:'batch', operations: ops.slice(b,b+100)});
        if(!res || !res.success) throw new Error((res&&res.message)||'batch gagal');
      }
      if (ops.length) console.info('[patch] Pre-restore stok invoice', invId, ':', ops.length, 'produk.');
      return ops.length > 0;
    } catch(e) {
      console.warn('[patch] Pre-restore stok gagal (lanjut jalur normal):', e && e.message);
      return false;
    }
  }

  var nativeFetch2 = window.fetch; // sudah dibungkus timeout di atas
  window.fetch = function (input, init) {
    try {
      var url = typeof input === 'string' ? input : ((input && input.url) || '');
      if (url.indexOf('/api/db.php') !== -1 && init && String(init.method||'').toUpperCase()==='POST' && init.body) {
        var bodyObj = null;
        try { bodyObj = JSON.parse(init.body); } catch(e) {}
        if (bodyObj && bodyObj.action==='delete' && bodyObj.collection==='invoices' && bodyObj.id) {
          var invId = String(bodyObj.id);
          var keyP = normInv(invId);
          if (!pendingDelete[keyP]) {
            pendingDelete[keyP] = true;
            return preRestoreInvoice(invId).then(function(){
              delete pendingDelete[keyP];
              return nativeFetch2(input, init); // hapus asli (server juga rollback bila dokumen masih ada)
            }).catch(function(){
              delete pendingDelete[keyP];
              return nativeFetch2(input, init);
            });
          }
        }
        // batch berisi delete invoices -> pre-restore juga
        if (bodyObj && bodyObj.action==='batch' && Array.isArray(bodyObj.operations)) {
          var invDel = bodyObj.operations.filter(function(op){
            return op && op.collection==='invoices' && op.op==='delete';
          });
          if (invDel.length) {
            var chain = Promise.resolve();
            invDel.forEach(function(op){
              var ids = Array.isArray(op.id)?op.id:[op.id];
              ids.forEach(function(id){
                var kk = normInv(id);
                if(pendingDelete[kk]) return;
                pendingDelete[kk] = true;
                chain = chain.then(function(){ return preRestoreInvoice(id).catch(function(){}); })
                             .then(function(){ delete pendingDelete[kk]; });
              });
            });
            return chain.then(function(){ return nativeFetch2(input, init); });
          }
        }
      }
    } catch(e) { /* jangan ganggu request asli */ }
    return nativeFetch2(input, init);
  };

  /* ---------- baca daftar produk lokal ---------- */
  function parseMaybe(s) {
    if (typeof s !== 'string') return s;
    try {
      var v = JSON.parse(s);
      // beberapa versi app membungkus: {data:[...]} atau string ganda
      if (typeof v === 'string') { try { v = JSON.parse(v); } catch (e) {} }
      return v;
    } catch (e) { return null; }
  }
  function localProducts() {
    var raw = parseMaybe(localStorage.getItem(LS_PRODUCTS));
    if (Array.isArray(raw)) return raw;
    if (raw && Array.isArray(raw.data)) return raw.data;
    if (raw && Array.isArray(raw.barang)) return raw.barang;
    return [];
  }

  /* ---------- flush ke server (debounce, max 1x/2detik) ---------- */
  var flushTimer = null, flushing = false, dirty = false;
  function queueFlush() {
    if (flushTimer) return;
    flushTimer = setTimeout(function () { flushTimer = null; flushToServer(); }, 1500);
  }

  async function flushToServer() {
    if (flushing) { dirty = true; return; }
    flushing = true;
    try {
      do {
        dirty = false;
        var proofTs = parseInt(localStorage.getItem(LS_PROOF) || '0', 10);
        if (!proofTs) continue;
        var sentKey = 'ervo_stock_restore_sent_v1';
        if (parseInt(localStorage.getItem(sentKey) || '0', 10) >= proofTs) continue;

        var locals = localProducts();
        if (!locals.length) { nativeSetItem(sentKey, String(Date.now())); continue; }

        var resp = await jget(API + '?c=products&since=0');
        if (!resp || !resp.success || !Array.isArray(resp.data)) continue;

        var byId = {}, byKode = {};
        resp.data.forEach(function (row) {
          var d = row.data || {};
          var idk = normKey(row.id);
          byId[idk] = d;
          var kk = normKey(d.kode);
          if (kk && !byKode[kk]) byKode[kk] = d;
        });

        var ops = [], seen = {};
        for (var i = 0; i < locals.length; i++) {
          var p = locals[i];
          if (!p) continue;
          var kode = normKey(p.kode);
          if (!kode) continue;
          var kelola = p.kelolaStok;
          if (kelola === false || kelola === 'false') continue;
          if (p.stok === '' || p.stok == null || isNaN(parseFloat(String(p.stok)))) continue;

          var doc = byId[kode] || byKode[kode] || null;
          if (!doc) continue;                       // bukan produk known → lewati
          var idRow = byId[kode] ? kode : (byKode[kode] ? Object.keys(byId).filter(function (k) { return byId[k] === byKode[kode]; })[0] : null);
          if (!idRow || seen[idRow]) continue;
          seen[idRow] = true;

          var cur = parseFloat(String(doc.stok == null ? '0' : doc.stok));
          if (isNaN(cur)) cur = 0;
          var want = parseFloat(String(p.stok));
          if (Math.abs(cur - want) < 0.0001) continue; // sudah sama, tak perlu tulis

          ops.push({ op: 'put', collection: 'products', id: idRow, data: { stok: String(want), updatedAt: new Date().toISOString() } });
        }

        // kirim bertahap ≤100 operasi per request agar tidak kena limit host
        for (var b = 0; b < ops.length; b += 100) {
          var chunk = ops.slice(b, b + 100);
          var res = await jpost({ action: 'batch', operations: chunk });
          if (!res || !res.success) throw new Error((res && res.message) || 'batch gagal');
        }
        nativeSetItem(sentKey, String(Date.now()));
        if (ops.length) console.info('[patch] Stok tersinkron ke server:', ops.length, 'produk.');
      } while (dirty);
    } catch (e) {
      console.warn('[patch] Sinkron stok ke server gagal (akan dicoba lagi):', e && e.message);
      setTimeout(queueFlush, 8000); // retry periodik sampai berhasil
    } finally {
      flushing = false;
    }
  }

  // jalan ulang saat tab aktif kembali (mis. setelah edit offline)
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) queueFlush();
  });
  setInterval(queueFlush, 60000); // heartbeat 60 detik (cheap: only if proof baru)

  /* =========================================================
   * 1b) UI "Koreksi Stok Manual" — dipakai bila invoice sudah
   *     terlanjur terhapus / stok lama belum sempat tercatat,
   *     atau rollback otomatis tidak menemukan dokumennya.
   *     Menambah stok langsung ke MySQL (server-first).
   * ========================================================= */
  function ensureUI() {
    if (document.getElementById('ervo-stock-helper')) return;
    var btn = document.createElement('button');
    btn.id = 'ervo-stock-helper';
    btn.textContent = '🔧 Koreksi Stok';
    btn.title = 'Kembalikan stok ke database (mis. setelah invoice terhapus)';
    btn.style.cssText = 'position:fixed;right:14px;bottom:86px;z-index:9998;width:44px;height:44px;' +
      'border-radius:50%;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font-size:18px;' +
      'box-shadow:0 2px 10px rgba(0,0,0,.18);cursor:pointer;display:none';
    document.body.appendChild(btn);

    // tampilkan hanya di area transaksi/produk/laporan (cocokkan URL/hash umum)
    function toggle() {
      var h = (location.hash + location.pathname).toLowerCase();
      var show = /transaksi|riwayat|invoice|produk|barang|lapor/.test(h);
      btn.style.display = show ? 'block' : 'none';
    }
    toggle();
    window.addEventListener('hashchange', toggle);
    window.addEventListener('popstate', toggle);
    setInterval(toggle, 3000);

    btn.addEventListener('click', openDialog);
  }

  function openDialog() {
    if (document.getElementById('ervo-stock-dlg')) return;
    var dlg = document.createElement('div');
    dlg.id = 'ervo-stock-dlg';
    dlg.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.45);' +
      'display:flex;align-items:center;justify-content:center;padding:16px';
    dlg.innerHTML =
      '<div style="background:#fff;border-radius:14px;max-width:420px;width:100%;padding:20px;font-family:system-ui,sans-serif">' +
      '<h3 style="margin:0 0 4px;font-size:16px">Koreksi Stok Manual</h3>' +
      '<p style="margin:0 0 12px;font-size:12px;color:#64748b">Kembalikan qty ke database (dipakai bila stok tidak pulih setelah invoice dihapus).</p>' +
      '<label style="font-size:12px;display:block;margin-bottom:4px">Cari produk (kode / nama)</label>' +
      '<input id="ev-q" placeholder="cth: BRG-001 / stiker" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:8px">' +
      '<div id="ev-list" style="max-height:150px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:10px"></div>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">' +
      '<span style="font-size:12px">Δ qty (+masuk / −keluar)</span>' +
      '<input id="ev-qty" type="number" step="any" value="0" style="width:90px;padding:6px;border:1px solid #cbd5e1;border-radius:8px">' +
      '</div>' +
      '<div id="ev-msg" style="font-size:12px;color:#b91c1c;min-height:16px;margin-bottom:8px"></div>' +
      '<div style="display:flex;justify-content:flex-end;gap:8px">' +
      '<button id="ev-cancel" style="padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer">Batal</button>' +
      '<button id="ev-save" style="padding:8px 14px;border-radius:8px;border:0;background:#2563eb;color:#fff;cursor:pointer">Simpan ke Database</button>' +
      '</div></div>';
    document.body.appendChild(dlg);

    var qEl = dlg.querySelector('#ev-q'), listEl = dlg.querySelector('#ev-list');
    var qtyEl = dlg.querySelector('#ev-qty'), msgEl = dlg.querySelector('#ev-msg');
    var chosen = null, cache = null;

    function loadCache() {
      if (cache) return Promise.resolve(cache);
      return jget(API + '?c=products&since=0').then(function (r) {
        cache = (r && r.success && Array.isArray(r.data)) ? r.data : [];
        return cache;
      });
    }
    function render() {
      var q = normKey(qEl.value);
      loadCache().then(function (rows) {
        listEl.innerHTML = '';
        rows.filter(function (row) {
          if (!q) return true;
          var d = row.data || {};
          return normKey(d.nama).indexOf(q) > -1 || normKey(d.kode).indexOf(q) > -1 || normKey(row.id).indexOf(q) > -1;
        }).slice(0, 30).forEach(function (row) {
          var d = row.data || {};
          var it = document.createElement('div');
          it.style.cssText = 'padding:6px 10px;font-size:12px;cursor:pointer;border-bottom:1px solid #f1f5f9';
          it.textContent = (d.kode ? d.kode + ' — ' : '') + (d.nama || row.id) + ' (stok: ' + (d.stok != null ? d.stok : '-') + ')';
          it.onclick = function () {
            chosen = row; it.parentNode.querySelectorAll('div').forEach(function (x) { x.style.background = '#fff'; });
            it.style.background = '#dbeafe';
          };
          listEl.appendChild(it);
        });
      }).catch(function (e) { msgEl.textContent = 'Gagal memuat produk: ' + e.message; });
    }
    qEl.addEventListener('input', render);
    render();

    dlg.querySelector('#ev-cancel').onclick = function () { dlg.remove(); };
    dlg.querySelector('#ev-save').onclick = function () {
      msgEl.textContent = '';
      if (!chosen) { msgEl.textContent = 'Pilih produk dulu.'; return; }
      var delta = parseFloat(qtyEl.value || '0');
      if (!delta) { msgEl.textContent = 'Isi Δ qty (tidak boleh 0).'; return; }
      var cur = parseFloat(String((chosen.data || {}).stok == null ? '0' : chosen.data.stok));
      if (isNaN(cur)) cur = 0;
      var next = Math.max(0, cur + delta);
      var btn = dlg.querySelector('#ev-save'); btn.disabled = true; btn.textContent = 'Menyimpan…';
      jpost({
        action: 'put', collection: 'products', id: chosen.id,
        data: { stok: String(next), updatedAt: new Date().toISOString() }
      }).then(function (r) {
        if (!r || !r.success) throw new Error((r && r.message) || 'server menolak');
        // samakan cache lokal agar UI langsung konsisten
        try {
          var locals = localProducts(), hit = false;
          for (var i = 0; i < locals.length; i++) {
            if (locals[i] && normKey(locals[i].kode) === normKey(chosen.id)) { locals[i].stok = String(next); hit = true; }
          }
          if (hit) nativeSetItem(LS_PRODUCTS, JSON.stringify(locals));
        } catch (e) {}
        alert('Stok "' + ((chosen.data || {}).nama || chosen.id) + '" diperbarui: ' + cur + ' → ' + next);
        dlg.remove();
      }).catch(function (e) {
        msgEl.textContent = 'Gagal: ' + e.message;
        btn.disabled = false; btn.textContent = 'Simpan ke Database';
      });
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureUI);
  } else {
    ensureUI();
  }
  console.info('[patch.js] aktif — sinkron stok ke MySQL + timeout laporan 20s.');
})();
