<?php
/**
 * ==============================================================
 * ERVO STORE POS - REST API Endpoint untuk cPanel MySQL
 * Mendukung 17 Tabel Database Mandiri & Sinkronisasi Kasir
 * ==============================================================
 */

require_once __DIR__ . '/config.php';

header("Content-Type: application/json; charset=UTF-8");

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Membaca payload JSON jika request dikirim dalam bentuk raw body (POST/PUT)
$rawInput = file_get_contents('php://input');
$jsonBody = [];
if (!empty($rawInput)) {
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) {
        $jsonBody = $decoded;
        if (empty($action) && isset($jsonBody['action'])) {
            $action = $jsonBody['action'];
        }
    }
}

function normalizeDbDate($d) {
    if (empty($d)) return date('Y-m-d');
    $d = trim((string)$d);
    if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', $d, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[1], (int)$m[2], (int)$m[3]);
    }
    if (preg_match('/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/', $d, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    $ts = strtotime(str_replace('/', '-', $d));
    return $ts ? date('Y-m-d', $ts) : date('Y-m-d');
}

try {
    switch ($action) {
        case 'ping':
            echo json_encode([
                "success" => true,
                "message" => "API MySQL cPanel ERVO STORE Berjalan Normal!",
                "database" => DB_NAME,
                "timestamp" => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'bulk_restore':
        case 'sync_all':
        case 'upload_all':
            $payload = !empty($jsonBody['data']) ? $jsonBody['data'] : (!empty($jsonBody['payload']) ? $jsonBody['payload'] : $jsonBody);
            $mode = $jsonBody['mode'] ?? 'replace';
            
            $pdo->beginTransaction();
            $counts = [
                'products' => 0,
                'customers' => 0,
                'invoices' => 0,
                'expenses' => 0,
                'stockIn' => 0,
                'stockOpname' => 0,
                'vendors' => 0,
                'kasirUsers' => 0
            ];

            if ($mode === 'replace') {
                $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
                if (!empty($payload['products'])) $pdo->exec("DELETE FROM products");
                if (!empty($payload['customers'])) $pdo->exec("DELETE FROM customers");
                if (!empty($payload['invoices'])) $pdo->exec("DELETE FROM invoices");
                if (!empty($payload['expenses'])) $pdo->exec("DELETE FROM expenses");
                if (!empty($payload['stockIn'])) $pdo->exec("DELETE FROM stockIn");
                if (!empty($payload['stockOpnames'])) $pdo->exec("DELETE FROM stockOpname");
                if (!empty($payload['vendors'])) $pdo->exec("DELETE FROM vendors");
                if (!empty($payload['kasirUsers'])) $pdo->exec("DELETE FROM kasirUsers");
                if (!empty($payload['backupCheckpoints'])) $pdo->exec("DELETE FROM backupCheckpoints");
                if (!empty($payload['businessTransactions'])) $pdo->exec("DELETE FROM businessTransactions");
                if (!empty($payload['deletedInvoices'])) $pdo->exec("DELETE FROM deletedInvoices");
                if (!empty($payload['deletedProducts'])) $pdo->exec("DELETE FROM deletedProducts");
                if (!empty($payload['deletedCustomers'])) $pdo->exec("DELETE FROM deletedCustomers");
                if (!empty($payload['deletedExpenses'])) $pdo->exec("DELETE FROM deletedExpenses");
                $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
            }

            // Products
            if (!empty($payload['products']) && is_array($payload['products'])) {
                $stmt = $pdo->prepare("INSERT INTO products (kode, nama, harga, kategori, stok, satuan, tipe_harga, harga_jual_modal, supplier, pricing_scheme_json)
                    VALUES (:kode, :nama, :harga, :kategori, :stok, :satuan, :tipe_harga, :harga_jual_modal, :supplier, :pricing_scheme_json)
                    ON DUPLICATE KEY UPDATE 
                    nama = VALUES(nama), harga = VALUES(harga), kategori = VALUES(kategori), stok = VALUES(stok), satuan = VALUES(satuan),
                    tipe_harga = VALUES(tipe_harga), harga_jual_modal = VALUES(harga_jual_modal), supplier = VALUES(supplier), pricing_scheme_json = VALUES(pricing_scheme_json)");
                foreach ($payload['products'] as $p) {
                    $kode = $p['kode'] ?? '';
                    $nama = $p['nama'] ?? '';
                    if (empty($kode) || empty($nama)) continue;
                    $pricingRaw = $p['pricingScheme'] ?? ($p['pricing_scheme_json'] ?? null);
                    $pricingSchemeJson = (is_string($pricingRaw) && trim($pricingRaw) !== '')
                        ? $pricingRaw
                        : json_encode($pricingRaw, JSON_UNESCAPED_UNICODE);
                    $stmt->execute([
                        ':kode' => $kode,
                        ':nama' => $nama,
                        ':harga' => floatval($p['harga'] ?? 0),
                        ':kategori' => $p['kategori'] ?? 'Umum',
                        ':stok' => (string)($p['stok'] ?? ''),
                        ':satuan' => $p['satuan'] ?? 'pcs',
                        ':tipe_harga' => $p['tipeHarga'] ?? $p['tipe_harga'] ?? 'fix',
                        ':harga_jual_modal' => floatval($p['hargaJualModal'] ?? $p['harga_jual_modal'] ?? 0),
                        ':supplier' => $p['supplier'] ?? '',
                        ':pricing_scheme_json' => $pricingSchemeJson,
                    ]);
                    $counts['products']++;
                }
            }

            // Customers
            if (!empty($payload['customers']) && is_array($payload['customers'])) {
                $stmt = $pdo->prepare("INSERT INTO customers (nama, kelas, diskon, telepon, alamat, catatan)
                    VALUES (:nama, :kelas, :diskon, :telepon, :alamat, :catatan)
                    ON DUPLICATE KEY UPDATE 
                    kelas = VALUES(kelas), diskon = VALUES(diskon), telepon = VALUES(telepon), alamat = VALUES(alamat), catatan = VALUES(catatan)");
                foreach ($payload['customers'] as $c) {
                    $nama = $c['nama'] ?? '';
                    if (empty($nama)) continue;
                    $stmt->execute([
                        ':nama' => $nama,
                        ':kelas' => $c['kelas'] ?? 'Reguler',
                        ':diskon' => floatval($c['diskon'] ?? 0),
                        ':telepon' => $c['telepon'] ?? '',
                        ':alamat' => $c['alamat'] ?? '',
                        ':catatan' => $c['catatan'] ?? '',
                    ]);
                    $counts['customers']++;
                }
            }

            // Invoices
            if (!empty($payload['invoices']) && is_array($payload['invoices'])) {
                $stmt = $pdo->prepare("INSERT INTO invoices (invoice_no, date, time, customer, cashier, pay_method, subtotal, disc_pct, disc_amt, tax_pct, tax_amt, nego_amt, total, dp, sisa, kembalian, deadline, status, items_json, histori_pelunasan_json)
                    VALUES (:invoice_no, :date, :time, :customer, :cashier, :pay_method, :subtotal, :disc_pct, :disc_amt, :tax_pct, :tax_amt, :nego_amt, :total, :dp, :sisa, :kembalian, :deadline, :status, :items_json, :histori_pelunasan_json)
                    ON DUPLICATE KEY UPDATE 
                    customer = VALUES(customer), cashier = VALUES(cashier), pay_method = VALUES(pay_method), subtotal = VALUES(subtotal),
                    disc_pct = VALUES(disc_pct), disc_amt = VALUES(disc_amt), tax_pct = VALUES(tax_pct), tax_amt = VALUES(tax_amt),
                    nego_amt = VALUES(nego_amt), total = VALUES(total), dp = VALUES(dp), sisa = VALUES(sisa), kembalian = VALUES(kembalian),
                    deadline = VALUES(deadline), status = VALUES(status), items_json = VALUES(items_json), histori_pelunasan_json = VALUES(histori_pelunasan_json)");
                foreach ($payload['invoices'] as $inv) {
                    $invNo = $inv['invoice_no'] ?? $inv['invoiceNo'] ?? $inv['noInvoice'] ?? '';
                    if (empty($invNo)) continue;
                    $itemsRaw = $inv['items'] ?? ($inv['items_json'] ?? []);
                    $itemsJson = (is_string($itemsRaw) && trim($itemsRaw) !== '')
                        ? $itemsRaw
                        : json_encode(is_array($itemsRaw) ? $itemsRaw : [], JSON_UNESCAPED_UNICODE);
                    $histRaw = $inv['histori_pelunasan_json'] ?? ($inv['historiPelunasan'] ?? ($inv['pelunasanHistory'] ?? ($inv['histori_pelunasan'] ?? [])));
                    $historiJson = (is_string($histRaw) && trim($histRaw) !== '')
                        ? $histRaw
                        : json_encode(is_array($histRaw) ? $histRaw : [], JSON_UNESCAPED_UNICODE);
                    $invTotal = floatval($inv['total'] ?? 0);
                    $invDp = floatval($inv['dp'] ?? 0);
                    $invSisa = floatval($inv['sisa'] ?? 0);
                    $invStatus = trim((string)($inv['status'] ?? ''));
                    if ($invStatus === '') {
                        $invStatus = ($invSisa > 0) ? ($invDp > 0 ? 'DP' : 'BELUM BAYAR') : 'LUNAS';
                    }
                    $stmt->execute([
                        ':invoice_no' => $invNo,
                        ':date' => normalizeDbDate($inv['date'] ?? $inv['tanggal'] ?? date('Y-m-d')),
                        ':time' => $inv['time'] ?? $inv['jam'] ?? date('H:i'),
                        ':customer' => $inv['customer'] ?? $inv['pelanggan'] ?? 'Umum',
                        ':cashier' => $inv['cashier'] ?? $inv['kasir'] ?? 'Admin',
                        ':pay_method' => $inv['pay_method'] ?? $inv['payMethod'] ?? $inv['metodePembayaran'] ?? 'Tunai',
                        ':subtotal' => floatval($inv['subtotal'] ?? $inv['total'] ?? 0),
                        ':disc_pct' => floatval($inv['disc_pct'] ?? $inv['discPct'] ?? 0),
                        ':disc_amt' => floatval($inv['disc_amt'] ?? $inv['discAmt'] ?? 0),
                        ':tax_pct' => floatval($inv['tax_pct'] ?? $inv['taxPct'] ?? 0),
                        ':tax_amt' => floatval($inv['tax_amt'] ?? $inv['taxAmt'] ?? 0),
                        ':nego_amt' => floatval($inv['nego_amt'] ?? $inv['negoAmt'] ?? 0),
                        ':total' => $invTotal,
                        ':dp' => $invDp,
                        ':sisa' => $invSisa,
                        ':kembalian' => floatval($inv['kembalian'] ?? 0),
                        ':deadline' => $inv['deadline'] ?? '',
                        ':status' => $invStatus,
                        ':items_json' => $itemsJson,
                        ':histori_pelunasan_json' => $historiJson,
                    ]);
                    $counts['invoices']++;
                }
            }

            // Expenses
            if (!empty($payload['expenses']) && is_array($payload['expenses'])) {
                $stmt = $pdo->prepare("INSERT INTO expenses (id, tanggal, kategori, keterangan, nominal, pj)
                    VALUES (:id, :tanggal, :kategori, :keterangan, :nominal, :pj)
                    ON DUPLICATE KEY UPDATE 
                    tanggal = VALUES(tanggal), kategori = VALUES(kategori), keterangan = VALUES(keterangan), nominal = VALUES(nominal), pj = VALUES(pj)");
                foreach ($payload['expenses'] as $e) {
                    $id = $e['id'] ?? ('EXP-' . uniqid());
                    $stmt->execute([
                        ':id' => $id,
                        ':tanggal' => normalizeDbDate($e['tanggal'] ?? date('Y-m-d')),
                        ':kategori' => $e['kategori'] ?? 'Beban Operasional',
                        ':keterangan' => $e['keterangan'] ?? '',
                        ':nominal' => floatval($e['nominal'] ?? 0),
                        ':pj' => $e['pj'] ?? 'Admin',
                    ]);
                    $counts['expenses']++;
                }
            }

            // StockIn
            if (!empty($payload['stockIn']) && is_array($payload['stockIn'])) {
                $stmt = $pdo->prepare("INSERT INTO stockIn (id, tanggal, time, kode_produk, nama_produk, jumlah, satuan, harga_beli, total_biaya, supplier, no_po, gudang, catatan, cashier)
                    VALUES (:id, :tanggal, :time, :kode_produk, :nama_produk, :jumlah, :satuan, :harga_beli, :total_biaya, :supplier, :no_po, :gudang, :catatan, :cashier)
                    ON DUPLICATE KEY UPDATE 
                    nama_produk = VALUES(nama_produk), jumlah = VALUES(jumlah), harga_beli = VALUES(harga_beli), total_biaya = VALUES(total_biaya)");
                foreach ($payload['stockIn'] as $s) {
                    $id = $s['id'] ?? ('SI-' . uniqid());
                    $stmt->execute([
                        ':id' => $id,
                        ':tanggal' => normalizeDbDate($s['date'] ?? $s['tanggal'] ?? date('Y-m-d')),
                        ':time' => $s['time'] ?? date('H:i'),
                        ':kode_produk' => $s['kode'] ?? '',
                        ':nama_produk' => $s['nama'] ?? '',
                        ':jumlah' => floatval($s['qty'] ?? $s['jumlahMasuk'] ?? 0),
                        ':satuan' => $s['satuan'] ?? 'pcs',
                        ':harga_beli' => floatval($s['hargaBeli'] ?? 0),
                        ':total_biaya' => floatval($s['totalBiaya'] ?? 0),
                        ':supplier' => $s['supplier'] ?? '',
                        ':no_po' => $s['noPo'] ?? '',
                        ':gudang' => $s['gudang'] ?? 'Gudang Utama',
                        ':catatan' => $s['catatan'] ?? '',
                        ':cashier' => $s['cashier'] ?? 'Admin',
                    ]);
                    $counts['stockIn']++;
                }
            }

            // Vendors
            if (!empty($payload['vendors']) && is_array($payload['vendors'])) {
                $stmt = $pdo->prepare("INSERT INTO vendors (id, nama, kategori, telepon, email, alamat, kontak_person, nomor_rekening, catatan, created_at)
                    VALUES (:id, :nama, :kategori, :telepon, :email, :alamat, :kontak_person, :nomor_rekening, :catatan, :created_at)
                    ON DUPLICATE KEY UPDATE 
                    nama = VALUES(nama), kategori = VALUES(kategori), telepon = VALUES(telepon), email = VALUES(email), alamat = VALUES(alamat), kontak_person = VALUES(kontak_person), nomor_rekening = VALUES(nomor_rekening), catatan = VALUES(catatan)");
                foreach ($payload['vendors'] as $v) {
                    $id = $v['id'] ?? ('VEN-' . uniqid());
                    $stmt->execute([
                        ':id' => $id,
                        ':nama' => $v['nama'] ?? '',
                        ':kategori' => $v['kategori'] ?? 'Umum',
                        ':telepon' => $v['telepon'] ?? '',
                        ':email' => $v['email'] ?? '',
                        ':alamat' => $v['alamat'] ?? '',
                        ':kontak_person' => $v['kontakPerson'] ?? '',
                        ':nomor_rekening' => $v['nomorRekening'] ?? '',
                        ':catatan' => $v['catatan'] ?? '',
                        ':created_at' => $v['createdAt'] ?? date('Y-m-d'),
                    ]);
                    $counts['vendors']++;
                }
            }

            // Settings
            if (!empty($payload['settings'])) {
                $s = $payload['settings'];
                $stmt = $pdo->prepare("INSERT INTO settings (id, name, address, phone, footer, rekening, prefix_invoice, auto_logout_minutes)
                    VALUES (1, :name, :address, :phone, :footer, :rekening, :prefix_invoice, :auto_logout_minutes)
                    ON DUPLICATE KEY UPDATE 
                    name = VALUES(name), address = VALUES(address), phone = VALUES(phone), footer = VALUES(footer),
                    rekening = VALUES(rekening), prefix_invoice = VALUES(prefix_invoice), auto_logout_minutes = VALUES(auto_logout_minutes)");
                $stmt->execute([
                    ':name' => $s['name'] ?? 'ERVO PRINT',
                    ':address' => $s['address'] ?? '',
                    ':phone' => $s['phone'] ?? '',
                    ':footer' => $s['footer'] ?? '',
                    ':rekening' => $s['rekening'] ?? '',
                    ':prefix_invoice' => $s['prefixInvoice'] ?? 'INV-',
                    ':auto_logout_minutes' => intval($s['autoLogoutMinutes'] ?? 15),
                ]);
            }

            // Kasir Users (CRITICAL: Always insert and never leave empty!)
            $rawKasir = !empty($payload['kasirUsers']) ? $payload['kasirUsers'] : (!empty($payload['kasirList']) ? $payload['kasirList'] : []);
            if (empty($rawKasir)) {
                $rawKasir = [['nama' => 'Admin', 'role' => 'Owner', 'password' => 'ervo123', 'aktif' => 1]];
            }
            $stmt = $pdo->prepare("INSERT INTO kasirUsers (nama, role, password, aktif)
                VALUES (:nama, :role, :password, :aktif)
                ON DUPLICATE KEY UPDATE 
                role = VALUES(role), password = VALUES(password), aktif = VALUES(aktif)");
            foreach ($rawKasir as $ku) {
                $nama = is_string($ku) ? $ku : ($ku['nama'] ?? '');
                if (empty($nama)) continue;
                $role = is_array($ku) ? ($ku['role'] ?? 'Kasir') : 'Kasir';
                $password = is_array($ku) ? ($ku['password'] ?? 'ervo123') : 'ervo123';
                $aktif = is_array($ku) ? intval($ku['aktif'] ?? 1) : 1;
                $stmt->execute([
                    ':nama' => $nama,
                    ':role' => $role,
                    ':password' => $password,
                    ':aktif' => $aktif
                ]);
                $counts['kasirUsers']++;
            }

            // Backup Checkpoints
            if (!empty($payload['backupCheckpoints']) && is_array($payload['backupCheckpoints'])) {
                $stmt = $pdo->prepare("INSERT INTO backupCheckpoints (id, timestamp, formattedDate, formattedTime, triggerType, label, operator, counts_json, layers_json, payload_json)
                    VALUES (:id, :timestamp, :formattedDate, :formattedTime, :triggerType, :label, :operator, :counts_json, :layers_json, :payload_json)
                    ON DUPLICATE KEY UPDATE 
                    label = VALUES(label), operator = VALUES(operator), counts_json = VALUES(counts_json), layers_json = VALUES(layers_json), payload_json = VALUES(payload_json)");
                foreach ($payload['backupCheckpoints'] as $cp) {
                    $id = $cp['id'] ?? '';
                    if (empty($id)) continue;
                    $stmt->execute([
                        ':id' => $id,
                        ':timestamp' => $cp['timestamp'] ?? date('c'),
                        ':formattedDate' => $cp['formattedDate'] ?? date('d/m/Y'),
                        ':formattedTime' => $cp['formattedTime'] ?? date('H:i:s'),
                        ':triggerType' => $cp['trigger'] ?? $cp['triggerType'] ?? 'MANUAL',
                        ':label' => $cp['label'] ?? 'Checkpoint',
                        ':operator' => $cp['operator'] ?? 'Admin',
                        ':counts_json' => (isset($cp['counts']) && is_string($cp['counts']) && trim($cp['counts']) !== '') ? $cp['counts'] : json_encode($cp['counts'] ?? [], JSON_UNESCAPED_UNICODE),
                        ':layers_json' => (isset($cp['layers']) && is_string($cp['layers']) && trim($cp['layers']) !== '') ? $cp['layers'] : json_encode($cp['layers'] ?? [], JSON_UNESCAPED_UNICODE),
                        ':payload_json' => (isset($cp['payload']) && is_string($cp['payload']) && trim($cp['payload']) !== '') ? $cp['payload'] : json_encode($cp['payload'] ?? null, JSON_UNESCAPED_UNICODE),
                    ]);
                    $counts['backupCheckpoints'] = ($counts['backupCheckpoints'] ?? 0) + 1;
                }
            }

            // Business Transactions
            if (!empty($payload['businessTransactions']) && is_array($payload['businessTransactions'])) {
                $stmt = $pdo->prepare("INSERT INTO businessTransactions (id, date, businessUnit, type, category, amount, description, paymentMethod, referenceNo, status, source, sourceApp, createdAt)
                    VALUES (:id, :date, :businessUnit, :type, :category, :amount, :description, :paymentMethod, :referenceNo, :status, :source, :sourceApp, :createdAt)
                    ON DUPLICATE KEY UPDATE 
                    amount = VALUES(amount), description = VALUES(description), paymentMethod = VALUES(paymentMethod), status = VALUES(status)");
                foreach ($payload['businessTransactions'] as $bt) {
                    $id = $bt['id'] ?? '';
                    if (empty($id)) continue;
                    $stmt->execute([
                        ':id' => $id,
                        ':date' => $bt['date'] ?? date('Y-m-d'),
                        ':businessUnit' => $bt['businessUnit'] ?? 'ERVO STORE',
                        ':type' => $bt['type'] ?? 'income',
                        ':category' => $bt['category'] ?? 'Penjualan Kasir',
                        ':amount' => floatval($bt['amount'] ?? 0),
                        ':description' => $bt['description'] ?? '',
                        ':paymentMethod' => $bt['paymentMethod'] ?? 'Tunai',
                        ':referenceNo' => $bt['referenceNo'] ?? '',
                        ':status' => $bt['status'] ?? 'completed',
                        ':source' => $bt['source'] ?? 'api_sync',
                        ':sourceApp' => $bt['sourceApp'] ?? '',
                        ':createdAt' => $bt['createdAt'] ?? date('c'),
                    ]);
                    $counts['businessTransactions'] = ($counts['businessTransactions'] ?? 0) + 1;
                }
            }

            // Auxiliary Deletion Tables & Audit Logs
            if (!empty($payload['deletedInvoices']) && is_array($payload['deletedInvoices'])) {
                $stmt = $pdo->prepare("INSERT INTO deletedInvoices (invoice_no, deleted_by, reason) VALUES (:invoice_no, :deleted_by, :reason) ON DUPLICATE KEY UPDATE reason = VALUES(reason)");
                foreach ($payload['deletedInvoices'] as $di) {
                    $no = is_string($di) ? $di : ($di['invoice_no'] ?? $di['invoiceNo'] ?? '');
                    if (empty($no)) continue;
                    $stmt->execute([
                        ':invoice_no' => $no,
                        ':deleted_by' => is_array($di) ? ($di['deleted_by'] ?? 'Admin') : 'Admin',
                        ':reason' => is_array($di) ? ($di['reason'] ?? 'Dihapus via kasir POS') : 'Dihapus via kasir POS'
                    ]);
                }
            }
            if (!empty($payload['deletedProducts']) && is_array($payload['deletedProducts'])) {
                $stmt = $pdo->prepare("INSERT INTO deletedProducts (kode_or_nama) VALUES (:kode_or_nama)");
                foreach ($payload['deletedProducts'] as $dp) {
                    $item = is_string($dp) ? $dp : ($dp['kode_or_nama'] ?? $dp['nama'] ?? $dp['kode'] ?? '');
                    if (empty($item)) continue;
                    $stmt->execute([':kode_or_nama' => $item]);
                }
            }
            if (!empty($payload['deletedCustomers']) && is_array($payload['deletedCustomers'])) {
                $stmt = $pdo->prepare("INSERT INTO deletedCustomers (nama) VALUES (:nama)");
                foreach ($payload['deletedCustomers'] as $dc) {
                    $item = is_string($dc) ? $dc : ($dc['nama'] ?? '');
                    if (empty($item)) continue;
                    $stmt->execute([':nama' => $item]);
                }
            }
            if (!empty($payload['deletedExpenses']) && is_array($payload['deletedExpenses'])) {
                $stmt = $pdo->prepare("INSERT INTO deletedExpenses (id) VALUES (:id) ON DUPLICATE KEY UPDATE id = VALUES(id)");
                foreach ($payload['deletedExpenses'] as $de) {
                    $item = is_string($de) ? $de : ($de['id'] ?? '');
                    if (empty($item)) continue;
                    $stmt->execute([':id' => $item]);
                }
            }
            if (!empty($payload['stockinDeleteLogs']) && is_array($payload['stockinDeleteLogs'])) {
                $stmt = $pdo->prepare("INSERT INTO _stockin_delete_log (stockin_id, kode_produk, nama_produk, qty, rollback_stock, deleted_by, notes)
                    VALUES (:stockin_id, :kode_produk, :nama_produk, :qty, :rollback_stock, :deleted_by, :notes)");
                foreach ($payload['stockinDeleteLogs'] as $sl) {
                    if (empty($sl['stockin_id'])) continue;
                    $stmt->execute([
                        ':stockin_id' => $sl['stockin_id'],
                        ':kode_produk' => $sl['kode_produk'] ?? '',
                        ':nama_produk' => $sl['nama_produk'] ?? '',
                        ':qty' => floatval($sl['qty'] ?? 0),
                        ':rollback_stock' => intval($sl['rollback_stock'] ?? 0),
                        ':deleted_by' => $sl['deleted_by'] ?? 'Admin',
                        ':notes' => $sl['notes'] ?? '',
                    ]);
                }
            }

            $pdo->commit();
            echo json_encode([
                "success" => true,
                "message" => "Pemulihan data ke database MySQL cPanel berhasil! Total: {$counts['products']} produk, {$counts['customers']} pelanggan, {$counts['invoices']} transaksi tersimpan.",
                "counts" => $counts
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_all':
            $products = $pdo->query("SELECT * FROM products ORDER BY nama ASC")->fetchAll();
            $customers = $pdo->query("SELECT * FROM customers ORDER BY nama ASC")->fetchAll();
            $invoicesRaw = $pdo->query("SELECT * FROM invoices ORDER BY date DESC, time DESC")->fetchAll();
            $expenses = $pdo->query("SELECT * FROM expenses ORDER BY tanggal DESC")->fetchAll();
            $stockIn = $pdo->query("SELECT * FROM stockIn ORDER BY tanggal DESC, time DESC")->fetchAll();
            $stockOpnamesRaw = $pdo->query("SELECT * FROM stockOpname ORDER BY tanggal DESC")->fetchAll();
            $vendors = $pdo->query("SELECT * FROM vendors ORDER BY nama ASC")->fetchAll();
            $kasirUsers = $pdo->query("SELECT nama, role, password, aktif FROM kasirUsers ORDER BY nama ASC")->fetchAll();
            $settingsStmt = $pdo->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
            $settings = $settingsStmt->fetch() ?: null;
            if ($settings) {
                $settings['prefixInvoice'] = $settings['prefix_invoice'] ?? ($settings['prefixInvoice'] ?? 'INV-');
                $settings['autoLogoutMinutes'] = isset($settings['auto_logout_minutes'])
                    ? intval($settings['auto_logout_minutes'])
                    : intval($settings['autoLogoutMinutes'] ?? 15);
            }

            // Auxiliary tables
            $backupCheckpointsRaw = [];
            try { $backupCheckpointsRaw = $pdo->query("SELECT * FROM backupCheckpoints ORDER BY timestamp DESC")->fetchAll(); } catch (Exception $e) {}
            $businessTransactions = [];
            try { $businessTransactions = $pdo->query("SELECT * FROM businessTransactions ORDER BY date DESC")->fetchAll(); } catch (Exception $e) {}
            $deletedInvoices = [];
            try { $deletedInvoices = $pdo->query("SELECT * FROM deletedInvoices")->fetchAll(); } catch (Exception $e) {}
            $deletedProducts = [];
            try { $deletedProducts = $pdo->query("SELECT * FROM deletedProducts")->fetchAll(); } catch (Exception $e) {}
            $deletedCustomers = [];
            try { $deletedCustomers = $pdo->query("SELECT * FROM deletedCustomers")->fetchAll(); } catch (Exception $e) {}
            $deletedExpenses = [];
            try { $deletedExpenses = $pdo->query("SELECT * FROM deletedExpenses")->fetchAll(); } catch (Exception $e) {}
            $stockinDeleteLog = [];
            try { $stockinDeleteLog = $pdo->query("SELECT * FROM _stockin_delete_log ORDER BY id DESC LIMIT 200")->fetchAll(); } catch (Exception $e) {}
            $invoiceRestoreLog = [];
            try { $invoiceRestoreLog = $pdo->query("SELECT * FROM _invoice_restore_log ORDER BY id DESC LIMIT 200")->fetchAll(); } catch (Exception $e) {}

            $invoices = [];
            foreach ($invoicesRaw as $inv) {
                $inv['items'] = [];
                if (!empty($inv['items_json']) && is_string($inv['items_json'])) {
                    $decoded = json_decode($inv['items_json'], true);
                    if (is_array($decoded)) {
                        $inv['items'] = $decoded;
                    }
                }
                $inv['historiPelunasan'] = [];
                $inv['pelunasanHistory'] = [];
                if (!empty($inv['histori_pelunasan_json']) && is_string($inv['histori_pelunasan_json'])) {
                    $decodedHist = json_decode($inv['histori_pelunasan_json'], true);
                    if (is_array($decodedHist)) {
                        $inv['historiPelunasan'] = $decodedHist;
                        $inv['pelunasanHistory'] = $decodedHist;
                    }
                }
                $inv['invoiceNo'] = $inv['invoice_no'] ?? '';
                $inv['noInvoice'] = $inv['invoice_no'] ?? '';
                $invDate = $inv['date'] ?? date('Y-m-d');
                $inv['date'] = $invDate;
                $inv['tanggal'] = $invDate;
                $invTime = $inv['time'] ?? '';
                $inv['time'] = $invTime;
                $inv['jam'] = $invTime;
                $inv['payMethod'] = $inv['pay_method'] ?? 'Tunai';
                $inv['metodePembayaran'] = $inv['pay_method'] ?? 'Tunai';
                $inv['subtotal'] = floatval($inv['subtotal'] ?? 0);
                $inv['discPct'] = floatval($inv['disc_pct'] ?? 0);
                $inv['discAmt'] = floatval($inv['disc_amt'] ?? 0);
                $inv['taxPct'] = floatval($inv['tax_pct'] ?? 0);
                $inv['taxAmt'] = floatval($inv['tax_amt'] ?? 0);
                $inv['negoAmt'] = floatval($inv['nego_amt'] ?? 0);
                $inv['total'] = floatval($inv['total'] ?? 0);
                $inv['dp'] = floatval($inv['dp'] ?? 0);
                $inv['sisa'] = floatval($inv['sisa'] ?? 0);
                $inv['kembalian'] = floatval($inv['kembalian'] ?? 0);
                $invoices[] = $inv;
            }

            $normalizedProducts = [];
            foreach ($products as $p) {
                if (!empty($p['pricing_scheme_json']) && is_string($p['pricing_scheme_json'])) {
                    $decoded = json_decode($p['pricing_scheme_json'], true);
                    if ($decoded !== null) {
                        $p['pricingScheme'] = $decoded;
                    }
                }
                $p['tipeHarga'] = $p['tipe_harga'] ?? 'fix';
                $p['hargaJualModal'] = floatval($p['harga_jual_modal'] ?? 0);
                $normalizedProducts[] = $p;
            }

            $stockOpnames = [];
            foreach ($stockOpnamesRaw as $so) {
                if (!empty($so['items_json']) && is_string($so['items_json'])) {
                    $decoded = json_decode($so['items_json'], true);
                    if ($decoded !== null) {
                        $so['items'] = $decoded;
                    }
                }
                $stockOpnames[] = $so;
            }

            $backupCheckpoints = [];
            foreach ($backupCheckpointsRaw as $cp) {
                if (!empty($cp['counts_json']) && is_string($cp['counts_json'])) {
                    $cp['counts'] = json_decode($cp['counts_json'], true);
                }
                if (!empty($cp['layers_json']) && is_string($cp['layers_json'])) {
                    $cp['layers'] = json_decode($cp['layers_json'], true);
                }
                if (!empty($cp['payload_json']) && is_string($cp['payload_json'])) {
                    $cp['payload'] = json_decode($cp['payload_json'], true);
                }
                $backupCheckpoints[] = $cp;
            }

            echo json_encode([
                "success" => true,
                "products" => $normalizedProducts,
                "customers" => $customers,
                "invoices" => $invoices,
                "expenses" => $expenses,
                "stockIn" => $stockIn,
                "stockOpnames" => $stockOpnames,
                "vendors" => $vendors,
                "kasirUsers" => $kasirUsers,
                "settings" => $settings,
                "backupCheckpoints" => $backupCheckpoints,
                "businessTransactions" => $businessTransactions,
                "deletedInvoices" => $deletedInvoices,
                "deletedProducts" => $deletedProducts,
                "deletedCustomers" => $deletedCustomers,
                "deletedExpenses" => $deletedExpenses,
                "_stockin_delete_log" => $stockinDeleteLog,
                "_invoice_restore_log" => $invoiceRestoreLog,
                "timestamp" => date('c')
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_products':
            $stmt = $pdo->query("SELECT * FROM products ORDER BY nama ASC");
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_customers':
            $stmt = $pdo->query("SELECT * FROM customers ORDER BY nama ASC");
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_invoices':
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 0;
            if ($limit > 0) {
                $stmt = $pdo->prepare("SELECT * FROM invoices ORDER BY date DESC, time DESC LIMIT :lim");
                $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
                $stmt->execute();
            } else {
                $stmt = $pdo->query("SELECT * FROM invoices ORDER BY date DESC, time DESC");
            }
            $rawInvs = $stmt->fetchAll();
            $invList = [];
            foreach ($rawInvs as $inv) {
                $inv['items'] = [];
                if (!empty($inv['items_json']) && is_string($inv['items_json'])) {
                    $decoded = json_decode($inv['items_json'], true);
                    if (is_array($decoded)) $inv['items'] = $decoded;
                }
                $inv['historiPelunasan'] = [];
                $inv['pelunasanHistory'] = [];
                if (!empty($inv['histori_pelunasan_json']) && is_string($inv['histori_pelunasan_json'])) {
                    $decodedHist = json_decode($inv['histori_pelunasan_json'], true);
                    if (is_array($decodedHist)) {
                        $inv['historiPelunasan'] = $decodedHist;
                        $inv['pelunasanHistory'] = $decodedHist;
                    }
                }
                $inv['invoiceNo'] = $inv['invoice_no'] ?? '';
                $inv['noInvoice'] = $inv['invoice_no'] ?? '';
                $inv['payMethod'] = $inv['pay_method'] ?? 'Tunai';
                $inv['subtotal'] = floatval($inv['subtotal'] ?? 0);
                $inv['total'] = floatval($inv['total'] ?? 0);
                $inv['dp'] = floatval($inv['dp'] ?? 0);
                $inv['sisa'] = floatval($inv['sisa'] ?? 0);
                $inv['kembalian'] = floatval($inv['kembalian'] ?? 0);
                $invList[] = $inv;
            }
            echo json_encode(["success" => true, "data" => $invList], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_expenses':
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 0;
            if ($limit > 0) {
                $stmt = $pdo->prepare("SELECT * FROM expenses ORDER BY tanggal DESC LIMIT :lim");
                $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
                $stmt->execute();
            } else {
                $stmt = $pdo->query("SELECT * FROM expenses ORDER BY tanggal DESC");
            }
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_stock_in':
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 0;
            if ($limit > 0) {
                $stmt = $pdo->prepare("SELECT * FROM stockIn ORDER BY tanggal DESC, time DESC LIMIT :lim");
                $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
                $stmt->execute();
            } else {
                $stmt = $pdo->query("SELECT * FROM stockIn ORDER BY tanggal DESC, time DESC");
            }
            echo json_encode(["success" => true, "data" => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_settings':
            $stmt = $pdo->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
            $settingsRow = $stmt->fetch() ?: null;
            if ($settingsRow) {
                $settingsRow['prefixInvoice'] = $settingsRow['prefix_invoice'] ?? ($settingsRow['prefixInvoice'] ?? 'INV-');
                $settingsRow['autoLogoutMinutes'] = isset($settingsRow['auto_logout_minutes'])
                    ? intval($settingsRow['auto_logout_minutes'])
                    : intval($settingsRow['autoLogoutMinutes'] ?? 15);
            }
            echo json_encode(["success" => true, "data" => $settingsRow], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_invoice':
        case 'save_transaction':
            $data = !empty($jsonBody['invoice']) ? $jsonBody['invoice'] : (!empty($jsonBody['data']) ? $jsonBody['data'] : $jsonBody);
            if (empty($data['invoice_no']) && empty($data['invoiceNo'])) {
                echo json_encode(["success" => false, "message" => "Nomor invoice tidak boleh kosong"]);
                break;
            }

            $invoiceNo = $data['invoice_no'] ?? $data['invoiceNo'] ?? $data['noInvoice'];
            $rawDate = $data['date'] ?? $data['tanggal'] ?? date('Y-m-d');
            $date = normalizeDbDate($rawDate);
            $time = $data['time'] ?? $data['jam'] ?? date('H:i');
            $customer = $data['customer'] ?? $data['pelanggan'] ?? 'Umum';
            $cashier = $data['cashier'] ?? $data['kasir'] ?? 'Admin';
            $payMethod = $data['pay_method'] ?? $data['payMethod'] ?? $data['metodePembayaran'] ?? 'Tunai';
            $subtotal = floatval($data['subtotal'] ?? 0);
            $discPct = floatval($data['disc_pct'] ?? $data['discPct'] ?? 0);
            $discAmt = floatval($data['disc_amt'] ?? $data['discAmt'] ?? 0);
            $taxPct = floatval($data['tax_pct'] ?? $data['taxPct'] ?? 0);
            $taxAmt = floatval($data['tax_amt'] ?? $data['taxAmt'] ?? 0);
            $negoAmt = floatval($data['nego_amt'] ?? $data['negoAmt'] ?? 0);
            $total = floatval($data['total'] ?? 0);
            $dp = floatval($data['dp'] ?? 0);
            $sisa = floatval($data['sisa'] ?? 0);
            $kembalian = floatval($data['kembalian'] ?? 0);
            $deadline = $data['deadline'] ?? '';
            $status = $data['status'] ?? ($sisa > 0 ? 'BELUM LUNAS' : 'LUNAS');
            $items = [];
            if (!empty($data['items'])) {
                $items = is_array($data['items']) ? $data['items'] : (json_decode($data['items'], true) ?: []);
            }
            $itemsJson = json_encode($items, JSON_UNESCAPED_UNICODE);
            $histRaw = $data['histori_pelunasan_json'] ?? ($data['historiPelunasan'] ?? ($data['pelunasanHistory'] ?? ($data['histori_pelunasan'] ?? [])));
            $historiJson = (is_string($histRaw) && trim($histRaw) !== '')
                ? $histRaw
                : json_encode(is_array($histRaw) ? $histRaw : [], JSON_UNESCAPED_UNICODE);

            $checkStmt = $pdo->prepare("SELECT invoice_no FROM invoices WHERE invoice_no = :no");
            $checkStmt->execute([':no' => $invoiceNo]);
            $isNewInvoice = !$checkStmt->fetch();

            $sql = "INSERT INTO invoices (invoice_no, date, time, customer, cashier, pay_method, subtotal, disc_pct, disc_amt, tax_pct, tax_amt, nego_amt, total, dp, sisa, kembalian, deadline, status, items_json, histori_pelunasan_json)
                    VALUES (:invoice_no, :date, :time, :customer, :cashier, :pay_method, :subtotal, :disc_pct, :disc_amt, :tax_pct, :tax_amt, :nego_amt, :total, :dp, :sisa, :kembalian, :deadline, :status, :items_json, :histori_pelunasan_json)
                    ON DUPLICATE KEY UPDATE 
                    customer = VALUES(customer), cashier = VALUES(cashier), pay_method = VALUES(pay_method), subtotal = VALUES(subtotal),
                    disc_pct = VALUES(disc_pct), disc_amt = VALUES(disc_amt), tax_pct = VALUES(tax_pct), tax_amt = VALUES(tax_amt),
                    nego_amt = VALUES(nego_amt), total = VALUES(total), dp = VALUES(dp), sisa = VALUES(sisa), kembalian = VALUES(kembalian),
                    deadline = VALUES(deadline), status = VALUES(status), items_json = VALUES(items_json), histori_pelunasan_json = VALUES(histori_pelunasan_json)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':invoice_no' => $invoiceNo,
                ':date' => $date,
                ':time' => $time,
                ':customer' => $customer,
                ':cashier' => $cashier,
                ':pay_method' => $payMethod,
                ':subtotal' => $subtotal,
                ':disc_pct' => $discPct,
                ':disc_amt' => $discAmt,
                ':tax_pct' => $taxPct,
                ':tax_amt' => $taxAmt,
                ':nego_amt' => $negoAmt,
                ':total' => $total,
                ':dp' => $dp,
                ':sisa' => $sisa,
                ':kembalian' => $kembalian,
                ':deadline' => $deadline,
                ':status' => $status,
                ':items_json' => $itemsJson,
                ':histori_pelunasan_json' => $historiJson,
            ]);

            // Jika client mengirim updated_products, update stok langsung di MySQL
            $updatedProducts = !empty($jsonBody['updated_products']) ? $jsonBody['updated_products'] : (!empty($data['updated_products']) ? $data['updated_products'] : []);
            if (!empty($updatedProducts) && is_array($updatedProducts)) {
                $upStmt = $pdo->prepare("UPDATE products SET stok = :stok WHERE (kode = :kode OR nama = :nama) AND stok != ''");
                foreach ($updatedProducts as $up) {
                    $uKode = trim($up['kode'] ?? '');
                    $uNama = trim($up['nama'] ?? '');
                    $uStok = strval($up['stok'] ?? '');
                    if ($uStok !== '' && (!empty($uKode) || !empty($uNama))) {
                        $upStmt->execute([':stok' => $uStok, ':kode' => $uKode, ':nama' => $uNama]);
                    }
                }
            } else if ($isNewInvoice && !empty($items) && is_array($items)) {
                // Kurangi stok produk di MySQL hanya jika transaksi ini baru
                foreach ($items as $it) {
                    $qty = floatval($it['qty'] ?? 0);
                    $kode = trim($it['kode'] ?? '');
                    $nama = trim($it['nama'] ?? '');
                    if ($qty > 0) {
                        $deducted = false;
                        if (!empty($kode)) {
                            $deductStmt = $pdo->prepare("UPDATE products SET stok = GREATEST(0, CAST(stok AS DECIMAL(10,2)) - :qty) WHERE kode = :kode AND stok != ''");
                            $deductStmt->execute([':qty' => $qty, ':kode' => $kode]);
                            if ($deductStmt->rowCount() > 0) {
                                $deducted = true;
                            }
                        }
                        if (!$deducted && !empty($nama)) {
                            $deductStmt = $pdo->prepare("UPDATE products SET stok = GREATEST(0, CAST(stok AS DECIMAL(10,2)) - :qty) WHERE nama = :nama AND stok != ''");
                            $deductStmt->execute([':qty' => $qty, ':nama' => $nama]);
                            if ($deductStmt->rowCount() == 0) {
                                $deductStmt = $pdo->prepare("UPDATE products SET stok = GREATEST(0, CAST(stok AS DECIMAL(10,2)) - :qty) WHERE :nama LIKE CONCAT(nama, '%') AND stok != '' LIMIT 1");
                                $deductStmt->execute([':qty' => $qty, ':nama' => $nama]);
                            }
                        }
                    }
                }
            }

            echo json_encode(["success" => true, "message" => "Transaksi $invoiceNo berhasil disimpan ke MySQL", "invoiceNo" => $invoiceNo], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_product':
            $p = !empty($jsonBody['product']) ? $jsonBody['product'] : $jsonBody;
            $kode = $p['kode'] ?? '';
            $nama = $p['nama'] ?? '';
            if (empty($kode) || empty($nama)) {
                echo json_encode(["success" => false, "message" => "Kode dan nama produk wajib diisi"]);
                break;
            }
            $stmt = $pdo->prepare("INSERT INTO products (kode, nama, harga, kategori, stok, satuan, tipe_harga, harga_jual_modal, supplier, pricing_scheme_json)
                VALUES (:kode, :nama, :harga, :kategori, :stok, :satuan, :tipe_harga, :harga_jual_modal, :supplier, :pricing_scheme_json)
                ON DUPLICATE KEY UPDATE 
                nama = VALUES(nama), harga = VALUES(harga), kategori = VALUES(kategori), stok = VALUES(stok), satuan = VALUES(satuan),
                tipe_harga = VALUES(tipe_harga), harga_jual_modal = VALUES(harga_jual_modal), supplier = VALUES(supplier), pricing_scheme_json = VALUES(pricing_scheme_json)");
            $stmt->execute([
                ':kode' => $kode,
                ':nama' => $nama,
                ':harga' => floatval($p['harga'] ?? 0),
                ':kategori' => $p['kategori'] ?? 'Umum',
                ':stok' => (string)($p['stok'] ?? ''),
                ':satuan' => $p['satuan'] ?? 'pcs',
                ':tipe_harga' => $p['tipeHarga'] ?? $p['tipe_harga'] ?? 'fix',
                ':harga_jual_modal' => floatval($p['hargaJualModal'] ?? $p['harga_jual_modal'] ?? 0),
                ':supplier' => $p['supplier'] ?? '',
                ':pricing_scheme_json' => (isset($p['pricingScheme']) && is_string($p['pricingScheme']) && trim($p['pricingScheme']) !== '') ? $p['pricingScheme'] : json_encode($p['pricingScheme'] ?? null, JSON_UNESCAPED_UNICODE),
            ]);
            echo json_encode(["success" => true, "message" => "Produk $kode berhasil disimpan ke database"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_customer':
            $c = !empty($jsonBody['customer']) ? $jsonBody['customer'] : $jsonBody;
            $nama = $c['nama'] ?? '';
            if (empty($nama)) {
                echo json_encode(["success" => false, "message" => "Nama pelanggan wajib diisi"]);
                break;
            }
            $stmt = $pdo->prepare("INSERT INTO customers (nama, kelas, diskon, telepon, alamat, catatan)
                VALUES (:nama, :kelas, :diskon, :telepon, :alamat, :catatan)
                ON DUPLICATE KEY UPDATE 
                kelas = VALUES(kelas), diskon = VALUES(diskon), telepon = VALUES(telepon), alamat = VALUES(alamat), catatan = VALUES(catatan)");
            $stmt->execute([
                ':nama' => $nama,
                ':kelas' => $c['kelas'] ?? 'Reguler',
                ':diskon' => floatval($c['diskon'] ?? 0),
                ':telepon' => $c['telepon'] ?? '',
                ':alamat' => $c['alamat'] ?? '',
                ':catatan' => $c['catatan'] ?? '',
            ]);
            echo json_encode(["success" => true, "message" => "Pelanggan $nama berhasil disimpan"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_expense':
            $e = !empty($jsonBody['expense']) ? $jsonBody['expense'] : $jsonBody;
            $id = $e['id'] ?? ('EXP-' . date('YmdHis'));
            $stmt = $pdo->prepare("INSERT INTO expenses (id, tanggal, kategori, keterangan, nominal, pj)
                VALUES (:id, :tanggal, :kategori, :keterangan, :nominal, :pj)
                ON DUPLICATE KEY UPDATE 
                tanggal = VALUES(tanggal), kategori = VALUES(kategori), keterangan = VALUES(keterangan), nominal = VALUES(nominal), pj = VALUES(pj)");
            $stmt->execute([
                ':id' => $id,
                ':tanggal' => normalizeDbDate($e['tanggal'] ?? date('Y-m-d')),
                ':kategori' => $e['kategori'] ?? 'Beban Operasional',
                ':keterangan' => $e['keterangan'] ?? '',
                ':nominal' => floatval($e['nominal'] ?? 0),
                ':pj' => $e['pj'] ?? 'Admin',
            ]);
            echo json_encode(["success" => true, "message" => "Pengeluaran $id berhasil dicatat"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_settings':
            $s = !empty($jsonBody['settings']) ? $jsonBody['settings'] : $jsonBody;
            $name = $s['name'] ?? 'ERVO PRINT';
            $stmt = $pdo->prepare("INSERT INTO settings (id, name, address, phone, footer, rekening, prefix_invoice, auto_logout_minutes)
                VALUES (1, :name, :address, :phone, :footer, :rekening, :prefix_invoice, :auto_logout_minutes)
                ON DUPLICATE KEY UPDATE 
                name = VALUES(name), address = VALUES(address), phone = VALUES(phone), footer = VALUES(footer),
                rekening = VALUES(rekening), prefix_invoice = VALUES(prefix_invoice), auto_logout_minutes = VALUES(auto_logout_minutes)");
            $stmt->execute([
                ':name' => $name,
                ':address' => $s['address'] ?? '',
                ':phone' => $s['phone'] ?? '',
                ':footer' => $s['footer'] ?? '',
                ':rekening' => $s['rekening'] ?? '',
                ':prefix_invoice' => $s['prefixInvoice'] ?? $s['prefix_invoice'] ?? 'INV-',
                ':auto_logout_minutes' => intval($s['autoLogoutMinutes'] ?? $s['auto_logout_minutes'] ?? 15),
            ]);
            echo json_encode(["success" => true, "message" => "Pengaturan toko berhasil diperbarui"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_invoice':
            $no = $_GET['invoice_no'] ?? $jsonBody['invoice_no'] ?? $jsonBody['invoiceNo'] ?? '';
            if (!empty($no)) {
                // 1. Ambil data invoice sebelum dihapus untuk mengembalikan stok barang
                $itemsToRestore = [];
                if (!empty($jsonBody['items']) && is_array($jsonBody['items'])) {
                    $itemsToRestore = $jsonBody['items'];
                } else {
                    $invStmt = $pdo->prepare("SELECT items_json FROM invoices WHERE invoice_no = :no");
                    $invStmt->execute([':no' => $no]);
                    $invData = $invStmt->fetch();
                    if ($invData && !empty($invData['items_json'])) {
                        $decoded = json_decode($invData['items_json'], true);
                        if (is_array($decoded)) {
                            $itemsToRestore = $decoded;
                        }
                    }
                }

                // 2. Kembalikan stok untuk setiap item di invoice
                if (!empty($itemsToRestore)) {
                    foreach ($itemsToRestore as $it) {
                        $qty = floatval($it['qty'] ?? 0);
                        $kode = trim($it['kode'] ?? '');
                        $nama = trim($it['nama'] ?? '');
                        if ($qty > 0 && (!empty($kode) || !empty($nama))) {
                            if (!empty($kode)) {
                                $restoreStmt = $pdo->prepare("UPDATE products SET stok = CAST(stok AS DECIMAL(10,2)) + :qty WHERE kode = :kode AND stok != ''");
                                $restoreStmt->execute([':qty' => $qty, ':kode' => $kode]);
                            } else {
                                $restoreStmt = $pdo->prepare("UPDATE products SET stok = CAST(stok AS DECIMAL(10,2)) + :qty WHERE nama = :nama AND stok != ''");
                                $restoreStmt->execute([':qty' => $qty, ':nama' => $nama]);
                            }
                        }
                    }
                }

                // 3. Hapus invoice dari tabel
                $stmt = $pdo->prepare("DELETE FROM invoices WHERE invoice_no = :no");
                $stmt->execute([':no' => $no]);
                $stmtLog = $pdo->prepare("INSERT INTO deletedInvoices (invoice_no, deleted_by, reason) VALUES (:no, :by, :reason) ON DUPLICATE KEY UPDATE deleted_at = CURRENT_TIMESTAMP");
                $stmtLog->execute([
                    ':no' => $no,
                    ':by' => $jsonBody['deleted_by'] ?? $jsonBody['authorizer'] ?? 'Admin',
                    ':reason' => $jsonBody['reason'] ?? 'Dihapus kasir/laporan'
                ]);
            }
            echo json_encode(["success" => true, "message" => "Invoice $no berhasil dihapus dan stok barang telah dikembalikan"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_product':
            $target = $_GET['kode'] ?? $jsonBody['kode'] ?? $jsonBody['target'] ?? '';
            if (!empty($target)) {
                $stmt = $pdo->prepare("DELETE FROM products WHERE kode = :target OR nama = :target");
                $stmt->execute([':target' => $target]);
                $stmtLog = $pdo->prepare("INSERT INTO deletedProducts (kode_or_nama) VALUES (:target)");
                $stmtLog->execute([':target' => $target]);
            }
            echo json_encode(["success" => true, "message" => "Produk $target berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_customer':
            $nama = $_GET['nama'] ?? $jsonBody['nama'] ?? '';
            if (!empty($nama)) {
                $stmt = $pdo->prepare("DELETE FROM customers WHERE nama = :nama");
                $stmt->execute([':nama' => $nama]);
                $stmtLog = $pdo->prepare("INSERT INTO deletedCustomers (nama) VALUES (:nama)");
                $stmtLog->execute([':nama' => $nama]);
            }
            echo json_encode(["success" => true, "message" => "Pelanggan $nama berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_expense':
            $id = $_GET['id'] ?? $jsonBody['id'] ?? '';
            if (!empty($id)) {
                $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = :id");
                $stmt->execute([':id' => $id]);
            }
            echo json_encode(["success" => true, "message" => "Pengeluaran $id berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_stock_in':
            $s = !empty($jsonBody['stockIn']) ? $jsonBody['stockIn'] : (!empty($jsonBody['data']) ? $jsonBody['data'] : $jsonBody);
            $id = $s['id'] ?? ('SI-' . date('YmdHis'));
            $qty = floatval($s['qty'] ?? $s['jumlahMasuk'] ?? 0);

            // Cek apakah data barang masuk ini sudah pernah diproses sebelumnya (mencegah penambahan stok ganda)
            $checkStmt = $pdo->prepare("SELECT id FROM stockIn WHERE id = :id");
            $checkStmt->execute([':id' => $id]);
            $isNewStockIn = ($checkStmt->fetchColumn() === false);

            $stmt = $pdo->prepare("INSERT INTO stockIn (id, tanggal, time, kode_produk, nama_produk, jumlah, satuan, harga_beli, total_biaya, supplier, no_po, gudang, catatan, cashier)
                VALUES (:id, :tanggal, :time, :kode_produk, :nama_produk, :jumlah, :satuan, :harga_beli, :total_biaya, :supplier, :no_po, :gudang, :catatan, :cashier)
                ON DUPLICATE KEY UPDATE 
                nama_produk = VALUES(nama_produk), jumlah = VALUES(jumlah), harga_beli = VALUES(harga_beli), total_biaya = VALUES(total_biaya)");
            $stmt->execute([
                ':id' => $id,
                ':tanggal' => normalizeDbDate($s['date'] ?? $s['tanggal'] ?? date('Y-m-d')),
                ':time' => $s['time'] ?? date('H:i'),
                ':kode_produk' => $s['kode'] ?? '',
                ':nama_produk' => $s['nama'] ?? '',
                ':jumlah' => $qty,
                ':satuan' => $s['satuan'] ?? 'pcs',
                ':harga_beli' => floatval($s['hargaBeli'] ?? 0),
                ':total_biaya' => floatval($s['totalBiaya'] ?? 0),
                ':supplier' => $s['supplier'] ?? '',
                ':no_po' => $s['noPo'] ?? '',
                ':gudang' => $s['gudang'] ?? 'Gudang Utama',
                ':catatan' => $s['catatan'] ?? '',
                ':cashier' => $s['cashier'] ?? 'Admin',
            ]);

            $allowStockUpdate = (!isset($s['updateProductStock']) || $s['updateProductStock'] !== false) &&
                                (!isset($jsonBody['updateProductStock']) || $jsonBody['updateProductStock'] !== false);

            // Hanya tambah stok jika data ini baru dan updateProductStock diizinkan
            if ($isNewStockIn && $allowStockUpdate && $qty > 0 && !empty($s['kode'])) {
                $addStmt = $pdo->prepare("UPDATE products SET stok = CAST(stok AS DECIMAL(10,2)) + :qty WHERE kode = :kode AND stok != ''");
                $addStmt->execute([':qty' => $qty, ':kode' => $s['kode']]);
            }
            echo json_encode(["success" => true, "message" => "Barang masuk $id berhasil disimpan"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_stock_in':
            $id = $_GET['id'] ?? $jsonBody['id'] ?? '';
            $rollback = $jsonBody['rollback'] ?? null;
            if (!empty($id)) {
                if (!empty($rollback) && !empty($rollback['kode']) && floatval($rollback['qty'] ?? 0) > 0) {
                    $rbQty = floatval($rollback['qty']);
                    $rbStmt = $pdo->prepare("UPDATE products SET stok = GREATEST(0, CAST(stok AS DECIMAL(10,2)) - :qty) WHERE kode = :kode AND stok != ''");
                    $rbStmt->execute([':qty' => $rbQty, ':kode' => $rollback['kode']]);
                }
                $stmt = $pdo->prepare("DELETE FROM stockIn WHERE id = :id");
                $stmt->execute([':id' => $id]);
            }
            echo json_encode(["success" => true, "message" => "Barang masuk $id berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_vendor':
            $v = !empty($jsonBody['vendor']) ? $jsonBody['vendor'] : (!empty($jsonBody['data']) ? $jsonBody['data'] : $jsonBody);
            $id = $v['id'] ?? ('VEN-' . date('YmdHis'));
            $stmt = $pdo->prepare("INSERT INTO vendors (id, nama, kategori, telepon, email, alamat, kontak_person, nomor_rekening, catatan, created_at)
                VALUES (:id, :nama, :kategori, :telepon, :email, :alamat, :kontak_person, :nomor_rekening, :catatan, :created_at)
                ON DUPLICATE KEY UPDATE 
                nama = VALUES(nama), kategori = VALUES(kategori), telepon = VALUES(telepon), email = VALUES(email), alamat = VALUES(alamat), kontak_person = VALUES(kontak_person), nomor_rekening = VALUES(nomor_rekening), catatan = VALUES(catatan)");
            $stmt->execute([
                ':id' => $id,
                ':nama' => $v['nama'] ?? '',
                ':kategori' => $v['kategori'] ?? 'Umum',
                ':telepon' => $v['telepon'] ?? '',
                ':email' => $v['email'] ?? '',
                ':alamat' => $v['alamat'] ?? '',
                ':kontak_person' => $v['kontakPerson'] ?? '',
                ':nomor_rekening' => $v['nomorRekening'] ?? '',
                ':catatan' => $v['catatan'] ?? '',
                ':created_at' => $v['createdAt'] ?? date('Y-m-d'),
            ]);
            echo json_encode(["success" => true, "message" => "Vendor berhasil disimpan"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_vendor':
            $id = $_GET['id'] ?? $jsonBody['id'] ?? '';
            if (!empty($id)) {
                $stmt = $pdo->prepare("DELETE FROM vendors WHERE id = :id");
                $stmt->execute([':id' => $id]);
            }
            echo json_encode(["success" => true, "message" => "Vendor berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'save_kasir_user':
            $u = !empty($jsonBody['user']) ? $jsonBody['user'] : $jsonBody;
            $nama = $u['nama'] ?? '';
            if (!empty($nama)) {
                $stmt = $pdo->prepare("INSERT INTO kasirUsers (nama, role, password, aktif)
                    VALUES (:nama, :role, :password, 1)
                    ON DUPLICATE KEY UPDATE role = VALUES(role), password = VALUES(password)");
                $stmt->execute([
                    ':nama' => $nama,
                    ':role' => $u['role'] ?? 'Kasir',
                    ':password' => $u['password'] ?? 'ervo123',
                ]);
            }
            echo json_encode(["success" => true, "message" => "Kasir $nama berhasil disimpan"], JSON_UNESCAPED_UNICODE);
            break;

        case 'delete_kasir_user':
            $nama = $_GET['nama'] ?? $jsonBody['nama'] ?? '';
            if (!empty($nama)) {
                $stmt = $pdo->prepare("DELETE FROM kasirUsers WHERE nama = :nama");
                $stmt->execute([':nama' => $nama]);
            }
            echo json_encode(["success" => true, "message" => "Kasir $nama berhasil dihapus"], JSON_UNESCAPED_UNICODE);
            break;

        case 'truncate_all_data':
        case 'reset_database':
            $tablesToTruncate = [
                'products', 'customers', 'invoices', 'expenses', 'stockIn', 
                'stockOpname', 'vendors', 'deletedInvoices', 'deletedProducts', 
                'deletedCustomers', 'deletedExpenses', '_stockin_delete_log', 
                '_invoice_restore_log', 'backupCheckpoints', 'businessTransactions'
            ];
            foreach ($tablesToTruncate as $tbl) {
                try {
                    $pdo->exec("DELETE FROM `$tbl`");
                } catch (Exception $e) {}
            }
            echo json_encode(["success" => true, "message" => "Seluruh tabel data transaksi dan master berhasil dikosongkan bersih di database"], JSON_UNESCAPED_UNICODE);
            break;

        default:
            echo json_encode([
                "success" => false,
                "message" => "Action '$action' tidak dikenali."
            ], JSON_UNESCAPED_UNICODE);
            break;
    }
} catch (Exception $err) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Terjadi kesalahan pada server API: " . $err->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
